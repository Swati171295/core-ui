package com.prospecta.mdo.module.dto.elastic;

import java.io.Serializable;
import java.util.LinkedHashMap;

import lombok.Data;

@Data
public class MaterialAttributesES implements Serializable{

	private static final long serialVersionUID = -1070271554150647898L;
	private String nounCode;
	private String modeCode;
	/***
	* The list of fields and values for the attributes combination
	*/
	private LinkedHashMap<String,LinkedHashMap<String, FieldValue>> attributes;
}
