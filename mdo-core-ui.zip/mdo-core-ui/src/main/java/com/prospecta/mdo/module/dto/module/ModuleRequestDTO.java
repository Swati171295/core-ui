/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import com.prospecta.mdo.module.enums.ModuleType;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author savan
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModuleRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -844608141086805861L;

	@ApiModelProperty(
			name = "moduledescription",
			value = "Map representing moduledescription",
			dataType = "Object",
			required = true
	)
	@NotEmpty(message = "moduledescription must not be empty")
	@NotNull(message = "moduledescription must not be null")
	private Map<String , ModuleDescriptionInformationRequestDTO> moduledescription;

	@ApiModelProperty(
			name = "usermodified",
			value = "String representing usermodified",
			dataType = "java.lang.String",
			required = true
	)
	@NotEmpty(message = "usermodified must not be empty")
	private String usermodified;

	@ApiModelProperty(
			name = "displayCriteria",
			value = "String representing displayCriteria",
			dataType = "java.lang.String",
			required = true
	)
	@NotEmpty(message = "display_criteria must not be empty")
	private String displayCriteria;

	@ApiModelProperty(
			name = "fields",
			value = "List representing fieldRequest"
	)
	@Valid
	private List<FieldsRequestDTO> fields;

	@ApiModelProperty(
			name = "industry",
			value = "String representing industry",
			dataType = "java.lang.String"
	)
	private String industry;

	@ApiModelProperty(
			name = "isSingleRecord",
			value = "isSingleRecord",
			dataType = "java.lang.Boolean"
	)
	private Boolean isSingleRecord;

	@ApiModelProperty(
			name = "systemType",
			value = "String representing systemType",
			required = true,
			dataType = "java.lang.String"
	)
	@NotEmpty(message = "system_type must not be empty")
	private String systemType;

	@ApiModelProperty(
			name = "owner",
			value = "Short representing owner",
			dataType = "java.lang.Short"
	)
	private Short owner;

	@ApiModelProperty(
			name = "dataType",
			value = "Short representing dataType",
			dataType = "java.lang.Short"
	)
	private Short dataType;

	@ApiModelProperty(
			name = "persistent",
			value = "Short representing persistent",
			dataType = "java.lang.Short"
	)
	private Short persistent;

	@ApiModelProperty(
			name = "dataPrivacy",
			value = "Short representing dataPrivacy",
			dataType = "java.lang.Short"
	)
	private Short dataPrivacy;

	@ApiModelProperty(
			name = "parentModuleIds",
			value = "List representing parentModuleIds",
			dataType = "java.util.List"
	)
	private List<Long> parentModuleIds;

	@ApiModelProperty(
			name = "type",
			value = "Type Of DataSet",
			dataType = "com.prospecta.mdo.module.enums.ModuleType"
	)
	private ModuleType type;

}
