package com.prospecta.mdo.module.dto.tab;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.prospecta.mdo.module.enums.FieldType;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@NoArgsConstructor
public class TabFieldDetailsDTO {

    @JsonIgnore
    private UUID tabUuid;
    @JsonIgnore
    private String tabDescription;
    private String fieldId;
    private String fieldDescription;
    private String description;
    private FieldType type;
    private String pickList;
    private String dataType;

    public TabFieldDetailsDTO(UUID tabUuid, String tabDescription, String fieldId, String fieldDescription,
                              String description, FieldType type) {
        this.tabUuid = tabUuid;
        this.tabDescription = tabDescription;
        this.fieldId = fieldId;
        this.fieldDescription = fieldDescription;
        this.description = description;
        this.type = type;
    }

    public TabFieldDetailsDTO(String fieldId, String fieldDescription,FieldType type) {

        this.fieldId = fieldId;
        this.fieldDescription = fieldDescription;
        this.type = type;
    }
}
