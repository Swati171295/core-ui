/**
 * 
 */
package com.prospecta.mdo.module.dto.layout;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LayoutTabResponseDTO {
	
	private String layoutTabId;

	private boolean acknowledge;

	private String errorMsg;

}
