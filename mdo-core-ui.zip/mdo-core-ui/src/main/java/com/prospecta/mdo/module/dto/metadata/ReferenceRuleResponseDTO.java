/**
 * 
 */
package com.prospecta.mdo.module.dto.metadata;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.prospecta.mdo.module.dto.module.ModuleResponseDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ReferenceRuleResponseDTO extends ModuleResponseDTO {
	
	private String reference_uuid;
}
