package com.prospecta.mdo.module.dto.virtualdata;

import lombok.Data;

@Data
public class DeleteUdrResponse {

	private boolean acknowledge;

	private String errorMsg;
	
	private Object response;

}
