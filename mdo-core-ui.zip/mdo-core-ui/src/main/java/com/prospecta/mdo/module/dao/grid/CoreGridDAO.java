package com.prospecta.mdo.module.dao.grid;

import com.prospecta.mdo.module.model.grid.CoreGridSettingModel;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

import static com.prospecta.mdo.module.util.QueryConstants.GET_GRID_SEQUENCE_FIELDS;
import static com.prospecta.mdo.module.util.QueryConstants.GET_GRID_SORT_FIELDS;

public interface CoreGridDAO extends PagingAndSortingRepository<CoreGridSettingModel, String> {

    Optional<List<CoreGridSettingModel>> findByGridFieldIdAndModuleIdAndTenantId(String gridFieldId, Long moduleId, String tenantId);

    Optional<CoreGridSettingModel> findByGridFieldIdAndFieldIdAndModuleIdAndTenantId(String gridFieldId, String field,Long moduleId, String tenantId);

    @Query(GET_GRID_SORT_FIELDS)
    List<CoreGridSettingModel> findSortableFields(@Param("id") String id, @Param ("search") String search,
                                                  @Param ("moduleId") Long moduleId, @Param ("tenantId") String tenantId,
                                                  @Param ("lang") String lang, @Param("sort") boolean sort, Pageable pageable);

    @Query(GET_GRID_SEQUENCE_FIELDS)
    List<CoreGridSettingModel> findSequenceFields(@Param ("id") String id, @Param ("search") String search,
                                                  @Param ("moduleId") Long moduleId, @Param ("tenantId") String tenantId,
                                                  @Param ("lang") String lang,@Param("sequence") boolean sequence, Pageable pageable);

}
