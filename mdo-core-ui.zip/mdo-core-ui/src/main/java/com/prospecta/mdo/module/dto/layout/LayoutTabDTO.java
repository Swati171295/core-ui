/**
 * 
 */
package com.prospecta.mdo.module.dto.layout;

import com.prospecta.mdo.module.model.layout.CoreLayoutTabModel;
import com.prospecta.mdo.module.model.tab.CoreTabLabelsModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

import static org.springframework.beans.BeanUtils.copyProperties;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LayoutTabDTO {

	@ApiModelProperty(
			name = "tabid",
			value = "id of Tab",
			dataType = "java.lang.String"

	)
	private String tabid;

	@ApiModelProperty(
			name = "description",
			value = "Description of Tab",
			dataType = "java.lang.String"

	)
	private String description;

	@ApiModelProperty(
			name = "tabOrder",
			value = "Order of Tab",
			dataType = "java.lang.Short"

	)
	private Short tabOrder;

	@ApiModelProperty(
			name = "isTabReadOnly",
			value = "Is Tab Read Only, Default value is false.",
			dataType = "java.lang.Boolean"
	)
	private Boolean isTabReadOnly = false;

	@ApiModelProperty(
			name = "isTabHidden",
			value = "Is Tab Hidden, Default value is false.",
			dataType = "java.lang.Boolean"
	)
	private Boolean isTabHidden=false;

	@ApiModelProperty(
			name = "udrId",
			value = "UDR ID",
			dataType = "java.util.UUID"
	)
	private UUID udrId;

	public LayoutTabDTO(CoreLayoutTabModel model, CoreTabLabelsModel labelsModel) {
		copyProperties(model,this);
		this.tabid = model.getTcode().toString();
		this.description = labelsModel.getTabText();

	}
	public LayoutTabDTO(FetchedLayoutDTO dto) {
		copyProperties(dto,this);
		this.tabid = dto.getTcode().toString();
	}
}
