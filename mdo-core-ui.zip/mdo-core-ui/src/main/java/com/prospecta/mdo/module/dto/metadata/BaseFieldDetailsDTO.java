/**
 * 
 */
package com.prospecta.mdo.module.dto.metadata;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BaseFieldDetailsDTO {
	
	private String description;
	
	private String dataType;
	
	private String pickList;
	
	private Long maxChar;
	
	private Short structureId;
	
}
