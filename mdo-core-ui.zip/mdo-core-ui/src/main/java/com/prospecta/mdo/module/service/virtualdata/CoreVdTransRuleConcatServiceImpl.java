package com.prospecta.mdo.module.service.virtualdata;

import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdTransFieldSettingDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdTransRuleConcatDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdTransRuleConcatRequestDTO;
import com.prospecta.mdo.module.enums.ConcatFieldType;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransRuleConcatModel;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class CoreVdTransRuleConcatServiceImpl implements CoreVdTransRuleConcatService {

	@Autowired
	private CoreVdTransRuleConcatDAO coreVdTransRuleConcatDAO;
	
	@Autowired
	private CoreVdTransFieldSettingDAO coreVdTransFieldSettingDAO;

	String message = "Virtual dataset header not found";
	/**
     * This method is used to get the virtual dataset transformation rule by vd concat id .
     * @param vdConcatId
     */
	@Override
	public CoreVdTransRuleConcatModel getVdTransRuleConcatbyConcatId(UUID vdConcatId) {
		StopWatch watch = new StopWatch();
		watch.start("Get Core vd Group Information");
		Optional<CoreVdTransRuleConcatModel> coreVdTransRuleConcatModel=coreVdTransRuleConcatDAO.findById(vdConcatId);
		if (!coreVdTransRuleConcatModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdTransRuleConcatModel.get();
	}
	
	/**
     * This method is used to get the virtual dataset transformation rule concat by trans field id .
     * @param transFieldId
     */
	@Override
	public List<CoreVdTransRuleConcatModel> getVdTransRuleConcatbytransFieldId(UUID transFieldId) {
		StopWatch watch = new StopWatch();
		watch.start("Get List of Core vd Group Information");
		Optional<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModel=coreVdTransFieldSettingDAO.findById(transFieldId);
		if (!coreVdTransFieldSettingModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		List<CoreVdTransRuleConcatModel> coreVdTransRuleConcatModel=coreVdTransRuleConcatDAO.findByCoreVdTransFieldSetting(coreVdTransFieldSettingModel.get());
		if (coreVdTransRuleConcatModel.isEmpty()) {
			throw new NotFound404Exception("Virtual dataset group not found");
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdTransRuleConcatModel;
	}
	
	/**
     * This method is used to delete the virtual dataset transformation rule by vd concat id .
     * @param vdConcatId
     */
	@Override
	public void deleteVdTransRuleConcatbyConcatId(UUID vdConcatId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Information");
		watch.start("Delete vd groups");
		coreVdTransRuleConcatDAO.deleteById(vdConcatId);
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to delete the virtual dataset transformation rule by transformation field id .
     * @param transFieldId
     */
	@Override
	public void deleteVdTransRuleConcatbytransFieldId(UUID transFieldId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Information by virtual dataset Started");
		watch.start("Delete vd groups");
		Optional<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModel=coreVdTransFieldSettingDAO.findById(transFieldId);
		if (!coreVdTransFieldSettingModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		coreVdTransRuleConcatDAO.deleteByCoreVdTransFieldSetting(coreVdTransFieldSettingModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to save/update the virtual dataset transformation rule by trans field id .
     * @param transRuleConcatRequestDTO
     * @param coreVdTransFieldSetting
     */
	@Override
	public CoreVdTransRuleConcatModel saveAndUpdateRuleConcat(VdTransRuleConcatRequestDTO transRuleConcatRequestDTO, CoreVdTransFieldSettingModel coreVdTransFieldSetting) {
		if (transRuleConcatRequestDTO != null) {
			if (coreVdTransFieldSetting != null) {
				StopWatch watch = new StopWatch();
				CoreVdTransRuleConcatModel coreVdTransRuleConcatModel = new CoreVdTransRuleConcatModel();
				try {
					log.info("Store virtal dataset transformation rule concat started");
					watch.start("Store virtal dataset transformation rule concat");

					copyProperties(transRuleConcatRequestDTO, coreVdTransRuleConcatModel);
					if (transRuleConcatRequestDTO.getVdConcatId() == null) {
						coreVdTransRuleConcatModel.setVdConcatId(UUID.randomUUID());
					}
					coreVdTransRuleConcatModel.setCoreVdTransFieldSetting(coreVdTransFieldSetting);
					coreVdTransRuleConcatModel.setFieldType(
							ConcatFieldType.fromValue(transRuleConcatRequestDTO.getFieldType().toUpperCase()));
					coreVdTransRuleConcatModel = coreVdTransRuleConcatDAO.save(coreVdTransRuleConcatModel);
					watch.stop();
				} catch (Exception e) {
					log.error("error while store virtal dataset transformation rule concat: " + e.getMessage());
					throw new CommonVirtualDatasetException(e.getMessage());
				}
				log.info(watch.prettyPrint());
				return coreVdTransRuleConcatModel;
			} else {
				throw new NotFound404Exception("Virtual transformation field setting data is not present while storing transformation rule concat information.");
			}
		} else {
			throw new NotFound404Exception("Virtual data rule concat is not present while storing it.");
		}	
	}

	/**
     * This method is used to delete the virtual dataset transformation rule concat.
     * @param transConcatDetail
     * @param transId
     */
	@Override
	public void deleteVdTransRuleConcat(List<VdTransRuleConcatRequestDTO> transConcatDetail, UUID transId) {
		StopWatch watch = new StopWatch();
		try {
			watch.start("Delete vd transformation rule concat information");
			log.info("Fetch the all transformation rule concat information with transId and compare with new data");
			Optional<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModel = coreVdTransFieldSettingDAO
					.findById(transId);
			if (!coreVdTransFieldSettingModel.isPresent()) {
				log.error("Virtual transformation field setting information not found");
				throw new NotFound404Exception("Virtual transformation field setting information not found");
			}
			List<UUID> newVdConcatId = transConcatDetail.stream().filter(g -> g.getVdConcatId() != null)
					.map(VdTransRuleConcatRequestDTO::getVdConcatId).collect(Collectors.toList());
			List<UUID> vdConcatId = coreVdTransRuleConcatDAO
					.findByCoreVdTransFieldSetting(coreVdTransFieldSettingModel.get()).stream()
					.filter(grp -> !newVdConcatId.contains(grp.getVdConcatId()))
					.map(CoreVdTransRuleConcatModel::getVdConcatId).collect(Collectors.toList());
			log.info("Delete all transformation rule concat information data if user deleted any");
			coreVdTransRuleConcatDAO.deleteByVdConcatIdIn(vdConcatId);
			watch.stop();
			log.info(watch.prettyPrint());
		} catch (Exception e) {
			log.error("error while Delete vd transformation rule concat information: " + e.getMessage());
			throw new CommonVirtualDatasetException(e.getMessage());
		}
	}
}