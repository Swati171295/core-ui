package com.prospecta.mdo.module.dto.grid;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.UUID;

@Data
public class SequenceSettingRequestDTO implements Serializable {

    public static final String[] IGNORABLE_UPDATE_FIELDS = {"moduleId", "tenantId", "gridSettingUuid"};

    @ApiModelProperty(
            name = "gridSettingUuid",
            value = "Grid Setting UUID references grid setting table",
            dataType = "java.util.UUID"
    )
    @NotNull(message = "Grid Setting Uuid must not be null")
    private UUID gridSettingUuid;

    @ApiModelProperty(
            name = "sequenceStart",
            value = "Depicts Starting value of the Sequence",
            dataType = "java.lang.Long"
    )
    private Long sequenceStart;

    @ApiModelProperty(
            name = "sequenceInterval",
            value = "Depicts Interval of the Sequence",
            dataType = "java.lang.Integer"
    )
    private Integer sequenceInterval;
}
