package com.prospecta.mdo.module.grpc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.util.JsonFormat;
import com.prospecta.mdo.module.dto.metadata.CreateFieldRequestDTO;
import com.prospecta.mdo.module.enums.Grpc;
import demo.interfaces.grpc.*;
import demo.interfaces.grpc.DynamicGenerationServiceGrpc.DynamicGenerationServiceBlockingStub;
import io.grpc.ManagedChannel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.prospecta.mdo.module.util.Constants.DEADLINE_TIME;

@Service
@Slf4j
public class DynamicCrudGenerationImpl {


    @Value("${grpc.crud.address.url:0.0.0.0}")
    private String addressName;
    @Value("${grpc.crud.address.port:10008}")
    private int addressPort;

    private ManagedChannel channel;

    public void setChannel(ManagedChannel c) {
        this.channel=c;
    }

    public boolean generateDynamicTables(Long moduleId, String tenantId, CreateFieldRequestDTO requestDTO) {
        log.info("DynamicGenerationImpl ------ generateDynamicTables started");
        try {
            setManagedChannel();
            DynamicGenerationServiceBlockingStub dynamicStub = DynamicGenerationServiceGrpc
                    .newBlockingStub(channel);

            DynamicTableGenerateRequest request = getDynamicTableGenerateRequest(tenantId, moduleId, requestDTO);
            log.info("DynamicGenerationImpl ------  generateDynamicTables ended");
            return dynamicStub.withDeadlineAfter(DEADLINE_TIME, TimeUnit.SECONDS).generateDynamicTable(request).getResponse();

        } catch (Exception e) {
            log.error("Error {}", e.getMessage());
        }

        return false;
    }


    public boolean alterColumns(Long moduleId, String tenantId, CreateFieldRequestDTO requestDTO) {
        log.info("DynamicGenerationImpl ------ alterColumns started");
        try {

            setManagedChannel();
            DynamicGenerationServiceBlockingStub dynamicStub = DynamicGenerationServiceGrpc
                    .newBlockingStub(channel);

            DynamicTableGenerateRequest request = getDynamicTableGenerateRequest(tenantId, moduleId, requestDTO);
            log.info("DynamicGenerationImpl ------  alterColumns ended");
            return dynamicStub.withDeadlineAfter(DEADLINE_TIME, TimeUnit.SECONDS).alterColumns(request).getResponse();
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return false;
    }

    public boolean createUpdateDynamicIndex(Long moduleId, String tenantId, CreateFieldRequestDTO requestDTO) {
        log.info("DynamicGenerationImpl ------ createUpdateDynamicIndex started");
        try {
            setManagedChannel();
            DynamicGenerationServiceBlockingStub dynamicStub = DynamicGenerationServiceGrpc
                    .newBlockingStub(channel);

            DynamicTableGenerateRequest request = getDynamicTableGenerateRequest(tenantId, moduleId, requestDTO);
            log.info("DynamicGenerationImpl ------ createUpdateDynamicIndex ended");
            return dynamicStub.withDeadlineAfter(DEADLINE_TIME, TimeUnit.SECONDS).generateDynamicIndex(request).getResponse();
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return false;
    }

    public boolean deleteTable(List<String> structureIds, List<String> gridFields, Long moduleId, String tenantId) {
        log.info("DynamicGenerationImpl ------ Delete Table Index started");
        try {
            setManagedChannel();
            DynamicGenerationServiceBlockingStub dynamicStub = DynamicGenerationServiceGrpc
                    .newBlockingStub(channel);

            DynamicTableDeletionRequest request = DynamicTableDeletionRequest.newBuilder().setModuleId(moduleId.toString())
                    .setTenantId(tenantId)
                    .addAllGridFields(gridFields)
                    .addAllStructureIds(structureIds)
                    .build();
            log.info("DynamicGenerationImpl ------ Delete Table Index ended");
            return dynamicStub.withDeadlineAfter(DEADLINE_TIME, TimeUnit.SECONDS).deleteTable(request).getResponse();
        } catch (Exception e) {
            log.error(e.getMessage());
        }

        return false;
    }

    public boolean deleteIndex(List<String> structureIds, List<String> gridFields, Long moduleId, String tenantId) {
        log.info("DynamicGenerationImpl ------ Delete Index started");
        try {
            setManagedChannel();
            DynamicGenerationServiceBlockingStub dynamicStub = DynamicGenerationServiceGrpc
                    .newBlockingStub(channel);

            DynamicTableDeletionRequest request = DynamicTableDeletionRequest.newBuilder().setModuleId(moduleId.toString())
                    .setTenantId(tenantId)
                    .addAllGridFields(gridFields)
                    .addAllStructureIds(structureIds)
                    .build();
            log.info("DynamicGenerationImpl ------ Delete Index ended");
            return dynamicStub.withDeadlineAfter(DEADLINE_TIME, TimeUnit.SECONDS).deleteIndex(request).getResponse();
        } catch (Exception e) {
            log.error(e.getMessage());
        }

        return false;
    }

    public boolean deleteColumn(List<String> structureId, List<String> fieldId, Long moduleId, String tenantId,String keyField) {
        log.info("DynamicGenerationImpl ------ Delete Column started");
        try {
            setManagedChannel();
            DynamicGenerationServiceBlockingStub dynamicStub = DynamicGenerationServiceGrpc
                    .newBlockingStub(channel);

            DeleteColumnRequest request = DeleteColumnRequest.newBuilder().setModuleId(moduleId.toString())
                    .setTenantId(tenantId)
                    .addAllFieldId(fieldId)
                    .addAllStructureId(structureId)
                    .setKeyField(keyField)
                    .build();
            log.info("DynamicGenerationImpl ------ Delete Column ended");
            return dynamicStub.withDeadlineAfter(DEADLINE_TIME, TimeUnit.SECONDS).deleteColumn(request).getResponse();
        } catch (Exception e) {
            log.error(e.getMessage());
        }

        return false;
    }

    private DynamicTableGenerateRequest getDynamicTableGenerateRequest(String tenantId, Long moduleId, CreateFieldRequestDTO requestDTO) throws JsonProcessingException, InvalidProtocolBufferException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        String json = mapper.writeValueAsString(requestDTO);

        ModuleRequestDTOGrpc.Builder moduleRequestDTO = ModuleRequestDTOGrpc.newBuilder();
        JsonFormat.parser().ignoringUnknownFields().merge(json, moduleRequestDTO);
        moduleRequestDTO.setTenantId(tenantId).build();

        return DynamicTableGenerateRequest.newBuilder().setModuleId(moduleId.toString())
                .setModuleRequestDTO(moduleRequestDTO).build();
    }

    private void setManagedChannel() {
        if (channel ==null)  {
            setChannel(Grpc.INSTANCE.getChannel(addressName,addressPort)) ;
        }
    }
}
