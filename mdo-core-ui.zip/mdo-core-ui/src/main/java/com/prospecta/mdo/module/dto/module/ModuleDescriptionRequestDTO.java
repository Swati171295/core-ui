/**
 *
 */
package com.prospecta.mdo.module.dto.module;

import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModuleDescriptionRequestDTO {

	@ApiModelProperty(
			name = "moduleDescription",
			value = "JSON Object representing Module Description",
			dataType = "java.util.Map"
	)
	private Map<String , String> moduledescription;

	@ApiModelProperty(
			name = "information",
			value = "JSON Object representing Information",
			dataType = "java.util.Map"
	)
	private Map<String , String> information;

}
