/**
 * 
 */
package com.prospecta.mdo.module.dto.metadata;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Satyam
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReferenceRuleRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5436667774522846920L;


	@ApiModelProperty(
			name = "moduleId",
			value = "Long representing module id",
			dataType = "java.lang.Long",
			required = true
	)
	private Long moduleId;
	
	@ApiModelProperty(
			name = "fieldId",
			value = "String representing, field Id",
			dataType = "java.lang.String",
			required = true
	)
	private String fieldId;
	
	@ApiModelProperty(
			name = "referencedModuleId",
			value = "Long representing referenced module id",
			dataType = "java.lang.Long",
			required = true
	)
	private Long referencedModuleId;
	
	@ApiModelProperty(
			name = "referencedFieldId",
			value = "String representing, referenced field Id",
			dataType = "java.lang.String",
			required = true
	)
	private String referencedFieldId;
	
	@ApiModelProperty(
			name = "order_data",
			value = "Short representing order data",
			dataType = "java.lang.Short",
			required = true
	)
	private Short orderData;

}
