/**
 * 
 */
package com.prospecta.mdo.module.service.layout;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.prospecta.mdo.module.dto.elastic.MDORecordES;
import com.prospecta.mdo.module.dto.layout.*;
import com.prospecta.mdo.module.dto.module.FieldDTO;
import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;

import java.util.List;
import java.util.Map;

/**
 * @author savan
 *
 */
public interface CoreLayoutHeaderService {

	LayoutResponseDTO createLayout(LayoutRequestDTO requestDTO, Long moduleid, String tenantCode, String userModified);

	LayoutResponseDTO updateLayout(LayoutRequestDTO requestDTO, String layoutId, Long moduleid, String tenantCode,
			String username);

	List<FetchedLayoutDTO> getLayout(String layoutId, Long moduleid, String language, String tenantCode);

	LayoutTabResponseDTO createUpdateLayoutTab(LayoutTabDTO requestDTO, Long moduleId, String layoutId,
                                               String tenantCode);

	MDORecordES prepareMDOESRecord(String layoutId, Long moduleid, String language, String tenantCode);

	FieldDTO generateMetadata(String language, String tenantCode, ObjectMapper mapper, CoreMetadataModel metadata);

	FieldDTO generateMetadataField(String language, String tenantCode, ObjectMapper mapper, CoreMetadataModel metadata);

	LayoutResponseDTO deleteLayout(String layoutId,String tenantId);

	List<LayoutDetailsResponseDTO> listLayouts(Long moduleId,String tenantCode,String searchTerm,Integer fetchCount,Integer fetchSize,LayoutListRequestDTO layoutFilters,Long dateCreated,Long dateModified);

	Map<String,Long> layoutCount(Long moduleId, String tenantCode);

	LayoutDetailsResponseDTO getLayout(String layoutId,Long moduleId,String tenantCode);

	List<FetchedLayoutDTO> saveLayoutDetails(String layoutId, List<FetchedLayoutDTO> requestDTO,
											 Long moduleid, String tenantCode,String language,String userName);
	
	RuleMappingResponseDTO createOrUpdateRuleMapping(RuleMappingRequestDTO requestDTO, Long moduleId, String layoutId, String tenantId);
	
	RuleMappingResponseDTO deleteRuleMapping(RuleMappingRequestDTO requestDTO, Long moduleId, String layoutId, String tenantId);
}
