/**
 * 
 */
package com.prospecta.mdo.module.enums;

/**
 * @author paras.miglani
 *
 */
public enum MDORecordStatus {
	
	APP,
	INP,
	SENT,
	FERR,
	ERR,
	SYS,
	PENDING,
	INPROGRESS,
	COMPLETED,
	FAILED
}
