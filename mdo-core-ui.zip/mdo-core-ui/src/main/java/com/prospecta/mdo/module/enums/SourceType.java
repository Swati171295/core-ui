package com.prospecta.mdo.module.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum SourceType {

	SYSTABLE('0'), MODULE('1'),GROUP('2'),VIRTUALDATASET('3');
	
	public char asChar() {
        return asChar;
    }

    private final char asChar;

    SourceType(char asChar) {
        this.asChar = asChar;
    }
    
    @JsonCreator
	public static SourceType fromValue(String value) {
		return Enum.valueOf(SourceType.class, value);
	}
}
