/**
 * 
 */
package com.prospecta.mdo.module.rest.layout;

import com.prospecta.mdo.module.dto.JWTToken;
import com.prospecta.mdo.module.dto.elastic.MDORecordES;
import com.prospecta.mdo.module.dto.layout.*;
import com.prospecta.mdo.module.service.layout.CoreLayoutHeaderService;
import io.swagger.annotations.*;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author paras.miglani
 *
 */
@RestController
@RequestMapping(value = "/layout")
@Api(tags = {"Layout"}, description = "Layout Resource")
public class LayoutRestController {

	@Autowired
	private CoreLayoutHeaderService coreLayoutHeaderService;

	/**
	 * This method is used to create layout.
	 * 
	 * @param requestDTO
	 * @param moduleid
	 * @return
	 */
	@ApiOperation(value = "Create Layout.", notes = "Api to create new Layout")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = LayoutResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/{moduleId}/create")
	public ResponseEntity<LayoutResponseDTO> createLayout(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which new layout needs to be registered/created",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleid,
			@ApiParam(
					name = "",
					value = "Json Object representing LayoutRequest",
					type = "body",
					required = true
			)
			@RequestBody LayoutRequestDTO requestDTO) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		LayoutResponseDTO responseDTO = coreLayoutHeaderService.createLayout(requestDTO, moduleid,
				jwtToken.getTenantCode(), jwtToken.getUsername());

		if (responseDTO.isAcknowledge()) {
			return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * This method is used to update the layout.
	 * 
	 * @param moduleid
	 * @param layoutId
	 * @param requestDTO
	 * @return
	 */
	@ApiOperation(value = "Update Layout.", notes = "Api to update existing Layout")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = LayoutResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PutMapping("/{moduleId}/{layoutId}/update")
	public ResponseEntity<LayoutResponseDTO> updateLayout(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which existing layout needs to be updated",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleid,
			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the layout needs to be updated",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "layoutId") String layoutId,
			@ApiParam(
					name = "",
					value = "Json Object representing LayoutRequest",
					type = "body",
					required = true
			)
			@RequestBody LayoutRequestDTO requestDTO){

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();
		
		LayoutResponseDTO responseDTO = coreLayoutHeaderService.updateLayout(requestDTO, layoutId, moduleid, jwtToken.getTenantCode(), jwtToken.getUsername());
		
		if (responseDTO.isAcknowledge()) {
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * This method is used to fetch layout.
	 * 
	 * @param moduleid
	 * @param layoutId
	 * @param language
	 * @return
	 */
	@ApiOperation(value = "Get Layout", notes = "Get Layout /Tab/Field Assignment based on layout Id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = ArrayList.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/layoutdetails/{moduleId}/{layoutId}/{language}")
	public ResponseEntity<List<FetchedLayoutDTO>> getLayout(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which layout needs to be fetched",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleid,
			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the layout needs to be fetched",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "layoutId") String layoutId,
			@ApiParam(
					name = "language",
					value = "Language",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "en"))
			)
			@PathVariable(name = "language") String language) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		List<FetchedLayoutDTO> response = coreLayoutHeaderService.getLayout(layoutId, moduleid,language, jwtToken.getTenantCode());

		if (null != response && !response.isEmpty()) {
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * This method is used to save layout details.
	 *
	 * @param moduleid
	 * @param layoutId
	 * @param language
	 * @return
	 */
	@ApiOperation(value = "Save Layout Details", notes = "Save Layout/Tab/Field Assignment based on layout Id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created", content = {@Content(
					mediaType = "application/json",
					array = @ArraySchema(schema = @Schema(implementation = FetchedLayoutDTO.class))
			)}),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/{moduleId}/save-layout-details/{layoutId}/{language}")
	public ResponseEntity<List<FetchedLayoutDTO>> saveLayoutDetails(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which layout needs to be saved",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleid,
			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the layout needs to be saved",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "layoutId") String layoutId,
			@ApiParam(
					name = "language",
					value = "Language Of Tab Description",
					required = true,
					type = "String",
					format = "String"
			)
			@PathVariable(name = "language") String language,
			@ApiParam(
					name = "requestDTO",
					value = "JSON representing Layout Details to be saved",
					required = true
			)
			@RequestBody List<FetchedLayoutDTO> requestDTO) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		List<FetchedLayoutDTO> response = coreLayoutHeaderService.saveLayoutDetails(layoutId,requestDTO, moduleid,jwtToken.getTenantCode(),language, jwtToken.getUsername());

		return new ResponseEntity<>(response, HttpStatus.CREATED);

	}
	
	/**
	 * This method is used Update/Save Layout Tab.
	 * 
	 * @param requestDTO
	 * @param moduleId
	 * @param layoutId
	 * @return
	 */
	@ApiOperation(value= "Update/Save Layout Tab Assignment.", notes = "Api to update/save Layout Tab assignment")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = LayoutTabResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/{moduleId}/assignTab/{layoutId}")
	public ResponseEntity<LayoutTabResponseDTO> createUpdateLayoutTab(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which layout tab needs to be updated/saved",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the layout tab needs to be updated/saved",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "layoutId") String layoutId,
			@ApiParam(
					name = "",
					value = "Json Object representing LayoutTabRequest",
					type = "body",
					required = true
			)
			@RequestBody LayoutTabDTO requestDTO) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		LayoutTabResponseDTO responseDTO = coreLayoutHeaderService.createUpdateLayoutTab(requestDTO, moduleId, layoutId, 
				jwtToken.getTenantCode());

		if (responseDTO.isAcknowledge()) {
			return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * This method is used to prepare and return MDOESRecord JSON based on layout and Fields.
	 * 
	 * @param moduleid
	 * @param layoutId
	 * @param language
	 * @return
	 */
	@ApiOperation(value = "MDOESRecord JSON based", notes = "Prepare and return MDOESRecord JSON based on layout and Fields")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = MDORecordES.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/prepare-mdoesrecord/{moduleId}/{layoutId}/{language}")
	public ResponseEntity<MDORecordES> prepareMDOESRecord(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which MDOESRecord needs to be fetched",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleid,
			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the MDOESRecord needs to be fetched",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "layoutId") String layoutId,
			@ApiParam(
					name = "language",
					value = "Language",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "en"))
			)
			@PathVariable(name = "language") String language) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		MDORecordES response = coreLayoutHeaderService.prepareMDOESRecord(layoutId, moduleid, language, jwtToken.getTenantCode());

		if (null != response) {
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * This method is used to delete Layout.
	 *
	 * @param layoutId
	 * @return
	 */
	@ApiOperation(value= "Delete Layout", notes = "Api to Delete Layout")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = LayoutTabResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@DeleteMapping("/delete")
	public ResponseEntity<LayoutResponseDTO> deleteLayout(

			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the layout tab needs to be deleted",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@RequestParam(name = "layoutId") String layoutId) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		LayoutResponseDTO responseDTO = coreLayoutHeaderService.deleteLayout(layoutId,
				jwtToken.getTenantCode());

		return new ResponseEntity<>(responseDTO,HttpStatus.OK);
	}

	/**
	 * This method is used to fetch Layout List.
	 *
	 * @param moduleId
	 * @return
	 */
	@ApiOperation(value= "Fetch Layout List", notes = "Api to Fetch Layout List")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
					mediaType = "application/json",
					array = @ArraySchema(schema = @Schema(implementation = LayoutDetailsResponseDTO.class))
			)}),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/{moduleId}/list")
	public ResponseEntity<List<LayoutDetailsResponseDTO>> listLayout(

			@ApiParam(
					name = "moduleId",
					value = "Module Id against which the layouts need to be fetched",
					required = true,
					type = "Long",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "SearchTerm",
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "form")))
			@RequestParam("searchTerm") String searchterm,
			@ApiParam(
					name = "fetchSize",
					value = "Limit",
					required = true,
					type = "Integer",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
	        @RequestParam("fetchSize") Integer fetchSize,
			@ApiParam(
					name = "fetchCount",
					value = "offset",
					required = true,
					type = "Long",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
	        @RequestParam("fetchCount") Integer fetchCount,
			@ApiParam(
					name = "dateCreated",
					value = "Created on",
					type = "Long",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1630412013513")),
					allowableValues = "range[0, infinity]"
			)
			@RequestParam("dateCreated") Long dateCreated,
			@ApiParam(
					name = "dateModified",
					value = "Modified on",
					type = "Long",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1630412013513")),
					allowableValues = "range[0, infinity]"
			)
			@RequestParam("dateModified") Long dateModified,
			@ApiParam(
					name = "listFilters",
					value = "Filter List",
					type = "com.prospecta.mdo.module.dto.layout.LayoutListRequestDTO"
			)
			@RequestBody LayoutListRequestDTO listFilters) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		List<LayoutDetailsResponseDTO> responseDTO= coreLayoutHeaderService.listLayouts(moduleId,
				jwtToken.getTenantCode(),searchterm,fetchCount,fetchSize,listFilters,dateCreated,dateModified);

		return new ResponseEntity<>(responseDTO,HttpStatus.OK);
	}

	/**
	 * This method is used to fetch Layout Count in a module.
	 *
	 * @param moduleId
	 * @return
	 */
	@ApiOperation(value= "Fetch Layout Count", notes = "Api to fetch Layout count in a module")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = Map.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/{moduleId}/count")
	public ResponseEntity<Map<String,Long>> layoutCount(

			@ApiParam(
					name = "moduleId",
					value = "Module Id against which the layout count needs to be fetched",
					required = true,
					type = "Long",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleId) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		return new ResponseEntity<>(coreLayoutHeaderService.layoutCount(moduleId,
				jwtToken.getTenantCode()),HttpStatus.OK);
	}

	/**
	 * This method is used to fetch Layout Properties.
	 *
	 * @param moduleId
	 * @return
	 */
	@ApiOperation(value= "Fetch Layout Properties", notes = "Api to fetch Layout Properties")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = LayoutDetailsResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/{moduleId}/get-layout")
	public ResponseEntity<LayoutDetailsResponseDTO> getLayout(

			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the layout needs to be fetched",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@RequestParam(name = "layoutId") String layoutId,
			@ApiParam(
					name = "moduleId",
					value = "Module Id against which the layout needs to be fetched",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleId) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		LayoutDetailsResponseDTO responseDTO = coreLayoutHeaderService.getLayout(layoutId,moduleId,
				jwtToken.getTenantCode());

		return new ResponseEntity<>(responseDTO,HttpStatus.OK);
	}
	
	/**
	 * This method is used to create or update rule mapping of layout.
	 * 
	 * @param requestDTO
	 * @param moduleid
	 * @return
	 */
	@ApiOperation(value = "Create or update rule mapping.", notes = "Api to create or update rule mapping")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = RuleMappingResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PutMapping("/{moduleId}/save-rule-mapping/{layoutId}")
	public ResponseEntity<RuleMappingResponseDTO> saveOrUpdateRuleMappings(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId for rule mapping",
					required = true,
					type = "number",
					format = "long"
			)
			@PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the layout needs to be updated",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "layoutId") String layoutId,
			@ApiParam(
					name = "",
					value = "Json Object representing LayoutRequest",
					type = "body",
					required = true
			)
			@RequestBody RuleMappingRequestDTO requestDTO) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		RuleMappingResponseDTO responseDTO = coreLayoutHeaderService.createOrUpdateRuleMapping(requestDTO, moduleId, layoutId, jwtToken.getTenantCode());

		return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
	}
	
	/**
	 * This method is used to delete rule mapping of layout.
	 * 
	 * @param requestDTO
	 * @param moduleid
	 * @return
	 */
	@ApiOperation(value = "delete rule mapping.", notes = "Api to create or update rule mapping")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = RuleMappingResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@DeleteMapping("/{moduleId}/delete-rule-mapping/{layoutId}")
	public ResponseEntity<RuleMappingResponseDTO> deleteRuleMappings(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId for rule mapping",
					required = true,
					type = "number",
					format = "long"
			)
			@PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the layout needs to be updated",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "layoutId") String layoutId,
			@ApiParam(
					name = "",
					value = "Json Object representing LayoutRequest",
					type = "body",
					required = true
			)
			@RequestBody RuleMappingRequestDTO requestDTO) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		RuleMappingResponseDTO responseDTO = coreLayoutHeaderService.deleteRuleMapping(requestDTO, moduleId, layoutId, jwtToken.getTenantCode());

		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}
}
