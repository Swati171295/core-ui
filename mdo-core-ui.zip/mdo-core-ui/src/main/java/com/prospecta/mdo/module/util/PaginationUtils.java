package com.prospecta.mdo.module.util;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

public class PaginationUtils {
	
	public static Pageable getValidPage(Integer page, Integer size) {

		if (page == null || page < 1)
			page = 0;
		else
			page = page - 1;

		if (size == null || size <= 0)
			size = 10;

		PageRequest pageRequest = PageRequest.of(page, size);

		return pageRequest;
	}

}
