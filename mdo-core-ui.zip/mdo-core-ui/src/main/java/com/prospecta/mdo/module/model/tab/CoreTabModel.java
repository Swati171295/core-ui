/**
 * 
 */
package com.prospecta.mdo.module.model.tab;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import lombok.Data;

/**
 * @author savan
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_TAB_MDO")
public class CoreTabModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5277076322610416000L;
	
	@Id 
	@Type(type = "uuid-char")
	@Column(name = "TCODE", columnDefinition = "uuid")
	private UUID tcode;
	
	@Type(type = "uuid-char")
	@Column(name = "LAYOUTID", columnDefinition = "uuid")
	private UUID layoutId;
	
	@Column(name = "MODULEID")
	private Long moduleId;
	
	@Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
	private String tenantId;
	
	@Column(name = "USERMODIFIED", columnDefinition = "nvarchar(150)")
	private String userModified; 
	
	@Column(name = "DATECREATED")
	private Long dateCreated;

}
