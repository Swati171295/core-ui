package com.prospecta.mdo.module.repository.metadata;

import com.prospecta.mdo.module.model.metadata.elastic.UserFieldMetadata;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserFieldMetadataRepository extends ElasticsearchRepository<UserFieldMetadata,String> {

    Optional<UserFieldMetadata> findByFieldIdAndModuleIdAndTenantIdAndUserId(String fieldId, Long moduleId,
                                                                             String tenantId, String userId);

    void deleteByFieldIdAndModuleIdAndTenantIdAndUserId(String fieldId, Long moduleId,
                                                        String tenantId, String userId);

}
