/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModuleDescriptionDTO {

	@ApiModelProperty(
			name = "moduleId",
			value = "Long representing Module Id",
			dataType = "java.lang.Long"
	)
	private Long moduleid;

	@ApiModelProperty(
			name = "description",
			value = "String representing Module Description",
			dataType = "java.lang.String"
	)
	private String description;

	@ApiModelProperty(
			name = "information",
			value = "JSON Object representing Module Information",
			dataType = "java.util.Map"
	)
	private Map<String, String> information;
	
}
