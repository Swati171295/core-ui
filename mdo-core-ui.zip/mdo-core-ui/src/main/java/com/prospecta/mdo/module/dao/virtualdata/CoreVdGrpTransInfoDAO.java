package com.prospecta.mdo.module.dao.virtualdata;

import java.util.List;
import java.util.UUID;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;

@Repository
public interface CoreVdGrpTransInfoDAO extends PagingAndSortingRepository<CoreVdGrpTransInfoModel, UUID>{

	List<CoreVdGrpTransInfoModel> findByCoreVdGroups(CoreVdGroupsModel coreVdGroupsModel);

	void deleteByCoreVdGroups(CoreVdGroupsModel coreVdGroupsModel);

	List<CoreVdGrpTransInfoModel> findByUuidIn(List<UUID> groupTransId);

	void deleteByUuidIn(List<UUID> groupTransId);

}
