package com.prospecta.mdo.module.dto.virtualdata;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import lombok.Data;

@Data
public class UdrIdChildResponseDTO {

	private UUID uuid;
	
	private Long udrId;
	
	private String conditionFieldId;

	private String conditionValueFieldId;

	private String  conditionFieldValue;

	private String conditionFieldStartValue;

	private String conditionFieldEndValue;
	
	private String blockType;

	private String conditionOperator;

	private String blockDesc;

	private String objectType;

	private String plantCode;

	private String sRegex;

	private String targetInfo;

	private String conditionalFieldValueCtrl;
	
	private Integer order;
	
	private String blockCond;

	private String targetObjectType;
	
	private String sourceObjectType;

	List<UdrIdChildResponseDTO> childs = new ArrayList<>();
}
