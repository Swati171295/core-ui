package com.prospecta.mdo.module.dao.virtualdata;

import java.util.List;
import java.util.UUID;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransRuleReplaceModel;

@Repository
public interface CoreVdTransRuleReplaceDAO extends PagingAndSortingRepository<CoreVdTransRuleReplaceModel, UUID>{

	List<CoreVdTransRuleReplaceModel> findByCoreVdTransFieldSetting(
			CoreVdTransFieldSettingModel coreVdTransFieldSettingModel);

	void deleteByCoreVdTransFieldSetting(CoreVdTransFieldSettingModel coreVdTransFieldSettingModel);

	List<CoreVdTransRuleReplaceModel> findByVdReplaceIdIn(List<UUID> vdReplaceId);

	void deleteByVdReplaceIdIn(List<UUID> vdReplaceId);

}
