package com.prospecta.mdo.module.service.virtualdata;

import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Pageable;

import com.prospecta.mdo.module.dto.virtualdata.CommonResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.ResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdHeaderRequestDTO;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

public interface CoreVdHeaderService {
	
	CoreVdHeaderModel getVirtualDataset(UUID vdId);

	CoreVdHeaderModel updateVirtualDataset(VdHeaderRequestDTO requestDto,String tenantCode);
	
	void deleteVirtualDataset(UUID vdId);
	
	CommonResponseDTO createVirtualDataset(VdHeaderRequestDTO requestDto,String tenantCode);

	ResponseDTO getVirtualDatasetList(List<String> tenantIds, Pageable paging,String searchString);
}
