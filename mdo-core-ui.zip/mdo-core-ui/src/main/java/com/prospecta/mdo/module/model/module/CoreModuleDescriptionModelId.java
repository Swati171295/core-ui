/**
 * 
 */
package com.prospecta.mdo.module.model.module;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data 
@NoArgsConstructor
public class CoreModuleDescriptionModelId implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6727869074973052201L;

	private Long moduleId;
	
	private String language;
	
	private String tenantId;

	public CoreModuleDescriptionModelId(Long moduleId, String language, String tenantId) {
		super();
		this.moduleId = moduleId;
		this.language = language;
		this.tenantId = tenantId;
	}
	
}
