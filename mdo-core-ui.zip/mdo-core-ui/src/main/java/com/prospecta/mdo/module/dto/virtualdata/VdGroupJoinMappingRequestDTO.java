package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class VdGroupJoinMappingRequestDTO {
	
	@ApiModelProperty(
			name = "joinMappingId",
			value = "Join mapping id of virtual dataset",
			dataType = "java.util.UUID;",
			required = true
	)
	public UUID joinMappingId;
	
	@ApiModelProperty(
			name = "sourceOneField",
			value = "Id of the field 1 which is mapped in join",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "sourceOne field must not be null in mapping")
	public String sourceOneField;
	
	@ApiModelProperty(
			name = "sourceTwoField",
			value = "Id of the field 2 which is mapped in join",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "sourceTwo field must not be null in mapping")
	public String sourceTwoField;	
	
	@ApiModelProperty(
			name = "orderBy",
			value = "Order of the datasets",
			dataType = "java.lang.Short",
			required = true
	)
	public Short orderBy;
	
	@ApiModelProperty(
			name = "operator",
			value = "String representing compare operator",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "Operator must not be null in join mapping")
	public String operator;

}