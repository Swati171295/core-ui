/**
 *
 */
package com.prospecta.mdo.module.model.grid;

import com.prospecta.mdo.module.enums.SortType;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.io.Serializable;
import java.util.UUID;

/**
 * @author savan
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_GRID_SETTING_MDO")
@NoArgsConstructor
public class CoreGridSettingModel implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -8013597403575331845L;

	@Id
	@Type(type = "uuid-char")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "UUID")
	private UUID uuid;

	@Column(name = "FIELDID", columnDefinition = "nvarchar(50)")
	private String fieldId;

	@Column(name = "IS_HIDE")
	private Boolean isHide;

	@Column(name = "IS_DISPLAYONLY")
	private Boolean isDisplayOnly;

	@Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
	private String tenantId;

	@Column(name = "ORDER_DATA")
	private Byte order;

	@Column(name="MODULEID",columnDefinition = "bigint")
	private Long moduleId;

	@Column(name="GRIDFIELDID",columnDefinition = "nvarchar(50)")
	private String gridFieldId;

	@Column(name = "IS_SORT")
	private Boolean isSort;

	@Column(name = "IS_SEQUENCE")
	private Boolean isSequence;

	@Column(name = "IS_UNIQUE")
	private Boolean isUnique;

	@Column(name = "IS_EDITABLE")
	private Boolean isEditable;

	@Column(name = "IS_MANDATORY")
	private Boolean isMandatory;

	@Column(name = "SORT_TYPE")
	@Enumerated(EnumType.STRING)
	private SortType sortType;

    public CoreGridSettingModel(Long moduleId,String gridFieldId,String tenantId) {
        this.gridFieldId=gridFieldId;
        this.moduleId=moduleId;
        this.tenantId=tenantId;
    }
}
