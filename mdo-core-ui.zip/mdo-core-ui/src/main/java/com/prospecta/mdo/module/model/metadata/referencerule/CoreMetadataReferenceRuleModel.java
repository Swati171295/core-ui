/**
 *
 */
package com.prospecta.mdo.module.model.metadata.referencerule;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import lombok.Data;

/**
 * @author satyam
 */
@Data
@Entity
@Table(name = "CORE_METADATA_REFERENCE_RULES")
@Audited
public class CoreMetadataReferenceRuleModel implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -5251381986609063262L;

    @Id
    @Type(type = "uuid-char")
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "REFERENCE_UUID")
    private UUID referenceUuid;
    
    @Column(name = "MODULEID", columnDefinition = "bigint")
	private Long moduleId;
    
    @Column(name = "FIELDID", columnDefinition = "nvarchar(50)")
    private String fieldId;
    
    @Column(name = "DATA_REFERENCE_FIELDID", columnDefinition = "nvarchar(50)")
    private String dataReferenceFieldId;
    
    @Column(name = "REFERENCED_MODULEID", columnDefinition = "bigint")
	private Long referencedModuleId;
    
    @Column(name = "REFERENCED_FIELDID", columnDefinition = "nvarchar(50)")
	private String referencedFieldId;

    @Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
    private String tenantId;
    
    @Column(name = "ORDER_DATA", columnDefinition = "smallint")
    private Short orderData;

}
