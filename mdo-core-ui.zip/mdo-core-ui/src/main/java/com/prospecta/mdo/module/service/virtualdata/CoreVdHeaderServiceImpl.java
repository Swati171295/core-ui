package com.prospecta.mdo.module.service.virtualdata;

import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdHeaderDAO;
import com.prospecta.mdo.module.dto.virtualdata.CommonResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.ResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdHeaderListResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdHeaderRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdHeaderResponseDTO;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.exception.NoMatchFoundException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.exception.TenanatIdNotFoundException;
import com.prospecta.mdo.module.exception.VDNameExistsException;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class CoreVdHeaderServiceImpl implements CoreVdHeaderService {

	@Autowired
	private CoreVdHeaderDAO coreVdHeaderDAO;

	/**
	 * This method is used to create virtual dataset.
	 */
	@Override
	public CommonResponseDTO createVirtualDataset(VdHeaderRequestDTO requestDto, String tenantId) {

		StopWatch watch = new StopWatch();

		VdHeaderResponseDTO vdHeaderResponseDTO = new VdHeaderResponseDTO();

		CommonResponseDTO commonResponseDTO = new CommonResponseDTO();

		watch.start("Create virtual dataset header");

		// check for tenantId not null
		if (null == tenantId) {
			throw new TenanatIdNotFoundException("TenantId not Found!");
		}

		// check vdName already exists in DB
		CoreVdHeaderModel coreVdHeaderModel = coreVdHeaderDAO.findByVdNameAndTenantId(requestDto.getVdName(), tenantId);

		// if vdName present executes if otherwise else
		if (null == coreVdHeaderModel) {
			CoreVdHeaderModel model = new CoreVdHeaderModel();
			model.setVdId(UUID.randomUUID());
			model.setVdName(requestDto.getVdName());
			model.setVdDescription(requestDto.getVdDescription());
			model.setTenantId(tenantId);

			model = coreVdHeaderDAO.save(model);
			watch.stop();

			vdHeaderResponseDTO.setVdId(model.getVdId());
			vdHeaderResponseDTO.setVdName(model.getVdName());

			commonResponseDTO.setData(vdHeaderResponseDTO);
			commonResponseDTO.setMessage("Your dataset has been created successfully.");
			commonResponseDTO.setStatus(HttpStatus.OK.value());
			commonResponseDTO.setSuccess(true);

			log.info(watch.prettyPrint());
			return commonResponseDTO;
		} else {
			throw new VDNameExistsException("Virtual dataset name is exists try with another!!");
		}
	}

	/**
	 * This method is used to get searched virtual dataset.
	 */
	@Override
	public ResponseDTO getVirtualDatasetList(List<String> tenantId, Pageable paging, String searchString) {
		StopWatch watch = new StopWatch();

		List<VdHeaderListResponseDTO> listResponseDTO = new ArrayList<>();

		watch.start("Get list of virtual dataset header");

		List<CoreVdHeaderModel> vdHeaderModels;

		if (tenantId.isEmpty() && searchString == null) {
			vdHeaderModels = coreVdHeaderDAO.findByOrderByVdNameAsc(paging);
		} else if (searchString == null) {
			vdHeaderModels = coreVdHeaderDAO.findByTenantIdOrderByVdNameAsc(tenantId, paging);
		} else if (tenantId.isEmpty()) {
			vdHeaderModels = coreVdHeaderDAO.searchAllBySearchString(searchString, paging);
			if (vdHeaderModels.isEmpty()) {
				throw new NoMatchFoundException("No match found.");
			}
		} else {
			vdHeaderModels = coreVdHeaderDAO.searchAllByTenantIdAndSearchString(searchString, tenantId, paging);
			if (vdHeaderModels.isEmpty()) {
				throw new NoMatchFoundException("No match found.");
			}
		}
		watch.stop();
		log.info(watch.prettyPrint());
		for (CoreVdHeaderModel coreVdHeaderModel : vdHeaderModels) {
			VdHeaderListResponseDTO vdHeaderListResponseDTO = new VdHeaderListResponseDTO();
			vdHeaderListResponseDTO.setVdId(coreVdHeaderModel.getVdId());
			vdHeaderListResponseDTO.setVdName(coreVdHeaderModel.getVdName());
			vdHeaderListResponseDTO.setTenantId(coreVdHeaderModel.getTenantId());
			listResponseDTO.add(vdHeaderListResponseDTO);
		}
		return new ResponseDTO("Success", listResponseDTO);

	}

	/**
	 * This method is used to get virtual dataset.
	 * @param vdId
	 */
	@Override
	public CoreVdHeaderModel getVirtualDataset(UUID vdId) {
		if (vdId != null) {
			StopWatch watch = new StopWatch();
			Optional<CoreVdHeaderModel> coreVdHeaderModel;
			try {
				watch.start("Get Core vd Group Information");
				coreVdHeaderModel = coreVdHeaderDAO.findById(vdId);
				if (!coreVdHeaderModel.isPresent()) {
					throw new NotFound404Exception("Virtual dataset header not found");
				}
			} catch (Exception e) {
				log.error("error while get Virtual Dataset Information: " + e.getMessage());
				throw new CommonVirtualDatasetException(e.getMessage());
			}
			watch.stop();
			log.info(watch.prettyPrint());
			return coreVdHeaderModel.get();
		} else {
			throw new CommonVirtualDatasetException("virtual dataset id not present while getting it.");
		}	
	}
		
	/**
	 * This method is used to update virtual dataset.
	 * 
	 * @param requestDto
	 * @param tenantCode
	 */
	@Override
	public CoreVdHeaderModel updateVirtualDataset(VdHeaderRequestDTO requestDto, String tenantCode) {
		if (requestDto != null) {
			StopWatch watch = new StopWatch();
			CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
			try {
				watch.start("Update Virtual Dataset Information");
				log.info("Update Virtual Dataset Information");
				requestDto.setTenantId(null != tenantCode ? tenantCode : requestDto.getTenantId());
				if (requestDto.getTenantId() == null) {
					throw new CommonVirtualDatasetException("Tenant id must not be null in virtual dataset");
				}
				copyProperties(requestDto, coreVdHeaderModel);
				coreVdHeaderModel.setIndexName("dyn_vd_do_" + requestDto.getVdId());
				coreVdHeaderModel.setTableName("dyn_" + requestDto.getVdId());
				coreVdHeaderModel.setJobSchedulerId(requestDto.getJobSchedulerId());
				coreVdHeaderModel = coreVdHeaderDAO.save(coreVdHeaderModel);
				watch.stop();
			} catch (Exception e) {
				log.error("error while update Virtual Dataset Information: " + e.getMessage());
				throw new CommonVirtualDatasetException(e.getMessage());
			}
			log.info(watch.prettyPrint());
			return coreVdHeaderModel;
		} else {
			throw new CommonVirtualDatasetException("virtual dataset not present while storing it.");
		}

	}

	/**
	 * This method is used to delete virtual set.
	 * 
	 * @param vdId
	 * @throws CommonResponseDTO
	 */
	@Override
	public void deleteVirtualDataset(UUID vdId) {
		StopWatch watch = new StopWatch();
		try {
			log.info("Delete Group Information");
			watch.start("Delete vd groups");
			coreVdHeaderDAO.deleteById(vdId);
			watch.stop();
			log.info(watch.prettyPrint());
		} catch (Exception e) {
			log.error("error while deleting virtual dataset" + e.getMessage());
			throw new CommonVirtualDatasetException("error while deleting virtual dataset");
		}
	}

}