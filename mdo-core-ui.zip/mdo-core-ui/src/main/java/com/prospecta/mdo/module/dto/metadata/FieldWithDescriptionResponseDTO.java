/**
 * 
 */
package com.prospecta.mdo.module.dto.metadata;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class FieldWithDescriptionResponseDTO extends BaseFieldDetailsDTO {
	
	private String fieldId;
	
	private List<FieldWithDescriptionResponseDTO> grid;
	
}
