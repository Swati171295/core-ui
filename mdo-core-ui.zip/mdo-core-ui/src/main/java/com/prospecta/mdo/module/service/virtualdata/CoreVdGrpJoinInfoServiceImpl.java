package com.prospecta.mdo.module.service.virtualdata;

import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpJoinInfoDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinInfoRequestDTO;
import com.prospecta.mdo.module.enums.JoinOperator;
import com.prospecta.mdo.module.enums.JoinType;
import com.prospecta.mdo.module.enums.SourceType;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinInfoModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class CoreVdGrpJoinInfoServiceImpl implements CoreVdGrpJoinInfoService {

	@Autowired
	private CoreVdGrpJoinInfoDAO coreVdGrpJoinInfoDAO;
	
	@Autowired
	private CoreVdGroupsDAO coreVdGroupsDAO;
	
	/**
     * This method is used to get the virtual dataset join info by joinId.
     * @param joinId
     */
	@Override
	public CoreVdGrpJoinInfoModel getVdJoinInfobyJoinId(UUID joinId) {
		StopWatch watch = new StopWatch();
		watch.start("Get Core vd Group Join Info");
		Optional<CoreVdGrpJoinInfoModel> coreVdGrpJoinInfoModel=coreVdGrpJoinInfoDAO.findById(joinId);
		if (!coreVdGrpJoinInfoModel.isPresent()) {
			throw new NotFound404Exception("Virtual dataset group join info not found");
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGrpJoinInfoModel.get();
	}
	
	/**
     * This method is used to get the virtual dataset join info by groupId.
     * @param groupId
     */
	@Override
	public List<CoreVdGrpJoinInfoModel> getVdJoinInfobyGroupId(UUID groupId) {
		StopWatch watch = new StopWatch();
		watch.start("Get List of Core vd Group Information");
		Optional<CoreVdGroupsModel> coreVdGroupsModel=coreVdGroupsDAO.findById(groupId);
		if (!coreVdGroupsModel.isPresent()) {
			throw new NotFound404Exception("Virtual dataset groups not found");
		}
		List<CoreVdGrpJoinInfoModel> coreVdGrpJoinInfoModel=coreVdGrpJoinInfoDAO.findByCoreVdGroups(coreVdGroupsModel.get());
		if (coreVdGrpJoinInfoModel.isEmpty()) {
			throw new NotFound404Exception("Virtual dataset group join info not found");
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGrpJoinInfoModel;
	}

	/**
     * This method is used to delet the virtual dataset join info by join id.
     * @param joinId
     */
	@Override
	public void deleteVdJoinInfobyJoinId(UUID joinId) {
		
		StopWatch watch = new StopWatch();
		log.info("Delete Group Join Information");
		watch.start("Delete vd group join info");
		coreVdGrpJoinInfoDAO.deleteById(joinId);
		watch.stop();
		log.info(watch.prettyPrint());
	}

	/**
     * This method is used to delet the virtual dataset join info by group id.
     * @param groupId
     */
	@Override
	public void deleteVdJoinInfobyGroupId(UUID groupId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Join Information by group id Started");
		watch.start("Delete vd group join information");
		Optional<CoreVdGroupsModel> coreVdGrpJoinInfoModel=coreVdGroupsDAO.findById(groupId);
		if (!coreVdGrpJoinInfoModel.isPresent()) {
			throw new NotFound404Exception("Virtual dataset header not found");
		}
		coreVdGrpJoinInfoDAO.deleteByCoreVdGroups(coreVdGrpJoinInfoModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
		

	}

	/**
     * This method is used to delet the virtual dataset join info by group id.
     * @param groupJoinDetail
     * @param groupId
     */
	@Override
	public void deleteVdGroupInfo(List<VdGroupJoinInfoRequestDTO> groupJoinDetail, UUID groupId) {
		StopWatch watch = new StopWatch();
		try {
			watch.start("Delete vd group join information");
			log.info("Fetch the all group join information with groupId and compare with new data");
			Optional<CoreVdGroupsModel> coreVdGroupsModel = coreVdGroupsDAO.findById(groupId);
			if (!coreVdGroupsModel.isPresent()) {
				log.error("group are not found");
				throw new NotFound404Exception("group are not found");
			}
			List<UUID> newJoinId = groupJoinDetail.stream().filter(g -> g.getGroupJoinId() != null)
					.map(VdGroupJoinInfoRequestDTO::getGroupJoinId).collect(Collectors.toList());
			List<UUID> joinId = coreVdGrpJoinInfoDAO.findByCoreVdGroups(coreVdGroupsModel.get()).stream()
					.filter(grp -> !newJoinId.contains(grp.getUuid())).map(CoreVdGrpJoinInfoModel::getUuid)
					.collect(Collectors.toList());
			log.info("Delete all the group join information data if user deleted any");
			coreVdGrpJoinInfoDAO.deleteByUuidIn(joinId);
			watch.stop();
			log.info(watch.prettyPrint());
		} catch (Exception e) {
			log.error("error while Delete vd group join information: " + e.getMessage());
			throw new CommonVirtualDatasetException(e.getMessage());
		}
	}

	/**
     * This method is used to save or update join group information.
     * @param groupJoinInfoRequestDTO
     * @param coreVdGroupsModel
     */
	@Override
	public CoreVdGrpJoinInfoModel saveAndUpdateGrpJoinInfo(VdGroupJoinInfoRequestDTO requestDto,
			CoreVdGroupsModel coreVdGroupsModel) {
		if (requestDto != null) {
			if (coreVdGroupsModel != null) {
				StopWatch watch = new StopWatch();
				CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();
				try {
					log.info("Store virtal dataset group join information Started");
					watch.start("Store virtal dataset group join information.");
					copyProperties(requestDto, coreVdGrpJoinInfoModel);
					if (requestDto.getGroupJoinId() == null) {
						coreVdGrpJoinInfoModel.setUuid(UUID.randomUUID());
					} else {
						coreVdGrpJoinInfoModel.setUuid(requestDto.getGroupJoinId());
					}
					coreVdGrpJoinInfoModel.setResultScopeUdrId(requestDto.getResultScopeUdr());
					coreVdGrpJoinInfoModel.setSourceOneScopeUdrId(requestDto.getSourceOneScopeUdr());
					coreVdGrpJoinInfoModel.setSourceTwoScopeUdrId(requestDto.getSourceTwoScopeUdr());
					coreVdGrpJoinInfoModel.setCoreVdGroups(coreVdGroupsModel);
					coreVdGrpJoinInfoModel.setSourceOneType(SourceType.fromValue(requestDto.getSourceOneType().toUpperCase()));
					coreVdGrpJoinInfoModel.setSourceTwoType(SourceType.fromValue(requestDto.getSourceTwoType().toUpperCase()));
					coreVdGrpJoinInfoModel.setJoinType(JoinType.fromValue(requestDto.getJoinType().toUpperCase()));
					coreVdGrpJoinInfoModel.setJoinOperator(JoinOperator.fromValue(requestDto.getJoinOperator().toUpperCase()));
					coreVdGrpJoinInfoModel.setSourceOneModuleId(requestDto.getSourceOneModule());
					coreVdGrpJoinInfoModel.setSourceTwoModuleId(requestDto.getSourceTwoModule());
					coreVdGrpJoinInfoModel = coreVdGrpJoinInfoDAO.save(coreVdGrpJoinInfoModel);
					watch.stop();
				} catch (Exception e) {
					log.error("error while Store virtal dataset group join information: " + e.getMessage());
					throw new CommonVirtualDatasetException(e.getMessage());
				}
				log.info(watch.prettyPrint());
				return coreVdGrpJoinInfoModel;
			} else {
				log.error("Virtual group is not present while storing group join information.");
				throw new NotFound404Exception("Virtual group is not present while storing group join information.");
			}
		} else {
			log.error("Virtual group join is not present while storing it.");
			throw new NotFound404Exception("Virtual group join is not present while storing it.");
		}

	}

}
