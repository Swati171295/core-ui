package com.prospecta.mdo.module.exception;

public class GRPCException extends RuntimeException {

    private String message;

    public GRPCException(String message) {
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }
}

