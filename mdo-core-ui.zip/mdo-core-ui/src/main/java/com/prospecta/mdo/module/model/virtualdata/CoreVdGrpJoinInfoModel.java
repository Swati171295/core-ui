package com.prospecta.mdo.module.model.virtualdata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import com.prospecta.mdo.module.enums.JoinOperator;
import com.prospecta.mdo.module.enums.JoinType;
import com.prospecta.mdo.module.enums.SourceType;

import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;

/**
 * @author komal
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_VD_GRP_JOIN_INFO")
@DynamicInsert
public class CoreVdGrpJoinInfoModel implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2951940932188627632L;

	@Id
	@Type(type = "uuid-char")
	@Column(name = "UUID")
	private UUID uuid;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "GROUPID", nullable = false)
	private CoreVdGroupsModel coreVdGroups;
	
	@Column(name = "SOURCE_ONE", columnDefinition = "nvarchar(200)")
	private String sourceOne;
	
	@Column(name = "SOURCE_ONE_TYPE")
	private SourceType sourceOneType;
	
	@Column(name = "SOURCE_ONE_MODULEID")
	private Long sourceOneModuleId;
	
	@Column(name = "SOURCE_TWO", columnDefinition = "nvarchar(200)")
	private String sourceTwo;
	
	@Column(name = "SOURCE_TWO_TYPE")
	private SourceType sourceTwoType;
	
	@Column(name = "SOURCE_TWO_MODULEID")
	private Long sourceTwoModuleId;
	
	@Column(name = "SOURCE_ONE_SCOPE_UDRID", columnDefinition = "nvarchar(50)")
	private String sourceOneScopeUdrId;
	
	@Column(name = "SOURCE_TWO_SCOPE_UDRID", columnDefinition = "nvarchar(50)")
	private String sourceTwoScopeUdrId;
	
	@Column(name = "RESULT_SCOPE_UDRID", columnDefinition = "nvarchar(50)")
	private String resultScopeUdrId;
		
	@Column(name = "JOIN_TYPE")
	private JoinType joinType;
	
	@Column(name = "JOIN_OPERATOR")
	private JoinOperator joinOperator;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "coreVdGrpJoinInfo")
	private List<CoreVdGrpJoinMappingModel> coreVdGrpJoinMapping = new ArrayList<>();
	
}
