/**
 * 
 */
package com.prospecta.mdo.module.model.auditentity;

import java.util.UUID;

import org.hibernate.envers.RevisionListener;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.prospecta.mdo.module.dto.JWTToken;

/**
 * @author savan
 *
 */
public class CustomEntityListener implements RevisionListener {

	@Override
	public void newRevision(Object revisionEntity) {
		AuditRevisionEntity entity =  (AuditRevisionEntity)revisionEntity;
		
		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();
		
		entity.setUserModified(jwtToken.getUsername());
		entity.setTenantID(jwtToken.getTenantCode());
		entity.setProcessId(UUID.randomUUID().toString());
	
	}

}
