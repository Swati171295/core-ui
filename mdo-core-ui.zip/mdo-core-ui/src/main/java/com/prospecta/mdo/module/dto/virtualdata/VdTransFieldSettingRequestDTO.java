package com.prospecta.mdo.module.dto.virtualdata;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
@Data
public class VdTransFieldSettingRequestDTO {
	
	@ApiModelProperty(
			name = "transFieldId",
			value = "transFieldId is the id of Transformation",
			dataType = "java.util.UUID",
			required = true
	)
	public UUID transFieldId;
	
	@ApiModelProperty(
			name = "fieldName",
			value = "Name of the field",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "fieldName must not be null in fieldsetting")
	public String fieldName;
	
	@ApiModelProperty(
			name = "transRuleType",
			value = "transRuleType is the Transformation rule type e.g CONCAT,REGEX,LENGTH",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "transformation ruleType must not be null")
	public String transRuleType;
	
	@ApiModelProperty(
			name = "fieldAlias",
			value = "Field alias where temporary name can be given to the transformation",
			dataType = "java.util.String",
			required = true
	)
	public String fieldAlias;
	
	@ApiModelProperty(
			name = "dataType",
			value = "Data type of the field",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "dataType must not be null in field setting")
	public String dataType;

	@ApiModelProperty(
			name = "length",
			value = "Length of the field",
			dataType = "java.lang",
			required = true
	)
	public int length;
	
	@ApiModelProperty(
			name = "isGroup",
			value = "Storing either true or false for isGroup",
			dataType = "java.lang",
			required = true
	)
	public boolean isGroup;
	
	@ApiModelProperty(
			name = "isCustomField",
			value = "Storing either true or false for isCustomField",
			dataType = "java.lang",
			required = true
	)
	public boolean isCustomField;
	
	@ApiModelProperty(
			name = "fieldDescription",
			value = "Description of transformation table",
			dataType = "java.util.String",
			required = true
	)
	public String fieldDescription;
	
    List<@Valid VdTransRuleConcatRequestDTO> transConcatDetail = new ArrayList<>();
    
    List<@Valid VdTransRuleReplaceRequestDTO> transReplaceDetail = new ArrayList<>();
	
}
