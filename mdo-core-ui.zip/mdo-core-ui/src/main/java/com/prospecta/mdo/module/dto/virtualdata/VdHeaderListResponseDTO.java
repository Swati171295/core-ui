package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import lombok.Data;

@Data
public class VdHeaderListResponseDTO {

	private UUID vdId;

	private String vdName;

	private String tenantId;

}
