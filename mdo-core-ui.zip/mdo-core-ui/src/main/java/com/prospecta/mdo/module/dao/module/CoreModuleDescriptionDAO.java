/**
 * 
 */
package com.prospecta.mdo.module.dao.module;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.module.CoreModuleDescriptionModel;

/**
 * @author savan
 *
 */
@Repository
public interface CoreModuleDescriptionDAO extends PagingAndSortingRepository<CoreModuleDescriptionModel, Long> {

	List<CoreModuleDescriptionModel> findAllByTenantIdAndModuleId(String tenantId,Long moduleId);

	void deleteByModuleIdAndTenantId(Long moduleid, String tenantCode);

	List<CoreModuleDescriptionModel> findByTenantIdAndLanguageAndDescriptionLike(String tenantCode,
	        String language, String description);

	CoreModuleDescriptionModel findByModuleIdAndTenantIdAndLanguage(Long moduleId, String tenantCode, String language);

	void deleteByModuleIdAndTenantIdAndLanguage(Long moduleid, String tenantCode, String language);
}
