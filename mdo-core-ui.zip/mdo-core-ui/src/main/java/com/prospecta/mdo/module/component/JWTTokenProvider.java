package com.prospecta.mdo.module.component;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.prospecta.mdo.module.dto.JWTToken;
import com.prospecta.mdo.module.exception.JWTExpiredException;
import com.prospecta.mdo.module.service.module.ServerSettingService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author panther
 *
 */
@Component @Slf4j
public class JWTTokenProvider {
	
	public static final String JWT_TOKEN = "JWT-TOKEN";
	public static final String JWT_REFRESH_TOKEN = "JWT-REFRESH-TOKEN";
	private static final List<String> AUDIENCE = Arrays.asList("library","MRO","analytics","core","sync");
	private static final String CIPHER = "AES/GCM/NoPadding";
	
	/**
	 * JWT Request Signer
	 */
	private JWSSigner reqSigner;
	
	/**
	 * JWT Request Sign Verifier
	 */
	private JWSVerifier reqVerifier;
	
	@Autowired private ServerSettingService ssService;

	@PostConstruct
	protected void artifacts() throws JOSEException, InvalidKeySpecException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException {
		
		String rsk = ssService.getJWTRSK();
		
		reqSigner = new MACSigner(rsk.getBytes());
		reqVerifier = new MACVerifier(rsk.getBytes());
		Cipher cipher = Cipher.getInstance(CIPHER);
		log.info("Cipher algorithm loaded {}", cipher.getAlgorithm());
	}
	
	public String createToken(String payload) throws JOSEException {
		return this.createToken(payload, 15);
    }
	
    public String createToken(String payload, long expiryInMinutes) throws JOSEException {
    	ZonedDateTime zdt = LocalDateTime.now().atZone(ZoneOffset.UTC);
		
		// Prepare JWT with claims set.
		JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
				.subject(payload)
				.issuer("auth")
				.expirationTime(Date.from(zdt.plusMinutes(expiryInMinutes).toInstant()))
				.audience(AUDIENCE)
				.issueTime(Date.from(zdt.toInstant()))
				.build();

		// JWT prepared and ready to be signed.
		SignedJWT signedJWT = new SignedJWT(new JWSHeader(JWSAlgorithm.HS256), claimsSet);

		// Apply the HMAC protection. JWT Signing.
		signedJWT.sign(reqSigner);
		
		return signedJWT.serialize();
    }
    
    public String getPayload(String token) throws ParseException, JOSEException, JWTExpiredException {
    	SignedJWT signedJWT = SignedJWT.parse(token);
    	if(!signedJWT.verify(reqVerifier)) {
			log.warn("Signature verification failed {}", signedJWT);
			throw new JOSEException("Signature verification failed");
		}
		
		JWTClaimsSet readOnlyJWTClaimsSet = signedJWT.getJWTClaimsSet();

		//Expiration Time Check
		if (null == readOnlyJWTClaimsSet.getExpirationTime()) {
			log.error("No expiration time on SignedJWT claimset {}", readOnlyJWTClaimsSet);
			throw new JOSEException("No expiration time on SignedJWT claimset");
		}
		ZonedDateTime jwtExpirationTime = ZonedDateTime.ofInstant(readOnlyJWTClaimsSet.getExpirationTime().toInstant(), ZoneOffset.UTC);
		ZonedDateTime currentTime = LocalDateTime.now().atZone(ZoneOffset.UTC);

		if(jwtExpirationTime.isBefore(currentTime.minus(2, ChronoUnit.MINUTES))) { // 2 mins time sync grace period
			throw new JWTExpiredException("JWT time expired", readOnlyJWTClaimsSet.getSubject(), jwtExpirationTime);
		}
		
		//All good return subject
		return readOnlyJWTClaimsSet.getSubject();
    }
    
    public String resolveToken(HttpServletRequest req) {
        String bearerToken = req.getHeader(HttpHeaders.AUTHORIZATION);
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7, bearerToken.length());
        }
        return null;
    }
    
    public JWTToken resolveToken(String authorizationHeader) throws ParseException, JOSEException, JWTExpiredException, JsonProcessingException {
        String bearer = "Bearer ";
        String subject = getPayload(authorizationHeader.replace(bearer, ""));
        
        ObjectMapper om = new ObjectMapper();
        return om.readValue(subject, JWTToken.class);
    }
    
}