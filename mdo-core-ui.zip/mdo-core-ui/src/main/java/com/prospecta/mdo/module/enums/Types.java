/**
 * 
 */
package com.prospecta.mdo.module.enums;

import java.util.Arrays;
import java.util.Optional;

/**
 * @author savan
 *
 */
public enum Types {

	HEADER(0), TANDC(1),FLOW(2),HTML(3),PDF(4);

	private final int value;

	Types(int value) {
        this.value = value;
    }

    public static Optional<Types> valueOf(int value) {
        return Arrays.stream(values())
            .filter(legNo -> legNo.value == value)
            .findFirst();
    }
}
