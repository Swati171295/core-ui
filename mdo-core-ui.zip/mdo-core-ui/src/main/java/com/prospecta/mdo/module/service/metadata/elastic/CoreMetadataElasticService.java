package com.prospecta.mdo.module.service.metadata.elastic;

import com.prospecta.mdo.module.dto.metadata.BulkDeleteDTO;
import com.prospecta.mdo.module.dto.metadata.CreateFieldRequestDTO;
import com.prospecta.mdo.module.dto.metadata.CreateFieldResponseDTO;
import com.prospecta.mdo.module.dto.metadata.FieldIdsRequestDTO;
import com.prospecta.mdo.module.dto.module.FieldDTO;

import javax.validation.Valid;

public interface CoreMetadataElasticService {

    CreateFieldResponseDTO createDraftField(@Valid CreateFieldRequestDTO fields, String tenantCode, String username,
                                            Long moduleId);

    FieldDTO getDraftField(String fieldId, String tenantCode, String username,
                           Long moduleId);
    CreateFieldResponseDTO deleteDraftField(String fieldId, String tenantCode, String username,
                                            Long moduleId);
    BulkDeleteDTO deleteBulkDraftField(FieldIdsRequestDTO requestDTO, String tenantCode, String username,
                                       Long moduleId);
}
