package com.prospecta.mdo.module.rest.virtualdata;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.prospecta.mdo.module.dto.JWTToken;
import com.prospecta.mdo.module.dto.virtualdata.CommonResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.CoreVdSchedulerRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.ResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdHeaderRequestDTO;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.service.virtualdata.CommonService;
import com.prospecta.mdo.module.service.virtualdata.CoreVdHeaderService;
import com.prospecta.mdo.module.service.virtualdata.CoreVdSchedulerService;
import com.prospecta.mdo.module.util.PaginationUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;

@Api(tags = { "Virtualdata" }, description = "VirtualData Resource")
@RestController
@RequestMapping(value = "/virtualdataset")
@Slf4j
@Validated
public class VirtualDataRestController {

	@Autowired
	private CommonService commonService;

	@Autowired
	private CoreVdHeaderService coreVdHeaderService;

	@Autowired
	private CoreVdSchedulerService coreVdSchedulerService;

	CommonResponseDTO commomResponse = new CommonResponseDTO();

	/**
	 * This API is used to save virtual dataset information
	 * 
	 * @return
	 */
	@ApiOperation(value = "Save or update virtual dataset configuration", notes = "Api to save or update new virtual dataset configuration.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Your dataset has been updated successfully.", content = @Content(schema = @Schema(implementation = CommonResponseDTO.class))),
			@ApiResponse(responseCode = "401", description = "Access denied.", content = @Content(schema = @Schema(implementation = CommonResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/save-update")
	public ResponseEntity<CommonResponseDTO> updateVirtualDataset(@Valid @RequestBody VdHeaderRequestDTO request) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		try {
			JWTToken jwtToken = (JWTToken) auth.getDetails();
			CommonResponseDTO commonResponse = commonService.updateVirtualDataset(request, jwtToken.getTenantCode());
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while executing main thread" + e.getMessage());
			return new ResponseEntity<>(new CommonResponseDTO(500, false, e.getMessage(), null),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * This API is used to create virtual dataset header
	 * 
	 * @param tenantId
	 * @RequestBody CoreVdHeaderModel
	 * @return
	 */
	@ApiOperation(value = "Create virtual dataset header", notes = "Api to create new virtual dataset header.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Your dataset has been created successfully.", content = @Content(schema = @Schema(implementation = CommonResponseDTO.class))),
			@ApiResponse(responseCode = "401", description = "Access denied.", content = @Content(schema = @Schema(implementation = CommonResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/create-dataset")
	public ResponseEntity<CommonResponseDTO> createVirtualDataset(
			@ApiParam(name = "tenantId", value = "Tenant Id", required = false, type = "String", format = "String", examples = @Example(value = @ExampleProperty(value = "M00001"))) @RequestParam(name = "tenantId", required = false) String tenantId,
			@Validated @RequestBody VdHeaderRequestDTO vdHeaderRequestDTO) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		tenantId = (jwtToken.getTenantCode() == null) ? tenantId : jwtToken.getTenantCode();

		VdHeaderRequestDTO requestDTO = new VdHeaderRequestDTO(vdHeaderRequestDTO.getVdName(),
				vdHeaderRequestDTO.getVdDescription());

		CommonResponseDTO commonResponse = coreVdHeaderService.createVirtualDataset(requestDTO, tenantId);

		return new ResponseEntity<>(commonResponse, HttpStatus.OK);
	}

	/**
	 * This API is used to list virtual dataset *
	 * 
	 * @param page
	 * @param size
	 * @param searchString
	 * @return
	 */
	@ApiOperation(value = "Get list of virtual dataset with pagination.", notes = "Api to get list of virtual dataset with pagination.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Success", content = @Content(schema = @Schema(implementation = ResponseDTO.class))),
			@ApiResponse(responseCode = "401", description = "Access denied.", content = @Content(schema = @Schema(implementation = CommonResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/get-dataset-list")
	public ResponseEntity<ResponseDTO> listVirtualDataset(

			@ApiParam(name = "page", value = "page", required = false, type = "Integer", format = "Integer", examples = @Example(value = @ExampleProperty(value = "0"))) @RequestParam(name = "page", required = false) Integer page,
			@ApiParam(name = "size", value = "Display the number of the Dataset", required = false, type = "Integer", format = "Integer", examples = @Example(value = @ExampleProperty(value = "0"))) @RequestParam(name = "size", required = false) Integer size,
			@ApiParam(name = "tenantId", value = "Tenant Id", required = false, type = "String", format = "String", examples = @Example(value = @ExampleProperty(value = "M00001"))) @RequestParam(name = "tenantId", required = false) String tenantId,
			@ApiParam(name = "searchstring", value = "String to be searched", required = false, type = "String", format = "String", examples = @Example(value = @ExampleProperty(value = "abc"))) @RequestParam(name = "searchstring", required = false) String searchString) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		tenantId = (jwtToken.getTenantCode() == null) ? tenantId : jwtToken.getTenantCode();

		List<String> tenantIds = tenantId != null ? Arrays.asList(tenantId.split(",")) : new ArrayList<>();

		Pageable pageable = PaginationUtils.getValidPage(page, size);

		ResponseDTO responseDTO = coreVdHeaderService.getVirtualDatasetList(tenantIds, pageable, searchString);

		return new ResponseEntity<>(responseDTO, HttpStatus.OK);

	}

	/**
	 * Delete Virtual dataset by vdId
	 * 
	 * @param vdId
	 * @return
	 */
	@ApiOperation(value = "delete virtual dataset based on vdId", notes = "Api to get list of virtual dataset with pagination.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Success", content = @Content(schema = @Schema(implementation = ResponseDTO.class))),
			@ApiResponse(responseCode = "401", description = "Access denied.", content = @Content(schema = @Schema(implementation = CommonResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong.") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@DeleteMapping("/delete-dataset")
	public ResponseEntity<CommonResponseDTO> deleteVirtualDataset(

			@ApiParam(name = "vdId", value = "Tab Code against which tab field needs to be deleted", required = true, type = "UUID", format = "UUID", examples = @Example(value = @ExampleProperty(value = "444a553-1d90-4ee1-9b83-eaa68a28f17a"))) @RequestParam(name = "vdId", required = true) UUID vdId,
			HttpServletRequest request) {
		try {
			String auth = "Authorization";
			if (request.getHeader(auth) != null && request.getHeader(auth).split("Bearer").length > 2) {
				throw new CommonVirtualDatasetException("Error while getting token.");
			}
			String tokenKey = request.getHeader(auth).split("Bearer")[1];
			CommonResponseDTO commonResponse = commonService.deleteVirtualDataset(vdId, tokenKey);
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while executing main thread" + e.getMessage());
			return new ResponseEntity<>(new CommonResponseDTO(500, false, e.getMessage(), null),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * This API is used to get virtual dataset header
	 * 
	 * @param vdId
	 * @return
	 */
	@ApiOperation(value = "Get virtual dataset header", notes = "Api to create new virtual dataset header.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "success", content = @Content(schema = @Schema(implementation = ResponseDTO.class))),
			@ApiResponse(responseCode = "401", description = "Access denied.", content = @Content(schema = @Schema(implementation = CommonResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/get-dataset")
	public ResponseEntity<ResponseDTO> getVirtualDataset(
			@ApiParam(name = "vdId", value = "Virtual Dataset Id", required = true, type = "UUID", format = "UUID", examples = @Example(value = @ExampleProperty(value = "1c0dec3e-553a-4ca1-a621-0b56feb33583"))) @RequestParam(name = "vdId", required = true) UUID vdId,
			HttpServletRequest request) {

		try {
			String auth = "Authorization";
			if (request.getHeader(auth) != null && request.getHeader(auth).split("Bearer").length > 2) {
				throw new CommonVirtualDatasetException("Error while getting token.");
			}
			String tokenKey = request.getHeader(auth).split("Bearer")[1];
			ResponseDTO responseDTO = commonService.getVirtualDataset(vdId, tokenKey);
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while executing main thread" + e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(e.getMessage(), null), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * This API is used to Schedule dataset job and create dataset object
	 * 
	 * @param
	 * @return
	 */
	@ApiOperation(value = "Schedule virtual dataset header", notes = "Api to Schedule dataset job and create dataset object.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "success", content = @Content(schema = @Schema(implementation = CommonResponseDTO.class))),
			@ApiResponse(responseCode = "401", description = "Access denied.", content = @Content(schema = @Schema(implementation = CommonResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/create-scheduler")
	public ResponseEntity<CommonResponseDTO> createScheduler(@Valid @RequestBody CoreVdSchedulerRequestDTO requestDTO,
			HttpServletRequest request) {
		try {
			String auth = "Authorization";
			if (request.getHeader(auth) != null && request.getHeader(auth).split("Bearer").length > 2) {
				throw new CommonVirtualDatasetException("Error while getting token.");
			}
			String tokenKey = request.getHeader(auth).split("Bearer")[1];
			CommonResponseDTO responseDTO = coreVdSchedulerService.scheduleJob(requestDTO, tokenKey);
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while executing main thread" + e.getMessage());
			return new ResponseEntity<>(new CommonResponseDTO(e.getMessage(), null), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * This API is used to submit virtual dataset object from scheduler to Spark Job
	 * 
	 * @param vdId and schedulerId
	 * @return
	 */
	@ApiOperation(value = "submit virtual dataset object from scheduler to Spark Job", notes = "API is used to submit virtual dataset object from scheduler to Spark Job.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "success", content = @Content(schema = @Schema(implementation = CommonResponseDTO.class))),
			@ApiResponse(responseCode = "401", description = "Access denied.", content = @Content(schema = @Schema(implementation = CommonResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/send-to-spark")
	public ResponseEntity<CommonResponseDTO> sparkJob(@RequestParam(name = "vdId", required = true) UUID vdId,
			HttpServletRequest request) {
		try {
			String auth = "Authorization";
			if (request.getHeader(auth) != null && request.getHeader(auth).split("Bearer").length > 2) {
				throw new CommonVirtualDatasetException("Error while getting token.");
			}
			String tokenKey = request.getHeader(auth).split("Bearer")[1];
			CommonResponseDTO responseDTO = coreVdSchedulerService.sendToSparkJob(vdId, tokenKey);
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while executing main thread" + e.getMessage());
			return new ResponseEntity<>(new CommonResponseDTO(e.getMessage(), null), HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}

}
