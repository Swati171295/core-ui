package com.prospecta.mdo.module.model.virtualdata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import lombok.Data;

/**
 * @author komal
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_VD_HEADER")
@DynamicInsert
public class CoreVdHeaderModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Type(type = "uuid-char")
	@Column(name = "VD_ID")
	private UUID vdId;

	@Column(name = "VD_NAME", columnDefinition = "nvarchar(200)")
	private String vdName;

	@Column(name = "VD_DESCRIPTION", columnDefinition = "nvarchar(2000)")
	private String vdDescription;

	@Column(name = "JOB_SCHEDULAR_ID", columnDefinition = "nvarchar(50)")
	private String jobSchedulerId;

	@Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
	private String tenantId;

	@Column(name = "DATECREATED")
	private Long dateCreated;

	@Column(name = "USERCREATED", columnDefinition = "nvarchar(150)")
	private String userCreated;

	@Column(name = "DATEMODIFIED")
	private Long dateModified;

	@Column(name = "USERMODIFIED", columnDefinition = "nvarchar(150)")
	private String userModified;

	@Column(name = "INDEX_NAME", columnDefinition = "nvarchar(200)")
	private String indexName;

	@Column(name = "TABLE_NAME", columnDefinition = "nvarchar(100)")
	private String tableName;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "coreVdHeader")
	private List<CoreVdGroupsModel> coreVdGroups = new ArrayList<>();
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "coreVdHeader")
	private List<CoreVdGrpResultsModel> coreVdGrpResults = new ArrayList<>();

}
