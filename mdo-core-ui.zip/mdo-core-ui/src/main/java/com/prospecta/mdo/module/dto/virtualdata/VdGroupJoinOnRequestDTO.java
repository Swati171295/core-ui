package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class VdGroupJoinOnRequestDTO {
	
	@ApiModelProperty(
			name = "joinColumnId",
			value = "Id of join columns",
			dataType = "java.util.UUID;",
			required = true
	)
	public UUID joinColumnId;
	
	@ApiModelProperty(
			name = "sourceField",
			value = "Source field, which can be a TABLENAME, GROUPID",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message= "source field tablename or groupid must not be empty while joining")
	public String sourceField;
	
	@ApiModelProperty(
			name = "sourceOneFieldId",
			value = "Source one field id, which is Field/Column name",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message= "source field id must not be empty while joining")
	public String sourceFieldId;
	
	@ApiModelProperty(
			name = "targetField",
			value = "target field, which can be a TABLENAME, GROUPID",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message= "target field tablename or groupid must not be empty while joining")
	public String targetField;
	
	@ApiModelProperty(
			name = "targetFieldId",
			value = "target field id, which is Field/Column name",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message= "target field id must not be empty while joining")
	public String targetFieldId;	
	
	@ApiModelProperty(
			name = "condition",
			value = "Compare operator conditions e.g Equals, NOT Equals, Like, Not Like",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message= "Compare operator for two field must not be null")
	public String condition;
	
}