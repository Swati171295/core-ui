package com.prospecta.mdo.module.service.virtualdata;

import java.util.UUID;

import com.prospecta.mdo.module.dto.virtualdata.CommonResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.ResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdHeaderRequestDTO;

public interface CommonService {

	CommonResponseDTO updateVirtualDataset(VdHeaderRequestDTO request, String tenantCode);

	ResponseDTO getVirtualDataset(UUID vdId, String tokenKey);

	CommonResponseDTO deleteVirtualDataset(UUID vdId, String tokenKey);

}
