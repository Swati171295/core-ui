package com.prospecta.mdo.module.dao.virtualdata;

import java.util.UUID;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

/**
 * @author komal
 *
 */
@Repository
public interface CoreVdHeaderDAO extends PagingAndSortingRepository<CoreVdHeaderModel, UUID> {
	
	CoreVdHeaderModel findByVdNameAndTenantId(String vdName, String tenantId);
	
	@Query(value="select vd from CoreVdHeaderModel as vd where vd.vdName like %:searchString% ORDER BY vd.vdName ASC")
	List<CoreVdHeaderModel> searchAllBySearchString(String searchString, Pageable paging);

	@Query(value="select vd from CoreVdHeaderModel as vd where vd.tenantId in (:tenantIds) AND vd.vdName like %:searchString% ORDER BY vd.vdName ASC")
	List<CoreVdHeaderModel> searchAllByTenantIdAndSearchString(String searchString, List<String> tenantIds, Pageable paging);

	List<CoreVdHeaderModel> findByOrderByVdNameAsc(Pageable paging);

	@Query(value="select vd from CoreVdHeaderModel as vd where vd.tenantId in (:tenantIds) ORDER BY vd.vdName ASC")
	List<CoreVdHeaderModel> findByTenantIdOrderByVdNameAsc(List<String> tenantIds, Pageable paging);	
	
} 