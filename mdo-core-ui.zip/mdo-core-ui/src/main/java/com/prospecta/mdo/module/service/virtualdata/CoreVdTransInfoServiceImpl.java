package com.prospecta.mdo.module.service.virtualdata;

import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpTransInfoDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupTransInfoRequestDTO;
import com.prospecta.mdo.module.enums.SourceScope;
import com.prospecta.mdo.module.enums.SourceType;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class CoreVdTransInfoServiceImpl implements CoreVdTransInfoService {

	@Autowired
	private CoreVdGrpTransInfoDAO coreVdGrpTransInfoDAO;

	@Autowired
	private CoreVdGroupsDAO coreVdGroupsDAO;
	
	String message = "Virtual dataset header not found";
	/**
     * This method is used to get the virtual dataset transformation infoformation by trans id
     * @param transId
     */
	@Override
	public CoreVdGrpTransInfoModel getVdTransInfobyTransInfoId(UUID transId) {
		StopWatch watch = new StopWatch();
		watch.start("Get Core vd Group Information");
		Optional<CoreVdGrpTransInfoModel> coreVdGrpTransInfoModel = coreVdGrpTransInfoDAO.findById(transId);
		if (!coreVdGrpTransInfoModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGrpTransInfoModel.get();
	}
	
	/**
     * This method is used to get the virtual dataset transformation infoformation by group id
     * @param groupId
     */
	@Override
	public List<CoreVdGrpTransInfoModel> getVdTransInfobygroupId(UUID groupId) {
		StopWatch watch = new StopWatch();
		watch.start("Get List of Core vd Group Information");
		Optional<CoreVdGroupsModel> coreVdGroupsModel = coreVdGroupsDAO.findById(groupId);
		if (!coreVdGroupsModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		List<CoreVdGrpTransInfoModel> coreVdGrpTransInfoModel = coreVdGrpTransInfoDAO
				.findByCoreVdGroups(coreVdGroupsModel.get());
		if (coreVdGrpTransInfoModel.isEmpty()) {
			throw new NotFound404Exception("Virtual dataset group not found");
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGrpTransInfoModel;
	}
	
	/**
     * This method is used to delete the virtual dataset transformation infoformation by trans id
     * @param transId
     */
	@Override
	public void deleteVdTransInfobyTransInfoId(UUID transId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Information");
		watch.start("Delete vd groups");
		coreVdGrpTransInfoDAO.deleteById(transId);
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to delete the virtual dataset transformation infoformation by group id
     * @param groupId
     */
	@Override
	public void deleteVdTransInfobygroupId(UUID groupId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Information by virtual dataset started");
		watch.start("Delete vd groups");
		Optional<CoreVdGroupsModel> coreVdGroupsModel = coreVdGroupsDAO.findById(groupId);
		if (!coreVdGroupsModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		coreVdGrpTransInfoDAO.deleteByCoreVdGroups(coreVdGroupsModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to save/update the virtual dataset transformation information
     * @param transInfoRequestDTO
     * @param coreVdGroups
     */
	@Override
	public CoreVdGrpTransInfoModel saveOrUpdateVdTransInfo(VdGroupTransInfoRequestDTO transInfoRequestDTO, CoreVdGroupsModel coreVdGroups) {
		if (transInfoRequestDTO != null) {
			if (coreVdGroups != null) {
				StopWatch watch = new StopWatch();
				CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
				try {
					log.info("Store virtal dataset transformation infoformation started");
					watch.start("Store virtal dataset transformation infoformation");
					copyProperties(transInfoRequestDTO, coreVdGrpTransInfoModel);
					if (transInfoRequestDTO.getGroupTransId() == null) {
						coreVdGrpTransInfoModel.setUuid(UUID.randomUUID());
					} else {
						coreVdGrpTransInfoModel.setUuid(transInfoRequestDTO.getGroupTransId());
					}
					coreVdGrpTransInfoModel.setCoreVdGroups(coreVdGroups);
					coreVdGrpTransInfoModel.setResultScopeUdrId(transInfoRequestDTO.getResultScopeUdr());
					coreVdGrpTransInfoModel.setSourceModuleId(transInfoRequestDTO.getSourceModule());
					coreVdGrpTransInfoModel.setSourceScopeUdrId(transInfoRequestDTO.getSourceScopeUdr());
					coreVdGrpTransInfoModel.setSourceType(SourceType.fromValue(transInfoRequestDTO.getSourceType().toUpperCase()));
					coreVdGrpTransInfoModel.setSourceScope(SourceScope.fromValue(transInfoRequestDTO.getSourceScope().toUpperCase()));
					coreVdGrpTransInfoModel = coreVdGrpTransInfoDAO.save(coreVdGrpTransInfoModel);
					watch.stop();
				} catch (Exception e) {
					log.error("error while store virtal dataset transformation infoformation: " + e.getMessage());
					throw new CommonVirtualDatasetException(e.getMessage());
				}
				log.info(watch.prettyPrint());
				return coreVdGrpTransInfoModel;
			} else {
				throw new NotFound404Exception("Virtual data is not present while storing transformation information.");
			}
		} else {
			throw new NotFound404Exception("Virtual data transformation information is not present while storing it.");
		}
	}

	/**
     * This method is used to delete the virtual dataset transformation information
     * @param groupTransDetail
     * @param groupId
     */
	@Override
	public void deleteVdTransInfo(List<VdGroupTransInfoRequestDTO> groupTransDetail, UUID groupId) {
		StopWatch watch = new StopWatch();
		try {
			watch.start("Delete vd group tranformation information");
			log.info("Fetch the all group tranformation information with groupId and compare with new data");
			Optional<CoreVdGroupsModel> coreVdGroupsModel = coreVdGroupsDAO.findById(groupId);
			if (!coreVdGroupsModel.isPresent()) {
				log.error("Virtual groups information not found");
				throw new NotFound404Exception("Virtual groups information not found");
			}
			List<UUID> newgroupTransId = groupTransDetail.stream().filter(g -> g.getGroupTransId() != null)
					.map(VdGroupTransInfoRequestDTO::getGroupTransId).collect(Collectors.toList());
			List<UUID> groupTransId = coreVdGrpTransInfoDAO.findByCoreVdGroups(coreVdGroupsModel.get()).stream()
					.filter(grp -> !newgroupTransId.contains(grp.getUuid())).map(CoreVdGrpTransInfoModel::getUuid)
					.collect(Collectors.toList());
			log.info("Delete all the group information data if user deleted any");
			coreVdGrpTransInfoDAO.deleteByUuidIn(groupTransId);
			watch.stop();
			log.info(watch.prettyPrint());
		} catch (Exception e) {
			log.error("error while Delete vd group tranformation information: " + e.getMessage());
			throw new CommonVirtualDatasetException(e.getMessage());
		}
	}
}