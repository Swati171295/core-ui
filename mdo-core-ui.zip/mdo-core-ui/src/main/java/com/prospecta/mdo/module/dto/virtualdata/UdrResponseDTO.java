package com.prospecta.mdo.module.dto.virtualdata;



import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class UdrResponseDTO {
	
	private List<UdrIdChildResponseDTO> when = new ArrayList<>();
	
	private List<UdrIdChildResponseDTO> then = new ArrayList<>();
	
	private String brInfo;
}
