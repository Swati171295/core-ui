package com.prospecta.mdo.module.model.virtualdata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;

/**
 * @author komal
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_VD_TRANS_FIELDSETTING")
@DynamicInsert
public class CoreVdTransFieldSettingModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7556274649666432081L;

	@Id
	@Type(type = "uuid-char")
	@Column(name = "TRANS_FIELD_ID")
	private UUID transId;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "GROUPID", nullable = false)
	private CoreVdGroupsModel coreVdGroups;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "TRANSFORMATION_ID", nullable = false)
	private CoreVdGrpTransInfoModel coreVdGrpTransInfo;
	
	@Column(name = "FIELDNAME", columnDefinition = "nvarchar(100)")
	private String fieldName;
	
	@Column(name = "RULE_TYPE", columnDefinition = "nvarchar(100)")
	private String ruleType;
	
	@Column(name = "FIELDDESCRIPTION", columnDefinition = "nvarchar(200)")
	private String fieldDescription;
	
	@Column(name = "IS_CUSTOMFIELD")
	private Boolean isCustomField;
	
	@Column(name = "IS_GROUPBY")
	private Boolean isGroupBy;
	
	@Column(name = "FIELD_ALIAS", columnDefinition = "nvarchar(100)")
	private String fieldAlias;
	
	@Column(name = "LENGTH", columnDefinition = "Integer")
	private int length;
	
	@Column(name = "DATA_TYPE", columnDefinition = "nvarchar(100)")
	private String dataType;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "coreVdTransFieldSetting")
	private List<CoreVdTransRuleConcatModel> coreVdTransRuleConcat = new ArrayList<>();
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "coreVdTransFieldSetting")
	private List<CoreVdTransRuleReplaceModel> coreVdTransRuleReplace = new ArrayList<>();

}
