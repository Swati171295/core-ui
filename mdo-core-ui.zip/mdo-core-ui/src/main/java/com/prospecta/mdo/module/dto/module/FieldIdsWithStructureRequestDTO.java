/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldIdsWithStructureRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9538854870148077L;
	@ApiModelProperty(
			name = "structureId",
			value = "String representing Structure Id",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message = "Structure must be present")
	@NotEmpty(message = "Structure must be present")
	private String structureId;
}
