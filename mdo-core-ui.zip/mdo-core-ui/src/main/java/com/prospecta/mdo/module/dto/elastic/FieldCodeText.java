package com.prospecta.mdo.module.dto.elastic;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 * @author paras.miglani
 *
 */

@XmlRootElement(name = "fieldCodeValue")
public class FieldCodeText implements Serializable {

	private static final long serialVersionUID = -6388977964925105189L;

	/***
	 * contain the code
	 */
	private String c;

	/***
	 * contain the value text for code
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String t;

	/***
	 * contain the value text for code
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String p;

	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public String getT() {
		return t;
	}

	public void setT(String t) {
		this.t = t;
	}

	public String getP() {
		return p;
	}

	public void setP(String p) {
		this.p = p;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((c == null) ? 0 : c.hashCode());
		result = prime * result + ((p == null) ? 0 : p.hashCode());
		result = prime * result + ((t == null) ? 0 : t.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FieldCodeText other = (FieldCodeText) obj;
		if (c == null) {
			if (other.c != null)
				return false;
		} else if (!c.equals(other.c)) {
			return false;
		}
		if (p == null) {
			if (other.p != null)
				return false;
		} else if (!p.equals(other.p)) {
			return false;
		}
		if (t == null) {
			if (other.t != null)
				return false;
		} else if (!t.equals(other.t)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "FieldCodeValue [c=" + c + ", t=" + t + ", p=" + p + "]";
	}

}
