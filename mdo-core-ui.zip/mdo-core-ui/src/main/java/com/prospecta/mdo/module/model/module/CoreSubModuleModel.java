/**
 * 
 */
package com.prospecta.mdo.module.model.module;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import lombok.Data;

/**
 * @author savan
 *
 */
@Data
@Entity
@Table(name = "CORE_SUB_MODULE_MDO")
@Audited
public class CoreSubModuleModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1145229572858250728L;

	@Id
	@Type(type = "uuid-char")
	@Column(name = "UUID", columnDefinition = "uuid")
	private UUID uuid;
	
	@Column(name = "MODULEID")
	private Long moduleId;
	
	@Column(name = "PARENT_MODULEID")
	private Long parentModuleId;
	
}
