/**
 *
 */
package com.prospecta.mdo.module.service.layout;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prospecta.mdo.module.dao.layout.CoreLayoutHeaderDAO;
import com.prospecta.mdo.module.dao.layout.CoreLayoutRuleMappingDAO;
import com.prospecta.mdo.module.dao.layout.CoreLayoutTabDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataLangDAO;
import com.prospecta.mdo.module.dao.module.CoreModuleDAO;
import com.prospecta.mdo.module.dao.module.CoreModuleDescriptionDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabFieldsDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabLabelsDAO;
import com.prospecta.mdo.module.dto.elastic.FieldValue;
import com.prospecta.mdo.module.dto.elastic.GridValueES;
import com.prospecta.mdo.module.dto.elastic.MDORecordES;
import com.prospecta.mdo.module.dto.layout.*;
import com.prospecta.mdo.module.dto.metadata.FieldWithDescriptionResponseDTO;
import com.prospecta.mdo.module.dto.module.ChildFieldsDTO;
import com.prospecta.mdo.module.dto.module.FieldDTO;
import com.prospecta.mdo.module.dto.module.ModuleDescriptionInformationRequestDTO;
import com.prospecta.mdo.module.dto.tab.TabFieldDTO;
import com.prospecta.mdo.module.dto.tab.TabRequestDTO;
import com.prospecta.mdo.module.dto.tab.TabResponseDTO;
import com.prospecta.mdo.module.dto.tab.UUIDRequestListDTO;
import com.prospecta.mdo.module.enums.FieldType;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.layout.CoreLayoutHeaderModel;
import com.prospecta.mdo.module.model.layout.CoreLayoutRuleMappingModel;
import com.prospecta.mdo.module.model.layout.CoreLayoutTabModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;
import com.prospecta.mdo.module.model.module.CoreModuleDescriptionModel;
import com.prospecta.mdo.module.model.module.CoreModuleModel;
import com.prospecta.mdo.module.model.tab.CoreTabFieldsModel;
import com.prospecta.mdo.module.model.tab.CoreTabLabelsModel;
import com.prospecta.mdo.module.model.tab.CoreTabModel;
import com.prospecta.mdo.module.service.metadata.CoreMetadataService;
import com.prospecta.mdo.module.service.tab.CoreTabModelService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

import static com.prospecta.mdo.module.util.Constants.LAYOUT_DELETE_SUCCESS;
import static org.springframework.beans.BeanUtils.copyProperties;


/**
 * @author savan
 */
@Service
@Transactional
@Slf4j
public class CoreLayoutHeaderServiceImpl implements CoreLayoutHeaderService {

    @Autowired
    private CoreLayoutHeaderDAO coreLayoutHeaderDAO;

    @Autowired
    private CoreModuleDAO coreModuleDAO;

    @Autowired
    private CoreTabDAO coreTabDAO;

    @Autowired
    private CoreTabLabelsDAO coreTabLabelsDAO;

    @Autowired
    private CoreTabFieldsDAO coreTabFieldsDAO;

    @Autowired
    private CoreMetadataDAO coreMetadataDAO;

    @Autowired
    private CoreMetadataLangDAO coreMetadataLangDAO;

    @Autowired
    private CoreLayoutTabDAO coreLayoutTabDAO;

    @Autowired
    private CoreMetadataService coreMetadataService;

    @Autowired
    private CoreTabModelService coreTabService;

    @Autowired
    private CoreModuleDescriptionDAO coreModuleDescriptionDAO;
    
    @Autowired
    private CoreLayoutRuleMappingDAO coreLayoutRuleMappingDAO;

    public static final String ERROR = "Error while executing api: ";

    /**
     * This method is used to create the layout.
     */
    @Override
    public LayoutResponseDTO createLayout(LayoutRequestDTO requestDTO, Long moduleid, String tenantCode,
                                          String userModified) {
        StopWatch watch = new StopWatch();

        LayoutResponseDTO responseDTO = new LayoutResponseDTO();

        watch.start("Create and save layout");
        try {

            CoreModuleModel module = coreModuleDAO.findByModuleIdAndTenantId(moduleid, tenantCode);
            if (null == module) {
                throw new NoSuchElementException("No module data found for this request.");
            }

            CoreLayoutHeaderModel layout = new CoreLayoutHeaderModel();
            layout.setLayoutId(UUID.randomUUID());
            layout.setModuleId(moduleid);
            layout.setTenantId(tenantCode);
            layout.setDescription(requestDTO.getDescription());
            layout.setType(Short.parseShort(requestDTO.getType()));
            Long date= LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
            layout.setDateCreated(date);
            layout.setDateModified(date);
            layout.setUserCreated(userModified);
            layout.setUserModified(userModified);
            layout.setLabels(requestDTO.getLabels());
            layout.setUsage(requestDTO.getUsage());
            layout.setHelpText(requestDTO.getHelpText());

            layout = coreLayoutHeaderDAO.save(layout);
            watch.stop();

            responseDTO.setAcknowledge(true);
            responseDTO.setLayoutId(layout.getLayoutId().toString());

            log.info(watch.prettyPrint());
            return responseDTO;

        } catch (Exception e) {
            responseDTO.setAcknowledge(false);
            responseDTO.setErrorMsg(e.getMessage());
            log.error(ERROR, e);
            return responseDTO;
        }

    }

    /**
     * This method is used to update the layout
     */
    @Override
    public LayoutResponseDTO updateLayout(LayoutRequestDTO requestDTO, String layoutid, Long moduleid, String tenantCode,
                                          String username) {
        StopWatch watch = new StopWatch();

        LayoutResponseDTO responseDTO = new LayoutResponseDTO();

        watch.start("Create and save layout");
        try {

            CoreLayoutHeaderModel layout = coreLayoutHeaderDAO.findByLayoutIdAndModuleIdAndTenantId(UUID.fromString(layoutid), moduleid, tenantCode);
            if (null == layout) {
                throw new NoSuchElementException("No layout data found for this request");
            }

            layout.setDescription(requestDTO.getDescription());
            layout.setType(Short.parseShort(requestDTO.getType()));
            layout.setDateModified(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli());
            layout.setUserModified(username);
            layout.setLabels(requestDTO.getLabels());
            layout.setUsage(requestDTO.getUsage());
            layout.setHelpText(requestDTO.getHelpText());

            layout = coreLayoutHeaderDAO.save(layout);
            watch.stop();

            responseDTO.setLayoutId(layout.getLayoutId().toString());
            responseDTO.setAcknowledge(true);

            log.info(watch.prettyPrint());
            return responseDTO;

        } catch (Exception e) {
            log.error(ERROR, e);
            responseDTO.setErrorMsg(e.getMessage());
            responseDTO.setAcknowledge(false);
            return responseDTO;
        }
    }

    /**
     * This method is used to fetch layout.
     */
    @Override
    public List<FetchedLayoutDTO> getLayout(String layoutId, Long moduleid, String language, String tenantCode) {

        StopWatch watch = new StopWatch();

        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        List<FetchedLayoutDTO> layout = new ArrayList<>();

        watch.start("Fetch Layout /Tab/Field Assignment based on layout Id");
        try {

            List<CoreLayoutTabModel> tabModel = coreLayoutTabDAO.findByLayoutIdAndTenantId(UUID.fromString(layoutId),
                    tenantCode);

            if (null == tabModel) {
                throw new NoSuchElementException("There is no Tab data found related to this request");
            }

            tabModel.forEach(tab -> {

                List<CoreTabFieldsModel> coreTabFields = coreTabFieldsDAO.findByTcode(tab.getTcode());
                CoreTabLabelsModel coreTabLabels = coreTabLabelsDAO.findByTcodeAndLanguage(tab.getTcode(), language);
                List<LayoutFieldsDTO> layoutFields = new ArrayList<>();

                coreTabFields.forEach(tabField->{

                    LayoutFieldsDTO layoutdto = new LayoutFieldsDTO();

                    if(tabField.getFieldType() != FieldType.FIELD) {
                        copyProperties(tabField,layoutdto);
                        layoutdto.setTabFieldUuid(tabField.getUuid());
                        layoutFields.add(layoutdto);
                        return;
                    }

                    List<CoreMetadataModel> metadataFields = coreMetadataDAO
                        .findByModuleIdAndTenantIdAndFieldIdOrParentField(moduleid, tenantCode, tabField.getFieldId(),
                                tabField.getFieldId());

                // store available field data
                List<FieldWithDescriptionResponseDTO> responsefieldsList = new ArrayList<>();

                FieldDTO parentField = new FieldDTO();

                List<ChildFieldsDTO> childfields = new ArrayList<>();

                for (CoreMetadataModel metadata : metadataFields) {

                    if (null == metadata.getParentField() || metadata.getParentField().isEmpty()) {
                        parentField = generateMetadataField(language, tenantCode, mapper, metadata);
                    } else {
                        FieldDTO field = generateMetadataField(language, tenantCode, mapper, metadata);
                        ChildFieldsDTO childField = mapper.convertValue(field, new TypeReference<ChildFieldsDTO>() {
                        });

                        childfields.add(childField);
                    }
                }
                parentField.setChildfields(childfields);

                // generate the response fields list
                coreMetadataService.generateResponseField(language, responsefieldsList, parentField, mapper);

                layoutdto = mapper.convertValue(tabField, new TypeReference<LayoutFieldsDTO>() {
                });

                layoutdto.setMetadata(responsefieldsList);
                layoutdto.setFieldType(FieldType.FIELD);
                layoutdto.setTabFieldUuid(tabField.getUuid());
                layoutFields.add(layoutdto);

            });

            FetchedLayoutDTO fetchDTO = mapper.convertValue(coreTabLabels, new TypeReference<FetchedLayoutDTO>() {
            });

            fetchDTO.setLayoutId(layoutId);
            fetchDTO.setTabOrder(tab.getTabOrder());
            fetchDTO.setUdrId(tab.getUdrId());
            fetchDTO.setIsTabReadOnly(tab.getIsTabReadOnly());
            fetchDTO.setFields(layoutFields);
            fetchDTO.setIsTabHidden(tab.getIsTabHidden());

            layout.add(fetchDTO);
            });
            watch.stop();
            log.info(watch.prettyPrint());
            return layout;

        } catch (Exception e) {
            log.error(ERROR, e);
        }

        return layout;
    }

    /**
     * This method is used to generate language metadata.
     */
    @Override
    public FieldDTO generateMetadata(String language, String tenantCode, ObjectMapper mapper,
                                     CoreMetadataModel metadata) {

        CoreMetadataLangModel metadataLang = coreMetadataLangDAO
                .findByFieldIdAndLanguageAndTenantIdAndModuleId(metadata.getFieldId(), language, tenantCode, metadata.getModuleId());

        FieldDTO field = mapper.convertValue(metadata, new TypeReference<FieldDTO>() {
        });
        if (null != metadataLang) {
            Map<String, ModuleDescriptionInformationRequestDTO> shortText = new HashMap<>();
            if (metadata.getModuleId() != null && tenantCode != null && language != null) {
                CoreModuleDescriptionModel coreModuleDescriptionModel = coreModuleDescriptionDAO.findByModuleIdAndTenantIdAndLanguage(metadata.getModuleId(), tenantCode, language);
                if (Objects.nonNull(coreModuleDescriptionModel)) {
                    ModuleDescriptionInformationRequestDTO moduleDescriptionInformationRequestDTO = new ModuleDescriptionInformationRequestDTO();
                    moduleDescriptionInformationRequestDTO.setDescription(coreModuleDescriptionModel.getDescription());
                    moduleDescriptionInformationRequestDTO.setInformation(coreModuleDescriptionModel.getInformation());
                    shortText.put(language, moduleDescriptionInformationRequestDTO);
                }
            }
            Map<String, String> helpText = new HashMap<>();
            helpText.put(language, null != metadataLang.getHelpText() ? metadataLang.getHelpText() : null);
            Map<String, String> longText = new HashMap<>();
            longText.put(language, null != metadataLang.getLongText() ? metadataLang.getLongText() : null);

            field.setShortText(shortText);
            field.setHelptexts(helpText);
            field.setLongtexts(longText);
        }

        return field;
    }

    @Override
    public FieldDTO generateMetadataField(String language, String tenantCode, ObjectMapper mapper, CoreMetadataModel metadata) {

        CoreMetadataLangModel metadataLang = coreMetadataLangDAO
                .findByFieldIdAndLanguageAndTenantIdAndModuleId(metadata.getFieldId(), language, tenantCode, metadata.getModuleId());


        FieldDTO field = mapper.convertValue(metadata, new TypeReference<FieldDTO>() {
        });

        if (metadataLang == null) {
            return field;
        }

        Map<String, ModuleDescriptionInformationRequestDTO> shortText = new HashMap<>();
        ModuleDescriptionInformationRequestDTO descriptionInformationRequestDTO=new ModuleDescriptionInformationRequestDTO();
        descriptionInformationRequestDTO.setDescription(null != metadataLang.getShortText() ? metadataLang.getShortText() : null);
        descriptionInformationRequestDTO.setInformation(null != metadataLang.getHelpText() ? metadataLang.getHelpText() : null);
        shortText.put(language,descriptionInformationRequestDTO);

        Map<String, String> longText = new HashMap<>();
        longText.put(language, null != metadataLang.getLongText() ? metadataLang.getLongText() : null);

        field.setShortText(shortText);
        field.setLongtexts(longText);


        return field;
    }

    /**
     * This method is used to delete layout
     *
     * @param layoutId
     * @param tenantId
     * @return responseDTO
     */

    @Override
    @Transactional
    public LayoutResponseDTO deleteLayout(String layoutId, String tenantId) {

        StopWatch watch = new StopWatch();

        watch.start();

        //Find Layout,if not found throw error
        CoreLayoutHeaderModel coreLayoutHeaderModel = coreLayoutHeaderDAO.findByLayoutIdAndTenantId(UUID.fromString(layoutId), tenantId)
                .orElseThrow(() ->
                        new NotFound404Exception("Layout Id Not Found : "+layoutId)
                );

        //Find Layout tabs against Layout Id
        List<CoreLayoutTabModel> layoutTabs = coreLayoutTabDAO.findByLayoutIdAndTenantId(UUID.fromString(layoutId), tenantId);

        if (!layoutTabs.isEmpty()) {

            //List of tabs under the layout id
            List<UUID> tabCodes = layoutTabs.stream().map(CoreLayoutTabModel::getTcode).collect(Collectors.toList());

            //Find and Delete Tab Fields
            coreTabFieldsDAO.findByTcodeIn(tabCodes).ifPresent(tabFields -> coreTabFieldsDAO.deleteAll(tabFields));

            //Delete Layout Tabs
            coreLayoutTabDAO.deleteAll(layoutTabs);
        }
        //Find And Delete Tabs Against Layout Id
        coreTabDAO.findByLayoutIdAndTenantId(UUID.fromString(layoutId), tenantId)
                .ifPresent(tabs -> coreTabDAO.deleteAll(tabs));

        //Delete Layout
        coreLayoutHeaderDAO.delete(coreLayoutHeaderModel);

        watch.stop();
        log.info(watch.prettyPrint());

        LayoutResponseDTO responseDTO = new LayoutResponseDTO();
        responseDTO.setAcknowledge(true);
        responseDTO.setSuccessMsg(LAYOUT_DELETE_SUCCESS);
        responseDTO.setLayoutId(layoutId);

        return responseDTO;
    }

    /**
     * This method is used to fetch layout list
     *
     * @param moduleId
     * @param tenantCode
     * @param searchTerm
     * @param fetchCount
     * @param fetchSize
     * @param type
     * @param userCreated
     * @param userModified
     * @param dateCreated
     * @param dateModified
     * @return responseDTO
     */
    @Override
    public List<LayoutDetailsResponseDTO> listLayouts(Long moduleId, String tenantCode, String searchTerm,
                                                      Integer fetchCount, Integer fetchSize,LayoutListRequestDTO dto,Long dateCreated,Long dateModified) {

        StopWatch watch = new StopWatch();
        watch.start("Fetch Layout List");

        Pageable pageable = PageRequest.of(fetchCount, fetchSize);

        List<CoreLayoutHeaderModel> model = coreLayoutHeaderDAO.findLayoutList(moduleId,tenantCode,dto.getType(),dto.getUserCreated(),dto.getUserModified(),
                dateCreated,dateModified,searchTerm,pageable);

       watch.stop();
       log.info(watch.prettyPrint());

       return model.parallelStream()
               .map(LayoutDetailsResponseDTO::new)
               .collect(Collectors.toList());

    }
    /**
     * This method is used for fetching layout count
     */
    @Override
    public Map<String, Long> layoutCount(Long moduleId, String tenantCode) {

        StopWatch watch = new StopWatch();
        watch.start("Fetch Layout Count");

        Map<String, Long> map = new HashMap<>();
        map.put("count",coreLayoutHeaderDAO.countByModuleIdAndTenantId(moduleId,tenantCode));

        watch.stop();
        log.info(watch.prettyPrint());
        return map;
    }

    /**
     * This method is used for fetching layout properties
     */
    @Override
    public LayoutDetailsResponseDTO getLayout(String layoutId, Long moduleId, String tenantCode) {
        StopWatch watch = new StopWatch();
        watch.start("Fetch Layout");

        UUID id= UUID.fromString(layoutId);

        watch.stop();
        log.info(watch.prettyPrint());
        return new LayoutDetailsResponseDTO(coreLayoutHeaderDAO.findByLayoutIdAndModuleIdAndTenantId(id,moduleId,tenantCode
        ));
    }

    /**
     * This method is used for saving layout details
     */

    @Override
    public List<FetchedLayoutDTO> saveLayoutDetails(String layoutId, List<FetchedLayoutDTO> requestDTO,
                                                    Long moduleid, String tenantCode,String language,String userName) {

        StopWatch watch = new StopWatch();
        watch.start("Save Layout Details started");

        for (FetchedLayoutDTO dto : requestDTO) {

            setOrUpdateTab(moduleid, tenantCode, dto,layoutId,language,userName);
            setOrUpdateLayoutTab(moduleid, tenantCode, dto,layoutId);
            setOrUpdateTabFields(tenantCode, dto);

        }

        List<UUID> tCodeList = requestDTO.stream().map(FetchedLayoutDTO::getTcode).collect(Collectors.toList());
        List<UUID> deleteList = coreLayoutTabDAO.findIdByTcodeNotIn(tCodeList);

        deleteList.forEach(uuid-> coreTabService.deleteTabField(uuid,new UUIDRequestListDTO(),tenantCode));

        watch.stop();
        log.info(watch.prettyPrint());
        return requestDTO;
    }

    /**
     * This method is used for saving layout tab field properties
     */
    private void setOrUpdateTabFields(String tenantCode, FetchedLayoutDTO dto) {

        List<TabFieldDTO> tabFieldDtoUpdate= dto.getFields().stream()
                .filter(field -> field.getTabFieldUuid()!=null)
                .map(TabFieldDTO ::new)
                .collect(Collectors.toList());

        if (!tabFieldDtoUpdate.isEmpty()) {
            coreTabService.assignFieldToTabUpdate(tabFieldDtoUpdate, dto.getTcode(), tenantCode);
        }

       List<TabFieldDTO> tabFieldDtoSave = dto.getFields().stream()
                .filter(field -> field.getTabFieldUuid()==null)
                .map(TabFieldDTO ::new)
                .collect(Collectors.toList());

        if (!tabFieldDtoSave.isEmpty()) {
            coreTabService.assignFieldToTab(tabFieldDtoSave, dto.getTcode(), tenantCode);
        }
        tabFieldDtoSave.addAll(tabFieldDtoUpdate);

        List<CoreTabFieldsModel> models = coreTabFieldsDAO.findByTcodeAndUuidNotIn(dto.getTcode()
                ,tabFieldDtoSave.stream()
                        .map(TabFieldDTO::getTabFieldUuid)
                        .collect(Collectors.toList()));

        coreTabFieldsDAO.deleteAll(models);
        dto.setFields(tabFieldDtoSave.stream().map(LayoutFieldsDTO::new).collect(Collectors.toList()));
    }


    /**
     * This method is used for saving layout tab properties
     */
    private void setOrUpdateLayoutTab(Long moduleid, String tenantCode, FetchedLayoutDTO dto,String layoutId) {

        LayoutTabDTO layoutTabDTO = new LayoutTabDTO();
        copyProperties(dto,layoutTabDTO);
        layoutTabDTO.setTabid(dto.getTcode().toString());

        LayoutTabResponseDTO responseDTO = createUpdateLayoutTab(layoutTabDTO, moduleid, layoutId, tenantCode);

         if (!responseDTO.isAcknowledge()) {
            throw new NotFound404Exception(responseDTO.getErrorMsg());
        }
    }

    /**
     * This method is used for saving tab properties
     */
    private void setOrUpdateTab(Long moduleid, String tenantCode, FetchedLayoutDTO dto,String layoutId,String language,String userName) {

        TabRequestDTO tabRequestDTO = new TabRequestDTO();

        Map<String,String> description= new HashMap<>();
        Map<String,String> information = new HashMap<>();
        description.put(language, dto.getTabText());
        information.put(language, dto.getInformation());

        tabRequestDTO.setDescription(description);
        tabRequestDTO.setInformation(information);
        tabRequestDTO.setModuleid(moduleid.toString());

        TabResponseDTO responseDTO;
        if (dto.getTcode() != null) {
            responseDTO =coreTabService.updateTab(tabRequestDTO,UUID.fromString(layoutId), dto.getTcode(), tenantCode,userName);
        }
        else {
          responseDTO= coreTabService.createTab(tabRequestDTO,UUID.fromString(layoutId), tenantCode,userName);
          dto.setTcode(UUID.fromString(responseDTO.getTcode()));
        }
        if (!responseDTO.isAcknowledge()) {
            throw new NotFound404Exception(responseDTO.getErrorMsg());
        }
    }

    /**
     * This method is used for Update/Save Layout Tab Assignment
     */
    @Override
    public LayoutTabResponseDTO createUpdateLayoutTab(LayoutTabDTO requestDTO, Long moduleId, String layoutId,
                                                      String tenantCode) {
        StopWatch watch = new StopWatch();

        LayoutTabResponseDTO responseDTO = new LayoutTabResponseDTO();

        watch.start("Create and save layout tab");
        try {

            CoreLayoutHeaderModel layoutHeader = coreLayoutHeaderDAO
                    .findByLayoutIdAndModuleIdAndTenantId(UUID.fromString(layoutId), moduleId, tenantCode);
            if (null == layoutHeader) {
                throw new NoSuchElementException("No layout data found for this request.");
            }

            CoreTabModel coreTabModel = coreTabDAO.findByTcodeAndLayoutIdAndModuleIdAndTenantId(UUID.fromString(requestDTO.getTabid()),
                    UUID.fromString(layoutId),
                    moduleId, tenantCode);

            if (null == coreTabModel) {
                throw new NoSuchElementException("No tab data associated with this requested layout.");
            }

            CoreLayoutTabModel layoutTab = coreLayoutTabDAO.findByTcodeAndLayoutIdAndTenantId(coreTabModel.getTcode(),
                    UUID.fromString(layoutId), tenantCode);

            if (null != layoutTab) {
                // update
                layoutTab.setTabOrder(requestDTO.getTabOrder());
                layoutTab.setIsTabReadOnly(requestDTO.getIsTabReadOnly());
                layoutTab.setIsTabHidden(requestDTO.getIsTabHidden());
                layoutTab.setUdrId(requestDTO.getUdrId());

                layoutTab = coreLayoutTabDAO.save(layoutTab);

                responseDTO.setLayoutTabId(layoutTab.getUuid().toString());

            } else {
                // create
                CoreLayoutTabModel layoutModel = new CoreLayoutTabModel();
                layoutModel.setUuid(UUID.randomUUID());
                layoutModel.setLayoutId(UUID.fromString(layoutId));
                layoutModel.setTcode(coreTabModel.getTcode());
                layoutModel.setTenantId(tenantCode);
                layoutModel.setTabOrder(requestDTO.getTabOrder());
                layoutModel.setIsTabReadOnly(requestDTO.getIsTabReadOnly());
                layoutModel.setIsTabHidden(requestDTO.getIsTabHidden());
                layoutModel.setUdrId(requestDTO.getUdrId());

                layoutModel = coreLayoutTabDAO.save(layoutModel);

                responseDTO.setLayoutTabId(layoutModel.getUuid().toString());
            }

            watch.stop();

            responseDTO.setAcknowledge(true);

            log.info(watch.prettyPrint());
            return responseDTO;

        } catch (Exception e) {
            responseDTO.setAcknowledge(false);
            responseDTO.setErrorMsg(e.getMessage());
            log.error(ERROR, e);
            return responseDTO;
        }
    }

    /**
     * This method is used to prepare the empty MDOESRecord object for data insertion in elastic search.
     */
    @Override
    public MDORecordES prepareMDOESRecord(String layoutId, Long moduleid, String language, String tenantCode) {

        StopWatch watch = new StopWatch();

        MDORecordES recordjson = new MDORecordES();

        watch.start("Preparing MDOESRecord JSON based on layout and Fields");
        try {

            CoreTabModel tabModel = coreTabDAO.findByLayoutIdAndModuleIdAndTenantId(UUID.fromString(layoutId), moduleid,
                    tenantCode);

            if (null == tabModel) {
                throw new NoSuchElementException("There is no Tab data found related to this request");
            }

            List<CoreTabFieldsModel> coreTabFields = coreTabFieldsDAO.findByTcode(tabModel.getTcode());

            LinkedHashMap<String, FieldValue> hdvs = new LinkedHashMap<>();

            LinkedHashMap<String, GridValueES> gvs = new LinkedHashMap<>();

            coreTabFields.stream().forEach(tabField -> {

                // core layout tab labels
                CoreTabLabelsModel coreTabLabels = coreTabLabelsDAO.findByTcodeAndLanguage(tabModel.getTcode(),
                        language);

                // metadata fields
                List<CoreMetadataModel> metadataFields = coreMetadataDAO
                        .findByModuleIdAndTenantIdAndFieldIdOrParentField(moduleid, tenantCode, tabField.getFieldId(),
                                tabField.getFieldId());

                // prepare hdvs
                prepareHdvs(hdvs, tabField, coreTabLabels);

                // prepare gvs
                prepareGvs(gvs, tabField, metadataFields, language, tenantCode);

            });

            // set hdvs and gvs to recordJson
            recordjson.setHdvs(hdvs);
            recordjson.setGvs(gvs);

            watch.stop();
            log.info(watch.prettyPrint());
            return recordjson;

        } catch (Exception e) {
            log.error(ERROR, e);
        }

        return recordjson;
    }

    /**
     * This method is used to prepare the GVS data
     *
     * @param gvs
     * @param rows
     * @param rowData
     * @param tabField
     * @param metadataFields
     */
    private void prepareGvs(LinkedHashMap<String, GridValueES> gvs, CoreTabFieldsModel tabField,
                            List<CoreMetadataModel> metadataFields, String language, String tenantCode) {

        GridValueES gridValueES = new GridValueES();

        LinkedList<LinkedHashMap<String, FieldValue>> rows = new LinkedList<>();

        for (CoreMetadataModel metadata : metadataFields) {

            CoreMetadataLangModel metadataLang = coreMetadataLangDAO
                    .findByFieldIdAndLanguageAndTenantIdAndModuleId(metadata.getFieldId(), language, tenantCode, metadata.getModuleId());

            LinkedHashMap<String, FieldValue> rowData = new LinkedHashMap<>();

            if (null == metadata.getParentField() || metadata.getParentField().isEmpty()) {
                gridValueES.setGId(metadata.getFieldId());
                gridValueES.setLs(metadataLang.getShortText());

            } else {

                FieldValue rowsFieldValue = new FieldValue();
                rowsFieldValue.setFId(metadata.getFieldId());
                rowsFieldValue.setLs(metadataLang.getShortText());

                rowData.put(metadata.getFieldId(), rowsFieldValue);
                rows.add(rowData);
            }
        }

        gridValueES.setRows(rows);

        gvs.put(tabField.getFieldId(), gridValueES);
    }

    /**
     * This method is used to prepare the HDVS data
     *
     * @param hdvs
     * @param tabField
     * @param coreTabLabels
     */
    private void prepareHdvs(LinkedHashMap<String, FieldValue> hdvs, CoreTabFieldsModel tabField,
                             CoreTabLabelsModel coreTabLabels) {
        FieldValue hdvsFieldValue = new FieldValue();
        hdvsFieldValue.setFId(tabField.getFieldId());
        hdvsFieldValue.setLs(coreTabLabels.getTabText());

        hdvs.put(tabField.getFieldId(), hdvsFieldValue);
    }

    
	@Override
	public RuleMappingResponseDTO createOrUpdateRuleMapping(RuleMappingRequestDTO requestDTO, Long moduleId,
			String layoutId, String tenantId) {
		StopWatch watch = new StopWatch();
		watch.start("creating or updating rule mapping for layoutid");
		CoreLayoutRuleMappingModel existingCoreLayoutRuleMapping = coreLayoutRuleMappingDAO
				.findByLayoutIdAndModuleIdAndTenantId(UUID.fromString(layoutId), moduleId, tenantId);

		if (existingCoreLayoutRuleMapping != null) {
			deleteRuleMappings(moduleId, UUID.fromString(layoutId), requestDTO.getRuleMappingIds());
		}
		
		List<CoreLayoutRuleMappingModel> coreLayoutRuleMappings = new ArrayList<>();
		for (UUID ruleMappingId : requestDTO.getRuleMappingIds()) {
			CoreLayoutRuleMappingModel coreLayoutRuleMappingModel = new CoreLayoutRuleMappingModel();
			coreLayoutRuleMappingModel.setLayoutId(UUID.fromString(layoutId));
			coreLayoutRuleMappingModel.setRuleMappingId(ruleMappingId);
			coreLayoutRuleMappingModel.setModuleId(moduleId);
			coreLayoutRuleMappingModel.setTenantId(tenantId);
			coreLayoutRuleMappings.add(coreLayoutRuleMappingModel);
		}

		coreLayoutRuleMappingDAO.saveAll(coreLayoutRuleMappings);
		watch.stop();

		RuleMappingResponseDTO responseDTO = new RuleMappingResponseDTO();
		responseDTO.setAcknowledge(true);
		responseDTO.setSuccessMsg("Rule mapping deleted successfully");

		return responseDTO;
	}

	@Override
	public RuleMappingResponseDTO deleteRuleMapping(RuleMappingRequestDTO requestDTO, Long moduleId, String layoutId,
			String tenantId) {
		StopWatch watch = new StopWatch();
		watch.start("deleting rule mapping for layoutid");
		deleteRuleMappings(moduleId, UUID.fromString(layoutId), requestDTO.getRuleMappingIds());
		watch.stop();

		RuleMappingResponseDTO responseDTO = new RuleMappingResponseDTO();
        responseDTO.setAcknowledge(true);
        responseDTO.setSuccessMsg("Rule mapping deleted successfully");
        
        log.info(watch.prettyPrint());
        return responseDTO;
	}

	private void deleteRuleMappings(Long moduleId, UUID layoutId, List<UUID> existingRuleMappingIds) {
		log.info("Existing rule mapping ids :: "+existingRuleMappingIds);
		coreLayoutRuleMappingDAO.deleteRuleMappingByModuleIdLayoutIdAndRuleMappingIds(moduleId, layoutId, existingRuleMappingIds);
	}

}
