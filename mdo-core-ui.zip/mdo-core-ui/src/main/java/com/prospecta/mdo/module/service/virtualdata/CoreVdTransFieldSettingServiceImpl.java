package com.prospecta.mdo.module.service.virtualdata;

import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpTransInfoDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdTransFieldSettingDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdTransFieldSettingRequestDTO;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class CoreVdTransFieldSettingServiceImpl implements CoreVdTransFieldSettingService {

	@Autowired
	private CoreVdTransFieldSettingDAO coreVdTransFieldSettingDAO;

	@Autowired
	private CoreVdGroupsDAO coreVdGroupsDAO;

	@Autowired
	private CoreVdGrpTransInfoDAO coreVdGrpTransInfoDAO;
	
	String message = "Delete Group Information by virtual dataset Started";
	/**
     * This method is used to get the virtual dataset transformation field setting by vd id.
     * @param vdId
     */
	@Override
	public CoreVdTransFieldSettingModel getVdTransFieldSettingbyFieldId(UUID fieldId) {
		StopWatch watch = new StopWatch();
		watch.start("Get Core vd Group Information");
		Optional<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModel = coreVdTransFieldSettingDAO.findById(fieldId);
		if (!coreVdTransFieldSettingModel.isPresent()) {
			throw new NotFound404Exception("Virtual dataset group trans field setting not found");
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdTransFieldSettingModel.get();
	}
	
	
	/**
     * This method is used to get the virtual dataset transformation field setting by group id.
     * @param groupId
     */
	@Override
	public List<CoreVdTransFieldSettingModel> getVdTransFieldSettingbygroupId(UUID groupId) {
		StopWatch watch = new StopWatch();
		watch.start("Get List of Core vd Group Trans Field Information");
		Optional<CoreVdGroupsModel> coreVdGroupsModel = coreVdGroupsDAO.findById(groupId);
		if (!coreVdGroupsModel.isPresent()) {
			throw new NotFound404Exception("Virtual dataset groups not found");
		}
		List<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModel = coreVdTransFieldSettingDAO
				.findByCoreVdGroups(coreVdGroupsModel.get());
		if (coreVdTransFieldSettingModel.isEmpty()) {
			throw new NotFound404Exception("Virtual dataset groups not found");
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdTransFieldSettingModel;
	}
	
	/**
     * This method is used to get the virtual dataset transformation field setting by transformation id.
     * @param transformationId
     */
	@Override
	public List<CoreVdTransFieldSettingModel> getVdTransFieldSettingbytransformationId(UUID transformationId) {
		StopWatch watch = new StopWatch();
		watch.start("Get List of Core vd Group Trans Field Information");
		Optional<CoreVdGrpTransInfoModel> coreVdGrpTransInfoModel = coreVdGrpTransInfoDAO.findById(transformationId);
		if (!coreVdGrpTransInfoModel.isPresent()) {
			throw new NotFound404Exception("Virtual dataset group trans info not found");
		}
		List<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModel = coreVdTransFieldSettingDAO
				.findByCoreVdGrpTransInfo(coreVdGrpTransInfoModel.get());
		if (coreVdTransFieldSettingModel.isEmpty()) {
			throw new NotFound404Exception("Virtual dataset group trans field setting not found");
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdTransFieldSettingModel;
	}
	
	/**
     * This method is used to delete the virtual dataset transformation field setting by field id.
     * @param fieldId
     */
	@Override
	public void deleteVdTransFieldSettingbyFieldId(UUID fieldId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Trans Field Setting Information");
		watch.start("Delete vd groups");
		coreVdTransFieldSettingDAO.deleteById(fieldId);
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to delete the virtual dataset transformation field setting by group id.
     * @param groupId
     */
	@Override
	public void deleteVdTransFieldSettingbygroupId(UUID groupId) {
		StopWatch watch = new StopWatch();
		log.info(message);
		watch.start(message);
		Optional<CoreVdGroupsModel> coreVdGroupsModel = coreVdGroupsDAO.findById(groupId);
		if (!coreVdGroupsModel.isPresent()) {
			throw new NotFound404Exception("Virtual dataset header not found");
		}
		coreVdTransFieldSettingDAO.deleteByCoreVdGroups(coreVdGroupsModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to delete the virtual dataset transformation field setting by transformation id.
     * @param transformationId
     */
	@Override
	public void deleteVdTransFieldSettingbytransformationId(UUID transformationId) {
		StopWatch watch = new StopWatch();
		log.info(message);
		watch.start("Delete vd groups Information");
		Optional<CoreVdGrpTransInfoModel> coreVdGrpTransInfoModel = coreVdGrpTransInfoDAO.findById(transformationId);
		if (!coreVdGrpTransInfoModel.isPresent()) {
			throw new NotFound404Exception("Virtual dataset header not found");
		}
		coreVdTransFieldSettingDAO.deleteByCoreVdGrpTransInfo(coreVdGrpTransInfoModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to save/update the virtual dataset transformation field setting
     * @param groupTransFieldSettingRequestDTO
     * @param coreVdGrpTransInfoModel
     */
	@Override
	public CoreVdTransFieldSettingModel saveAndUpdateTransFieldSetting(VdTransFieldSettingRequestDTO groupTransFieldSettingRequestDTO, CoreVdGrpTransInfoModel coreVdGrpTransInfoModel) {
		if (groupTransFieldSettingRequestDTO != null) {
			if (coreVdGrpTransInfoModel != null) {
				StopWatch watch = new StopWatch();
				CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = new CoreVdTransFieldSettingModel();
				try {
					log.info("Store virtal dataset transformation field setting started");
					watch.start("Store virtal dataset transformation field setting");
					copyProperties(groupTransFieldSettingRequestDTO, coreVdTransFieldSettingModel);
					if (groupTransFieldSettingRequestDTO.getTransFieldId() == null) {
						coreVdTransFieldSettingModel.setTransId(UUID.randomUUID());
					} else {
						coreVdTransFieldSettingModel.setTransId(groupTransFieldSettingRequestDTO.getTransFieldId());
					}
					coreVdTransFieldSettingModel.setCoreVdGroups(coreVdGrpTransInfoModel.getCoreVdGroups());
					coreVdTransFieldSettingModel.setCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
					coreVdTransFieldSettingModel.setRuleType(groupTransFieldSettingRequestDTO.getTransRuleType());
					coreVdTransFieldSettingModel.setIsCustomField(groupTransFieldSettingRequestDTO.isCustomField());
					coreVdTransFieldSettingModel.setIsGroupBy(groupTransFieldSettingRequestDTO.isGroup());
					coreVdTransFieldSettingModel = coreVdTransFieldSettingDAO.save(coreVdTransFieldSettingModel);
					watch.stop();
				} catch (Exception e) {
					log.error("error while store virtal dataset transformation field setting: " + e.getMessage());
					throw new CommonVirtualDatasetException(e.getMessage());
				}
				log.info(watch.prettyPrint());
				return coreVdTransFieldSettingModel;
			} else {
				throw new NotFound404Exception("Virtual group tranformation is not present while storing tranformation field setting information.");
			}
		} else {
			throw new NotFound404Exception("Virtual data tranformation field setting information is not present while storing it.");
		}
	}

	/**
     * This method is used to delete the virtual dataset transformation field setting
     * @param groupTransFieldSetting
     * @param uuid
     */
	@Override
	public void deleteVdTransFieldSetting(List<VdTransFieldSettingRequestDTO> groupTransFieldSetting, UUID groupId) {
		StopWatch watch = new StopWatch();
		try {
			watch.start("Delete vd field setting information");
			log.info("Fetch the all field setting information with groupId and compare with new data");
			Optional<CoreVdGrpTransInfoModel> coreVdGrpTransInfoModel = coreVdGrpTransInfoDAO.findById(groupId);
			if (!coreVdGrpTransInfoModel.isPresent()) {
				log.error("Virtual groups Transformation information not found");
				throw new NotFound404Exception("Virtual groups Transformation information not found");
			}
			List<UUID> newtransFieldId = groupTransFieldSetting.stream().filter(g -> g.getTransFieldId() != null)
					.map(VdTransFieldSettingRequestDTO::getTransFieldId).collect(Collectors.toList());
			List<UUID> transFieldId = coreVdTransFieldSettingDAO.findByCoreVdGrpTransInfo(coreVdGrpTransInfoModel.get())
					.stream().filter(grp -> !newtransFieldId.contains(grp.getTransId()))
					.map(CoreVdTransFieldSettingModel::getTransId).collect(Collectors.toList());
			log.info("Delete all the field setting information data if user deleted any");
			coreVdTransFieldSettingDAO.deleteByTransIdIn(transFieldId);
			watch.stop();
			log.info(watch.prettyPrint());
		} catch (Exception e) {
			log.error("error while Delete vd field setting information: " + e.getMessage());
			throw new CommonVirtualDatasetException(e.getMessage());
		}
	}
}