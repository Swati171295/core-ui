package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import lombok.Data;

@Data
public class VdTransRuleConcatResponseDTO {
	
	private UUID vdConcatId;
	
	private String fieldType;
	
	private String fieldValue;
	
	private String fieldName;

}
