package com.prospecta.mdo.module.service.virtualdata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Splitter;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdHeaderDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdSchedulerDAO;
import com.prospecta.mdo.module.dto.virtualdata.*;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdSchedulerModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.springframework.beans.BeanUtils.copyProperties;

@Service
@Slf4j
public class CoreVdSchedulerServiceImpl implements CoreVdSchedulerService{

	@Autowired
	private CommonService commonService;
	
	@Autowired
	private CoreVdSchedulerDAO coreVdSchedulerDAO;
	
	@Autowired
	private CoreVdHeaderDAO coreVdHeaderDAO;
	
	@Autowired
	private WebClientImpl webClientImpl;
	
	@Value("${server.canonical.url:localhost}")
	private String serverUrl;
	
	@Value("${spark.classname:com.default}")
	private String sparkClassName;
	
	@Value("${spark.param:hdfsurl}")
	private String sparkHdfsParam;
	
	@Value("${spark.filepath:testfilepath}")
	private String sparkFilepath;
	
	/**
	 * This method is used to store scheduler information to database.
	 * @param coreVdSchedulerRequestDTO
	 * @param tokenKey
	 * @return CommonResponseDTO
	 */
	@Override
	@Transactional
	public CommonResponseDTO scheduleJob(CoreVdSchedulerRequestDTO coreVdSchedulerRequestDTO,String tokenKey) {
		if (coreVdSchedulerRequestDTO != null) {
			StopWatch watch = new StopWatch();
			Long timeDiff = coreVdSchedulerRequestDTO.getEndTime().getTime() - coreVdSchedulerRequestDTO.getStartTime().getTime();
			if( timeDiff < 86400000) {
				throw new CommonVirtualDatasetException("Diffrence between StartTime and EndTime should min One day.");
			}
			CoreVdSchedulerModel coreVdScheduler = null;
			try {
				log.info("start storing virtual dayaset scheduler information");
				watch.start("start store scheduler information to database");
				ObjectMapper mapper = new ObjectMapper();
				Object headerResponseDTO=commonService.getVirtualDataset(coreVdSchedulerRequestDTO.getVdId(), tokenKey).getData();				
				Optional<CoreVdHeaderModel> coreVdHeaderModel =coreVdHeaderDAO.findById(coreVdSchedulerRequestDTO.getVdId());
				CoreVdSchedulerModel schedulerModel = new CoreVdSchedulerModel();
				if(coreVdHeaderModel.isPresent()) {
					schedulerModel.setVdId(coreVdHeaderModel.get());
				}
				Optional<CoreVdSchedulerModel> coreVdSchedulerModel = coreVdSchedulerDAO.findByVdId(schedulerModel.getVdId());
				if (coreVdSchedulerModel.isPresent()) {
					schedulerModel = coreVdSchedulerModel.get();
				}else {
					schedulerModel.setSchedulerId(UUID.randomUUID());
				}
				copyProperties(coreVdSchedulerRequestDTO,schedulerModel);
				
				schedulerModel.setRestParams(mapper.writeValueAsString(coreVdSchedulerRequestDTO.getRestParams()));
				schedulerModel.setVdObject(mapper.writeValueAsString(headerResponseDTO));
				schedulerModel.setTenantId(coreVdSchedulerRequestDTO.getTenantId());
				schedulerModel.setRestMethod(HttpMethod.valueOf(coreVdSchedulerRequestDTO.getRestMethod().toUpperCase()));
				coreVdScheduler = coreVdSchedulerDAO.save(schedulerModel);
				if(!scheduleJobForRest(coreVdScheduler,tokenKey)) {
					throw new CommonVirtualDatasetException("Error while scheduling a job for virtual dataset.");
				}
			} catch (Exception e) {
				log.error("error while schedule job: " + e.getMessage());
				throw new CommonVirtualDatasetException(e.getMessage());
			}
			watch.stop();
			log.info(watch.prettyPrint());
			CoreVdSchedulerResponseDTO coreVdSchedulerResponseDTO = new CoreVdSchedulerResponseDTO(coreVdScheduler.getSchedulerId(),coreVdScheduler.getVdId().getVdId());
			return new CommonResponseDTO(201,true,"Your job has been scheduled successfully.",coreVdSchedulerResponseDTO);
		} else {
			throw new CommonVirtualDatasetException("");
		}
	}

	/**
	 * This method is used to schedule a job.
	 * @param coreVdScheduler
	 * @param tokenKey
	 * @return boolean
	 */
	private boolean scheduleJobForRest(CoreVdSchedulerModel coreVdScheduler,String tokenKey) {
		try {
			log.info("start schedule a job for virtual dataset.");
			RestJobRequestDTO restJobRequestDTO = new RestJobRequestDTO();
			copyProperties(coreVdScheduler, restJobRequestDTO);
			restJobRequestDTO.setJobId(coreVdScheduler.getSchedulerId());
			restJobRequestDTO.setVdId(coreVdScheduler.getVdId().getVdId());
			restJobRequestDTO.setMs("CORE");
			restJobRequestDTO.setFqdn(serverUrl.replace("/core",""));
			restJobRequestDTO.setStartTime(coreVdScheduler.getStartTime().getTime());
			restJobRequestDTO.setEndTime(coreVdScheduler.getEndTime().getTime());
			restJobRequestDTO.setRestParams(Splitter.on(",").withKeyValueSeparator(":").split(coreVdScheduler.getRestParams().replace("{", "").replace("}", "")));
			webClientImpl.saveScheduleJob(restJobRequestDTO, tokenKey);
			return true;
		}catch (Exception e) {
			log.error("error while schedule job: " + e.getMessage());
			return false;
		}
		
	}

	/**
	 * This method is used to send scheduler information to spark.
	 * @param vdId
	 * @param tokenKey
	 * @return CommonResponseDTO
	 */
	@Override
	public CommonResponseDTO sendToSparkJob(UUID vdId, String tokenKey) {
		if (vdId != null) {
			StopWatch watch = new StopWatch();
			try {
				log.info("start sending virtual dataset with job details to spark.");
				watch.start("start sending scheduler information to spark");
				Optional<CoreVdHeaderModel> coreVdHeaderModel = coreVdHeaderDAO.findById(vdId);
				if (coreVdHeaderModel.isPresent()) {
					Optional<CoreVdSchedulerModel> coreVdSchedulerModel = coreVdSchedulerDAO.findByVdId(coreVdHeaderModel.get());
					if (!coreVdSchedulerModel.isPresent()) {
						throw new CommonVirtualDatasetException("Job is not schedule yet for provided virtal dataset");
					}

					String schedulerId = coreVdSchedulerModel.get().getSchedulerId().toString();
					List<String> syncparam = new ArrayList<>();
					syncparam.add(schedulerId);
					syncparam.add(sparkHdfsParam);

					SyncReqDTO syncReq = new SyncReqDTO();
					syncReq.setClassName(sparkClassName);
					syncReq.setFile(sparkFilepath);
					syncReq.setArgs(syncparam);		
					log.info("syncReq {}",syncReq);
					ResponseEntity<HashMap> responseValidate = webClientImpl.sendToSpark(syncReq,tokenKey);
					log.info("responseValidate {}",responseValidate);
					watch.stop();
					log.info(watch.prettyPrint());
					return new CommonResponseDTO(200, true,
							"Scheduler information are successfully submited to spark job.");
				} else {
					log.error("Virtual dataset not found for provided id.");
					throw new CommonVirtualDatasetException("Virtual dataset not found for provided id.");
				}
			} catch (Exception e) {
				log.error("Error while send schedule data to spark job.");
				throw new CommonVirtualDatasetException("Error while send schedule data to spark job.");
			}
		} else {
			log.error("Virtual dataset id must not be null.");
			throw new CommonVirtualDatasetException("Virtual dataset id must not be null.");
		}
	}
}
