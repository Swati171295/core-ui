package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
@Data
public class VdGroupResultsRequestDTO {
	
	@ApiModelProperty(
			name = "uuid",
			value = "UUID is the unique id of user",
			dataType = "java.util.UUID;",
			required = true
	)
	public UUID resultId;
	
	@ApiModelProperty(
			name = "source",
			value = "Source which will be given by frontend which can be either system table or table name",
			dataType = "java.util.String",
			required = true
	)
	public String source;
	
	@ApiModelProperty(
			name = "fieldId",
			value = "Field id contains result of field1 ",
			dataType = "java.util.String",
			required = true
	)
	public String fieldId;
	
	@ApiModelProperty(
			name = "fieldAlias",
			value = "fieldAlias will contain temporary name",
			dataType = "java.util.String",
			required = true
	)
	public String fieldAlias;

	@ApiModelProperty(
			name = "order",
			value = "Short representing the order of virtual datasets as per their name ",
			dataType = "java.lang",
			required = true
	)
	public Short order;
	
}