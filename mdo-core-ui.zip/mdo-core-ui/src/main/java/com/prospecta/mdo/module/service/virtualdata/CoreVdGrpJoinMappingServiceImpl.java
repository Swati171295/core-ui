package com.prospecta.mdo.module.service.virtualdata;

import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpJoinInfoDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpJoinMappingDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinMappingRequestDTO;
import com.prospecta.mdo.module.enums.CompareOperator;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinMappingModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class CoreVdGrpJoinMappingServiceImpl implements CoreVdGrpJoinMappingService {

	@Autowired
	private CoreVdGrpJoinMappingDAO coreVdGrpJoinMappingDAO;
	
	@Autowired
	private CoreVdGrpJoinInfoDAO coreVdGrpJoinInfoDAO;
	
	String message = "Virtual dataset group join mapping not found";

	/**
     * This method is used to get the virtual dataset join mapping by mapping id.
     * @param mappingId
     */
	@Override
	public CoreVdGrpJoinMappingModel getVdGroupJoinMappingbyMappingId(UUID mappingId) {
		StopWatch watch = new StopWatch();
		watch.start("Get Core vd Group Join Mapping");
		Optional<CoreVdGrpJoinMappingModel> coreVdGrpJoinMappingModel=coreVdGrpJoinMappingDAO.findById(mappingId);
		if (!coreVdGrpJoinMappingModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGrpJoinMappingModel.get();
	}
	
	/**
     * This method is used to get the virtual dataset join mapping by group info id.
     * @param groupInfoId
     */
	@Override
	public List<CoreVdGrpJoinMappingModel> getVdGroupJoinMappingbygroupInfoId(UUID groupInfoId) {
		StopWatch watch = new StopWatch();
		watch.start("Get List of Core vd Group Join Mapping");
		Optional<CoreVdGrpJoinInfoModel> coreVdGrpJoinInfoModel=coreVdGrpJoinInfoDAO.findById(groupInfoId);
		if (!coreVdGrpJoinInfoModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		List<CoreVdGrpJoinMappingModel> coreVdGrpJoinMappingModel=coreVdGrpJoinMappingDAO.findByCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel.get());
		if (coreVdGrpJoinMappingModel.isEmpty()) {
			throw new NotFound404Exception(message);
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGrpJoinMappingModel;
	}
	
	/**
     * This method is used to delet the virtual dataset join mapping by mapping id.
     * @param mappingId
     */
	@Override
	public void deleteVdGroupJoinMappingbyMappingId(UUID mappingId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Join Mapping");
		watch.start("Delete vd group join mapping");
		coreVdGrpJoinMappingDAO.deleteById(mappingId);
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to delet the virtual dataset join mapping by group info id.
     * @param groupInfoId
     */
	@Override
	public void deleteVdGroupJoinMappingbygroupInfoId(UUID groupInfoId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Information by virtual dataset Started");
		watch.start("Delete vd groups");
		Optional<CoreVdGrpJoinInfoModel> coreVdGrpJoinInfoModel=coreVdGrpJoinInfoDAO.findById(groupInfoId);
		if (!coreVdGrpJoinInfoModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		coreVdGrpJoinMappingDAO.deleteByCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
	}

	/**
     * This method is used to delet the virtual dataset join mapping by group info id.
     * @param joinMapping
     * @param joinInfoId
     */
	@Override
	public void deleteVdGrpJoinMapping(List<VdGroupJoinMappingRequestDTO> joinMapping, UUID joinInfoId) {
		StopWatch watch = new StopWatch();
		try {
			watch.start("Delete vd group mapping information");
			log.info("Fetch the all group mapping information with join information id and compare with new data");
			Optional<CoreVdGrpJoinInfoModel> coreVdGrpJoinInfoModel = coreVdGrpJoinInfoDAO.findById(joinInfoId);
			if (!coreVdGrpJoinInfoModel.isPresent()) {
				log.error(message);
				throw new NotFound404Exception(message);
			}
			List<UUID> newJoinMapping = joinMapping.stream().filter(g -> g.getJoinMappingId() != null)
					.map(VdGroupJoinMappingRequestDTO::getJoinMappingId).collect(Collectors.toList());
			List<UUID> joinMappingIds = coreVdGrpJoinMappingDAO.findByCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel.get())
					.stream().filter(grp -> !newJoinMapping.contains(grp.getUuid()))
					.map(CoreVdGrpJoinMappingModel::getUuid).collect(Collectors.toList());
			log.info("Delete all the group mapping information data if user deleted any");
			coreVdGrpJoinMappingDAO.deleteByUuidIn(joinMappingIds);
			watch.stop();
			log.info(watch.prettyPrint());
		} catch (Exception e) {
			log.error("error while Delete vd group mapping information: " + e.getMessage());
			throw new CommonVirtualDatasetException(e.getMessage());
		}
	}

	/**
     * This method is used to save or update join mapping information.
     * @param groupJoinMappingRequestDTO
     * @param coreVdGrpJoinInfoModel
     */
	@Override
	public CoreVdGrpJoinMappingModel saveAndUpdateJoinMapping(VdGroupJoinMappingRequestDTO groupJoinMappingRequestDTO,
			CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel) {
		if (groupJoinMappingRequestDTO != null) {
			if (coreVdGrpJoinInfoModel != null) {
				StopWatch watch = new StopWatch();
				CoreVdGrpJoinMappingModel coreVdGrpJoinMappingModel = new CoreVdGrpJoinMappingModel();
				try {
					log.info("Store virtal dataset group join mapping information Started");
					watch.start("Store virtal dataset group join mapping information.");
					copyProperties(groupJoinMappingRequestDTO, coreVdGrpJoinMappingModel);
					if (groupJoinMappingRequestDTO.getJoinMappingId() == null) {
						coreVdGrpJoinMappingModel.setUuid(UUID.randomUUID());
					} else {
						coreVdGrpJoinMappingModel.setUuid(groupJoinMappingRequestDTO.getJoinMappingId());
					}
					coreVdGrpJoinMappingModel.setCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel);
					coreVdGrpJoinMappingModel.setSourceOneFieldId(groupJoinMappingRequestDTO.getSourceOneField());
					coreVdGrpJoinMappingModel.setSourceTwoFieldId(groupJoinMappingRequestDTO.getSourceTwoField());
					coreVdGrpJoinMappingModel.setOrder(groupJoinMappingRequestDTO.getOrderBy());
					coreVdGrpJoinMappingModel
							.setCompareOperator(CompareOperator.fromValue(groupJoinMappingRequestDTO.getOperator().toUpperCase()));
					coreVdGrpJoinMappingModel = coreVdGrpJoinMappingDAO.save(coreVdGrpJoinMappingModel);
					watch.stop();
				} catch (Exception e) {
					log.error("error while Store virtal dataset group join mapping information: " + e.getMessage());
					throw new CommonVirtualDatasetException(e.getMessage());
				}
				log.info(watch.prettyPrint());
				return coreVdGrpJoinMappingModel;
			} else {
				log.error("Virtual join information is not present while storing group join mapping.");
				throw new NotFound404Exception(
						"Virtual join information is not present while storing group join mapping.");
			}
		} else {
			log.error("Virtual group join mapping is not present while storing it.");
			throw new NotFound404Exception("Virtual group join mapping is not present while storing it.");
		}

	}

}
