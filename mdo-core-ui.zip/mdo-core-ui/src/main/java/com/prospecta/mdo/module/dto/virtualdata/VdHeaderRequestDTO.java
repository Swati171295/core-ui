package com.prospecta.mdo.module.dto.virtualdata;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class VdHeaderRequestDTO {
	
	
	public VdHeaderRequestDTO() {
		super();
	}

	public VdHeaderRequestDTO(String vdName, String vdDescription) {
		super();
		this.vdName = vdName;
		this.vdDescription = vdDescription;
	}
	
	@ApiModelProperty(
			name = "vdId",
			value = "UUID representing Virtual dataset id",
			dataType = "java.util.UUID;",
			required = true
	)
	public UUID vdId;
	
	@ApiModelProperty(
			name = "vdName",
			value = "vdName is the name of virtual dataset",
			dataType = "java.lang.String",
			required = true
	)
	@NotEmpty(message = "vdName must not be empty")
	@NotNull(message = "vdName must not be null")
	public String vdName;
	
	@ApiModelProperty(
			name = "indexName",
			value = "Elastic Index name for reference of dataset e.g. dyn_vd_do_{VD_ID}",
			dataType = "java.lang.String",
			required = true
	)
	public String indexName;

	@ApiModelProperty(
			name = "tableName",
			value = "Name of table e.g. dyn_{VD_ID}",
			dataType = "java.lang.String",
			required = true
	)
	public String tableName;
	
	@ApiModelProperty(
			name = "tenantId",
			value = "Tenant Id of the client. Can’t be null or empty",
			dataType = "java.lang.String",
			required = true
	)
	public String tenantId;
	
	@ApiModelProperty(
			name = "userCreated",
			value = "User who created this Data set",
			dataType = "java.lang.String",
			required = true
	)
	public String userCreated;
	
	@ApiModelProperty(
			name = "dateCreated",
			value = "dateCreated is the Date of creation",
			dataType = "java.lang.Long",
			required = true
	)
	public Long dateCreated;
	
	@ApiModelProperty(
			name = "userModified",
			value = "User who last modified the dataset",
			dataType = "java.lang.String",
			required = true
	)
	public String userModified;
	
	@ApiModelProperty(
			name = "dateModified",
			value = "dateModified is the date of modification in the data set configuration",
			dataType = "java.lang.Long",
			required = true
	)
	public Long dateModified;
	
	@ApiModelProperty(
			name = "vdDescription",
			value = "Description of virtual database",
			dataType = "java.lang.String",
			required = true
	)
	public String vdDescription;
	
	@ApiModelProperty(
			name = "jobSchedularId",
			value = "Scheduler entry to get the reference of job scheduled against the dataset. Only one job can be scheduled at a time.",
			dataType = "java.lang.String",
			required = true
	)
	public String jobSchedulerId;
	
	List<@Valid VdGroupsRequestDTO> groupDetails = new ArrayList<>();
	
	List<@Valid VdGroupResultsRequestDTO> groupResult = new ArrayList<>();
	
}
