package com.prospecta.mdo.module.dto.module;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class ModuleDescriptionInformationRequestDTO implements Serializable {

    @ApiModelProperty(
            name = "description",
            value = "String representing description",
            dataType = "java.lang.String"
    )
    private String description;

    @ApiModelProperty(
            name = "information",
            value = "String representing information",
            dataType = "java.lang.String"
    )
    private String information;
}
