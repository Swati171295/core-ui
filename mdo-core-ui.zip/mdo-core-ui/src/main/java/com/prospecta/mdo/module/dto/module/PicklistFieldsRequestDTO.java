/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PicklistFieldsRequestDTO {
	@ApiModelProperty(
			name = "pickList",
			value = "String representing Pick List",
			dataType = "java.lang.String"
	)
	private String pickList;
	@ApiModelProperty(
			name = "description",
			value = "String representing description",
			dataType = "java.lang.String"
	)
	private String description;
	
}
