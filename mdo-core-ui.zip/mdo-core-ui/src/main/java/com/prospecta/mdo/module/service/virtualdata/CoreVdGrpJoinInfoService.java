package com.prospecta.mdo.module.service.virtualdata;

import java.util.List;
import java.util.UUID;

import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinInfoRequestDTO;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinInfoModel;

public interface CoreVdGrpJoinInfoService {
	
	CoreVdGrpJoinInfoModel getVdJoinInfobyJoinId(UUID joinId);
	
	List<CoreVdGrpJoinInfoModel> getVdJoinInfobyGroupId(UUID groupId);	
	
	void deleteVdJoinInfobyJoinId(UUID joinId);
	
	void deleteVdJoinInfobyGroupId(UUID groupId);

	void deleteVdGroupInfo(List<VdGroupJoinInfoRequestDTO> groupJoinDetail, UUID groupId);

	CoreVdGrpJoinInfoModel saveAndUpdateGrpJoinInfo(VdGroupJoinInfoRequestDTO groupJoinInfoRequestDTO,
			CoreVdGroupsModel coreVdGroupsModel);
	
}
