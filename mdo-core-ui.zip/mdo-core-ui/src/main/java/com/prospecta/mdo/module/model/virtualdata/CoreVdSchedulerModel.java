package com.prospecta.mdo.module.model.virtualdata;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.springframework.http.HttpMethod;

import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;

@Data
@Entity
@Audited
@Table(name = "CORE_VD_SCHEDULER")
@DynamicInsert
public class CoreVdSchedulerModel implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3300363470868026657L;
	
	@Id
	@Type(type = "uuid-char")
	@Column(name = "SCHEDULER_ID")
	private UUID schedulerId;
	
	@JsonIgnore
	@OneToOne
	@JoinColumn(name = "VD_ID", nullable = false)
	private CoreVdHeaderModel vdId;
	
	@Column(name = "VD_OBJECT", columnDefinition = "clob")
	private String vdObject;	
	
	@Column(name = "REST_ENDPOINT", columnDefinition = "nvarchar(200)")
	private String restEndpoint;
	
	@Column(name = "REST_PARAMS", columnDefinition = "clob")
	private String restParams;
	
	@Column(name = "REST_BODY", columnDefinition = "nvarchar(200)")
	private String restBody;
	
	@Column(name = "REST_METHOD", columnDefinition = "nvarchar(20)")
	@Enumerated(EnumType.STRING)
	private HttpMethod restMethod;
	
	@Column(name = "TENANT_ID", columnDefinition = "nvarchar(100)")
	private String tenantId;
	
	@Column(name = "START_TIME", columnDefinition = "nvarchar(100)")
	private Timestamp startTime;
	
	@Column(name = "END_TIME", columnDefinition = "nvarchar(100)")
	private Timestamp endTime;
	
	@Column(name = "CRON", columnDefinition = "nvarchar(200)")
	private String cron;

}
