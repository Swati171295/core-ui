/**
 * 
 */
package com.prospecta.mdo.module.dao.layout;

import com.prospecta.mdo.module.model.layout.CoreLayoutHeaderModel;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static com.prospecta.mdo.module.util.QueryConstants.LAYOUT_LIST;

/**
 * @author savan
 *
 */
@Repository
public interface CoreLayoutHeaderDAO extends PagingAndSortingRepository<CoreLayoutHeaderModel, UUID> {

	CoreLayoutHeaderModel findByLayoutIdAndModuleIdAndTenantId(UUID layoutid, Long moduleid, String tenantCode);

	Optional<CoreLayoutHeaderModel> findByLayoutIdAndTenantId(UUID layoutId,String tenantCode);

	@Query(LAYOUT_LIST)
	List<CoreLayoutHeaderModel> findLayoutList(@Param("moduleId") Long moduleId, @Param("tenantId") String tenantId,
											   @Param("type") List<Short> type, @Param("userCR") List<String> userCr,@Param("userMo") List<String> userMo,
											   @Param("dateCR") Long dateCr , @Param("dateMo") Long dateMo,
											   @Param("searchTerm") String searchTerm, Pageable pageable);

	Long countByModuleIdAndTenantId(Long moduleId,String tenantId);
}
