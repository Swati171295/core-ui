package com.prospecta.mdo.module.dto.virtualdata;

import java.util.Map;
import java.util.UUID;

import org.springframework.http.HttpMethod;

import lombok.Data;

@Data
public class RestJobRequestDTO {
	
	private UUID jobId;
	private UUID vdId;
	private String tenantId;
	private String ms;
	private String vdObject;
	private String restEndpoint;
	private Map<String, String> restParams;
	private String restBody;
	private HttpMethod restMethod;	
	private Long startTime;
	private Long endTime;
	private String cron;
	private String fqdn;

}
