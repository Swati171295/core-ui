package com.prospecta.mdo.module.model.virtualdata;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import com.prospecta.mdo.module.enums.CompareOperator;

import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;

/**
 * @author komal
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_VD_GRP_JOIN_ON")
@DynamicInsert
public class CoreVdGrpJoinOnModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5751487234989225249L;

	@Id
	@Type(type = "uuid-char")
	@Column(name = "JOIN_ON_ID")
	private UUID joinOnId;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "GRP_INFO_ID", nullable = false)
	private CoreVdGroupsModel coreVdGroups;
	
	@Column(name = "SOURCE_ONE", columnDefinition = "nvarchar(100)")
	private String sourceOne;
	
	@Column(name = "SOURCE_ONE_FIELDID", columnDefinition = "nvarchar(100)")
	private String sourceOneFieldId;
	
	@Column(name = "SOURCE_TWO", columnDefinition = "nvarchar(100)")
	private String sourceTwo;
	
	@Column(name = "SOURCE_TWO_FIELDID", columnDefinition = "nvarchar(100)")
	private String sourceTwoFieldId;
	
	@Column(name = "COMPARE_OPERATOR")
	private CompareOperator compareOperator;
	

}
