/**
 * 
 */
package com.prospecta.mdo.module.dto.layout;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FetchedLayoutDTO {
	
	private UUID tcode;

	private String tabText;
	
	private String information;
	
	private Boolean isTabReadOnly;

	private Boolean isTabHidden;

	private String layoutId;
	
	private Short tabOrder;

	private UUID udrId;
	
	private List<LayoutFieldsDTO> fields;

}
