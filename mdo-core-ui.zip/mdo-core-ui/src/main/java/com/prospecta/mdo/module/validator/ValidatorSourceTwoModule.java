package com.prospecta.mdo.module.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ValidatorSourceTwoModule implements ConstraintValidator<ValidateSourceTwoModule, Object> {
	
	private static Logger log = LoggerFactory.getLogger(ValidatorSourceTwoModule.class.getName());
	private String fieldName;
	private String expectedFieldValue;
	private String dependFieldName;
	private String message;

	@Override
	public void initialize(ValidateSourceTwoModule annotation) {
		fieldName = annotation.fieldName();
		expectedFieldValue = annotation.fieldValue();
		dependFieldName = annotation.dependFieldName();
		message=annotation.message();
	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext ctx) {
		if (value == null) {
			return true;
		}
		try {
			String fieldValue = BeanUtils.getProperty(value, fieldName);
			String dependFieldValue = BeanUtils.getProperty(value, dependFieldName);
			String msgFormatada = String.format(message, fieldValue);
			if (expectedFieldValue.equalsIgnoreCase(fieldValue) && dependFieldValue == null) {
				ctx.disableDefaultConstraintViolation();
				ctx.buildConstraintViolationWithTemplate(msgFormatada).addConstraintViolation();
				return false;
			}

		} catch (Exception e) {
			log.error("Accessor method is not available for class : {}, exception : {}", value.getClass().getName(), e);
			return false;
		}

		return true;
	}

}
