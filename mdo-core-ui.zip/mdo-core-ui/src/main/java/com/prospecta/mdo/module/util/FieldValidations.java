package com.prospecta.mdo.module.util;

public interface FieldValidations {
}
