/**
 * 
 */
package com.prospecta.mdo.module.dto.tab;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TabFieldResponseDTO {

	private UUID tCode;

	private List<String> fieldIs;

	private List<String> uuidList;

	private List<UUID> tabFieldUuids;

	private boolean acknowledge;

	private String errorMsg;

	private String successMsg;
	
}
