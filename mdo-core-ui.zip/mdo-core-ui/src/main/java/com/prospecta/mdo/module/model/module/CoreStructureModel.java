/**
 *
 */
package com.prospecta.mdo.module.model.module;

import lombok.Data;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author savan
 */
@Data
@Entity
@Table(name = "CORE_STRUCTURE_MDO")
@Audited
@IdClass(CoreStructureModelId.class)
public class CoreStructureModel implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -7782016831475827075L;

    @Id
    @Column(name = "STRUCTUREID", columnDefinition = "tinyint")
    private Short structureId;

    @Id
    @Column(name = "MODULEID")
    private Long moduleId;

    @Id
    @Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
    private String tenantId;

    @Column(name = "PARENT_STRUCID", columnDefinition = "tinyint")
    private Short parentStrucId;

    @Column(name = "IS_HEADER")
    private Boolean isHeader = true;

    @Column(name = "LANGUAGE")
    private String language;

    @Column(name = "STRUC_DESC", columnDefinition = "nvarchar(200)")
    private String strucDesc;
}
