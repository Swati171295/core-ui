/**
 * 
 */
package com.prospecta.mdo.module.dao.tab;

import java.util.UUID;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.tab.CoreTabLabelsModel;

/**
 * @author savan
 *
 */
@Repository
public interface CoreTabLabelsDAO extends PagingAndSortingRepository<CoreTabLabelsModel, UUID> {

	void deleteByTcode(UUID tcode);

	CoreTabLabelsModel findByTcodeAndLanguage(UUID tcode, String language);

}
