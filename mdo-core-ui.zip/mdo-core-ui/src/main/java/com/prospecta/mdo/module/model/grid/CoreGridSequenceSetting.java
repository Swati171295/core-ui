package com.prospecta.mdo.module.model.grid;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.util.UUID;

@Data
@Entity
@Audited
@Table(name = "CORE_GRID_SEQUENCE_SETTING")
@NoArgsConstructor
@IdClass(CompositeSequenceSettingId.class)
public class CoreGridSequenceSetting {

    @Id
    @Column(name="MODULE_ID")
    private Long moduleId;

    @Id
    @Column(name="TENANT_ID")
    private String tenantId;

    @Id
    @Type(type = "uuid-char")
    @Column(name="GRID_SETTING_UUID")
    private UUID gridSettingUuid;

    @Column(name="SEQUENCE_START")
    private Long sequenceStart;

    @Column(name="SEQUENCE_INTERVAL")
    private Integer sequenceInterval;

    public CoreGridSequenceSetting (Long moduleId,String tenantId,UUID gridSettingUuid) {
        this.moduleId=moduleId;
        this.tenantId =tenantId;
        this.gridSettingUuid=gridSettingUuid;
    }
}
