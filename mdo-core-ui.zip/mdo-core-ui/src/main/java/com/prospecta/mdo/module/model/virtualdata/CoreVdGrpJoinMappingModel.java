package com.prospecta.mdo.module.model.virtualdata;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import com.prospecta.mdo.module.enums.CompareOperator;

import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;

/**
 * @author komal
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_VD_GRP_JOIN_MAPPING")
@DynamicInsert
public class CoreVdGrpJoinMappingModel implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6420413656871914924L;

	@Id
	@Type(type = "uuid-char")
	@Column(name = "UUID")
	private UUID uuid;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "GRP_INFO_ID", nullable = false)
	private CoreVdGrpJoinInfoModel coreVdGrpJoinInfo;
	
	@Column(name = "SOURCE_ONE_FIELDID", columnDefinition = "nvarchar(100)")
	private String sourceOneFieldId;
	
	@Column(name = "SOURCE_TWO_FIELDID", columnDefinition = "nvarchar(100)")
	private String sourceTwoFieldId;
	
	@Column(name = "COMPARE_OPERATOR")
	private CompareOperator compareOperator;
	
	@Column(name = "ORDER_BY", columnDefinition = "tinyint")
	private Short order;

}
