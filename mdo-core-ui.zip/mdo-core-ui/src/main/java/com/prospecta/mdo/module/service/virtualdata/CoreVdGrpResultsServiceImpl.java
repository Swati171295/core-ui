package com.prospecta.mdo.module.service.virtualdata;

import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpResultsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdHeaderDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupResultsRequestDTO;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpResultsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class CoreVdGrpResultsServiceImpl implements CoreVdGrpResultsService {

	@Autowired
	private CoreVdGrpResultsDAO coreVdGrpResultsDAO;

	@Autowired
	private CoreVdHeaderDAO coreVdHeaderDAO;

	@Autowired
	private CoreVdGroupsDAO coreVdGroupsDAO;

	String message = "Virtual dataset group not found";
	
	String headerMessage = "Virtual dataset header not found";

	/**
     * This method is used to get the virtual dataset group results by vd id.
     * @param vdId
     */
	@Override
	public List<CoreVdGrpResultsModel> getVdResultbyvdId(UUID vdId) {
		StopWatch watch = new StopWatch();
		watch.start("Get List of Core vd Group Results Information");
		Optional<CoreVdHeaderModel> coreVdHeaderModel = coreVdHeaderDAO.findById(vdId);
		if (!coreVdHeaderModel.isPresent()) {
			throw new NotFound404Exception(headerMessage);
		}
		List<CoreVdGrpResultsModel> coreVdGrpResultsModel = coreVdGrpResultsDAO.findByCoreVdHeader(coreVdHeaderModel.get());
		if (coreVdGrpResultsModel.isEmpty()) {
			throw new NotFound404Exception(message);
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGrpResultsModel;
	}
	
	/**
     * This method is used to get the virtual dataset group results by group id.
     * @param groupId
     */
	@Override
	public List<CoreVdGrpResultsModel> getVdResultbygroupId(UUID groupId) {
		StopWatch watch = new StopWatch();
		watch.start("Get List of Core vd Group Results Information");
		Optional<CoreVdGroupsModel> coreVdGroupsModel = coreVdGroupsDAO.findById(groupId);
		if (!coreVdGroupsModel.isPresent()) {
			throw new NotFound404Exception(headerMessage);
		}
		List<CoreVdGrpResultsModel> coreVdGrpResultsModel = coreVdGrpResultsDAO.findByCoreVdGroups(coreVdGroupsModel.get());
		if (coreVdGrpResultsModel.isEmpty()) {
			throw new NotFound404Exception(message);
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGrpResultsModel;
	}
	
	/**
     * This method is used to delet the virtual dataset group results by vd id.
     * @param vdId
     */
	@Override
	public void deleteVdResultbyvdId(UUID vdId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Results Information by virtual dataset Started");
		watch.start("Delete vd groups");
		Optional<CoreVdHeaderModel> coreVdHeaderModel = coreVdHeaderDAO.findById(vdId);
		if (!coreVdHeaderModel.isPresent()) {
			throw new NotFound404Exception(headerMessage);
		}
		coreVdGrpResultsDAO.deleteByCoreVdHeader(coreVdHeaderModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
	}

	/**
     * This method is used to delet the virtual dataset group results by group id.
     * @param groupId
     */
	@Override
	public void deleteVdResultbygroupId(UUID groupId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Results Information by virtual dataset Started");
		watch.start("Delete vd groups");
		Optional<CoreVdGroupsModel> coreVdGroupsModel = coreVdGroupsDAO.findById(groupId);
		if (!coreVdGroupsModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		coreVdGrpResultsDAO.deleteByCoreVdGroups(coreVdGroupsModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to get the virtual dataset group results by result id.
     * @param resultId
     */
	@Override
	public CoreVdGrpResultsModel getVdResultbyresultId(UUID resultId) {
		StopWatch watch = new StopWatch();
		watch.start("Get Core vd Group Results Information");
		Optional<CoreVdGrpResultsModel> coreVdGrpResultsModel = coreVdGrpResultsDAO.findById(resultId);
		if (!coreVdGrpResultsModel.isPresent()) {
			throw new NotFound404Exception("Virtual dataset group results not found");
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGrpResultsModel.get();
	}
	
	/**
     * This method is used to delete the virtual dataset group results by result id.
     * @param resultId
     */
	@Override
	public void deleteVdResultbyresultId(UUID resultId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Results Information");
		watch.start("Delete vd group results");
		coreVdGrpResultsDAO.deleteById(resultId);
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to save/update the virtual dataset group results by result id.
     * @param resultId
     */
	@Override
	public CoreVdGrpResultsModel saveOrUpdateVdGroupResults(VdGroupResultsRequestDTO groupResultsRequestDTO, CoreVdGroupsModel coreVdGroups,CoreVdHeaderModel coreVdHeader) {
		if (groupResultsRequestDTO != null) {
			if (coreVdGroups != null) {
				if (coreVdHeader != null) {
					StopWatch watch = new StopWatch();
					CoreVdGrpResultsModel coreVdGrpResultsModel = new CoreVdGrpResultsModel();
					try {
						log.info("Store virtal dataset groups results started");
						watch.start("Store virtal dataset group results");
						copyProperties(groupResultsRequestDTO, coreVdGrpResultsModel);
						if (groupResultsRequestDTO.getResultId() == null) {
							coreVdGrpResultsModel.setUuid(UUID.randomUUID());
						} else {
							coreVdGrpResultsModel.setUuid(groupResultsRequestDTO.getResultId());
						}
						coreVdGrpResultsModel.setCoreVdGroups(coreVdGroups);
						coreVdGrpResultsModel.setCoreVdHeader(coreVdHeader);
						coreVdGrpResultsModel = coreVdGrpResultsDAO.save(coreVdGrpResultsModel);
						watch.stop();
					} catch (Exception e) {
						log.error("error while store virtal dataset group results: " + e.getMessage());
						throw new CommonVirtualDatasetException(e.getMessage());
					}
					log.info(watch.prettyPrint());
					return coreVdGrpResultsModel;
				} else {
					throw new NotFound404Exception(
							"Virtual data is not present while storing group results information.");
				}
			} else {
				throw new NotFound404Exception(
						"Virtual group data is not present while storing group results information.");
			}
		} else {
			throw new NotFound404Exception("Virtual data group results is not present while storing it.");
		}
	}

	/**
     * This method is used to delete the virtual dataset group results.
     * @param groupResult
     * @param groupId
     */
	@Override
	public void deleteVdGroupResults(List<VdGroupResultsRequestDTO> groupResult, UUID vdId) {
		StopWatch watch = new StopWatch();
		try {
			watch.start("Delete vd group result information");
			log.info("Fetch the all group result information with vdId and compare with new data");
			Optional<CoreVdHeaderModel> coreVdHeaderModel = coreVdHeaderDAO.findById(vdId);
			if (!coreVdHeaderModel.isPresent()) {
				log.error(headerMessage);
				throw new NotFound404Exception(headerMessage);
			}
			List<UUID> newresultId = groupResult.stream().filter(g -> g.getResultId() != null)
					.map(VdGroupResultsRequestDTO::getResultId).collect(Collectors.toList());
			List<UUID> resultId = coreVdGrpResultsDAO.findByCoreVdHeader(coreVdHeaderModel.get()).stream()
					.filter(grp -> !newresultId.contains(grp.getUuid())).map(CoreVdGrpResultsModel::getUuid)
					.collect(Collectors.toList());
			log.info("Delete all group result information data if user deleted any");
			coreVdGrpResultsDAO.deleteByUuidIn(resultId);
			watch.stop();
			log.info(watch.prettyPrint());
		} catch (Exception e) {
			log.error("error while Delete vd group result information: " + e.getMessage());
			throw new CommonVirtualDatasetException(e.getMessage());
		}
	}
	
}