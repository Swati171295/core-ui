package com.prospecta.mdo.module.service.metadata.elastic;

import com.prospecta.mdo.module.dto.metadata.BulkDeleteDTO;
import com.prospecta.mdo.module.dto.metadata.CreateFieldRequestDTO;
import com.prospecta.mdo.module.dto.metadata.CreateFieldResponseDTO;
import com.prospecta.mdo.module.dto.metadata.FieldIdsRequestDTO;
import com.prospecta.mdo.module.dto.module.FieldDTO;
import com.prospecta.mdo.module.dto.module.ModuleRequestDTO;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.metadata.elastic.UserFieldMetadata;
import com.prospecta.mdo.module.repository.metadata.UserFieldMetadataRepository;
import com.prospecta.mdo.module.service.metadata.CoreMetadataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CoreMetadataElasticServiceImpl implements CoreMetadataElasticService {

    public static final String ERROR = "Error while executing api: ";
    @Autowired
    CoreMetadataService coreMetadataService;
    @Autowired
    UserFieldMetadataRepository userFieldMetadataRepository;


    /**
     * This method will create/update the draft to ElasticSearch and return CreateFieldResponseDTO object
     *
     * @param fields
     * @param tenantCode
     * @param username
     * @param moduleId
     */
    @Override
    public CreateFieldResponseDTO createDraftField(CreateFieldRequestDTO fields, String tenantCode, String username, Long moduleId) {
        StopWatch watch = new StopWatch();

        CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();

        watch.start("Create metadata draft fields.");


        ModuleRequestDTO requestDto = new ModuleRequestDTO();
        requestDto.setFields(fields.getFields());

        //create dynamic fields if fieldId is null or empty
        List<String> dynamicFieldIds = coreMetadataService.createDynamicFieldIds(requestDto, moduleId, tenantCode,false);

        //create documents which needs to be drafted
        List<UserFieldMetadata> userFieldMetadataList = createUserFieldMetadata(fields, tenantCode, username, moduleId);
        userFieldMetadataRepository.saveAll(userFieldMetadataList);

        responseDTO.setAcknowledge(true);

        responseDTO.setDynamicFieldIds(userFieldMetadataList.parallelStream()
                .filter(field -> dynamicFieldIds.contains(field.getFieldId()))
                .map(UserFieldMetadata::getFieldId)
                .collect(Collectors.toList()));

        responseDTO.setDraftIds(userFieldMetadataList.parallelStream()
                .map(UserFieldMetadata::getId)
                .collect(Collectors.toList()));

        responseDTO.setSuccessMessage("Drafted Field Successfully");
        watch.stop();
        log.info(watch.prettyPrint());
        return responseDTO;

    }

    /**
     * This method will fetch the draft from ElasticSearch
     *
     * @param fieldId
     * @param tenantCode
     * @param username
     * @param moduleId
     */
    @Override
    public FieldDTO getDraftField(String fieldId, String tenantCode, String username, Long moduleId) {

        StopWatch watch = new StopWatch();

        watch.start("Get metadata draft fields.");

        //if Object Present then return it or else throw NOT FOUND Exception
        UserFieldMetadata fieldHistory = userFieldMetadataRepository
                .findByFieldIdAndModuleIdAndTenantIdAndUserId(fieldId, moduleId, tenantCode, username)
                .orElseThrow(() -> new NotFound404Exception("Field Details Not Found"));

        watch.stop();
        log.info(watch.prettyPrint());
        return fieldHistory.getFieldData();

    }

    @Override
    public CreateFieldResponseDTO deleteDraftField(String fieldId, String tenantCode, String username, Long moduleId) {
        StopWatch watch = new StopWatch();

        watch.start("Delete draft field");

        userFieldMetadataRepository.deleteByFieldIdAndModuleIdAndTenantIdAndUserId(fieldId,moduleId,tenantCode,username);

        watch.stop();
        log.info(watch.prettyPrint());

        CreateFieldResponseDTO responseDTO =new CreateFieldResponseDTO();
        responseDTO.setAcknowledge(true);

        responseDTO.setSuccessMessage("Drafted Field Deleted Successfully");
        return responseDTO;

    }

    @Override
    public BulkDeleteDTO deleteBulkDraftField(FieldIdsRequestDTO requestDTO, String tenantCode, String username, Long moduleId) {
        StopWatch watch = new StopWatch();

        watch.start("Delete Bulk draft fields");
        BulkDeleteDTO dto = new BulkDeleteDTO();
        List<String> deletedFields = new ArrayList<>();
        List<String> failedFields = new ArrayList<>();

        requestDTO.getFieldIds().parallelStream().forEach(field -> {
            try {
                deleteDraftField(field, tenantCode, username, moduleId);
                deletedFields.add(field);
            } catch (Exception e) {
                log.error("Failed To Delete Field {} : {}",field, e.getMessage());
                failedFields.add(field);
            }
        });
        dto.setDeletedFields(deletedFields);
        dto.setFailedFields(failedFields);
        watch.stop();
        log.info(watch.prettyPrint());
        return dto;
    }

    /**
     * This method will create Field Metadata Documents
     *
     * @param fields
     * @param tenantCode
     * @param username
     * @param moduleId
     */

    private List<UserFieldMetadata> createUserFieldMetadata(CreateFieldRequestDTO fields, String tenantCode,
                                                            String username, Long moduleId) {

        List<UserFieldMetadata> userFieldMetadataList = new ArrayList<>();

        fields.getFields().forEach(fieldList ->

                fieldList.getFieldlist().forEach(field -> {

                    //if object already present then fetch it or else create new Object
                    UserFieldMetadata fieldMetadata = userFieldMetadataRepository
                            .findByFieldIdAndModuleIdAndTenantIdAndUserId(field.getFieldId(), moduleId, tenantCode, username)
                            .orElse(new UserFieldMetadata(field.getFieldId(), tenantCode, moduleId, username));

                    fieldMetadata.setSearchString("").setFieldData(field);

                    userFieldMetadataList.add(fieldMetadata);
                })

        );
        return userFieldMetadataList;
    }

}
