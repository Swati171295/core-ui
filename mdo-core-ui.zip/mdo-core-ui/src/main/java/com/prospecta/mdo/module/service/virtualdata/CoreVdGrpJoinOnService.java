package com.prospecta.mdo.module.service.virtualdata;

import java.util.List;
import java.util.UUID;

import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinOnRequestDTO;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinOnModel;

public interface CoreVdGrpJoinOnService {
	
	CoreVdGrpJoinOnModel getVdGroupJoinOnbyGrpJoinId(UUID vdId);
	
	List<CoreVdGrpJoinOnModel> getVdGroupJoinOnbygroupInfoId(UUID groupInfoId);
	
	void deleteVdGroupJoinOnbyGrpJoinId(UUID vdId);
	
	void deleteVdGroupJoinOnbygroupInfoId(UUID groupInfoId);

	void deleteVdGrpJoinOn(List<VdGroupJoinOnRequestDTO> joinColumns, UUID groupId);

	CoreVdGrpJoinOnModel saveAndUpdateJoinOn(VdGroupJoinOnRequestDTO groupJoinOnRequestDTO,
			CoreVdGroupsModel coreVdGroupsModel);
}
