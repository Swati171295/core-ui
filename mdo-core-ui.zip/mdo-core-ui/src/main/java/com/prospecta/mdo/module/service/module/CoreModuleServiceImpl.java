/**
 *
 */
package com.prospecta.mdo.module.service.module;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataLangDAO;
import com.prospecta.mdo.module.dao.module.CoreModuleDAO;
import com.prospecta.mdo.module.dao.module.CoreModuleDescriptionDAO;
import com.prospecta.mdo.module.dao.module.CoreStructureDAO;
import com.prospecta.mdo.module.dao.module.CoreSubModuleDao;
import com.prospecta.mdo.module.dto.metadata.MetadataFieldsDTO;
import com.prospecta.mdo.module.dto.module.*;
import com.prospecta.mdo.module.exception.GRPCException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.grpc.DynamicCrudGenerationImpl;
import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;
import com.prospecta.mdo.module.model.module.CoreModuleDescriptionModel;
import com.prospecta.mdo.module.model.module.CoreModuleModel;
import com.prospecta.mdo.module.model.module.CoreStructureModel;
import com.prospecta.mdo.module.model.module.CoreSubModuleModel;
import com.prospecta.mdo.module.service.layout.CoreLayoutHeaderService;
import com.prospecta.mdo.module.service.metadata.CoreMetadataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import javax.transaction.Transactional;
import javax.validation.Valid;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.prospecta.mdo.module.util.Constants.MODULE_DELETE_SUCCESS;
import static com.prospecta.mdo.module.util.Constants.MODULE_NOT_FOUND;

/**
 * @author savan
 */
@Service
@Slf4j
@Transactional
public class CoreModuleServiceImpl implements CoreModuleService {

    @Autowired
    private CoreModuleDAO coreModuleDAO;

    @Autowired
    private CoreModuleDescriptionDAO coreModuleDescriptionDAO;

    @Autowired
    private CoreMetadataDAO coreMetadataDAO;

    @Autowired
    private CoreMetadataLangDAO coreMetadataLangDAO;

    @Autowired
    private CoreStructureDAO coreStructureDAO;

    @Autowired
    private CoreLayoutHeaderService coreLayoutHeaderService;

    @Autowired
    private CoreSubModuleDao coreSubModuleDao;

    @Autowired
    DynamicCrudGenerationImpl generationImpl;

    @Autowired
    CoreMetadataService service;

    public static final String ERROR = "Error while executing api: ";

    /**
     * This method is used to save the module
     *
     * @param requestDto
     * @param tenantCode
     */
    @Override
    public ModuleResponseDTO saveModel(ModuleRequestDTO requestDto, String tenantCode) {

        StopWatch watch = new StopWatch();

        ModuleResponseDTO responseDTO = new ModuleResponseDTO();

        try {

            watch.start("Save the core module");
            CoreModuleModel coreModule = new CoreModuleModel();
            coreModule.setTenantId(tenantCode);
            coreModule.setUserModified(requestDto.getUsermodified());
            coreModule.setDispCriteria(Short.parseShort(requestDto.getDisplayCriteria()));
            coreModule.setDateModified(Instant.now().toEpochMilli());
            coreModule.setOwner(requestDto.getOwner());
            coreModule.setSystemType(requestDto.getSystemType());
            coreModule.setPersistent(requestDto.getPersistent());
            coreModule.setIsSingleRecord(requestDto.getIsSingleRecord());
            coreModule.setDataType(requestDto.getDataType());
            coreModule.setIndustry(requestDto.getIndustry());
            coreModule.setPersistent(requestDto.getPersistent());
            coreModule.setDataPrivacy(requestDto.getDataPrivacy());
            coreModule.setType(requestDto.getType());
            CoreModuleModel module = coreModuleDAO.save(coreModule);
            saveModuleDescription(requestDto.getModuledescription(), module.getModuleId(), module.getTenantId());
            saveSubModule(module.getModuleId(), requestDto.getParentModuleIds());
            if (requestDto.getFields() != null)
                saveModuleFields(requestDto, module.getModuleId(), tenantCode, requestDto.getUsermodified());
            responseDTO.setModuleid(module.getModuleId());
            responseDTO.setAcknowledge(true);
            responseDTO.setModuleid(module.getModuleId());
            log.info(watch.prettyPrint());
            watch.stop();
            return responseDTO;

        } catch (Exception e) {
            responseDTO.setAcknowledge(false);
            responseDTO.setErrorMsg(e.getMessage());
            log.error(ERROR, e);
            return responseDTO;
        }
    }

    public void saveSubModule(Long moduleId, List<Long> parentModuleIds) {
        try {
            if (parentModuleIds != null && parentModuleIds.size() > 0)
                parentModuleIds.stream().forEach(id -> {
                    CoreSubModuleModel coreSubModuleModel = new CoreSubModuleModel();
                    coreSubModuleModel.setModuleId(moduleId);
                    coreSubModuleModel.setUuid(UUID.randomUUID());
                    coreSubModuleModel.setParentModuleId(id);
                    coreSubModuleDao.save(coreSubModuleModel);
                });
        } catch (Exception e) {
            log.error(ERROR, e);
        }
    }

    /**
     * This method will save the fields related to module
     *
     * @param requestDto
     * @param moduleid
     * @param usermodified
     * @return
     */
    public List<Iterable<CoreMetadataModel>> saveModuleFields(ModuleRequestDTO requestDto, Long moduleid, String tenantCode,
                                                              String usermodified) {

        StopWatch watch = new StopWatch();

        watch.start("Save module Fields");

        List<Iterable<CoreMetadataModel>> saveModuleFieldsList = new ArrayList<>();

        requestDto.getFields().forEach(field -> {

            if (field.getFieldlist().size() > 100) {
                log.error("Fields list size exceeded.");
                throw new ArrayIndexOutOfBoundsException("Fields list size exceeded.");
            }

            CoreStructureModel structureModel = savemoduleStructure(moduleid, tenantCode, field.getStructureid());

            List<CoreMetadataModel> metadataList = new ArrayList<>();

            field.getFieldlist().stream().forEach(list -> {
                log.info("Start inserting the field with field Id. '" + list.getFieldId() + "'.");
                constructLangData(tenantCode, list, moduleid);

                CoreMetadataModel metadata = constructMetadata(list, structureModel.getStructureId().toString(), moduleid,
                        tenantCode, usermodified);

                metadataList.add(metadata);
                log.info("field with fieldId '" + list.getFieldId() + "' is added to the list to save.");

            });
            Iterable<CoreMetadataModel> savedFields = coreMetadataDAO.saveAll(metadataList);
            log.info("All available fields are saved.");

            saveModuleFieldsList.add(savedFields);

        });
        watch.stop();
        log.info(watch.prettyPrint());
        return saveModuleFieldsList;
    }

    /**
     * @param moduleid
     * @param tenantCode
     * @param structureid
     * @return
     */
    private CoreStructureModel savemoduleStructure(Long moduleid, String tenantCode, String structureid) {
        StopWatch watch = new StopWatch();

        watch.start("Save module structure");

        CoreStructureModel structureModel = new CoreStructureModel();
        structureModel.setModuleId(moduleid);
        structureModel.setTenantId(tenantCode);
        if (null == structureid || structureid.isEmpty()) {
            structureModel.setStructureId((short) 1);
        } else {
            structureModel.setStructureId(Short.parseShort(structureid));
        }
        if (1 != structureModel.getStructureId()) {
            structureModel.setIsHeader(false);
        }
        structureModel.setParentStrucId((short) (structureModel.getStructureId() - 1));
        coreStructureDAO.save(structureModel);

        watch.stop();
        log.info(watch.prettyPrint());

        return structureModel;
    }

    /**
     * This method is used to construct and save the field descriptions
     *
     * @param tenantCode
     * @param list
     */
    public void constructLangData(String tenantCode, FieldDTO list, Long moduleid) {
        List<CoreMetadataLangModel> langList = new ArrayList<>();
        log.info("Start Constructing Language metadata from the field.");
        constructShortText(langList, list, tenantCode, moduleid);

        constructHelpText(langList, list, tenantCode, moduleid);


        if (null != list.getLongtexts() && !list.getLongtexts().isEmpty()) {
            constructLongText(langList, list, tenantCode, moduleid);
        }

        coreMetadataLangDAO.saveAll(langList);
        log.info("Language metadata from the field is saved.");
    }

    /**
     * This method is used to construct metadata object to save for fields
     *
     * @param list
     * @param structureid
     * @param moduleId
     * @param tenantCode
     * @param usermodified
     * @return
     */
    private CoreMetadataModel constructMetadata(FieldDTO list, String structureid, Long moduleId, String tenantCode,
                                                String usermodified) {

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        if (list.getPickList().equals("15")) {
            log.info("Saving all available child for the field.");
            List<CoreMetadataModel> metadataList = new ArrayList<>();

            list.getChildfields().stream().forEach(child -> {

                if (child.getParentField().equals(list.getFieldId())) {

                    FieldDTO childlist = mapper.convertValue(child, new TypeReference<FieldDTO>() {
                    });
                    log.info("Start inserting the child field with field Id. '" + child.getFieldId() + "'.");
                    constructLangData(tenantCode, childlist, moduleId);

                    CoreMetadataModel childMetadata = constructMetadata(childlist, structureid, moduleId, tenantCode,
                            usermodified);

                    metadataList.add(childMetadata);
                    log.info("chield field with fieldId '" + child.getFieldId() + "' is added to the list to save.");
                }

            });

            coreMetadataDAO.saveAll(metadataList);
            log.info("All available child for the field are saved.");
        }

        CoreMetadataModel metadataModel = mapper.convertValue(list, new TypeReference<CoreMetadataModel>() {
        });

        metadataModel.setStructureId(Short.parseShort(structureid));
        metadataModel.setTenantId(tenantCode);
        metadataModel.setModuleId(moduleId);
        metadataModel.setUserModified(usermodified);
        metadataModel.setDateModified(Instant.now().toEpochMilli());

        return metadataModel;
    }

    /**
     * This method is used to construct the Long text
     *
     * @param langList
     * @param list
     * @param tenantCode
     * @param moduleid
     */
    @Override
    public void constructLongText(List<CoreMetadataLangModel> langList, FieldDTO list, String tenantCode, Long moduleid) {

        list.getLongtexts().keySet().stream().forEach(key -> {

            if (!langList.stream().anyMatch(p -> p.getLanguage().equalsIgnoreCase(key))) {

                CoreMetadataLangModel langModel = new CoreMetadataLangModel();
                langModel.setUuid(UUID.randomUUID());
                langModel.setLanguage(key);
                langModel.setTenantId(tenantCode);
                langModel.setFieldId(list.getFieldId());
                langModel.setLongText(list.getLongtexts().get(key));
                langModel.setModuleId(moduleid);

                langList.add(langModel);
            }

        });
    }

    /**
     * This method is used to construct the Help text
     *
     * @param langList
     * @param list
     * @param tenantCode
     * @param moduleid
     */
    @Override
    public void constructHelpText(List<CoreMetadataLangModel> langList, FieldDTO list, String tenantCode, Long moduleid) {

        list.getShortText().keySet().stream().forEach(key -> {

            if (langList.stream().noneMatch(p -> p.getLanguage().equalsIgnoreCase(key))) {

                CoreMetadataLangModel langModel = new CoreMetadataLangModel();
                langModel.setUuid(UUID.randomUUID());
                langModel.setLanguage(key);
                langModel.setTenantId(tenantCode);
                langModel.setFieldId(list.getFieldId());
                langModel.setHelpText(list.getShortText().get(key).getInformation() != null ? list.getShortText().get(key).getInformation()
                        : null);
                langModel.setModuleId(moduleid);

                if (null != list.getLongtexts() && !list.getLongtexts().isEmpty()) {
                    langModel.setLongText(list.getLongtexts().containsKey(key) ? list.getLongtexts().get(key) : null);
                }

                langList.add(langModel);
            }

        });
    }

    /**
     * This method is used to construct the Short text
     *
     * @param langList
     * @param list
     * @param tenantCode
     * @param moduleid
     */
    @Override
    public void constructShortText(List<CoreMetadataLangModel> langList, FieldDTO list, String tenantCode, Long moduleid) {

        list.getShortText().keySet().stream().forEach(key -> {

            CoreMetadataLangModel langModel = new CoreMetadataLangModel();
            langModel.setUuid(UUID.randomUUID());
            langModel.setLanguage(key);
            langModel.setTenantId(tenantCode);
            langModel.setFieldId(list.getFieldId());
            langModel.setShortText(list.getShortText().get(key).getDescription());
            langModel.setModuleId(moduleid);

            langModel.setHelpText(list.getShortText().get(key).getInformation() != null
                    ? list.getShortText().get(key).getInformation() : null);

            if (null != list.getLongtexts() && !list.getLongtexts().isEmpty()) {
                langModel.setLongText(list.getLongtexts().containsKey(key) ? list.getLongtexts().get(key) : null);
            }

            langList.add(langModel);
        });

    }

    /**
     * This method will save the module Description
     *
     * @param moduleDescription
     */
    private void saveModuleDescription(Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription, Long moduleid, String tenantid) {
        StopWatch watch = new StopWatch();

        watch.start("Save module description");
        List<CoreModuleDescriptionModel> descriptionlist = new ArrayList<>();
        if (moduleDescription != null)
            moduleDescription.keySet().stream().forEach(key -> {

                CoreModuleDescriptionModel descriptionModel = new CoreModuleDescriptionModel();

                descriptionModel.setDescription(moduleDescription.get(key).getDescription());
                descriptionModel.setLanguage(key);
                descriptionModel.setModuleId(moduleid);
                descriptionModel.setTenantId(tenantid);
                descriptionModel.setInformation(moduleDescription.get(key).getInformation());
                descriptionlist.add(descriptionModel);

            });

        coreModuleDescriptionDAO.saveAll(descriptionlist);
        watch.stop();
        log.info(watch.prettyPrint());
    }

    /**
     * This method is used to save field for the module.
     *
     * @param field
     * @param tenantCode
     * @param moduleid
     */
    @Override
    public FieldResponseDTO saveField(@Valid FieldDTO field, String tenantCode, Long moduleid) {

        StopWatch watch = new StopWatch();

        FieldResponseDTO responseDTO = new FieldResponseDTO();
        watch.start("Save field for module");
        try {
            CoreStructureModel structure = coreStructureDAO.findTopByModuleIdOrderByStructureIdDesc(moduleid);

            if (null == structure) {
                throw new NoSuchElementException("There is no structure available for provided moduleId");
            }

            if (coreMetadataDAO.countByModuleId(moduleid) % 500 == 1) {
                structure = savemoduleStructure(moduleid, tenantCode, String.valueOf(structure.getStructureId() + 1));
            }

            constructLangData(tenantCode, field, moduleid);

            CoreMetadataModel metadataModel = coreMetadataDAO.save(constructMetadata(field, structure.getStructureId().toString(), moduleid, tenantCode, ""));
            watch.stop();

            responseDTO.setAcknowledge(true);
            responseDTO.setFieldId(metadataModel.getFieldId());
            log.info(watch.prettyPrint());
            return responseDTO;

        } catch (Exception e) {
            responseDTO.setAcknowledge(false);
            responseDTO.setErrorMsg(e.getMessage());
            log.error(ERROR, e);
            return responseDTO;
        }
    }

    /**
     * This method is used to get all the available fields related to structureId
     *
     * @param structureId
     * @param moduleid
     * @param language
     * @param fetchcount
     * @param fetchsize
     * @param tenantCode
     */
    @Override
    public FieldIdsWithStructureResponseDTO getFieldsWithStructure(String structureId, Long moduleid, String language,
                                                                   String fetchcount, String fetchsize, String tenantCode) {
        StopWatch watch = new StopWatch();

        FieldIdsWithStructureResponseDTO responseDTO = new FieldIdsWithStructureResponseDTO();
        watch.start("Fetching all the fieldIds related to structureid");
        try {
            Pageable pageable = PageRequest.of(Integer.parseInt(fetchcount), Integer.parseInt(fetchsize));

            List<String> fields = coreMetadataDAO.findByStructureIdAndModuleIdAndTenantId(Short.parseShort(structureId), moduleid, tenantCode, pageable);

            watch.stop();

            if (null != fields && !fields.isEmpty()) {
                responseDTO.setAcknowledge(true);
                responseDTO.setFieldIds(fields);
            } else {
                responseDTO.setAcknowledge(false);
                responseDTO.setErrorMsg("There are no related fieldIds available to this request");
            }

            log.info(watch.prettyPrint());
            return responseDTO;

        } catch (Exception e) {
            responseDTO.setAcknowledge(false);
            responseDTO.setErrorMsg(e.getMessage());
            log.error(ERROR, e);
            return responseDTO;
        }
    }

    /**
     * This method is used to Get All fieldId, MaxChar and shorttext based on pickList and searched description and Language
     *
     * @param requestDTO
     * @param moduleid
     * @param language
     * @param fetchcount
     * @param fetchsize
     * @param tenantCode
     */
    @Override
    public PickListFieldsResponseDTO getAllPicklistFields(PicklistFieldsRequestDTO requestDTO, Long moduleid,
                                                          String language, String fetchcount, String fetchsize, String tenantCode) {
        StopWatch watch = new StopWatch();

        PickListFieldsResponseDTO responseDTO = new PickListFieldsResponseDTO();
        watch.start("Get All fields based on picklist and serch description along with language");
        try {
            Pageable pageable = PageRequest.of(Integer.parseInt(fetchcount), Integer.parseInt(fetchsize));
            List<Map<String, Object>> responseData = coreMetadataDAO.getpicklistFields(requestDTO.getPickList(), requestDTO.getDescription(), moduleid, tenantCode, language, pageable);
            if (null != responseData && !responseData.isEmpty()) {
                responseDTO.setAcknowledge(true);
                responseDTO.setPickListField(responseData);
            } else {
                responseDTO.setAcknowledge(false);
                responseDTO.setErrorMsg("There are no related pickList fields available to this request");
            }
            watch.stop();
            log.info(watch.prettyPrint());
            return responseDTO;
        } catch (Exception e) {
            log.error(ERROR, e);
            responseDTO.setErrorMsg(e.getMessage());
            responseDTO.setAcknowledge(false);
            return responseDTO;
        }
    }

    /**
     * This method is used to Get All fieldId, MaxChar, DataType, pickList, structureId and shortText based on dataType and searched description and Language
     *
     * @param requestDTO
     * @param moduleid
     * @param language
     * @param fetchcount
     * @param fetchsize
     * @param tenantCode
     */
    @Override
    public DataTypeFieldsResponseDTO getAllDataTypefields(DataTypeFieldsRequestDTO requestDTO, Long moduleid,
                                                          String language, String fetchcount, String fetchsize, String tenantCode) {
        StopWatch watch = new StopWatch();

        DataTypeFieldsResponseDTO responseDTO = new DataTypeFieldsResponseDTO();
        watch.start("Get All fields based on picklist and serch description along with language");
        try {
            Pageable pageable = PageRequest.of(Integer.parseInt(fetchcount), Integer.parseInt(fetchsize));

            List<Map<String, Object>> responseData = coreMetadataDAO.getDataTypeFields(requestDTO.getDatatype(), requestDTO.getDescription(), moduleid, tenantCode, language, pageable);

            if (null != responseData && !responseData.isEmpty()) {
                responseDTO.setAcknowledge(true);
                responseDTO.setDataTypeField(responseData);
            } else {
                responseDTO.setAcknowledge(false);
                responseDTO.setErrorMsg("There are no related dataType fields available to this request");
            }

            watch.stop();
            log.info(watch.prettyPrint());
            return responseDTO;

        } catch (Exception e) {
            responseDTO.setAcknowledge(false);
            responseDTO.setErrorMsg(e.getMessage());
            log.error(ERROR, e);
            return responseDTO;
        }
    }

    /**
     * This method is used to update the module description.
     */
    @Override
    public ModuleResponseDTO updateModuleDescription(@Valid Map<String, ModuleDescriptionInformationRequestDTO> requestDto, String tenantCode,
                                                     Long moduleid) {
        StopWatch watch = new StopWatch();

        ModuleResponseDTO responseDTO = new ModuleResponseDTO();

        watch.start("Update module description.");
        try {

            CoreModuleModel moduleModel = coreModuleDAO.findByModuleIdAndTenantId(moduleid, tenantCode);
            if (null == moduleModel) {
                throw new NoSuchElementException("Ther is no module data available related to request.");
            }

            coreModuleDescriptionDAO.deleteByModuleIdAndTenantId(moduleid, tenantCode);
            if (requestDto != null)
                saveModuleDescription(requestDto, moduleid, tenantCode);

            responseDTO.setAcknowledge(true);
            responseDTO.setModuleid(moduleModel.getModuleId());
            watch.stop();
            log.info(watch.prettyPrint());
            return responseDTO;

        } catch (Exception e) {
            responseDTO.setAcknowledge(false);
            responseDTO.setErrorMsg(e.getMessage());
            log.error(ERROR, e);
            return responseDTO;
        }
    }

    /**
     * This method is used to get all the fields metadata based on the structure.
     */
    @Override
    public List<FieldDTO> getAllFieldsByStructure(Long moduleid, String language, String structureId, String fetchcount,
                                                  String fetchsize, String tenantCode) {
        StopWatch watch = new StopWatch();

        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        List<FieldDTO> responsefield = new ArrayList<>();
        watch.start("Fetching all metada fieldIds related to structureid");
        try {
            Pageable pageable = PageRequest.of(Integer.parseInt(fetchcount), Integer.parseInt(fetchsize));

            List<Object> fieldsList = coreMetadataDAO.findAllFieldsByStructure(Short.parseShort(structureId), moduleid,
                    tenantCode, language, pageable);

            fieldsList.stream().forEach(fields -> {
                Object[] arr = (Object[]) fields;
                MetadataFieldsDTO dto = new MetadataFieldsDTO();
                dto.setCoreMetadata((CoreMetadataModel) arr[0]);
                dto.setLangMetadata((CoreMetadataLangModel) arr[1]);

                List<CoreMetadataModel> metadataFields = coreMetadataDAO.findByModuleIdAndTenantIdAndParentField(
                        moduleid, tenantCode, dto.getCoreMetadata().getFieldId());

                FieldDTO parentField = mapper.convertValue(dto.getCoreMetadata(), new TypeReference<FieldDTO>() {
                });

                List<ChildFieldsDTO> childfields = new ArrayList<>();

                for (CoreMetadataModel metadata : metadataFields) {

                    FieldDTO field = coreLayoutHeaderService.generateMetadata(language, tenantCode, mapper,
                            metadata);
                    ChildFieldsDTO childField = mapper.convertValue(field, new TypeReference<ChildFieldsDTO>() {
                    });

                    childfields.add(childField);
                }
                parentField.setChildfields(childfields);

                responsefield.add(parentField);
            });

            watch.stop();

            log.info(watch.prettyPrint());
            return responsefield;

        } catch (Exception e) {
            log.error(ERROR, e);
        }
        return responsefield;
    }

    /**
     * This method is used to List of all Modules.
     */
    @Override
    public List<CoreModuleModel> getAllModules(String language, String fetchcount, String fetchsize,
                                               String tenantCode) {
        StopWatch watch = new StopWatch();

        List<CoreModuleModel> responseData = new ArrayList<>();
        watch.start("Get List of all Modules based on tanentId");
        try {
            Pageable pageable = PageRequest.of(Integer.parseInt(fetchcount), Integer.parseInt(fetchsize));

            List<Object> moduleList = coreModuleDAO.getAllModulesByTenantCode(tenantCode, language, pageable);

            moduleList.stream().forEach(module -> {
                ModuleDTO moduledto = new ModuleDTO();
                Object[] arr = (Object[]) module;
                moduledto.setModule((CoreModuleModel) arr[0]);
                CoreModuleModel coreModuleModel = moduledto.getModule();
                CoreModuleDescriptionModel coreModuleDescriptionModel = coreModuleDescriptionDAO.findByModuleIdAndTenantIdAndLanguage(coreModuleModel.getModuleId(), tenantCode, language);
                if (Objects.nonNull(coreModuleDescriptionModel)) {
                    Map<String, ModuleDescriptionInformationRequestDTO> requestDTOMap = new HashMap<>();
                    ModuleDescriptionInformationRequestDTO moduleDescriptionInformationRequestDTO = new ModuleDescriptionInformationRequestDTO();
                    moduleDescriptionInformationRequestDTO.setInformation(coreModuleDescriptionModel.getInformation());
                    moduleDescriptionInformationRequestDTO.setDescription(coreModuleDescriptionModel.getDescription());
                    requestDTOMap.put(coreModuleDescriptionModel.getLanguage(), moduleDescriptionInformationRequestDTO);
                    moduledto.setInformationRequestDTOMap(requestDTOMap);
                }
                CoreModuleDescriptionModel coreModuleDescriptionModels = (CoreModuleDescriptionModel) arr[1];
                ModuleDescriptionInformationRequestDTO moduleDescriptionInformationRequestDTO = new ModuleDescriptionInformationRequestDTO();
                moduleDescriptionInformationRequestDTO.setInformation(coreModuleDescriptionModels.getInformation());
                moduleDescriptionInformationRequestDTO.setDescription(coreModuleDescriptionModels.getDescription());
                moduledto.getModule().setModuleDescriptionRequestDTO(moduleDescriptionInformationRequestDTO);
                responseData.add(moduledto.getModule());

            });

            watch.stop();
            log.info(watch.prettyPrint());
            return responseData;

        } catch (Exception e) {
            log.error(ERROR, e);
        }
        return responseData;
    }

    /**
     * This method is used generate the module tree based on the serch description.
     */
    @Override
    public List<ModuleTreeDTO> getModuleTree(String language, String description, String tenantCode) {

        StopWatch watch = new StopWatch();

        List<ModuleTreeDTO> response = new ArrayList<>();

        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        watch.start("Generate Module tree based on the serch description.");
        try {

            // fetch module description
            List<CoreModuleDescriptionModel> moduleDescriptionList = coreModuleDescriptionDAO
                    .findByTenantIdAndLanguageAndDescriptionLike(tenantCode, language, "%" + description + "%");

            if (null != moduleDescriptionList) {

                moduleDescriptionList.stream().forEach(moduleDescription -> {
                    // prepare module data
                    ModuleTreeDTO module = createModule(mapper, moduleDescription);
                    response.add(module);
                });

                watch.stop();
                log.info(watch.prettyPrint());
                return response;

            } else {

                // find in field description
                List<CoreMetadataLangModel> metadataLang = coreMetadataLangDAO
                        .findByLanguageAndTenantIdAndShortTextLike(language, tenantCode, "%" + description + "%");

                if (null != metadataLang) {

                    // get all available fields
                    List<String> metadataFieldIds = metadataLang.stream().map(CoreMetadataLangModel::getFieldId)
                            .collect(Collectors.toList());

                    // remove duplicate fields
                    Set<String> set = new HashSet<>();
                    metadataFieldIds.stream().filter(s -> !set.contains(s)).forEach(set::add);

                    // store field data for all available modules
                    List<FieldDTO> fieldlist = new ArrayList<>();

                    // create the parent and child fields structure based on the available fields in
                    for (String field : set) {

                        List<CoreMetadataModel> metadataFields = coreMetadataDAO
                                .findByTenantIdAndFieldIdOrParentField(tenantCode, field, field);

                        // separate metadata based on the moduleId
                        Map<Long, List<CoreMetadataModel>> metadataMap = metadataFields.stream()
                                .collect(Collectors.groupingBy(CoreMetadataModel::getModuleId));

                        metadataMap.keySet().stream().forEach(meta ->

                                // create fields
                                createFieldData(language, tenantCode, mapper, fieldlist, metadataMap, meta)

                        );
                    }

                    // create the module tree for all available fields
                    createModuleWithFields(language, tenantCode, response, mapper, fieldlist);

                }
            }

            watch.stop();
            log.info(watch.prettyPrint());
            return response;

        } catch (Exception e) {
            log.error(ERROR, e);
        }
        return response;
    }

    /**
     * This method is used to create the field data
     *
     * @param language
     * @param tenantCode
     * @param mapper
     * @param fieldlist
     * @param metadataMap
     * @param meta
     */
    private void createFieldData(String language, String tenantCode, ObjectMapper mapper, List<FieldDTO> fieldlist,
                                 Map<Long, List<CoreMetadataModel>> metadataMap, Long meta) {
        FieldDTO parentField = new FieldDTO();

        List<ChildFieldsDTO> childfields = new ArrayList<>();

        for (CoreMetadataModel metadata : metadataMap.get(meta)) {

            if (null == metadata.getParentField() || metadata.getParentField().isEmpty()) {
                parentField = coreLayoutHeaderService.generateMetadata(language, tenantCode, mapper, metadata);
            } else {
                FieldDTO fieldDto = coreLayoutHeaderService.generateMetadata(language, tenantCode, mapper, metadata);
                ChildFieldsDTO childField = mapper.convertValue(fieldDto, new TypeReference<ChildFieldsDTO>() {
                });

                childfields.add(childField);
            }
        }
        parentField.setChildfields(childfields);
        fieldlist.add(parentField);
    }

    /**
     * This module is used to create the module tree with fields.
     *
     * @param language
     * @param tenantCode
     * @param response
     * @param mapper
     * @param fieldlist
     */
    private void createModuleWithFields(String language, String tenantCode, List<ModuleTreeDTO> response,
                                        ObjectMapper mapper, List<FieldDTO> fieldlist) {

        // remove null records from the list
        fieldlist.removeIf(x -> x.getModuleId() == null);

        // separate fields based on the moduleId
        Map<Long, List<FieldDTO>> fieldListMap = fieldlist.stream()
                .collect(Collectors.groupingBy(FieldDTO::getModuleId));

        // create the moduleTree with fields
        fieldListMap.keySet().stream().forEach(fieldList -> {

            CoreModuleModel coreModule = coreModuleDAO.findByModuleIdAndTenantId(fieldList, tenantCode);

            ModuleTreeDTO moduleDto = mapper.convertValue(coreModule, new TypeReference<ModuleTreeDTO>() {
            });

            CoreModuleDescriptionModel moduleDescription = coreModuleDescriptionDAO
                    .findByModuleIdAndTenantIdAndLanguage(moduleDto.getModuleId(), tenantCode, language);

            Map<String, String> moduledescription = new HashMap<>();
            moduledescription.put(moduleDescription.getLanguage(), moduleDescription.getDescription());

            moduleDto.setModuledescription(moduledescription);

            List<FieldListDTO> listDto = new ArrayList<>();

            FieldListDTO dto = new FieldListDTO();
            dto.setFieldlist(fieldListMap.get(fieldList));

            listDto.add(dto);

            moduleDto.setFields(listDto);

            response.add(moduleDto);

        });
    }

    /**
     * This method is used to create the module data
     *
     * @param mapper
     * @param moduleDescription
     * @return
     */
    private ModuleTreeDTO createModule(ObjectMapper mapper,
                                       CoreModuleDescriptionModel moduleDescription) {

        CoreModuleModel coreModule = coreModuleDAO.findByModuleIdAndTenantId(moduleDescription.getModuleId(),
                moduleDescription.getTenantId());

        ModuleTreeDTO moduleDto = mapper.convertValue(coreModule, new TypeReference<ModuleTreeDTO>() {
        });

        Map<String, String> moduledescription = new HashMap<>();
        moduledescription.put(moduleDescription.getLanguage(), moduleDescription.getDescription());

        moduleDto.setModuledescription(moduledescription);

        return moduleDto;
    }

    /**
     * This method is used to get the module description based on the moduleId and language.
     */
    @Override
    public ModuleDescriptionDTO getModuleDescriptionBasedOnModuleid(Long moduleid, String language,
                                                                    String tenantCode) {
        StopWatch watch = new StopWatch();

        ModuleDescriptionDTO responseDTO = new ModuleDescriptionDTO();

        watch.start("Get Module Description based on moduleid.");
        try {
            CoreModuleDescriptionModel coreModuleDescription = coreModuleDescriptionDAO
                    .findByModuleIdAndTenantIdAndLanguage(moduleid, tenantCode, language);

            if (null == coreModuleDescription) {
                throw new NoSuchElementException("There is no module description available for this request.");
            }

            responseDTO.setDescription(coreModuleDescription.getDescription());
            Map<String, String> information = new HashMap<>();
            information.put(coreModuleDescription.getLanguage(), coreModuleDescription.getDescription());
            responseDTO.setInformation(information);
            responseDTO.setModuleid(coreModuleDescription.getModuleId());

            watch.stop();
            log.info(watch.prettyPrint());
            return responseDTO;

        } catch (Exception e) {
            log.error(ERROR, e);
            return responseDTO;
        }
    }

    /**
     * This method is use to Get All Modules Based On Search Details.
     */
    @Override
    public List<CoreModuleModel> getAllModulesBasedOnSearchDetails(String language, String description,
                                                                   String tenantCode) {

        StopWatch watch = new StopWatch();

        List<CoreModuleModel> responseData = new ArrayList<>();

        watch.start("Get All Modules Based On Search Details.");
        try {

            List<CoreModuleDescriptionModel> coreModuleDescription = coreModuleDescriptionDAO
                    .findByTenantIdAndLanguageAndDescriptionLike(tenantCode, language, "%" + description + "%");

            if (null == coreModuleDescription || coreModuleDescription.isEmpty()) {
                throw new NullPointerException("There is no module available for this request");
            }

            List<Long> moduleIds = coreModuleDescription.stream().map(CoreModuleDescriptionModel::getModuleId)
                    .collect(Collectors.toList());

            if (null != moduleIds && !moduleIds.isEmpty()) {

                List<Object> modules = coreModuleDAO.findAllModulesBasedOnSearchDetail(tenantCode, language, moduleIds);
                modules.stream().forEach(module -> {
                    Object[] arr = (Object[]) module;
                    ModuleDTO moduledto = new ModuleDTO();
                    moduledto.setModule((CoreModuleModel) arr[0]);
                    CoreModuleDescriptionModel coreModuleDescriptionModel = (CoreModuleDescriptionModel) arr[1];
                    ModuleDescriptionInformationRequestDTO moduleDescriptionInformationRequestDTO = new ModuleDescriptionInformationRequestDTO();
                    moduleDescriptionInformationRequestDTO.setInformation(coreModuleDescriptionModel.getInformation());
                    moduleDescriptionInformationRequestDTO.setDescription(coreModuleDescriptionModel.getDescription());
                    moduledto.getModule().setModuleDescriptionRequestDTO(moduleDescriptionInformationRequestDTO);
                    responseData.add(moduledto.getModule());
                });
            }
            watch.stop();
            log.info(watch.prettyPrint());
            return responseData;

        } catch (Exception e) {
            log.error(ERROR, e);
            return null;
        }
    }


    @Override
    public CoreModuleResponse getDetailsByModuleId(String tenantCode, Long moduleId) {
        StopWatch watch = new StopWatch();
        watch.start("Get Module Based On Module Id");
        try {
            CoreModuleModel coreModuleModel = coreModuleDAO.findByModuleIdAndTenantId(moduleId, tenantCode);
            if (Objects.nonNull(coreModuleModel)) {
                CoreModuleResponse coreModuleResponse = new CoreModuleResponse();
                coreModuleResponse.setDataPrivacy(coreModuleModel.getDataPrivacy());
                coreModuleResponse.setDataType(coreModuleModel.getDataType());
                coreModuleResponse.setIndustry(coreModuleModel.getIndustry());
                coreModuleResponse.setOwner(coreModuleModel.getOwner());
                coreModuleResponse.setUsermodified(coreModuleModel.getUserModified());
                coreModuleResponse.setSystemType(coreModuleModel.getSystemType());
                coreModuleResponse.setDisplayCriteria(coreModuleModel.getDispCriteria());
                coreModuleResponse.setTenantId(coreModuleModel.getTenantId());
                coreModuleResponse.setIsSingleRecord(coreModuleModel.getIsSingleRecord());
                coreModuleResponse.setPersistent(coreModuleModel.getPersistent());
                coreModuleResponse.setDateModified(coreModuleModel.getDateModified());
                coreModuleResponse.setType(coreModuleModel.getType());
                List<CoreSubModuleModel> subModuleModelList = coreSubModuleDao.findAllByModuleId(moduleId);
                List<Long> parentModuleIdList = new ArrayList<>();
                if (subModuleModelList.size() > 0)
                    subModuleModelList.stream().forEach(subModuleModel -> parentModuleIdList.add(subModuleModel.getParentModuleId()));
                coreModuleResponse.setParentModuleIds(parentModuleIdList);
                List<CoreModuleDescriptionModel> descriptionModelList = coreModuleDescriptionDAO.findAllByTenantIdAndModuleId(tenantCode, coreModuleModel.getModuleId());
                Map<String, List<ModuleDescriptionInformationRequestDTO>> moduleDescInfoMap = new HashMap<>();
                if (descriptionModelList.size() > 0)
                    descriptionModelList.stream().forEach(coreModuleDescriptionModel -> {
                        ModuleDescriptionInformationRequestDTO descDto = new ModuleDescriptionInformationRequestDTO();
                        descDto.setDescription(coreModuleDescriptionModel.getDescription());
                        descDto.setInformation(coreModuleDescriptionModel.getInformation());
                        if (moduleDescInfoMap.containsKey(coreModuleDescriptionModel.getLanguage())) {
                            List<ModuleDescriptionInformationRequestDTO> savedLanguageMap = moduleDescInfoMap.get(coreModuleDescriptionModel.getLanguage());
                            savedLanguageMap.add(descDto);
                            moduleDescInfoMap.replace(coreModuleDescriptionModel.getLanguage(), savedLanguageMap);
                        } else {
                            List<ModuleDescriptionInformationRequestDTO> list = new ArrayList<>();
                            list.add(descDto);
                            moduleDescInfoMap.put(coreModuleDescriptionModel.getLanguage(), list);
                        }
                        coreModuleResponse.setModuleDescriptionMap(moduleDescInfoMap);
                    });
                return coreModuleResponse;
            } else {
                throw new NullPointerException("core module not available");
            }
        } catch (Exception e) {
            log.error(ERROR, e);
        }
        return null;
    }

    @Override
    public CoreStructureModel saveAndUpdateStructure(ModuleStructureDTO requestDto, String tenantCode) {
        StopWatch watch = new StopWatch();
        watch.start("save/update core structure");
        try {
            List<Short> list = new ArrayList<>();
            list.add(requestDto.getStructureId());
            List<CoreStructureModel> coreStructureModelList = coreStructureDAO.findByModuleIdAndStructureIdInAndTenantId(requestDto.getModuleId(), list, tenantCode);
            if (coreStructureModelList.size() > 0) {
                CoreStructureModel coreStructureModel = coreStructureModelList.get(0);
                coreStructureModel.setStrucDesc(requestDto.getStrucDesc());
                coreStructureModel.setLanguage(requestDto.getLanguage());
                coreStructureModel.setIsHeader(requestDto.getIsHeader());
                coreStructureModel.setParentStrucId(requestDto.getParentStrucId());
                coreStructureModel.setModuleId(requestDto.getModuleId());
                coreStructureModel.setTenantId(tenantCode);
                CoreStructureModel savedCoreStructureModel = coreStructureDAO.save(coreStructureModel);
                watch.stop();
                log.info(watch.prettyPrint());
                return savedCoreStructureModel;
            } else {
                CoreStructureModel coreStructureModel = new CoreStructureModel();
                coreStructureModel.setStrucDesc(requestDto.getStrucDesc());
                coreStructureModel.setLanguage(requestDto.getLanguage());
                coreStructureModel.setIsHeader(requestDto.getIsHeader());
                coreStructureModel.setParentStrucId(requestDto.getParentStrucId());
                coreStructureModel.setModuleId(requestDto.getModuleId());
                coreStructureModel.setTenantId(tenantCode);
                coreStructureModel.setStructureId(requestDto.getStructureId());
                CoreStructureModel savedCoreStructureModel = coreStructureDAO.save(coreStructureModel);
                watch.stop();
                log.info(watch.prettyPrint());
                return savedCoreStructureModel;
            }
        } catch (Exception e) {
            log.error(ERROR, e);
            return null;
        }
    }

	@Override
	public ModuleResponseDTO updateModule(ModuleRequestDTO requestDto, String tenantCode, Long moduleId) {
		StopWatch watch = new StopWatch();

		ModuleResponseDTO responseDTO = new ModuleResponseDTO();

		watch.start("Update module.");
		try {

			CoreModuleModel moduleModel = coreModuleDAO.findByModuleIdAndTenantId(moduleId, tenantCode);
			if (null == moduleModel) {
				throw new NoSuchElementException("Ther is no module data available related to request.");
			}

			moduleModel.setUserModified(requestDto.getUsermodified());
			moduleModel.setDispCriteria(Short.parseShort(requestDto.getDisplayCriteria()));
			moduleModel.setDateModified(Instant.now().toEpochMilli());
			moduleModel.setOwner(requestDto.getOwner());
			moduleModel.setSystemType(requestDto.getSystemType());
			moduleModel.setPersistent(requestDto.getPersistent());
			moduleModel.setIsSingleRecord(requestDto.getIsSingleRecord());
			moduleModel.setDataType(requestDto.getDataType());
			moduleModel.setIndustry(requestDto.getIndustry());
			moduleModel.setPersistent(requestDto.getPersistent());
			moduleModel.setDataPrivacy(requestDto.getDataPrivacy());
			CoreModuleModel module = coreModuleDAO.save(moduleModel);

			// Update module description
			updateModuleDescription(requestDto, tenantCode, moduleId, module);

			// Update sub module
			updateSubModule(requestDto, moduleId, module);

			responseDTO.setAcknowledge(true);
			responseDTO.setModuleid(module.getModuleId());
			watch.stop();
			log.info(watch.prettyPrint());
			return responseDTO;

		} catch (Exception e) {
			responseDTO.setAcknowledge(false);
			responseDTO.setErrorMsg(e.getMessage());
			log.error(ERROR, e);
			return responseDTO;
		}
	}

    /**
     * This method is used to delete Module.
     *
     * @param moduleId
     * @param tenantId
     * @return
     */
    @Override
    @Transactional
    public ModuleResponseDTO deleteModule(Long moduleId, String tenantId) {
        StopWatch watch = new StopWatch();

        List<String> structureIds=coreStructureDAO.findIdByModuleIdAndTenantId(moduleId,tenantId);
        List<String> gridFields= coreMetadataDAO.findGridFieldByModuleIdAndTenantIdAndPickList(moduleId,tenantId,"15");

            if (!generationImpl.deleteTable(structureIds, gridFields, moduleId, tenantId)
                    || !generationImpl.deleteIndex(structureIds, gridFields, moduleId, tenantId)) {
                throw new GRPCException("Unable to delete dynamic table or index");
            }

        ModuleResponseDTO responseDTO = new ModuleResponseDTO();

        log.info("Delete Module Task Started");

        watch.start("Delete Module.");

        CoreModuleModel module=coreModuleDAO.findByModuleIdAndTenantId(moduleId,tenantId);

        if (module == null) {
            throw new NotFound404Exception(MODULE_NOT_FOUND+":"+moduleId);
        }

        coreModuleDAO.delete(module);

        responseDTO.setAcknowledge(true);
        responseDTO.setModuleid(moduleId);
        responseDTO.setSuccessMsg(MODULE_DELETE_SUCCESS);
        watch.stop();
        log.info(watch.prettyPrint());
        return responseDTO;

    }

    @Override
    public ModuleResponseDTO deleteStructure(Long moduleId, Short structureId, String tenantCode) {

        StopWatch watch=new StopWatch();
        watch.start("Delete Structures");

        List<String> childStrucIds = service.getChildStrucIds(tenantCode,moduleId,structureId.toString());

        childStrucIds.add(structureId.toString());

        List<Short> strucIds = childStrucIds.stream()
                .map(Short::parseShort)
                .collect(Collectors.toList());

        List<CoreMetadataModel>  models= coreMetadataDAO.findByStructureIdInAndModuleIdAndTenantId(strucIds,moduleId,tenantCode);

        List<String>  gridModels  = models.stream()
                .filter( field -> field.getPickList().equals("15"))
                .map(CoreMetadataModel :: getFieldId)
                .collect(Collectors.toList());

        List<String> allModels = models.stream()
                .map(CoreMetadataModel :: getFieldId)
                .collect(Collectors.toList());

        if(!generationImpl.deleteTable(childStrucIds,gridModels,moduleId,tenantCode)) {
            throw new GRPCException("Unable to delete Dynamic Tables");
        }
        coreMetadataLangDAO.deleteByFieldIdInAndModuleIdAndTenantId(allModels,moduleId,tenantCode);
        coreMetadataDAO.deleteAll(models);

        coreStructureDAO.deleteAllByStructureIdInAndModuleIdAndAndTenantId(strucIds,moduleId,tenantCode);

        ModuleResponseDTO responseDTO = new ModuleResponseDTO();
        responseDTO.setAcknowledge(true);
        responseDTO.setSuccessMsg("Structure Deleted Successfully");
        watch.stop();
        log.info(watch.prettyPrint());

        return responseDTO;
    }

    /**
     * This method is used to get all Structures in a module.
     *
     * @param moduleId
     * @param tenantId
     * @param searchTerm
     * @param lang
     * @param fetchCount
     * @param fetchSize
     */
    @Override
    public List<ModuleStructureDTO> getAllStructures(Long moduleId,String tenantId, String searchTerm,String lang, Integer fetchCount, Integer fetchSize) {

        List<CoreStructureModel> model = coreStructureDAO
                .findByModuleIdandTenantId(moduleId,tenantId,searchTerm,lang,PageRequest.of(fetchCount,fetchSize));

        return model.stream().map(ModuleStructureDTO::new).collect(Collectors.toList());
    }

    private void updateModuleDescription(ModuleRequestDTO requestDto, String tenantCode, Long moduleId,
			CoreModuleModel module) {
		if (Objects.isNull(requestDto.getModuledescription()) || requestDto.getModuledescription().isEmpty()) {
			coreModuleDescriptionDAO.deleteByModuleIdAndTenantId(moduleId, tenantCode);
		} else {
			Map<String, ModuleDescriptionInformationRequestDTO> requestModuledescription = requestDto
					.getModuledescription();
			List<CoreModuleDescriptionModel> presentModuledescription = coreModuleDescriptionDAO
					.findAllByTenantIdAndModuleId(tenantCode, moduleId);

			for (Map.Entry<String, ModuleDescriptionInformationRequestDTO> entry : requestModuledescription
					.entrySet()) {
				String key = entry.getKey();
				ModuleDescriptionInformationRequestDTO descriptionInformationRequestDTO = entry.getValue();
				CoreModuleDescriptionModel presentDescription = coreModuleDescriptionDAO
						.findByModuleIdAndTenantIdAndLanguage(moduleId, tenantCode, key);
				if (Objects.nonNull(presentDescription)) {
					presentDescription.setDescription(descriptionInformationRequestDTO.getDescription());
					presentDescription.setInformation(descriptionInformationRequestDTO.getInformation());
					coreModuleDescriptionDAO.save(presentDescription);
				} else {
					Map<String, ModuleDescriptionInformationRequestDTO> newMap = new HashMap<>();
					newMap.put(key, descriptionInformationRequestDTO);
					saveModuleDescription(newMap, module.getModuleId(), module.getTenantId());
				}
			}

			if (Objects.nonNull(presentModuledescription) && !presentModuledescription.isEmpty()) {
				List<CoreModuleDescriptionModel> listToBeDeleted = presentModuledescription.stream()
						.filter(element -> !requestModuledescription.containsKey(element.getLanguage()))
						.collect(Collectors.toList());

				if (Objects.nonNull(listToBeDeleted) && !listToBeDeleted.isEmpty()) {
					listToBeDeleted.stream().forEach(element -> {
						coreModuleDescriptionDAO.deleteByModuleIdAndTenantIdAndLanguage(moduleId, tenantCode,
								element.getLanguage());
					});
				}
			}
		}
	}

	private void updateSubModule(ModuleRequestDTO requestDto, Long moduleId, CoreModuleModel module) {
		if (Objects.isNull(requestDto.getParentModuleIds()) || requestDto.getParentModuleIds().isEmpty()) {
			coreSubModuleDao.deleteByModuleId(module.getModuleId());
		} else {
			List<CoreSubModuleModel> subModuleList = coreSubModuleDao.findAllByModuleId(moduleId);
			List<Long> requestParentModuleIds = requestDto.getParentModuleIds();
			if (Objects.nonNull(subModuleList) && !subModuleList.isEmpty()) {
				List<Long> presentParentModuleIds = subModuleList.stream().map(e -> e.getParentModuleId())
						.collect(Collectors.toList());
				List<Long> listToBeDeleted = presentParentModuleIds.stream()
						.filter(element -> !requestParentModuleIds.contains(element)).collect(Collectors.toList());

				List<Long> listToBeAdded = requestParentModuleIds.stream()
						.filter(element -> !presentParentModuleIds.contains(element)).collect(Collectors.toList());

				if (Objects.nonNull(listToBeDeleted) && !listToBeDeleted.isEmpty()) {
					listToBeDeleted.stream().forEach(element -> {
						coreSubModuleDao.deleteByModuleIdAndParentModuleId(moduleId, element);
					});
				}
				saveSubModule(module.getModuleId(), listToBeAdded);
			} else {
				saveSubModule(module.getModuleId(), requestParentModuleIds);
			}
		}
	}
}
