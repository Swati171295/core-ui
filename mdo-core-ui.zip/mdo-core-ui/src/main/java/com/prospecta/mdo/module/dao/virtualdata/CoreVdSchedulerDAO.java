package com.prospecta.mdo.module.dao.virtualdata;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdSchedulerModel;

@Repository
public interface CoreVdSchedulerDAO extends PagingAndSortingRepository<CoreVdSchedulerModel, UUID>  {

	Optional<CoreVdSchedulerModel> findByVdId(CoreVdHeaderModel coreVdHeaderModel);

}
