package com.prospecta.mdo.module.dao.virtualdata;

import java.util.List;
import java.util.UUID;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinInfoModel;

@Repository
public interface CoreVdGrpJoinInfoDAO extends PagingAndSortingRepository<CoreVdGrpJoinInfoModel, UUID>{

	List<CoreVdGrpJoinInfoModel> findByCoreVdGroups(CoreVdGroupsModel coreVdGroupsModel);

	void deleteByCoreVdGroups(CoreVdGroupsModel coreVdGroupsModel);

	List<CoreVdGrpJoinInfoModel> findByUuidIn(List<UUID> joinId);

	void deleteByUuidIn(List<UUID> joinId);

}
