/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldIdsWithStructureResponseDTO {

	private boolean acknowledge;

	private String errorMsg;
	
	private List<String> fieldIds;
	
}
