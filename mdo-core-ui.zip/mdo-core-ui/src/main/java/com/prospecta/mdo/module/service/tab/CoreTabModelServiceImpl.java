/**
 *
 */
package com.prospecta.mdo.module.service.tab;


import com.prospecta.mdo.module.dao.layout.CoreLayoutTabDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataLangDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabFieldsDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabLabelsDAO;
import com.prospecta.mdo.module.dto.layout.LayoutTabDTO;
import com.prospecta.mdo.module.dto.tab.*;
import com.prospecta.mdo.module.enums.FieldType;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.layout.CoreLayoutTabModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;
import com.prospecta.mdo.module.model.tab.CoreTabFieldsModel;
import com.prospecta.mdo.module.model.tab.CoreTabLabelsModel;
import com.prospecta.mdo.module.model.tab.CoreTabModel;
import com.prospecta.mdo.module.service.metadata.CoreMetadataService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import javax.transaction.Transactional;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.prospecta.mdo.module.util.Constants.TAB_FIELD_DELETE_SUCCESS;
import static java.util.stream.Collectors.groupingBy;
import static org.springframework.beans.BeanUtils.copyProperties;

/**
 * @author savan
 *
 */
@Service
@Slf4j
@Transactional
public class CoreTabModelServiceImpl implements CoreTabModelService {

	@Autowired
	private CoreTabDAO coreTabDAO;
	
	@Autowired
	private CoreTabLabelsDAO coreTabLabelsDAO;
	
	@Autowired
	private CoreTabFieldsDAO coreTabFieldsDAO;

	@Autowired
	private CoreMetadataDAO coreMetadataDAO;

	@Autowired
	private CoreMetadataLangDAO coreMetadataLangDAO;

	@Autowired
	private CoreLayoutTabDAO coreLayoutTabDAO;

	@Autowired
	private CoreMetadataService coreMetadataService;

	public static final String ERROR = "Error while executing api: ";
	
	/**
	 * This method is used to create Tab.
	 */
	@Override
	public TabResponseDTO createTab(TabRequestDTO requestDTO, UUID layoutId, String tenantCode,
			String username) {
		StopWatch watch = new StopWatch();

		TabResponseDTO responseDTO = new TabResponseDTO();
		
		watch.start("Create Tab");
		try {

			CoreTabModel tabModel = new CoreTabModel();
			tabModel.setTcode(UUID.randomUUID());
			tabModel.setLayoutId(layoutId);
			tabModel.setModuleId(Long.parseLong(requestDTO.getModuleid()));
			tabModel.setTenantId(tenantCode);
			tabModel.setUserModified(username);
			tabModel.setDateCreated(Instant.now().toEpochMilli());

			tabModel = coreTabDAO.save(tabModel);

			constructAndSaveTabLabel(requestDTO, tabModel);

			responseDTO.setTcode(tabModel.getTcode().toString());
			responseDTO.setAcknowledge(true);

			watch.stop();
			log.info(watch.prettyPrint());
			return responseDTO;

		} catch (Exception e) {
			log.error(ERROR, e);
			responseDTO.setErrorMsg(e.getMessage());
			responseDTO.setAcknowledge(false);
			return responseDTO;
		}
	}

	@Override
	public LayoutTabDTO getLayoutTab(UUID tCode, UUID layoutId, String tenantCode) {

		StopWatch watch = new StopWatch();
		watch.start("Get Layout Tab");
		CoreLayoutTabModel model = coreLayoutTabDAO.findByTcodeAndLayoutIdAndTenantId(tCode,layoutId,tenantCode);
		if (model == null) {
			throw new NotFound404Exception("Tab Details Not Found");
		}
		LayoutTabDTO dto= new LayoutTabDTO();
		copyProperties(model,dto);

		watch.stop();
		log.info(watch.prettyPrint());
		return dto;
	}

	/**
	 * This method is used to construct and save tab label.
	 * 
	 * @param requestDTO
	 * @param tabModel
	 */
	private void constructAndSaveTabLabel(TabRequestDTO requestDTO, CoreTabModel tabModel) {
		List<CoreTabLabelsModel> labelList = new ArrayList<>();

		constructTabDescription(requestDTO, tabModel, labelList);

		if (null != requestDTO.getInformation() && !requestDTO.getInformation().isEmpty()) {
			constructTabInformation(requestDTO, tabModel, labelList);
		}

		coreTabLabelsDAO.saveAll(labelList);
	}

	/**
	 * This method is used to construct tab information.
	 * 
	 * @param requestDTO
	 * @param tabModel
	 * @param labelList
	 */
	private void constructTabInformation(TabRequestDTO requestDTO, CoreTabModel tabModel,
			List<CoreTabLabelsModel> labelList) {
		requestDTO.getInformation().keySet().forEach(key -> {

			if (!labelList.stream().anyMatch(l -> l.getLanguage().equalsIgnoreCase(key))) {
				CoreTabLabelsModel tabLableModel = new CoreTabLabelsModel();
				tabLableModel.setUuid(UUID.randomUUID());
				tabLableModel.setTcode(tabModel.getTcode());
				tabLableModel.setLanguage(key);
				tabLableModel.setInformation(requestDTO.getInformation().get(key));
			}

		});
	}

	/**
	 * This method is used to construct tab description.
	 * 
	 * @param requestDTO
	 * @param tabModel
	 * @param labelList
	 */
	private void constructTabDescription(TabRequestDTO requestDTO, CoreTabModel tabModel,
			List<CoreTabLabelsModel> labelList) {
		requestDTO.getDescription().keySet().stream().forEach(key -> {

			CoreTabLabelsModel tabLableModel = new CoreTabLabelsModel();
			tabLableModel.setUuid(UUID.randomUUID());
			tabLableModel.setTcode(tabModel.getTcode());
			tabLableModel.setLanguage(key);
			tabLableModel.setTabText(requestDTO.getDescription().get(key));

			if (null != requestDTO.getInformation() && !requestDTO.getInformation().isEmpty()) {
				tabLableModel.setInformation(
						requestDTO.getInformation().containsKey(key) ? requestDTO.getInformation().get(key) : null);
			}

			labelList.add(tabLableModel);
		});
	}

	/**
	 * This method is used to update Tab.
	 */
	@Override
	public TabResponseDTO updateTab(TabRequestDTO requestDTO, UUID layoutId, UUID tcode, String tenantCode,
			String username) {
		StopWatch watch = new StopWatch();

		TabResponseDTO responseDTO = new TabResponseDTO();

		watch.start("update Tab");
		try {

			CoreTabModel tabModel = coreTabDAO.findByTcodeAndLayoutIdAndModuleIdAndTenantId(tcode, layoutId,Long.parseLong(requestDTO.getModuleid()), tenantCode);

			if (null == tabModel) {
				throw new NoSuchElementException("There is no Tab data found related to this request");
			}

			tabModel.setUserModified(username);

			tabModel = coreTabDAO.save(tabModel);

			coreTabLabelsDAO.deleteByTcode(tabModel.getTcode());

			constructAndSaveTabLabel(requestDTO, tabModel);

			responseDTO.setAcknowledge(true);
			responseDTO.setTcode(tabModel.getTcode().toString());

			watch.stop();
			log.info(watch.prettyPrint());
			return responseDTO;

		} catch (Exception e) {
			responseDTO.setAcknowledge(false);
			responseDTO.setErrorMsg(e.getMessage());
			log.error(ERROR, e);
			return responseDTO;
		}
	}

	/**
	 * This method is used to Assign Field To Tab.
	 */
	@Override
	public List<TabFieldDTO> assignFieldToTab(List<TabFieldDTO> requestDTO, UUID tcode, String tenantCode) {
		StopWatch watch = new StopWatch();

		List<TabFieldDTO> responseDTO = new ArrayList<>();

		watch.start("Assign Field To Tab.");

			List<CoreTabFieldsModel> tabfieldslist = new ArrayList<>();

			requestDTO.forEach(field -> {

				CoreTabFieldsModel fieldModel = new CoreTabFieldsModel();


				fieldModel = new CoreTabFieldsModel();
				UUID uuid = UUID.randomUUID();
				fieldModel.setUuid(uuid);
				field.setTabFieldUuid(uuid);
				fieldModel.setTcode(tcode);
				fieldModel.setFieldId(field.getFieldId());
				fieldModel.setStructureId(field.getStructureId());
				fieldModel.setModuleId(field.getModuleId());
				fieldModel.setTenantId(tenantCode);
				fieldModel.setFieldType(field.getFieldType());


				fieldModel.setOrder(field.getOrder());
				fieldModel.setIsMandatory(field.getIsMandatory());
				fieldModel.setIsReadOnly(field.getIsReadonly());
				fieldModel.setIsHidden(field.getIsHidden());
				fieldModel.setIsAdd(field.getIsAdd());
				fieldModel.setIsDelete(field.getIsDelete());
				fieldModel.setDescription(field.getDescription() != null ? field.getDescription() : null);
				fieldModel.setUrl(field.getUrl() != null ? fieldModel.getUrl() : null);
				tabfieldslist.add(fieldModel);

			});

			Iterable<CoreTabFieldsModel> savedFields = coreTabFieldsDAO.saveAll(tabfieldslist);

			StreamSupport.stream(savedFields.spliterator(), false).forEach(field -> {
						TabFieldDTO dto=new TabFieldDTO();
						dto.setTabFieldUuid(field.getUuid());
						dto.setFieldType(field.getFieldType());
						dto.setFieldId(field.getFieldId());
						dto.setDescription(field.getDescription());
						responseDTO.add(dto);
					}
			);



			watch.stop();
			log.info(watch.prettyPrint());
			return responseDTO;

	}

	/**
	 * This method is used to update Assigned Fields To Tab.
	 */
	@Override
	public TabFieldResponseDTO assignFieldToTabUpdate(List<TabFieldDTO> requestDTO, UUID tCode,String tenantCode) {
		StopWatch watch = new StopWatch();

		TabFieldResponseDTO responseDTO = new TabFieldResponseDTO();

		watch.start("update Assigned Field To Tab.");

			List<CoreTabFieldsModel> tabfieldslist = new ArrayList<>();

			requestDTO.stream().forEach(field -> {


				CoreTabFieldsModel fieldModel = coreTabFieldsDAO.findByTcodeAndUuid(tCode,field.getTabFieldUuid()).orElseThrow(()-> new NotFound404Exception("Tab Field Not Found : "+field.getTabFieldUuid()));
				fieldModel.setOrder(field.getOrder());
				fieldModel.setIsMandatory(field.getIsMandatory());
				fieldModel.setIsReadOnly(field.getIsReadonly());
				fieldModel.setIsHidden(field.getIsHidden());
				fieldModel.setIsAdd(field.getIsAdd());
				fieldModel.setIsDelete(field.getIsDelete());
				fieldModel.setDescription(field.getDescription() != null && fieldModel.getFieldType() == FieldType.TEXT? field.getDescription() : null);
				fieldModel.setUrl(field.getUrl() != null && fieldModel.getFieldType() == FieldType.IMAGE ? fieldModel.getUrl() : null);
				tabfieldslist.add(fieldModel);

			});

			Iterable<CoreTabFieldsModel> savedFields = coreTabFieldsDAO.saveAll(tabfieldslist);

			List<String> fieldIds = new ArrayList<>();

			StreamSupport.stream(savedFields.spliterator(), false).forEach(field ->
					fieldIds.add(field.getFieldId())
			);

			responseDTO.setAcknowledge(true);
			responseDTO.setFieldIs(fieldIds);

			watch.stop();
			log.info(watch.prettyPrint());
			return responseDTO;
	}

	/**
	 * This method is used to Delete Tab Field.
	 * @param tCode
	 * @param requestListDTO
	 * @param tenantId
	 * @return
	 */
	@Override
	public TabFieldResponseDTO deleteTabField(UUID tCode, UUIDRequestListDTO requestListDTO, String tenantId) {

		StopWatch watch = new StopWatch();

		log.info("Delete Tab Field Task Started");

		watch.start("Delete Tab Field");

		TabFieldResponseDTO responseDTO = new TabFieldResponseDTO();

		if (requestListDTO.getUuidList() == null || requestListDTO.getUuidList().isEmpty()) {

			List<CoreTabFieldsModel> tabFieldsModel = coreTabFieldsDAO.findByTcodeAndTenantId(tCode, tenantId).orElse(new ArrayList<>());

			coreTabFieldsDAO.deleteAll(tabFieldsModel);
			coreLayoutTabDAO.deleteByTcode(tCode);
			responseDTO.setTCode(tCode);
		}

		else {
			List<UUID> uuid = requestListDTO.getUuidList().stream().map(UUID::fromString).collect(Collectors.toList());
			List<CoreTabFieldsModel> tabFieldsModel = coreTabFieldsDAO.findByUuidIn(uuid);
			coreTabFieldsDAO.deleteAll(tabFieldsModel);
		}

		responseDTO.setAcknowledge(true);
		responseDTO.setSuccessMsg(TAB_FIELD_DELETE_SUCCESS);
		responseDTO.setUuidList(requestListDTO.getUuidList());
		watch.stop();
		log.info(watch.prettyPrint());
		return responseDTO;
	}

	/**
	 * This method is used to Search assigned Tab Field.
	 *
	 * @return
	 */
	@Override
	public List<TabSearchDTO>  searchByDesc(Long moduleId, String searchTerm, Integer fetchCount,
											Integer fetchSize, String tenantCode,String language,UUID layoutId) {

      Pageable pageable = PageRequest.of(fetchCount,fetchSize);

      List<TabFieldDetailsDTO> data= coreTabFieldsDAO.searchTabFieldsByDesc(searchTerm,language,layoutId,pageable);

      List<String> fields = data.stream().filter(field -> field.getType() == FieldType.FIELD).map(TabFieldDetailsDTO::getFieldId).collect(Collectors.toList());

      List<CoreMetadataModel> models = coreMetadataDAO.findByFieldIdInAndModuleIdAndTenantId(fields,moduleId,tenantCode);

      data.forEach(field ->
      	models.stream().filter(model -> model.getFieldId().equals(field.getFieldId())).forEach(model -> {
      		field.setPickList(model.getPickList());
      		field.setDataType(model.getDataType());
		})
	  );

		Map<Pair<UUID,String>, List<TabFieldDetailsDTO>> tabGroup = data.stream()
				.collect(groupingBy(object -> new ImmutablePair<>(object.getTabUuid(),object.getTabDescription())));

		return  tabGroup.entrySet().stream()
				.map(field -> new TabSearchDTO(field.getKey().getLeft(),field.getKey().getRight(),field.getValue()))
				.collect(Collectors.toList());

	}

	/**
	 * This method is used to Search unassigned Tab Field.
	 *
	 * @return
	 */
	@Override
	public Map<Object, Object> searchUnassignedTabFields(Long moduleId, String searchTerm, Integer fetchCount,
															  Integer fetchSize, String tenantCode, String language,UUID layoutId) {

		Pageable pageable = PageRequest.of(fetchCount,fetchSize);

		List<CoreTabFieldsModel> tabFields = coreTabFieldsDAO.findBytCodeandLayoutId(layoutId);

		List<String> fields = tabFields.stream().map(CoreTabFieldsModel::getFieldId)
				.filter(Objects::nonNull)
				.collect(Collectors.toList());

		List<CoreMetadataLangModel> model= coreMetadataLangDAO.searchByFieldidNotIn(fields,searchTerm,language,moduleId,tenantCode,pageable);


		Map<Object, Object> finalMap = coreMetadataService.getHierachyFieldMap(moduleId, language, model, tenantCode);

		return finalMap;

	}

	/**
	* This Method returns layout tab list
	*/

	@Override
	public List<LayoutTabDTO> getLayoutTabList(UUID layoutId, String searchTerm, String language,
											   Integer fetchCount, Integer fetchSize, String tenantCode) {

		log.info("Get Layout Tab List");
		return coreLayoutTabDAO.findByLayoutId(layoutId,tenantCode,searchTerm,language,PageRequest.of(fetchCount,fetchSize));

	}

	/**
	 * This Method returns tab field List
	 */
	@Override
	public List<TabFieldDTO> getTabFields(Long moduleId, UUID tCode, Integer fetchCount, Integer fetchSize, String tenantCode, Short structureId) {

		log.info("Get Tab Fields List");

		Pageable pageable = PageRequest.of(fetchCount,fetchSize);
		List<CoreTabFieldsModel> modelList = structureId != null
				? coreTabFieldsDAO.findByTcodeAndTenantIdAndModuleIdAndStructureId(tCode,tenantCode,moduleId,structureId,pageable)
				: coreTabFieldsDAO.findByTcodeAndTenantIdAndModuleId(tCode,tenantCode,moduleId,pageable);

		return modelList.stream().map(TabFieldDTO :: new).collect(Collectors.toList());

	}

}
