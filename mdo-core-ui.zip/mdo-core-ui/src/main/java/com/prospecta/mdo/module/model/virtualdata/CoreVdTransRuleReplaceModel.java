package com.prospecta.mdo.module.model.virtualdata;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;

/**
 * @author komal
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_VD_TRANS_RULE_REPLACE")
@DynamicInsert
public class CoreVdTransRuleReplaceModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9133421005186638014L;

	@Id
	@Type(type = "uuid-char")
	@Column(name = "VD_REPLACE_ID")
	private UUID vdReplaceId;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "TRANS_FIELD_ID", nullable = false)
	private CoreVdTransFieldSettingModel coreVdTransFieldSetting;
	
	@Column(name = "REPLACE_FROM", columnDefinition = "nvarchar(200)")
	private String replaceFrom;
	
	@Column(name = "REPLACE_WITH", columnDefinition = "nvarchar(200)")
	private String replaceWith;

}
