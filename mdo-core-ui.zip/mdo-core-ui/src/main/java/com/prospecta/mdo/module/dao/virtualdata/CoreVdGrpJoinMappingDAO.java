package com.prospecta.mdo.module.dao.virtualdata;

import java.util.List;
import java.util.UUID;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinMappingModel;

@Repository
public interface CoreVdGrpJoinMappingDAO extends PagingAndSortingRepository<CoreVdGrpJoinMappingModel, UUID>{

	List<CoreVdGrpJoinMappingModel> findByCoreVdGrpJoinInfo(CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel);

	void deleteByCoreVdGrpJoinInfo(CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel);

	List<CoreVdGrpJoinMappingModel> findByUuidIn(List<UUID> joinMappingIds);

	void deleteByUuidIn(List<UUID> joinMappingIds);

}
