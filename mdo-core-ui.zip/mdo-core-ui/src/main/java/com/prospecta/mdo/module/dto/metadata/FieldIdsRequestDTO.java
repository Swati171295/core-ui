/**
 * 
 */
package com.prospecta.mdo.module.dto.metadata;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FieldIdsRequestDTO {

	@ApiModelProperty(
			name = "fieldList",
			value = "List representing fields"
	)
	private List<String> fieldIds;
}
