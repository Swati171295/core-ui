package com.prospecta.mdo.module.service.virtualdata;

import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdHeaderDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupsRequestDTO;
import com.prospecta.mdo.module.enums.GroupType;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class CoreVdGroupsServiceImpl implements CoreVdGroupsService {

	@Autowired
	private CoreVdGroupsDAO coreVdGroupsDAO;
	
	@Autowired
	private CoreVdHeaderDAO coreVdHeaderDAO;
	
	String message = "Virtual dataset not found";
	/**
     * This method is used to get the virtual dataset groups by vd id.
     * @param vdId
     */
	@Override
	public List<CoreVdGroupsModel> getVdGroupsbyvdId(UUID vdId) {
		StopWatch watch = new StopWatch();
		watch.start("Get List of Core vd Group Information");
		Optional<CoreVdHeaderModel> coreVdHeaderModel=coreVdHeaderDAO.findById(vdId);
		if (!coreVdHeaderModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		List<CoreVdGroupsModel> coreVdGroupsModel=coreVdGroupsDAO.findByCoreVdHeader(coreVdHeaderModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGroupsModel;
	}
	
	/**
     * This method is used to get the virtual dataset groups by group id.
     * @param groupId
     */
	@Override
	public CoreVdGroupsModel getVdGroupsbyGroupId(UUID groupId) {
		StopWatch watch = new StopWatch();
		watch.start("Get Core vd Group Information");
		Optional<CoreVdGroupsModel> coreVdGroupsModel=coreVdGroupsDAO.findById(groupId);
		if (!coreVdGroupsModel.isPresent()) {
			throw new NotFound404Exception("Virtual dataset groups not found");
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGroupsModel.get();
	}

	/**
     * This method is used to delete the virtual dataset groups by vd id.
     * @param vdId
     */
	@Override
	public void deleteVdGroupsbyvdId(UUID vdId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Information by virtual dataset Started");
		watch.start("Delete vd groups");
		Optional<CoreVdHeaderModel> coreVdHeaderModel=coreVdHeaderDAO.findById(vdId);
		if (!coreVdHeaderModel.isPresent()) {
			throw new NotFound404Exception("Virtual dataset groups not found");
		}
		coreVdGroupsDAO.deleteByCoreVdHeader(coreVdHeaderModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to delete the virtual dataset groups by group id.
     * @param groupId
     */
	@Override
	public void deleteVdGroupsbyGroupId(UUID groupId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Information");
		watch.start("Delete vd groups");
		coreVdGroupsDAO.deleteById(groupId);
		watch.stop();
		log.info(watch.prettyPrint());

	}

	/**
     * This method is used to save and update cd group information.
     * @param groupsRequestDTO
     * @param coreVdHeader
     */
	@Override
	public CoreVdGroupsModel saveOrUpdateVdGroups(VdGroupsRequestDTO groupsRequestDTO, CoreVdHeaderModel coreVdHeader,String tenantCode) {
		if (groupsRequestDTO != null) {
			if (coreVdHeader != null) {
				StopWatch watch = new StopWatch();
				CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
				try {
					log.info("Store virtal dataset group information Started");
					watch.start("Store virtal dataset group information.");
					groupsRequestDTO.setTenantId(null != tenantCode ? tenantCode : groupsRequestDTO.getTenantId());
					if(groupsRequestDTO.getTenantId() == null) {
						log.error("error while Store virtal dataset group information");
						throw new CommonVirtualDatasetException("Tenant id must not be null in group");
					}
					copyProperties(groupsRequestDTO, coreVdGroupsModel);
					if (groupsRequestDTO.getGroupId() == null) {
						coreVdGroupsModel.setGroupId(UUID.randomUUID());
					}
					coreVdGroupsModel.setCoreVdHeader(coreVdHeader);
					coreVdGroupsModel.setGroupType(GroupType.fromValue(groupsRequestDTO.getGroupType().toUpperCase()));
					coreVdGroupsModel = coreVdGroupsDAO.save(coreVdGroupsModel);
					watch.stop();
				} catch (Exception e) {
					log.error("error while Store virtal dataset group information: " + e.getMessage());
					throw new CommonVirtualDatasetException(e.getMessage());
				}
				log.info(watch.prettyPrint());
				return coreVdGroupsModel;
			} else {
				log.error("Virtual data is not present while storing group information.");
				throw new NotFound404Exception("Virtual data is not present while storing group information.");
			}
		} else {
			log.error("Virtual data group is not present while storing it.");
			throw new NotFound404Exception("Virtual data group is not present while storing it.");
		}
	}

	/**
     * This method is used to delete the virtual dataset groups.
     * @param groupDetails
     * @param vdId
     */
	@Override
	public void deleteCoreVdGroup(List<VdGroupsRequestDTO> groupDetails, UUID vdId) {
		StopWatch watch = new StopWatch();
		try {
			watch.start("Delete vd group information");
			log.info("Fetch the all group information with vdId and compare with new data");
			Optional<CoreVdHeaderModel> coreVdHeaderModel = coreVdHeaderDAO.findById(vdId);
			if (!coreVdHeaderModel.isPresent()) {
				log.error("Virtual dataset header not found");
				throw new NotFound404Exception("Virtual dataset header not found");
			}
			List<UUID> newgroupId = groupDetails.stream().filter(g -> g.getGroupId() != null)
					.map(VdGroupsRequestDTO::getGroupId).collect(Collectors.toList());
			List<UUID> groupId = coreVdGroupsDAO.findByCoreVdHeader(coreVdHeaderModel.get()).stream()
					.filter(grp -> !newgroupId.contains(grp.getGroupId())).map(CoreVdGroupsModel::getGroupId)
					.collect(Collectors.toList());
			log.info("Delete all the group information data if user deleted any");
			coreVdGroupsDAO.deleteByGroupIdIn(groupId);
			watch.stop();
			log.info(watch.prettyPrint());
		} catch (Exception e) {
			log.error("error while Delete vd group information: " + e.getMessage());
			throw new CommonVirtualDatasetException(e.getMessage());
		}
	}

}
