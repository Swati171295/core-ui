package com.prospecta.mdo.module.dto.virtualdata;

import java.sql.Timestamp;
import java.util.Map;
import java.util.UUID;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class CoreVdSchedulerRequestDTO {
	
	@ApiModelProperty(
			name = "vdId",
			value = "Id of virtual dataset",
			dataType = "java.util.UUID",
			required = true
	)
	@NotNull(message = "vdId must not be null")
	public UUID vdId;
	
	@ApiModelProperty(
			name = "restEndPoint",
			value = "restEndPoint for schedule a virtual dataset job",
			dataType = "java.lang.String",
			required = true
	)
	@NotEmpty(message = "restEndPoint must not be empty")
	@NotNull(message = "restEndPoint must not be null")
	public String restEndpoint;
	
	@ApiModelProperty(
			name = "restParams",
			value = "Request Parameters for schedule a virtual dataset job",
			dataType = "java.util.Map",
			required = true
	)
	@NotEmpty(message = "restParams must not be empty")
	@NotNull(message = "restParams must not be null")
	public Map<String, String> restParams;
	
	@ApiModelProperty(
			name = "restBody",
			value = "Requestbody for schedule a virtual dataset job",
			dataType = "java.lang.String",
			required = true
	)
	@NotEmpty(message = "restBody must not be empty")
	@NotNull(message = "restBody must not be null")
	public String restBody;
	
	@ApiModelProperty(
			name = "restMethod",
			value = "RequestMethod for schedule a virtual dataset job",
			dataType = "java.lang.String",
			required = true
	)
	@NotEmpty(message = "restMethod must not be empty")
	@NotNull(message = "restMethod must not be null")
	public String restMethod;
	
	@ApiModelProperty(
			name = "tenantId",
			value = "TenantId for schedule a virtual dataset job and tenantId must be in UUID format.",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message = "tenantId must not be null")
	public String tenantId;	
	
	@ApiModelProperty(
			name = "startTime",
			value = "StartTime for schedule a virtual dataset job and it must be in yyyy-MM-dd HH:mm:ss format.",
			dataType = "java.sql.Timestamp",
			required = true
	)
	@NotNull(message = "startTime must not be null")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
	public Timestamp startTime;
	
	@ApiModelProperty(
			name = "endTime",
			value = "EndTime for schedule a virtual dataset job and it must be in yyyy-MM-dd HH:mm:ss format.",
			dataType = "java.sql.Timestamp",
			required = true
	)
	@NotNull(message = "endTime must not be null")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
	public Timestamp endTime;
	
	@ApiModelProperty(
			name = "cron",
			value = "Cron expression value for schedule a virtual dataset job",
			dataType = "java.lang.String",
			required = true
	)
	@NotEmpty(message = "cron must not be empty")
	@NotNull(message = "cron must not be null")
	public String cron;

}
