/**
 * 
 */
package com.prospecta.mdo.module.dao.metadata.referencerule;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.metadata.referencerule.CoreMetadataReferenceRuleModel;

/**
 * @author satyam
 *
 */
@Repository
public interface CoreMetadataReferenceRuleDAO extends PagingAndSortingRepository<CoreMetadataReferenceRuleModel, String> {

}
