package com.prospecta.mdo.module.exception;

public class CommonVirtualDatasetException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2864129516126334401L;

	private final String message;

	public CommonVirtualDatasetException(String message) {
	        this.message = message;
	    }

	@Override
	public String getMessage() {
		return message;
	}
}
