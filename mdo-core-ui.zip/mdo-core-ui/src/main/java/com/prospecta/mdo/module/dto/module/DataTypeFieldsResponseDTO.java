/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DataTypeFieldsResponseDTO {

	private boolean acknowledge;

	private String errorMsg;
	
	private List<Map<String, Object>> dataTypeField;
}
