package com.prospecta.mdo.module.dto.layout;

import com.prospecta.mdo.module.model.layout.CoreLayoutHeaderModel;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

import static org.springframework.beans.BeanUtils.copyProperties;

@Data
@NoArgsConstructor
public class LayoutDetailsResponseDTO {

    private UUID layoutId;

    private String description;

    private String type;

    private String usage;

    private String labels;

    private String helpText;

    private String userCreated;

    private Long dateCreated;

    private String userModified;

    private Long dateModified;

    public LayoutDetailsResponseDTO(CoreLayoutHeaderModel model) {
        copyProperties(model, this);
        this.type = model.getType().toString();
    }

}
