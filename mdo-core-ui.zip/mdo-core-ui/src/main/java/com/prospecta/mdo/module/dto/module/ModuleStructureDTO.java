package com.prospecta.mdo.module.dto.module;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.prospecta.mdo.module.model.module.CoreStructureModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import static org.springframework.beans.BeanUtils.copyProperties;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ModuleStructureDTO {

    @ApiModelProperty(
            name = "Structure Id",
            value = "Short representing Structure Id",
            dataType = "java.lang.Short"
    )
    private Short structureId;
    @ApiModelProperty(
            name = "moduleId",
            value = "Long representing Module Id",
            dataType = "java.lang.Long"
    )
    private Long moduleId;

    @ApiModelProperty(
            name = "tenantId",
            value = "String representing Tenant Id",
            dataType = "java.lang.String"
    )
    @JsonIgnore
    private String tenantId;

    @ApiModelProperty(
            name = "parentStrucId",
            value = "Short representing Parent Structure Id",
            dataType = "java.lang.Short"
    )
    private Short parentStrucId;

    private Boolean isHeader;
    @ApiModelProperty(
            name = "language",
            value = "String representing Language",
            dataType = "java.lang.String"
    )
    private String language;
    @ApiModelProperty(
            name = "strucDesc",
            value = "String representing Structure Description",
            dataType = "java.lang.String"
    )
    private String strucDesc;

    public ModuleStructureDTO (CoreStructureModel model){
        copyProperties(model,this);
    }
}
