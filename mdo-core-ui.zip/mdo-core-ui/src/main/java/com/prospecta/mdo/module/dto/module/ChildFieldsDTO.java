/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.prospecta.mdo.module.util.FieldValidations;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

import static org.springframework.beans.BeanUtils.copyProperties;

/**
 * @author savan
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChildFieldsDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7088405556117205769L;

	@ApiModelProperty(
			name = "fieldId",
			value = "String representing FieldId",
			dataType = "java.lang.String",
			required = true
	)
	@NotEmpty(message = "FieldId must not be null",groups= FieldValidations.class)
	@Pattern(regexp="[\\s]*[a-zA-z0-9]*[\\s]*",message="wrong format for field id,no special characters allowed except underscore")
	private String fieldId;


	@NotNull(message = "ShortText must not be null")
	@NotEmpty(message = "ShortText must not be empty")
	private Map<String , ModuleDescriptionInformationRequestDTO> shortText;

	@ApiModelProperty(
			name = "helptexts",
			value = "Map representing helptexts",
			dataType = "Object",
			required = true
	)
	private Map<String , String> helptexts;

	@ApiModelProperty(
			name = "longtexts",
			value = "Map representing longTexts",
			dataType = "Object",
			required = true
	)
	private Map<String , String> longtexts;

	@ApiModelProperty(
			name = "dataType",
			value = "String representing DataType",
			dataType = "java.lang.String",
			required = true
	)
	@NotEmpty(message = "DataType must not be null")
	private String dataType;

	@ApiModelProperty(
			name = "pickList",
			value = "String representing pickList",
			dataType = "java.lang.String",
			required = true
	)
	@NotEmpty(message = "PickList must not be null")
	private String pickList;

	@ApiModelProperty(
			name = "maxChar",
			value = "Maximum Character length",
			dataType = "java.lang.Long"
	)
	private Long maxChar;

	@ApiModelProperty(
			name = "isKeyField",
			value = "Is Key Field, Default value is false.",
			dataType = "java.lang.Boolean"
	)
	private Boolean isKeyField = false;

	@ApiModelProperty(
			name = "isCriteriaField",
			value = "Is Criteria Field, Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isCriteriaField = false;

	@ApiModelProperty(
			name = "isWorkFlow",
			value = "Is Workflow, Default value is false.",
			dataType = "java.lang.Boolean"
	)
	private Boolean isWorkFlow = false;

	@ApiModelProperty(
			name = "isGridColumn",
			value = "Is Grid Column, Default value is false.",
			dataType = "java.lang.Boolean",
			required = true
	)
	@NotNull
	@AssertTrue(message = "Child field's GridColumn must be True")
	private Boolean isGridColumn = false;

	@ApiModelProperty(
			name = "isDescription",
			value = "Is Description, Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isDescription = false;

	@ApiModelProperty(
			name = "textCase",
			value = "String representing textCase",
			dataType = "java.lang.String"
	)
	private String textCase;

	@ApiModelProperty(
			name = "attachmentSize",
			value = "String representing AttachmentSize.",
			dataType = "java.lang.String"
	)
	private String attachmentSize;

	@ApiModelProperty(
			name = "fileTypes",
			value = "String representing FileTypes",
			dataType = "java.lang.String"
	)
	private String fileTypes;

	@ApiModelProperty(
			name = "isFutureDate",
			value = "Is Future Date, Default value is false.",
			dataType = "java.lang.Boolean"
	)
	private Boolean isFutureDate = false;

	@ApiModelProperty(
			name = "isPastDate",
			value = "Is Past Date, Default value is false.",
			dataType = "java.lang.Boolean"
	)
	private Boolean isPastDate = false;

	@ApiModelProperty(
			name = "outputLen",
			value = "String representing OutputLen",
			dataType = "java.lang.String"
	)
	private String outputLen;

	@ApiModelProperty(
			name = "structureId",
			value = "String representing Structure Id",
			dataType = "java.lang.String"
	)
	private String structureId;

	@ApiModelProperty(
			name = "pickService",
			value = "String representing Pick Service",
			dataType = "java.lang.String"
	)
	private String pickService;

	@ApiModelProperty(
			name = "moduleId",
			value = "Module Id",
			dataType = "java.lang.Long"
	)
	private Long moduleId;

	@ApiModelProperty(
			name = "parentField",
			value = "String representing ParentField.",
			dataType = "java.lang.String",
			required = true
	)
	@NotEmpty(message = "Parent Field must not be null",groups= FieldValidations.class)
	@Pattern(regexp="[\\s]*[a-zA-z0-9]*[\\s]*",message="wrong format for field id,no special characters allowed except underscore")
	private String parentField;

	@ApiModelProperty(
			name = "isReference",
			value = "Is Reference, Default value is false.",
			dataType = "java.lang.Boolean"
	)
	private Boolean isReference = false;

	@ApiModelProperty(
			name = "isDefault",
			value = "Is Default, Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isDefault = false;

	@ApiModelProperty(
			name = "isHeirarchy",
			value = "Is Heirarchy, Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isHeirarchy = false;

	@ApiModelProperty(
			name = "isWorkFlowCriteria",
			value = "Is WorkFlow Criteria, Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isWorkFlowCriteria = false;

	@ApiModelProperty(
			name = "isNumSettingCriteria",
			value = "Is Number Setting Criteria, Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isNumSettingCriteria = false;

	@ApiModelProperty(
			name = "isCheckList",
			value = "Is Check List, Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isCheckList = false;

	@ApiModelProperty(
			name = "isCompBased",
			value = "Is Comp Based, Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isCompBased = false;

	@ApiModelProperty(
			name = "dateModified",
			value = "Date Modified",
			dataType = "java.lang.Long"
	)
	private Long dateModified;

	@ApiModelProperty(
			name = "decimalValue",
			value = "Decimal Value",
			dataType = "java.lang.String"
	)
	private String decimalValue;

	@ApiModelProperty(
			name = "isTransient",
			value = "Is Transient, Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isTransient = false;

	@ApiModelProperty(
			name = "isSearchEngine",
			value = "Is Search Engine. Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isSearchEngine = false;

	@ApiModelProperty(
			name = "isPermission",
			value = "Is Permission. Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isPermission=false;

	@ApiModelProperty(
			name = "isRejection",
			value = "Is Rejection. Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isRejection =false;
	@ApiModelProperty(
			name = "isRequest",
			value = "Is Request. Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isRequest =false;

	@ApiModelProperty(
			name = "isSubGrid",
			value = "Is Sub Grid. Default value is false",
			dataType = "java.lang.Boolean"
	)
	private Boolean isSubGrid=false;
	
	@ApiModelProperty(
			name = "optionsLimit",
			value = "Options limit",
			dataType = "java.lang.Short"
	)
	private Short optionsLimit;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private List<ChildFieldsDTO> childfields;

	public ChildFieldsDTO (FieldDTO dto) {
		copyProperties(dto,this);
	}
}
