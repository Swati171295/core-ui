/**
 * 
 */
package com.prospecta.mdo.module.dao.layout;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.layout.CoreLayoutRuleMappingModel;
import com.prospecta.mdo.module.util.QueryConstants;

/**
 * @author satyam
 *
 */
@Repository
public interface CoreLayoutRuleMappingDAO extends PagingAndSortingRepository<CoreLayoutRuleMappingModel, UUID> {

	CoreLayoutRuleMappingModel findByLayoutIdAndModuleIdAndTenantId(UUID layoutid, Long moduleid, String tenantCode);

	@Modifying
	@Query(QueryConstants.DELETE_BY_MODULEID_LAYOUTID_RULEMAPPINGIDS)
	void deleteRuleMappingByModuleIdLayoutIdAndRuleMappingIds(Long moduleId, UUID layoutId,
			List<UUID> existingRuleMappingIds);
}
