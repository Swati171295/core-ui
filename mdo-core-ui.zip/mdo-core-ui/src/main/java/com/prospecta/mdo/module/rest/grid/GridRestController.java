/**
 *
 */
package com.prospecta.mdo.module.rest.grid;

import com.prospecta.mdo.module.dto.JWTToken;
import com.prospecta.mdo.module.dto.grid.GridResponseDTO;
import com.prospecta.mdo.module.dto.grid.GridSettingRequestDTO;
import com.prospecta.mdo.module.dto.grid.GridSettingResponseDTO;
import com.prospecta.mdo.module.dto.grid.SequenceSettingRequestDTO;
import com.prospecta.mdo.module.service.grid.CoreGridService;
import com.prospecta.mdo.module.util.ValidList;
import io.swagger.annotations.*;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @author paras.miglani
 *
 */
@RestController
@RequestMapping(value = "/grid")
@Api(tags = {"Grid"}, description = "Grid Resource")
public class GridRestController {

    @Autowired
    CoreGridService coreGridService;

    /**
     * This method is used to create/update Grid Setting.
     *
     * @param requestDTO
     * @param moduleId
     * @param gridFieldId
     * @return
     */
    @ApiOperation(value = "Save/Update Grid Field Settings", notes = "Api to Create or Update Grid Field Setting")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = GridResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @PutMapping("/gridfield/{moduleId}/save-or-update-grid-setting")
    public ResponseEntity<GridResponseDTO> createGridSetting(
            @ApiParam(
                    name = "moduleId",
                    value = "ModuleId against which Grid Setting needs to be created/updated",
                    required = true,
                    type = "number",
                    format = "Long",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleId,
            @ApiParam(
                    name = "gridFieldId",
                    value = "gridFieldId against which Grid Setting needs to be created/updated",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "FLD_345"))
            )
            @RequestParam(name = "fieldId") String gridFieldId,
            @ApiParam(
                    name = "",
                    value = "Json Object representing Grid Setting Request",
                    type = "body",
                    required = true
            )
            @RequestBody @Valid ValidList<GridSettingRequestDTO> requestDTO) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        return new ResponseEntity<>(coreGridService.saveUpdateGridSetting(requestDTO, moduleId, gridFieldId, jwtToken.getTenantCode())
                , HttpStatus.CREATED);
    }


    /**
     * This method is used to get Grid Setting.
     *
     *
     * @param moduleId
     * @param gridFieldId
     * @return
     */
    @ApiOperation(value = "Get Grid Field Settings", notes = "Api to Get Grid Field Setting")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = GridSettingResponseDTO.class))
            )}),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @GetMapping("/{moduleId}/get-grid-setting")
    public ResponseEntity<List<GridSettingResponseDTO>> getGridSetting(
            @ApiParam(
                    name = "moduleId",
                    value = "ModuleId against which Grid Setting needs to be fetched",
                    required = true,
                    type = "number",
                    format = "Long",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleId,
            @ApiParam(
                    name = "gridFieldId",
                    value = "gridFieldId against which Grid Setting needs to be fetched",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "FLD_345"))
            )
            @RequestParam(name = "fieldId") String gridFieldId) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        return new ResponseEntity<>(coreGridService.getGridSetting(moduleId, gridFieldId, jwtToken.getTenantCode())
                , HttpStatus.OK);
    }

    /**
     * This method is used to get Sortable Grid fields.
     *
     *
     * @param moduleId
     * @param gridFieldId
     * @return
     */
    @ApiOperation(value = "Get Sortable Grid Fields", notes = "Api to Get Sortable Grid Fields")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = GridSettingResponseDTO.class))
            )}),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @GetMapping("/{moduleId}/get-sort-grid-fields/{language}")
    public ResponseEntity<List<GridSettingResponseDTO>> getSortableGrids(
            @ApiParam(
                    name = "moduleId",
                    value = "ModuleId against which fields needs to be fetched",
                    required = true,
                    type = "number",
                    format = "Long",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleId,
            @ApiParam(
                    name = "language",
                    value = "Language against which description of the fields will be searched",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "en"))
            )
            @PathVariable (name = "language") String lang,
            @ApiParam(
                    name = "searchTerm",
                    value = "Search Term",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "FLD_345"))
            )
            @RequestParam ("searchTerm") String search,
            @ApiParam(
                    name = "fetchCount",
                    value = "Offset",
                    required = true,
                    type = "number",
                    format = "Integer",
                    examples = @Example(value = @ExampleProperty(value = "1"))
            )
            @RequestParam ("fetchCount") Integer fetchCount,
            @ApiParam(
                    name = "fetchSize",
                    value = "Limit",
                    required = true,
                    type = "number",
                    format = "Integer",
                    examples = @Example(value = @ExampleProperty(value = "1"))
            )
            @RequestParam ("fetchSize") Integer fetchSize,
            @ApiParam(
                    name = "gridFieldId",
                    value = "gridFieldId against which field need to be fetched,null supported",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "FLD_345"))
            )
            @RequestParam(name = "gridFieldId") String gridFieldId) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        return new ResponseEntity<>(coreGridService.getSortableGridFields(moduleId, gridFieldId, search,fetchCount,fetchSize,lang,jwtToken.getTenantCode())
                , HttpStatus.OK);
    }

    /**
     * This method is used to get Sequence Grid fields.
     *
     *
     * @param moduleId
     * @param gridFieldId
     * @return
     */
    @ApiOperation(value = "Get Sequence Grid Fields", notes = "Api to Get Sequence Grid Fields")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = GridSettingResponseDTO.class))
            )}),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @GetMapping("/{moduleId}/get-sequence-grid-fields/{language}")
    public ResponseEntity<List<GridSettingResponseDTO>> getSequenceGrids(
            @ApiParam(
                    name = "moduleId",
                    value = "ModuleId against which fields needs to be fetched",
                    required = true,
                    type = "number",
                    format = "Long",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleId,
            @ApiParam(
                    name = "language",
                    value = "Language against which description of the fields will be searched",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "en"))
            )
            @PathVariable (name = "language") String lang,
            @ApiParam(
                    name = "searchTerm",
                    value = "Search Term",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "FLD_345"))
            )
            @RequestParam ("searchTerm") String search,
            @ApiParam(
                    name = "fetchCount",
                    value = "Offset",
                    required = true,
                    type = "number",
                    format = "Integer",
                    examples = @Example(value = @ExampleProperty(value = "1"))
            )
            @RequestParam ("fetchCount") Integer fetchCount,
            @ApiParam(
                    name = "fetchSize",
                    value = "Limit",
                    required = true,
                    type = "number",
                    format = "Integer",
                    examples = @Example(value = @ExampleProperty(value = "1"))
            )
            @RequestParam ("fetchSize") Integer fetchSize,
            @ApiParam(
                    name = "gridFieldId",
                    value = "gridFieldId against which field need to be fetched,null supported",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "FLD_345"))
            )
            @RequestParam(name = "gridFieldId") String gridFieldId) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        return new ResponseEntity<>(coreGridService.getSequenceGridFields(moduleId, gridFieldId, search,fetchCount,fetchSize,lang,jwtToken.getTenantCode())
                , HttpStatus.OK);
    }

    /**
     * This method is used to save Grid Sequence Settings.
     *
     *
     * @param moduleId
     * @param requestDTO
     */
    @ApiOperation(value = "Save/Update Sequence Settings", notes = "Api to Save/Update Sequence Settings")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = GridResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @PutMapping("/{moduleId}/save-update-sequence-setting")
    public ResponseEntity<GridResponseDTO> saveUpdateSequenceSetting(
            @ApiParam(
                    name = "moduleId",
                    value = "ModuleId against which Sequence Setting needs to be saved/updated",
                    required = true,
                    type = "number",
                    format = "Long",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleId,
            @ApiParam(
                    name = "requestDTO",
                    value = "Sequence Setting Request DTO",
                    required = true,
                    type = "Object",
                    format = "List"
            )
            @RequestBody List<SequenceSettingRequestDTO> requestDTO) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        return new ResponseEntity<>(coreGridService.saveUpdateSequenceSetting(requestDTO,moduleId,jwtToken.getTenantCode())
                , HttpStatus.CREATED);
    }
}
