package com.prospecta.mdo.module.service.virtualdata;

import java.util.List;
import java.util.UUID;

import com.prospecta.mdo.module.dto.virtualdata.VdTransRuleReplaceRequestDTO;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransRuleReplaceModel;

public interface CoreVdTransRuleReplaceService {
	
	CoreVdTransRuleReplaceModel getVdTransRuleReplacebyreplaceId(UUID replaceId);
	
	List<CoreVdTransRuleReplaceModel> getVdTransRuleReplacebytransFieldId(UUID transFieldId);
	
	void deleteVdTransRuleReplacebyreplaceId(UUID replaceId);

	void deleteVdTransRuleReplacebytransFieldId(UUID transFieldId);

	void deleteVdTransRuleReplace(List<VdTransRuleReplaceRequestDTO> transReplaceDetail, UUID transId);

	CoreVdTransRuleReplaceModel saveOrUpdateVdTransRuleReplace(VdTransRuleReplaceRequestDTO groupTransRuleReplaceRequestDTO,
			CoreVdTransFieldSettingModel coreVdTransFieldSettingModel);
}