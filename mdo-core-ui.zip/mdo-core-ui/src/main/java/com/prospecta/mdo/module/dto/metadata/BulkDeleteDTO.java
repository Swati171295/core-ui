package com.prospecta.mdo.module.dto.metadata;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class BulkDeleteDTO implements Serializable {

    private List<String> deletedFields;
    private List<String> failedFields;
}
