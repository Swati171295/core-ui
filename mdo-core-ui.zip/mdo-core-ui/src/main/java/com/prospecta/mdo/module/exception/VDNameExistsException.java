package com.prospecta.mdo.module.exception;

public class VDNameExistsException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;
	
	private final String message;

    public VDNameExistsException(String message) {
    	super(message);
    	this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }

}
