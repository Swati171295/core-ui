/**
 * 
 */
package com.prospecta.mdo.module.dao.module;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.module.CoreModuleModel;

/**
 * @author savan
 *
 */
@Repository
public interface CoreModuleDAO extends PagingAndSortingRepository<CoreModuleModel, Long> {

	CoreModuleModel findByModuleIdAndTenantId(Long moduleId, String tenantCode);

	@Query("from CoreModuleModel AS m JOIN CoreModuleDescriptionModel AS d ON m.moduleId = d.moduleId WHERE m.tenantId=:tenantCode AND d.language=:language ORDER BY d.description ASC")
	List<Object> getAllModulesByTenantCode(@Param("tenantCode") String tenantCode,@Param("language") String language, Pageable pageable);

	@Query("from CoreModuleModel AS m JOIN CoreModuleDescriptionModel AS d ON m.moduleId = d.moduleId WHERE m.tenantId=:tenantCode AND d.language=:language AND m.moduleId IN :moduleIds ORDER BY d.description ASC")
	List<Object> findAllModulesBasedOnSearchDetail(String tenantCode, String language, List<Long> moduleIds);


}
