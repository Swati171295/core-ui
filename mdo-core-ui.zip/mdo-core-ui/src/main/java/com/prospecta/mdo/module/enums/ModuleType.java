package com.prospecta.mdo.module.enums;

public enum ModuleType {

    STD("Standard"),SYS("System"),TP("ThirdParty");

    private final String value;

    ModuleType(String value) {
        this.value = value;
    }
}
