package com.prospecta.mdo.module.enums;

public enum FieldType {

    FIELD, TEXT,IMAGE;
}
