package com.prospecta.mdo.module.model.virtualdata;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import com.prospecta.mdo.module.enums.ConcatFieldType;

import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;

/**
 * @author komal
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_VD_TRANS_RULE_CONCAT")
@DynamicInsert
public class CoreVdTransRuleConcatModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8921316229559069530L;

	@Id
	@Type(type = "uuid-char")
	@Column(name = "VD_CONCAT_ID")
	private UUID vdConcatId;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "TRANS_FIELD_ID", nullable = false)
	private CoreVdTransFieldSettingModel coreVdTransFieldSetting;
	
	@Column(name = "FIELD_TYPE")
	private ConcatFieldType fieldType;
	
	@Column(name = "FIELD_VALUE", columnDefinition = "nvarchar(200)")
	private String fieldValue;
	
	@Column(name = "FIELD_NAME", columnDefinition = "nvarchar(100)")
	private String fieldName;
	
	

}
