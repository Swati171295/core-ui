	package com.prospecta.mdo.module.model.virtualdata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import com.prospecta.mdo.module.enums.SourceScope;
import com.prospecta.mdo.module.enums.SourceType;

import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;

/**
 * @author komal
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_VD_GRP_TRANS_INFO")
@DynamicInsert
public class CoreVdGrpTransInfoModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 16952707607767873L;

	@Id
	@Type(type = "uuid-char")
	@Column(name = "UUID")
	private UUID uuid;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "GROUPID", nullable = false)
	private CoreVdGroupsModel coreVdGroups;
	
	@Column(name = "SOURCE", columnDefinition = "nvarchar(200)")
	private String source;
	
	@Column(name = "SOURCE_TYPE")
	private SourceType sourceType;
	
	@Column(name = "SOURCE_MODULEID")
	private Long sourceModuleId;
	
	@Column(name = "SOURCE_SCOPE_UDRID", columnDefinition = "nvarchar(50)")
	private String sourceScopeUdrId;
	
	@Column(name = "RESULT_SCOPE_UDRID", columnDefinition = "nvarchar(50)")
	private String resultScopeUdrId;
	
	@Column(name = "SOURCE_SCOPE")
	private SourceScope sourceScope;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "coreVdGrpTransInfo")
	private List<CoreVdTransFieldSettingModel> coreVdTransFieldSetting = new ArrayList<>();

}
