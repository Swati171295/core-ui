package com.prospecta.mdo.module.dto.virtualdata;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import lombok.Data;

@Data
public class VdGroupJoinInfoResponseDTO {
	
	private UUID groupJoinId;
	
	private String sourceOne;
	
	private String sourceOneType;
	
	private Long sourceOneModule;
	
	private String sourceTwo;
	
	private String sourceTwoType;
	
	private Long sourceTwoModule;	
	
	private UdrResponseDTO sourceOneScopeUdr;
	
	private UdrResponseDTO sourceTwoScopeUdr;
	
	private UdrResponseDTO resultScopeUdr;
	
	private String joinType;
	
	private String joinOperator;
	
	List<VdGroupJoinMappingResponseDTO> joinMapping = new ArrayList<>();
	

}
