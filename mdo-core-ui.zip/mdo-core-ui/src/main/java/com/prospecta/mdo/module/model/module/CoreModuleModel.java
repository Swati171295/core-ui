/**
 *
 */
package com.prospecta.mdo.module.model.module;

import com.prospecta.mdo.module.dto.module.ModuleDescriptionInformationRequestDTO;
import com.prospecta.mdo.module.enums.ModuleType;
import lombok.Data;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author savan
 */
@Data
@Entity
@Table(name = "CORE_MODULE_MDO")
@Audited
public class CoreModuleModel implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -5251381986609063252L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MODULEID")
    private Long moduleId;

    @Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
    private String tenantId;

    @Column(name = "USERMODIFIED", columnDefinition = "nvarchar(150)")
    private String userModified;

    @Column(name = "DATEMODIFIED")
    private Long dateModified;

    @Column(name = "DISP_CRITERIA", columnDefinition = "tinyint")
    private Short dispCriteria;

    @Transient
    private ModuleDescriptionInformationRequestDTO moduleDescriptionRequestDTO;

    @Column(name = "INDUSTRY", columnDefinition = "nvarchar(500)")
    private String industry;

    @Column(name = "IS_SINGLE_RECORD")
    private Boolean isSingleRecord;

    @Column(name = "SYSTEM_TYPE", columnDefinition = "nvarchar(500)")
    private String systemType;

    @Column(name = "OWNER", columnDefinition = "tinyint")
    private Short owner;

    @Column(name = "DATA_TYPE", columnDefinition = "tinyint")
    private Short dataType;

    @Column(name = "PERSISTENT", columnDefinition = "tinyint")
    private Short persistent;

    @Column(name = "DATA_PRIVACY", columnDefinition = "tinyint")
    private Short dataPrivacy;

    @Column(name="TYPE")
    @Enumerated(EnumType.STRING)
    private ModuleType type;
}
