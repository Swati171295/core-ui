package com.prospecta.mdo.module.service.virtualdata;

import java.util.List;
import java.util.UUID;

import com.prospecta.mdo.module.dto.virtualdata.VdGroupsRequestDTO;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

public interface CoreVdGroupsService {
	
	List<CoreVdGroupsModel> getVdGroupsbyvdId(UUID vdId);

	CoreVdGroupsModel getVdGroupsbyGroupId(UUID vdId);
	
	void deleteVdGroupsbyvdId(UUID vdId);
	
	void deleteVdGroupsbyGroupId(UUID tenantId);

	CoreVdGroupsModel saveOrUpdateVdGroups(VdGroupsRequestDTO groupsRequestDTO, CoreVdHeaderModel coreVdHeader, String tenantCode);

	void deleteCoreVdGroup(List<VdGroupsRequestDTO> groupDetails, UUID vdid);

}
