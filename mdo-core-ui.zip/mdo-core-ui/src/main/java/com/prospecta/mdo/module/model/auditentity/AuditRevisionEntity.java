/**
 * 
 */
package com.prospecta.mdo.module.model.auditentity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.RevisionEntity;
import org.hibernate.envers.RevisionNumber;
import org.hibernate.envers.RevisionTimestamp;

import lombok.Data;

/**
 * @author savan
 *
 */
@Data
@Entity
@Table(name = "CORE_UI_REVINFO")
@RevisionEntity(CustomEntityListener.class)
public class AuditRevisionEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7224729683145873747L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@RevisionNumber
    @Column(name="ID")
    private Long id;
    
	@RevisionTimestamp
	@Column(name= "TIMESTAMP")
	private long timestamp;
	
	@Column(name = "USERMODIFIED", columnDefinition = "NVARCHAR(150)")
    private String userModified;
    
    @Column(name = "PROCESSID" , columnDefinition = "NVARCHAR(100)")
    private String processId;
    
    @Column(name = "TENANTID", columnDefinition = "NVARCHAR(150)")
    private String tenantID;
}
