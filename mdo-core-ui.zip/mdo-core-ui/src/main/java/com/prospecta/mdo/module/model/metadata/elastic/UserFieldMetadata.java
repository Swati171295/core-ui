package com.prospecta.mdo.module.model.metadata.elastic;

import com.prospecta.mdo.module.dto.module.FieldDTO;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

@Data
@Accessors(chain=true)
@Document(indexName = "#{@environment.getProperty('server.name')}_user_field_metadata", createIndex = true)
@NoArgsConstructor
public class UserFieldMetadata {

    public UserFieldMetadata(String fieldId, String tenantId,
                             Long moduleId, String userId) {
        this.fieldId = fieldId;
        this.tenantId = tenantId;
        this.moduleId = moduleId;
        this.userId = userId;

    }

    @Id
    private String id;

    private String fieldId;

    private String tenantId;

    private Long moduleId;

    private String userId;

    private String searchString;

    private FieldDTO fieldData;
}
