/**
 * 
 */
package com.prospecta.mdo.module.model.layout;

import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.UUID;

/**
 * @author savan
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_LAYOUT_TAB")
public class CoreLayoutTabModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2427727024549974365L;

	@Id 
	@Type(type = "uuid-char")
	@Column(name = "UUID", columnDefinition = "uuid")
	private UUID uuid;
	
	@Type(type = "uuid-char")
	@Column(name = "TCODE", columnDefinition = "uuid")
	private UUID tcode;
	
	@Type(type = "uuid-char")
	@Column(name = "LAYOUTID", columnDefinition = "uuid")
	private UUID layoutId;
	
	@Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
	private String tenantId;
	
	@Column(name = "TAB_ORDER", columnDefinition = "tinyint")
	private Short tabOrder;
	
	@Column(name = "IS_TAB_READONLY")
	private Boolean isTabReadOnly;

	@Column(name = "IS_TAB_HIDDEN")
	private Boolean isTabHidden;

	@Type(type = "uuid-char")
	@Column(name = "UDR_ID", columnDefinition = "uuid")
	private UUID udrId;


}
