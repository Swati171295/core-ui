/**
 * 
 */
package com.prospecta.mdo.module.dto.metadata;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CreateFieldResponseDTO {

	private boolean acknowledge;

	private String successMessage;

	private String errorMsg;

	private List<String> dynamicFieldIds;

	private List<String> draftIds;
}
