package com.prospecta.mdo.module.dto.grid;

import com.prospecta.mdo.module.dto.metadata.CreateFieldResponseDTO;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author jaineet.singh
 *
 */

@Data
@NoArgsConstructor
public class GridResponseDTO extends CreateFieldResponseDTO {

    private String gridFieldId;
}
