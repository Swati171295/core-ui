package com.prospecta.mdo.module.service.grid;

import com.prospecta.mdo.module.dao.grid.CoreGridDAO;
import com.prospecta.mdo.module.dao.grid.CoreGridSequenceDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataDAO;
import com.prospecta.mdo.module.dto.grid.GridResponseDTO;
import com.prospecta.mdo.module.dto.grid.GridSettingRequestDTO;
import com.prospecta.mdo.module.dto.grid.GridSettingResponseDTO;
import com.prospecta.mdo.module.dto.grid.SequenceSettingRequestDTO;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.grid.CompositeSequenceSettingId;
import com.prospecta.mdo.module.model.grid.CoreGridSequenceSetting;
import com.prospecta.mdo.module.model.grid.CoreGridSettingModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.prospecta.mdo.module.dto.grid.SequenceSettingRequestDTO.IGNORABLE_UPDATE_FIELDS;
import static org.springframework.beans.BeanUtils.copyProperties;

/**
 * @author jaineet.singh
 *
 */
@Service
@Slf4j
public class CoreGridServiceImpl implements CoreGridService {

    @Autowired
    CoreMetadataDAO coreMetadataDAO;

    @Autowired
    CoreGridDAO coreGridDAO;

    @Autowired
    CoreGridSequenceDAO coreGridSequenceDAO;


    /**
     * This method is used to save grid setting
     *
     * @param requestDTO
     * @param moduleId
     * @param gridFieldId
     * @param tenantCode
     * @return responseDTO
     */
    @Override
    @Transactional
    public GridResponseDTO saveUpdateGridSetting(List<GridSettingRequestDTO> requestDTO, Long moduleId,
                                                 String gridFieldId, String tenantCode) {

        StopWatch watch = new StopWatch();

        watch.start("Save or Update Grid Field Settings");

        //Check If any of the field is not present in db,then throw error
        checkFieldIdsPresent(requestDTO, moduleId, tenantCode);

        //get updated list of model
        List<CoreGridSettingModel> gridSettingModel = getUpdatedGridList(gridFieldId, moduleId, tenantCode, requestDTO);

        coreGridDAO.saveAll(gridSettingModel);

        GridResponseDTO responseDTO = new GridResponseDTO();
        responseDTO.setGridFieldId(gridFieldId);
        responseDTO.setAcknowledge(true);

        watch.stop();
        log.info(watch.prettyPrint());
        return responseDTO;

    }

    /**
     * This method is used to get Grid Setting List
     *
     *
     * @param moduleId
     * @param gridFieldId
     * @param tenantCode
     */
    @Override
    public List<GridSettingResponseDTO> getGridSetting(Long moduleId, String gridFieldId, String tenantCode) {

        List<CoreGridSettingModel> gridSetting = coreGridDAO.findByGridFieldIdAndModuleIdAndTenantId(gridFieldId, moduleId, tenantCode)
                .orElseThrow(() -> new NotFound404Exception("Grid Setting Not Found for : " + gridFieldId));

        return gridSetting.parallelStream().map(GridSettingResponseDTO::new).collect(Collectors.toList());
    }

    /**
     * This method is used to get Sortable Grid List
     *
     *
     * @param moduleId
     * @param gridFieldId
     * @param tenantCode
     * @param search
     * @param fetchCount
     * @param fetchSize
     * @param lang
     */
    @Override
    public List<GridSettingResponseDTO> getSortableGridFields(Long moduleId, String gridFieldId, String search, Integer fetchCount,
                                                              Integer fetchSize, String lang, String tenantCode) {


        List<CoreGridSettingModel> gridSetting = coreGridDAO.findSortableFields(gridFieldId, search,moduleId,
                tenantCode,lang,true, PageRequest.of(fetchCount,fetchSize));

        return gridSetting.stream().map(GridSettingResponseDTO::new).collect(Collectors.toList());
    }

    /**
     * This method is used to get Sequence Grid List
     *
     *
     * @param moduleId
     * @param gridFieldId
     * @param tenantCode
     * @param search
     * @param fetchCount
     * @param fetchSize
     * @param lang
     */
    @Override
    public List<GridSettingResponseDTO> getSequenceGridFields(Long moduleId, String gridFieldId, String search, Integer fetchCount,
                                                              Integer fetchSize, String lang, String tenantCode) {


        List<CoreGridSettingModel> gridSetting = coreGridDAO.findSequenceFields(gridFieldId, search,moduleId,
                tenantCode,lang,true, PageRequest.of(fetchCount,fetchSize));

        return gridSetting.stream().map(GridSettingResponseDTO::new).collect(Collectors.toList());
    }

    /**
     * This method is used to save/update sequence setting
     *
     *
     * @param moduleId
     * @param tenantCode
     * @param requestDTO
     */
    @Override
    public GridResponseDTO saveUpdateSequenceSetting(List<SequenceSettingRequestDTO> requestDTO,Long moduleId, String tenantCode) {

        List<CoreGridSequenceSetting> list =new ArrayList<>();

        requestDTO.forEach(fields -> {
            CompositeSequenceSettingId id = new CompositeSequenceSettingId(moduleId,tenantCode,fields.getGridSettingUuid());
            CoreGridSequenceSetting model = coreGridSequenceDAO.findById(id).orElse(new CoreGridSequenceSetting(moduleId,tenantCode,fields.getGridSettingUuid()));
            copyProperties(fields,model,IGNORABLE_UPDATE_FIELDS);
            list.add(model);
        });

        coreGridSequenceDAO.saveAll(list);

        GridResponseDTO responseDTO = new GridResponseDTO();
        responseDTO.setAcknowledge(true);
        return responseDTO;
    }


    /**
     * This method is used to check absent field Ids
     *
     * @param requestDTO
     * @param moduleId
     * @param tenantCode
     */

    private void checkFieldIdsPresent(List<GridSettingRequestDTO> requestDTO, Long moduleId, String tenantCode) {

        //extract field Ids
        List<String> fieldIds = requestDTO.parallelStream()
                .map(GridSettingRequestDTO::getFieldId)
                .collect(Collectors.toList());

        //find the present field ids from given list
        List<String> presentIds = coreMetadataDAO.findFieldIdByFieldIdInAndModuleIdAndTenantId(fieldIds, moduleId, tenantCode);
        fieldIds.removeAll(presentIds);

        //check absent fields after removing present field ids from given list of field ids
        if (!fieldIds.isEmpty()) {
            throw new NotFound404Exception("Field Id " + fieldIds.get(0) + " doesn't exist or incorrect values");
        }
    }

    /**
     * This method is used to get updated Grid List
     *
     * @param requestDTO
     * @param moduleId
     * @param gridFieldId
     * @param tenantId
     */
    private List<CoreGridSettingModel> getUpdatedGridList(String gridFieldId, Long moduleId,
                                                          String tenantId, List<GridSettingRequestDTO> requestDTO) {

        List<CoreGridSettingModel> list = new ArrayList<>();
        //Get Grid Setting against grid field id else create a new one
        requestDTO.forEach(fields -> {
            CoreGridSettingModel gridSettingModels = coreGridDAO.findByGridFieldIdAndFieldIdAndModuleIdAndTenantId(gridFieldId,
                    fields.getFieldId(), moduleId, tenantId).orElse(new CoreGridSettingModel(moduleId, gridFieldId, tenantId));

            copyProperties(fields, gridSettingModels);
            list.add(gridSettingModels);
        });
        return list;
    }
}
