package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import lombok.Data;

@Data
public class VdGroupJoinMappingResponseDTO {
	
	
	private UUID joinMappingId;
	
	private String sourceOneField;
	
	private String sourceTwoField;	
	
	private Short orderBy;
	
	private String operator;

}
