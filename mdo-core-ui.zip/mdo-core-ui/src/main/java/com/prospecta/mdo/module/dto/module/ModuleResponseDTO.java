/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ModuleResponseDTO {

	public ModuleResponseDTO(Exception e){
		this.acknowledge=false;
		this.errorMsg=e.getMessage();
	}

	private Long moduleid;

	private boolean acknowledge;

	private String errorMsg;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String successMsg;
	
	private Map<String, String> fieldsErrors;
	
}
