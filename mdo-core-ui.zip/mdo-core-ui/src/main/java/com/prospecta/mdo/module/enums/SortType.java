package com.prospecta.mdo.module.enums;

public enum SortType {
    ASC,DESC;
}
