package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import lombok.Data;

@Data
public class VdGroupResultsResponseDTO {
	
	private UUID resultId;
	
	private String source;
	
	private String fieldId;
	
	private String fieldAlias;

	private Short order;

}
