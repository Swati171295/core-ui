package com.prospecta.mdo.module.dto;

import java.io.Serializable;
import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * @author panther
 *
 */
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class JWTToken implements Serializable {
	
	private static final long serialVersionUID = 5707018833649747987L;
	
	private String username;
	
	private Set<String> roles;

	private String tenantCode;
	
}