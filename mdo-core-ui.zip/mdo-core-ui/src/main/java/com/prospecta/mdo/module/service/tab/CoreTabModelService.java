/**
 * 
 */
package com.prospecta.mdo.module.service.tab;

import com.prospecta.mdo.module.dto.layout.LayoutTabDTO;
import com.prospecta.mdo.module.dto.tab.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author savan
 *
 */
public interface CoreTabModelService {

	TabResponseDTO createTab(TabRequestDTO requestDTO, UUID layoutId, String tenantCode, String username);

	LayoutTabDTO getLayoutTab(UUID tCode, UUID layoutId, String tenantCode);

	TabResponseDTO updateTab(TabRequestDTO requestDTO, UUID layoutId, UUID tcode, String tenantCode, String username);

	List<TabFieldDTO> assignFieldToTab(List<TabFieldDTO> requestDTO, UUID tcode, String tenantCode);

	TabFieldResponseDTO assignFieldToTabUpdate(List<TabFieldDTO> requestDTO,UUID tCode, String tenantCode);

	TabFieldResponseDTO deleteTabField(UUID tCode, UUIDRequestListDTO requestListDTO, String tenantId);

	List<TabSearchDTO> searchByDesc(Long moduleId, String searchTerm, Integer fetchCount, Integer fetchSize,
									String tenantCode, String language,UUID layoutId);

	Map<Object, Object> searchUnassignedTabFields(Long moduleId, String searchTerm, Integer fetchCount, Integer fetchSize,
												  String tenantCode, String language, UUID layoutId);

    List<LayoutTabDTO> getLayoutTabList(UUID layoutId, String searchTerm, String language,
										Integer fetchCount, Integer fetchSize, String tenantCode);

	List<TabFieldDTO> getTabFields(Long moduleId, UUID tCode, Integer fetchCount, Integer fetchSize, String tenantCode, Short structureId);
}
