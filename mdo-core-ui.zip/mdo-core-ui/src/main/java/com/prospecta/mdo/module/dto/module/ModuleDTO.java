/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import java.io.Serializable;
import java.util.Map;

import com.prospecta.mdo.module.model.module.CoreModuleDescriptionModel;
import com.prospecta.mdo.module.model.module.CoreModuleModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModuleDTO implements Serializable {

	private static final long serialVersionUID = -1933511557881213039L;
	@ApiModelProperty(
			name = "module",
			value = "Core Module Model Object",
			dataType = "Object"
	)
	private CoreModuleModel module;
	@ApiModelProperty(
			name = "information",
			value = "Map Representing Information",
			dataType = "Object"
	)
	private Map<String,ModuleDescriptionInformationRequestDTO> informationRequestDTOMap;
	

}
