package com.prospecta.mdo.module.util;

public class QueryConstants {

    public static final String LAYOUT_LIST = "select c from CoreLayoutHeaderModel c where " +
            "c.moduleId = :moduleId " +
            "and c.tenantId = :tenantId " +
            "and (COALESCE(:type, NULL) = null or c.type in :type) " +
            "and (COALESCE(:userCR, NULL) = null or c.userCreated in :userCR) " +
            "and (COALESCE(:userMo, NULL) = null or c.userModified in :userMo) " +
            "and (:dateCR is null or c.dateCreated = :dateCR) " +
            "and (:dateMo is null or c.dateModified = :dateMo) " +
            "and lower(c.description) LIKE lower(concat('%', :searchTerm,'%'))";

    public static final String IS_SEARCH_QUERY = "select c from CoreMetadataLangModel c,CoreMetadataModel cm where " +
            "c.moduleId = ?1 and c.language =?2 and c.tenantId =?3 and cm.isSearchEngine= true " +
            "and (c.fieldId =cm.fieldId and c.moduleId=cm.moduleId and c.tenantId=cm.tenantId) " +
            "and lower(c.shortText) LIKE lower(concat('%', ?4,'%'))";

    public static final String SEARCH_BY_DESC = "select c from CoreMetadataLangModel c,CoreMetadataModel cm where " +
            "c.moduleId = ?1 and c.language =?2 and c.tenantId =?3 " +
            "and (c.fieldId =cm.fieldId and c.moduleId=cm.moduleId and c.tenantId=cm.tenantId) " +
            "and lower(c.shortText) LIKE lower(concat('%', ?4,'%'))";

    public static final String TAB_FIELD_SEARCH = "select new com.prospecta.mdo.module.dto.tab.TabFieldDetailsDTO(l.tcode,l.tabText ,c.fieldId,m.shortText,c.description,c.fieldType) " +
            "from CoreTabLabelsModel l,CoreLayoutTabModel t,CoreTabFieldsModel c left join CoreMetadataLangModel m on c.fieldId=m.fieldId where " +
            "l.tcode=c.tcode and t.tcode=c.tcode and t.layoutId=?3 and l.language= ?2 and (" +
            "(lower(l.tabText) like lower(concat('%',?1,'%')) and (m.language =?2 or c.description is not null)) or " +
            "(lower(m.shortText) like lower(concat('%',?1,'%')) and m.language =?2) or " +
            "lower(c.description) like lower(concat('%',?1,'%')))";

    public static final String UNASSIGNED_TAB_FIELDS = "select c from CoreMetadataLangModel c,CoreMetadataModel m " +
            "where " +
            "lower(c.shortText) like lower(concat('%',:search,'%')) " +
            "and (c.fieldId NOT IN :list or COALESCE(:list, NULL) = null) " +
            "and c.language = :lang " +
            "and c.moduleId = :moduleId " +
            "and c.tenantId = :tenantId " +
            "and m.fieldId=c.fieldId " +
            "and (m.parentField is null or m.parentField ='')";

    public static final String FIND_BY_TCODE_AND_LAYOUT = "select c from CoreTabFieldsModel c,CoreLayoutTabModel t where t.tcode=c.tcode and t.layoutId =?1";

    public static final String GET_GRID_SORT_FIELDS = "select c from CoreGridSettingModel c,CoreMetadataLangModel m where c.fieldId = m.fieldId " +
            "and lower(m.shortText) like lower(concat('%',:search,'%')) " +
            "and (:id is '' or c.gridFieldId = :id) " +
            "and c.moduleId= :moduleId " +
            "and c.tenantId = :tenantId " +
            "and m.language = :lang " +
            "and c.isSort = :sort";

    public static final String GET_GRID_SEQUENCE_FIELDS = "select c from CoreGridSettingModel c,CoreMetadataLangModel m where (c.gridFieldId = :id or :id is '') " +
            "and lower(m.shortText) like lower(concat('%',:search,'%')) " +
            "and c.fieldId=m.fieldId " +
            "and c.moduleId= :moduleId " +
            "and c.tenantId = :tenantId " +
            "and m.language = :lang " +
            "and c.isSequence = :sequence";

    public static final String GET_ALL_STRUCTURES = "select c from CoreStructureModel c where c.moduleId = :moduleId and c.tenantId = :tenantId " +
            "and lower(c.strucDesc) like lower (concat('%',:search,'%')) or (:search = '' and c.strucDesc is null)" +
            "and c.language = :lang";

    public static final String GET_LAYOUT_TAB_LIST = "select new com.prospecta.mdo.module.dto.layout.LayoutTabDTO(c,m) from CoreLayoutTabModel c,CoreTabLabelsModel m where " +
            "c.layoutId =?1 and " +
            "c.tenantId =?2 and " +
            "lower(m.tabText) like lower(concat('%',?3,'%')) and " +
            "m.tcode = c.tcode and " +
            "m.language = ?4";
    
    public static final String DELETE_BY_MODULEID_LAYOUTID_RULEMAPPINGIDS = "delete from CoreLayoutRuleMappingModel c where c.moduleId = :moduleId and c.layoutId = :layoutId and"
    		+ " c.ruleMappingId IN (:existingRuleMappingIds)";

}
