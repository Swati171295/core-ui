package com.prospecta.mdo.module.dto.tab;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@NoArgsConstructor
public class TabSearchDTO {

    private UUID tabUuid;
    private String description;
    private List<TabFieldDetailsDTO> fields;

    public TabSearchDTO(UUID tabUuid, String description, List<TabFieldDetailsDTO> fields){
        this.tabUuid=tabUuid;
        this.description=description;
        this.fields=fields;
    }
}
