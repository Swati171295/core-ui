/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FieldListDTO {
	@ApiModelProperty(
			name = "fieldList",
			value = "List representing fields"
	)
	private List<FieldDTO> fieldlist;
	
}
