package com.prospecta.mdo.module.model.virtualdata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import com.prospecta.mdo.module.enums.GroupType;

import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;

/**
 * @author komal
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_VD_GROUPS")
@DynamicInsert
public class CoreVdGroupsModel implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5667824342875210606L;

	@Id
	@Type(type = "uuid-char")
	@Column(name = "GROUPID")
	private UUID groupId;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "VD_ID", nullable = false)
	private CoreVdHeaderModel coreVdHeader;
	
	@Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
	private String tenantId;
	
	@Column(name = "GROUP_NAME", columnDefinition = "nvarchar(200)")
	private String groupName;
	
	@Column(name = "GROUP_DESCRIPTION", columnDefinition = "nvarchar(2000)")
	private String groupDescription;
	
	@Column(name = "ORDER_BY", columnDefinition = "Integer")
	private int order;
	
	@Column(name = "GROUP_TYPE")
	private GroupType groupType;
	
	@Column(name = "DATECREATED")
	private Long dateCreated;

	@Column(name = "USERCREATED", columnDefinition = "nvarchar(150)")
	private String userCreated;

	@Column(name = "DATEMODIFIED")
	private Long dateModified;

	@Column(name = "USERMODIFIED", columnDefinition = "nvarchar(150)")
	private String userModified;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "coreVdGroups")
	private List<CoreVdGrpJoinInfoModel> coreVdGrpJoinInfo = new ArrayList<>();
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "coreVdGroups")
	private List<CoreVdGrpJoinOnModel> coreVdGrpJoinOn = new ArrayList<>();
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "coreVdGroups")
	private List<CoreVdGrpTransInfoModel> coreVdGrpTransInfo = new ArrayList<>();
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "coreVdGroups")
	private List<CoreVdTransFieldSettingModel> coreVdTransFieldSetting = new ArrayList<>();
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "coreVdGroups")
	private List<CoreVdGrpResultsModel> coreVdGrpResults = new ArrayList<>();


}
