package com.prospecta.mdo.module.dto.virtualdata;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import lombok.Data;

@Data
public class HeaderResponseDTO {

	private UUID vdId;
	
	private String vdName;
	
	private String indexName;

	private String tableName;
	
	private String tenantId;
	
	private String userCreated;
	
	private Long dateCreated;
	
	private String userModified;
	
	private Long dateModified;
	
	private String vdDescription;
	
	private String jobSchedulerId;
	
	List<VdGroupsResponseDTO> groupDetails = new ArrayList<>();
	
	List<VdGroupResultsResponseDTO> groupResult = new ArrayList<>();

}
