/**
 * 
 */
package com.prospecta.mdo.module.model.metadata;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import lombok.Data;

/**
 * @author savan
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_METADATA_LANG_MDO")
public class CoreMetadataLangModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5756510293990738562L;

	@Id
	@Type(type = "uuid-char")
	@Column(name = "UUID", columnDefinition = "uuid")
	private UUID uuid;
	
	@Column(name = "FIELDID", columnDefinition = "nvarchar(50)")
	private String fieldId;
	
	@Column(name = "LANGUAGE")
	private String language;
	
	@Column(name = "SHORTTEXT", columnDefinition = "nvarchar(50)")
	private String shortText;	
	
	@Column(name = "LONGTEXT", columnDefinition = "clob")
	private String longText;
	
	@Column(name = "HELPTEXT", columnDefinition = "clob")
	private String helpText;
	
	@Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
	private String tenantId;
	
	@Column(name = "MODULEID")
	private Long moduleId;
	
}
