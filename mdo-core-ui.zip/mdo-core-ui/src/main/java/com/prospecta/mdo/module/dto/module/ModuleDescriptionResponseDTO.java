/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModuleDescriptionResponseDTO {
	
	private Long moduleid;
	
	private String description;
	
	private boolean acknowledge;

	private String errorMsg;
	
}
