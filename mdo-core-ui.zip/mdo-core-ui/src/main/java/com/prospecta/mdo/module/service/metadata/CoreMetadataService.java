/**
 * 
 */
package com.prospecta.mdo.module.service.metadata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.prospecta.mdo.module.dto.metadata.CreateFieldRequestDTO;
import com.prospecta.mdo.module.dto.metadata.CreateFieldResponseDTO;
import com.prospecta.mdo.module.dto.metadata.FieldIdsRequestDTO;
import com.prospecta.mdo.module.dto.metadata.FieldWithDescriptionResponseDTO;
import com.prospecta.mdo.module.dto.metadata.ReferenceRuleRequestDTO;
import com.prospecta.mdo.module.dto.metadata.ReferenceRuleResponseDTO;
import com.prospecta.mdo.module.dto.module.FieldDTO;
import com.prospecta.mdo.module.dto.module.ModuleRequestDTO;
import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * @author savan
 *
 */
public interface CoreMetadataService {

	CreateFieldResponseDTO createField(@Valid CreateFieldRequestDTO fields, String tenantCode, String username,
			Long moduleid);

	CreateFieldResponseDTO updateField(@Valid CreateFieldRequestDTO fieldData, String tenantCode, String username,
			Long moduleid, String fieldId);

	CreateFieldResponseDTO removeField(String tenantCode, String username, Long moduleid, String fieldId);
	
	Map<Object, Object> getSearchablefieldswithdescription(Long moduleid, String language, String searchterm,
	        String fetchcount, String fetchsize, String tenantCode);

	Map<Object, Object> getHierachyFieldMap(Long moduleid, String language, List<CoreMetadataLangModel> metadataLang, String tenantCode);

	boolean generateResponseField(String language, List<FieldWithDescriptionResponseDTO> responsefieldsList,
	        FieldDTO parentField, ObjectMapper mapper);

	List<FieldWithDescriptionResponseDTO> getMetadataOfFieldsBasedOnFieldIdArrayList(FieldIdsRequestDTO reuestDTO, String language, String tenantCode);

	FieldDTO getFieldDetailsWithFieldId(Long moduleid, String fieldid, String tenantCode,String userName);

	List<String> createDynamicFieldIds(ModuleRequestDTO requestDTO, Long moduleId, String tenentId,boolean checkFields);

	Map<String,Long> fieldCount(Long moduleId, String tenantCode);

	List<FieldWithDescriptionResponseDTO> searchByDesc(Long moduleId,String tenantCode,String searchTerm,
													   Integer fetchCount,Integer fetchSize,String language);

	List<String> getChildStrucIds(String tenantCode, Long moduleid, String structureId);

	List<FieldDTO> getkeyFields(Short structureId, String tenantCode, String username, Long moduleId,
								String searchTerm,Integer fetchCount,Integer fetchSize);
	
	ReferenceRuleResponseDTO createReferenceRule(@Valid ReferenceRuleRequestDTO referenceRule, String dataReferencefieldId);
	
	ReferenceRuleResponseDTO updateReferenceRule(@Valid ReferenceRuleRequestDTO referenceRule, String referencedUuid);
}
