package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.prospecta.mdo.module.validator.ValidateFieldValue;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
@Data
@ValidateFieldValue(fieldName = "fieldType", fieldValue = "USERINPUT", dependFieldName = "fieldValue")
public class VdTransRuleConcatRequestDTO {
	
	@ApiModelProperty(
			name = "vdConcatId",
			value = "vdConcatId is the Virtual dataset concatenation id",
			dataType = "java.util.UUID",
			required = true
	)
	public UUID vdConcatId;
	
	@ApiModelProperty(
			name = "fieldType",
			value = "Field type which can be USERINPUT, TABLECOLUMN",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "fieldType must not be empty for concatination")
	public String fieldType;
	
	@ApiModelProperty(
			name = "fieldValue",
			value = "Field value, If User provieds some input then user can save things Blank space, TAB, {0-9,a-z,A-Z}",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "fieldValue must not be empty for concatination")
	public String fieldValue;
	
	@ApiModelProperty(
			name = "fieldName",
			value = "Name of the field",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "fieldName must not be empty for concatination")
	public String fieldName;
	
}