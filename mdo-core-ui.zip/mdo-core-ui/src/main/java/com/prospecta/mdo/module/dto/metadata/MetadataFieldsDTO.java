/**
 * 
 */
package com.prospecta.mdo.module.dto.metadata;

import java.io.Serializable;

import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MetadataFieldsDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8009170229940494181L;

	private CoreMetadataModel coreMetadata;
	
	private CoreMetadataLangModel langMetadata;
}
