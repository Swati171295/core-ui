/**
 * 
 */
package com.prospecta.mdo.module.dto.elastic;

import java.io.Serializable;
import java.util.List;

import lombok.Data;



/**
 * @author savan
 *
 */
@Data
public class FieldValue implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7257017829428008062L;



	/***
	* The MDO field id of the value that this java object stores
	*/
	private String fId;

	/***
	* The MDO value code against the field, should always store initial code
	*/
	private List<FieldCodeText> bc;

	/***
	* The MDO value code against the field, should always store code
	*/
	private List<FieldCodeText> vc;


	/**
	* The MDO old value against the field, use for change log
	*/
	private List<FieldCodeText> oc;


	/***
	* The MDO labels for this field id, stored based on language, key being the
	* language enum
	*/
	private String ls;
}
