/**
 * 
 */
package com.prospecta.mdo.module.dto.elastic;

import java.io.Serializable;
import java.util.LinkedHashMap;

import com.prospecta.mdo.module.enums.MDORecordStatus;

import lombok.Data;



/**
 * @author nikhil.channawar
 *
 */
@Data
public class MDORecordES implements Serializable{

	private static final long serialVersionUID = 82978089342303802L;

	/***
	 * The objectnumber of MDO
	 */
	private String id;  
	
	/***
	 * The header structure of MDO
	 */
	private String strId; 
	
	/***
	 * The header fields, with key being the field id, value is a complex construct
	 */
	private LinkedHashMap<String, FieldValue> hdvs;
	
	/***
	 * The grid values, key being the grid id, value is a complex contruct
	 */
	private LinkedHashMap<String, GridValueES> gvs;
	
	/***
	 * 	The hierarchy values, key being the hierarchy id, e.g. 4 for valuation hierarchy in material, value is a complex contruct
	 */
	private LinkedHashMap<String, HierarchyRecordES> hyvs;
	
	/***
	 * The status enum of the record at the header level
	 */
	private MDORecordStatus stat;
	
	private MaterialAttributesES noun; 
	
}
