/**
 * 
 */
package com.prospecta.mdo.module.dto.tab;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.prospecta.mdo.module.dto.layout.LayoutFieldsDTO;
import com.prospecta.mdo.module.enums.FieldType;
import com.prospecta.mdo.module.model.tab.CoreTabFieldsModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

import static org.springframework.beans.BeanUtils.copyProperties;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TabFieldDTO {


	@ApiModelProperty(
			name = "tabFieldUuid",
			value = "UUID representing tabFieldId",
			dataType = "java.util.UUID",
			hidden = true
	)
	private UUID tabFieldUuid;
	@ApiModelProperty(
			name = "fieldId",
			value = "String representing FieldId",
			dataType = "java.lang.String",
			required = true
	)
	private String fieldId;
	@ApiModelProperty(
			name = "structureId",
			value = "Structure Id",
			dataType = "java.lang.Short"
	)
	private Short structureId;
	@ApiModelProperty(
			name = "order",
			value = "Order",
			dataType = "java.lang.Short"
	)
	private Short order;
	@ApiModelProperty(
			name = "isMandatory",
			value = "Is Mandatory",
			dataType = "java.lang.Boolean"
	)
	private Boolean isMandatory;
	@ApiModelProperty(
			name = "isReadonly",
			value = "Is ReadOnly",
			dataType = "java.lang.Boolean"
	)
	private Boolean isReadonly;
	@ApiModelProperty(
			name = "isHidden",
			value = "Is Hidden",
			dataType = "java.lang.Boolean"
	)
	private Boolean isHidden;
	@ApiModelProperty(
			name = "moduleId",
			value = "Module Id",
			dataType = "java.lang.Long"
	)
	private Long moduleId;
	@ApiModelProperty(
			name = "isAdd",
			value = "Is Add",
			dataType = "java.lang.Boolean"
	)
	private Boolean isAdd;
	@ApiModelProperty(
			name = "isDelete",
			value = "Is Delete",
			dataType = "java.lang.Boolean"
	)
	private Boolean isDelete;

	@ApiModelProperty(
			name = "fieldType",
			value = "Enum representing Field Type",
			dataType = "com.prospecta.mdo.module.enums.FieldType",
			required = true
	)
	private FieldType fieldType;
	@ApiModelProperty(
			name = "description",
			value = "String representing TEXT",
			dataType = "java.lang.String",
			required = true
	)
	private String description;

	@ApiModelProperty(
			name = "url",
			value = "url containing IMAGE",
			dataType = "java.lang.String",
			required = true
	)
	private String url;

	public TabFieldDTO (CoreTabFieldsModel model) {
		copyProperties(model,this);
	}

	public TabFieldDTO(LayoutFieldsDTO layoutFieldsDTO) {
		copyProperties(layoutFieldsDTO,this);
		this.isReadonly= layoutFieldsDTO.getIsReadOnly();
	}

}
