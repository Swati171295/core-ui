package com.prospecta.mdo.module.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum JoinType {
	
	LEFT('0'), RIGHT('1'),INNER('2'),OUTER('3'), UNION('4');
	
	public char asChar() {
        return asChar;
    }

    private final char asChar;

    JoinType(char asChar) {
        this.asChar = asChar;
    }
    
    @JsonCreator
	public static JoinType fromValue(String value) {
		return Enum.valueOf(JoinType.class, value);
	}
}
