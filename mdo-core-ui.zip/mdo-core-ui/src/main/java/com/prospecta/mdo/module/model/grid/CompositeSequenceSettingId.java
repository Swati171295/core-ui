package com.prospecta.mdo.module.model.grid;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompositeSequenceSettingId implements Serializable {

    private Long moduleId;
    private String tenantId;
    private UUID gridSettingUuid;

}
