package com.prospecta.mdo.module.dto.virtualdata;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import lombok.Data;

@Data
public class VdTransFieldSettingResponseDTO {
	
	
	private UUID transFieldId;
	
	private String fieldName;
	
	private String transRuleType;
	
	private String fieldAlias;
	
	private String dataType;

	private int length;
	
	private boolean isGroup;
	
	private boolean isCustomField;
	
	private String fieldDescription;
	
    List<VdTransRuleConcatResponseDTO> transConcatDetail = new ArrayList<>();
    
    List<VdTransRuleReplaceResponseDTO> transReplaceDetail = new ArrayList<>();

}
