package com.prospecta.mdo.module.dto.grid;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.prospecta.mdo.module.enums.SortType;
import com.prospecta.mdo.module.model.grid.CoreGridSettingModel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.UUID;

import static org.springframework.beans.BeanUtils.copyProperties;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class GridSettingResponseDTO implements Serializable {

    private UUID uuid;
    private String gridFieldId;
    private String fieldId;
    private Boolean isHide;
    private Boolean isDisplayOnly;
    private Byte order;
    private Boolean isSort;
    private Boolean isSequence;
    private Boolean isUnique;
    private Boolean isEditable;
    private Boolean isMandatory;
    private SortType sortType;

    public GridSettingResponseDTO(CoreGridSettingModel model) {
        copyProperties(model, this);
    }
}
