/**
 * 
 */
package com.prospecta.mdo.module.rest.metadata;

import com.prospecta.mdo.module.dto.JWTToken;
import com.prospecta.mdo.module.dto.metadata.*;
import com.prospecta.mdo.module.dto.module.FieldDTO;
import com.prospecta.mdo.module.grpc.DynamicCrudGenerationImpl;
import com.prospecta.mdo.module.service.metadata.CoreMetadataService;
import com.prospecta.mdo.module.service.metadata.elastic.CoreMetadataElasticService;
import com.prospecta.mdo.module.util.FieldValidations;
import io.swagger.annotations.*;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author paras.miglani
 *
 */
@Api(tags = {"Metadata"}, description = "MetaData Resource")
@RestController
@RequestMapping(value = "/metadata")
public class MetadataRestController {

	@Autowired
	private CoreMetadataService coreMetadataService;

	@Autowired
	private CoreMetadataElasticService coreMetadataElasticService;

	@Autowired
    DynamicCrudGenerationImpl dynamicGenerationGrpc;

	/**
	 * This API is used to save Fields
	 * 
	 * @param moduleid
	 * @param fieldData
	 * @return
	 */
	@ApiOperation(value = "Create Field", notes = "Api to register/create new Field.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = CreateFieldResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong")})
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
	@PostMapping("/fields/{moduleId}/createField")
	public ResponseEntity<CreateFieldResponseDTO> createField(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which new field needs to be registered/created",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@Valid @PathVariable(name = "moduleId") Long moduleid,
			@ApiParam(
					name = "",
					value = "Json Object representing CreateFieldRequest",
					type = "body",
					required = true
			)
			@Valid @RequestBody CreateFieldRequestDTO fieldData) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();
		
		CreateFieldResponseDTO responseDTO = coreMetadataService.createField(fieldData, jwtToken.getTenantCode(), jwtToken.getUsername(), moduleid);
		
		if (responseDTO.isAcknowledge()) {

			return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * This API is used to Update Fields
	 * 
	 * @param moduleid
	 * @param fieldData
	 * @return
	 */
	@ApiOperation(value = "Update Field", notes = "Api to update existing Field.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = CreateFieldResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PutMapping("/{moduleId}/update/{fieldId}")
	public ResponseEntity<CreateFieldResponseDTO> updateField(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which existing field needs to be updated",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)

			@PathVariable(name = "moduleId") Long moduleid,
			@ApiParam(
					name = "fieldId",
					value = "Field Id against which the field needs to be updated",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "fieldId") String fieldId,

			@ApiParam(
					name = "",
					value = "Json Object representing CreateFieldRequest",
					type = "body",
					required = true
			)
			@Validated(FieldValidations.class) @RequestBody CreateFieldRequestDTO fieldData) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		CreateFieldResponseDTO responseDTO = coreMetadataService.updateField(fieldData, jwtToken.getTenantCode(),
				jwtToken.getUsername(), moduleid, fieldId);

		if (responseDTO.isAcknowledge()) {
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * This API is used to Remove Fields
	 * 
	 * @param moduleid
	 * @param fieldId
	 * @return
	 */
	@ApiOperation(value = "Metadata Remove Fields", notes = "This Api is used to remove fields")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = CreateFieldResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@DeleteMapping("/{moduleId}/remove/{fieldId}")
	public ResponseEntity<CreateFieldResponseDTO> removeField(
			@ApiParam(
					name = "moduleId",
					value = "Module Id against which the field needs to be updated",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleid,
			@ApiParam(
					name = "fieldId",
					value = "Field Id against which the field needs to be updated",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "fieldId") String fieldId) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		CreateFieldResponseDTO responseDTO = coreMetadataService.removeField(jwtToken.getTenantCode(),
				jwtToken.getUsername(), moduleid, fieldId);

		if (responseDTO.isAcknowledge()) {
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * This method is used to Get Searchable fields with field description.
	 * 
	 * @param moduleid
	 * @param language
	 * @param searchterm
	 * @param fetchcount
	 * @param fetchsize
	 * @return
	 */
	@ApiOperation(value = "Get Searchable fields with field description", notes = "This Api is used to search fields with field description")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = HashMap.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("fields/getSearchEngineFields/{moduleId}/{language}")
	public ResponseEntity<Map<Object, Object>> getSearchablefieldswithdescription(
			@ApiParam(
					name = "moduleId",
					value = "Module Id against which the field needs to be searched",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
	        @PathVariable(name = "moduleId") Long moduleid,
			@ApiParam(
					name = "language",
					value = "Language against which the field needs to be searched",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "en")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "language") String language,
			@ApiParam(
					name = "searchTerm",
					value = "Search Term against which the field needs to be searched",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "Earth")),
					allowableValues = "range[0, infinity]"
			)
	        @RequestParam(name = "searchterm") String searchterm,
			@ApiParam(
					name = "fetchCount",
					value = "Zero-based page index",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@RequestParam(name = "fetchcount") String fetchcount,
			@ApiParam(
					name = "fetchSize",
					value = "Size of the page to be returned.",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
	        @RequestParam(name = "fetchsize") String fetchsize) {
		
		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();
			
		Map<Object, Object> response = coreMetadataService.getSearchablefieldswithdescription(moduleid, language,
		        searchterm, fetchcount, fetchsize, jwtToken.getTenantCode());
		
		if (response != null && !response.isEmpty()) {
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/* This API is used to Remove Fields
	 * 
	 * @param moduleid
	 * @param field
	 * @return
	 */
	@ApiOperation(value = "Metadata Get Fields", notes = "Get Metadata of fields based on field Id array list.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = ArrayList.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/fields/get-fields-by-fields")
	public ResponseEntity<List<FieldWithDescriptionResponseDTO>> getMetadataOfFieldsBasedOnFieldIdArrayList(
			@ApiParam(
					name = "Language",
					value = "Language against which field to get",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "en")),
					allowableValues = "range[0, infinity]"
			)
			@RequestParam(name = "LANGUAGE") String language,
			@ApiParam(
					name = "fieldData",
					value = "Field Request",
					required = true
			)
			@RequestBody FieldIdsRequestDTO reuestDTO) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		List<FieldWithDescriptionResponseDTO> response = coreMetadataService.getMetadataOfFieldsBasedOnFieldIdArrayList(reuestDTO,language,jwtToken.getTenantCode());

		if (null != response) {
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	/**
	 * This method is used to Get fields with field id.
	 * 
	 * @param moduleid
	 * @param fieldid
	 * @return
	 */
	@ApiOperation(value = "Get Field", notes = "Get Field Details with Field Id.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = FieldDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("fields/{moduleId}/getFieldDetails")
	public ResponseEntity<FieldDTO> getFieldDetailsWithFieldId(
			@ApiParam(
					name = "moduleId",
					value = "Module Id against which the field needs to be searched",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
	        @PathVariable(name = "moduleId") Long moduleid,

			@ApiParam(
					name = "fieldId",
					value = "Field Id against which the field needs to be searched",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@RequestParam(name = "fieldid") String fieldid) {
		
		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();
			
		FieldDTO response = coreMetadataService.getFieldDetailsWithFieldId(moduleid, fieldid, jwtToken.getTenantCode(),jwtToken.getUsername());
		
		if (response != null) {
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * This API is used to save/updated Drafted Fields to ElasticSearch
	 *
	 * @param moduleId
	 * @param fieldData
	 * @return
	 */
	@ApiOperation(value = "Draft Field", notes = "Api to add new Field Draft")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = CreateFieldResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong")})
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
	@PutMapping("/fields/{moduleId}/draftField")
	public ResponseEntity<CreateFieldResponseDTO> draftField(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which new field needs to be drafted",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@Valid @PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "",
					value = "Json Object representing CreateFieldRequest",
					type = "body",
					required = true
			)
			@Valid @RequestBody CreateFieldRequestDTO fieldData) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		CreateFieldResponseDTO responseDTO = coreMetadataElasticService.createDraftField(fieldData, jwtToken.getTenantCode(), jwtToken.getUsername(), moduleId);

		return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);

	}

	/**
	 * This API is used to fetch Drafted Fields from ElasticSearch
	 *
	 * @param moduleId
	 * @param fieldId
	 * @return
	 */
	@ApiOperation(value = "Get Draft field", notes = "Get Draft field with fieldId")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = FieldDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong"),
			@ApiResponse(responseCode = "404", description = "Details Not Found")
	})
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("fields/{moduleId}/getDraftField")
	public ResponseEntity<Object> getDraftField(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which drafted field needs to be fetched",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "fieldId",
					value = "fieldId against which drafted field needs to be fetched",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "FLD_D34"))
			)
			@RequestParam(name = "fieldId") String fieldId) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		FieldDTO response = coreMetadataElasticService.getDraftField(fieldId, jwtToken.getTenantCode(), jwtToken.getUsername(), moduleId);
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	/**
	 * This API is used to delete Drafted Field from ElasticSearch
	 *
	 * @param moduleId
	 * @param fieldId
	 * @return
	 */
	@ApiOperation(value = "Delete Draft Field", notes = "Api to delete Field Draft")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = CreateFieldResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong")})
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
	@DeleteMapping("/{moduleId}/draftField/delete")
	public ResponseEntity<CreateFieldResponseDTO> deleteDraft(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which field needs to be deleted",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@Valid @PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "fieldId",
					value = "fieldId against which draft needs to be deleted",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@RequestParam(name = "fieldId") String fieldId) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		CreateFieldResponseDTO responseDTO = coreMetadataElasticService.deleteDraftField(fieldId, jwtToken.getTenantCode(), jwtToken.getUsername(), moduleId);

		return new ResponseEntity<>(responseDTO, HttpStatus.OK);

	}


	/**
	 * This API is used to bulk delete Drafted Fields from ElasticSearch
	 *
	 * @param moduleId
	 * @param requestDTO
	 * @return
	 */
	@ApiOperation(value = "Delete bulk Draft Fields", notes = "Api to delete bulk Field Draft")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = BulkDeleteDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong")})
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
	@DeleteMapping("/{moduleId}/draftField/bulk/delete")
	public ResponseEntity<BulkDeleteDTO> deleteBulkDraft(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which drafts need to be deleted",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@Valid @PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "",
					value = "Json Object representing FieldIdsRequest",
					type = "body",
					required = true
			)
			@RequestBody @Valid FieldIdsRequestDTO requestDTO) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		BulkDeleteDTO responseDTO = coreMetadataElasticService.deleteBulkDraftField(requestDTO, jwtToken.getTenantCode(), jwtToken.getUsername(), moduleId);

		return new ResponseEntity<>(responseDTO, HttpStatus.OK);

	}

	/**
	 * This API is used to Fetch Field Count
	 *
	 * @param moduleId
	 * @return
	 */
	@ApiOperation(value= "Fetch Field Count", notes = "Api to Fetch Field Count")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = Map.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/{moduleId}/count")
	public ResponseEntity<Map<String,Long>> layoutCount(

			@ApiParam(
					name = "moduleId",
					value = "Module Id against which the field count needs to be fetched",
					required = true,
					type = "Long",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleId) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		return new ResponseEntity<>(coreMetadataService.fieldCount(moduleId,
				jwtToken.getTenantCode()),HttpStatus.OK);
	}

	/**
	 * This method is used to Search fields with field description.
	 *
	 * @param moduleid
	 * @param language
	 * @param searchTerm
	 * @param fetchCount
	 * @param fetchSize
	 * @return
	 */
	@ApiOperation(value = "Search fields with field description", notes = "This Api is used to search fields with field description")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
					mediaType = "application/json",
					array = @ArraySchema(schema = @Schema(implementation = FieldWithDescriptionResponseDTO.class))
			)}),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/list-by-description/{moduleId}/{language}")
	public ResponseEntity<List<FieldWithDescriptionResponseDTO>> searchFieldsWithDescription(
			@ApiParam(
					name = "moduleId",
					value = "Module Id against which the field needs to be searched",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleid,
			@ApiParam(
					name = "language",
					value = "Language against which the field needs to be searched",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "en")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "language") String language,
			@ApiParam(
					name = "searchTerm",
					value = "Search Term against which the field needs to be searched",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "Earth")),
					allowableValues = "range[0, infinity]"
			)
			@RequestParam(name = "searchTerm") String searchTerm,
			@ApiParam(
					name = "fetchCount",
					value = "Zero-based page index",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@RequestParam(name = "fetchCount") Integer fetchCount,
			@ApiParam(
					name = "fetchSize",
					value = "Size of the page to be returned.",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@RequestParam(name = "fetchSize") Integer fetchSize) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		List<FieldWithDescriptionResponseDTO> response = coreMetadataService.searchByDesc(moduleid,jwtToken.getTenantCode() ,
				searchTerm, fetchCount, fetchSize,language );

			return new ResponseEntity<>(response, HttpStatus.OK);

	}

	/**
	 * This API is used to fetch Key fields in Hierarchy
	 *
	 * @param moduleId
	 * @param structureId
	 * @return
	 */
	@ApiOperation(value = "Get Key fields", notes = "Get Key fields in a Hierarchy")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
					mediaType = "application/json",
					array = @ArraySchema(schema = @Schema(implementation = FieldDTO.class))
			)}),
			@ApiResponse(responseCode = "500", description = "Something went wrong")
	})
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/{moduleId}/get-key-fields/{structId}")
	public ResponseEntity<List<FieldDTO>> getKeyFields(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which key fields needs to be fetched",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "structureId",
					value = "structureId against which key fields needs to be fetched",
					required = true,
					type = "Short",
					format = "Short",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@PathVariable(name = "structId") Short structureId,
			@ApiParam(
					name = "searchTerm",
					value = "Search Term",
					required = true,
					type = "String",
					format = "String"
			)
			@RequestParam(name = "searchTerm") String searchTerm,
			@ApiParam(
					name = "fetchCount",
					value = "Offset",
					required = true,
					type = "Short",
					format = "Short",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@RequestParam(name = "fetchCount") Integer fetchCount,
			@ApiParam(
					name = "fetchSize",
					value = "Limit",
					required = true,
					type = "Short",
					format = "Short",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@RequestParam(name = "fetchSize") Integer fetchSize) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		List<FieldDTO> response = coreMetadataService.getkeyFields(structureId, jwtToken.getTenantCode(), jwtToken.getUsername(), moduleId,
				searchTerm,fetchCount,fetchSize);
		return new ResponseEntity<>(response, HttpStatus.OK);

	}
	
	/**
	 * This API is used to save reference rule
	 * 
	 * @param moduleid
	 * @param fieldData
	 * @return
	 */
	@ApiOperation(value = "Save Reference Rule", notes = "Api to save new reference rule.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = ReferenceRuleResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong")})
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
	@PostMapping("/save-reference-rule/{dataReferencefieldId}")
	public ResponseEntity<ReferenceRuleResponseDTO> saveReferenceRule(
			@ApiParam(
					name = "dataReferencefieldId",
					value = "data reference field id which needs to be saved",
					required = true,
					type = "String",
					format = "String"
			)
			@Valid @PathVariable(name = "dataReferencefieldId") String dataReferencefieldId,
			@ApiParam(
					name = "",
					value = "Json Object representing reference rule data",
					type = "body",
					required = true
			)
			@Valid @RequestBody ReferenceRuleRequestDTO referenceRuleData) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();
		
		ReferenceRuleResponseDTO responseDTO = coreMetadataService.createReferenceRule(referenceRuleData, dataReferencefieldId);
		
		if (responseDTO.isAcknowledge()) {

			return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * This API is used to Update Fields
	 * 
	 * @param moduleid
	 * @param fieldData
	 * @return
	 */
	@ApiOperation(value = "Update Reference Rule", notes = "Api to update existing reference rule.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = CreateFieldResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PutMapping("/update-reference-rule/{referencedUuid}")
	public ResponseEntity<ReferenceRuleResponseDTO> updateReferenceRule(
			@ApiParam(
					name = "referencedUuid",
					value = "ReferencedUuid against which existing rule needs to be updated",
					required = true,
					type = "String",
					format = "String"
			)
			@PathVariable(name = "referencedUuid") String referencedUuid,
			@ApiParam(
					name = "",
					value = "Json Object representing reference rule data",
					type = "body",
					required = true
			)
			@Valid @RequestBody ReferenceRuleRequestDTO referenceRuleData) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		ReferenceRuleResponseDTO responseDTO = coreMetadataService.updateReferenceRule(referenceRuleData, referencedUuid);

		if (responseDTO.isAcknowledge()) {
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}

