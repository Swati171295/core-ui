/**
 * 
 */
package com.prospecta.mdo.module.dao.layout;

import com.prospecta.mdo.module.dto.layout.LayoutTabDTO;
import com.prospecta.mdo.module.model.layout.CoreLayoutTabModel;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

import static com.prospecta.mdo.module.util.QueryConstants.GET_LAYOUT_TAB_LIST;

/**
 * @author savan
 *
 */
@Repository
public interface CoreLayoutTabDAO extends PagingAndSortingRepository<CoreLayoutTabModel, UUID> {

	CoreLayoutTabModel findByTcodeAndLayoutIdAndTenantId(UUID tcode, UUID layoutId, String tenantCode);

	List<CoreLayoutTabModel> findByLayoutIdAndTenantId(UUID layoutId,String tenantCode);

	void deleteByTcode(UUID tCode);

	@Query(GET_LAYOUT_TAB_LIST)
	List<LayoutTabDTO> findByLayoutId(UUID layoutId, String tenantId, String search, String language, Pageable pageable);

	@Query("select c.tcode from CoreLayoutTabModel c where c.tcode not in ?1")
	List<UUID> findIdByTcodeNotIn(List<UUID> tCodes);

}
