package com.prospecta.mdo.module.dao.virtualdata;

import java.util.List;
import java.util.UUID;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

@Repository
public interface CoreVdGroupsDAO extends PagingAndSortingRepository<CoreVdGroupsModel, UUID>{

	List<CoreVdGroupsModel> findByCoreVdHeader(CoreVdHeaderModel coreVdHeaderModel);

	void deleteByCoreVdHeader(CoreVdHeaderModel coreVdHeaderModel);

	List<CoreVdGroupsModel> findByGroupIdIn(List<UUID> groupId);

	void deleteByGroupIdIn(List<UUID> groupId);

}
