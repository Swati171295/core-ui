/**
 * 
 */
package com.prospecta.mdo.module.dao.tab;

import com.prospecta.mdo.module.dto.tab.TabFieldDetailsDTO;
import com.prospecta.mdo.module.model.tab.CoreTabFieldsModel;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static com.prospecta.mdo.module.util.QueryConstants.FIND_BY_TCODE_AND_LAYOUT;
import static com.prospecta.mdo.module.util.QueryConstants.TAB_FIELD_SEARCH;

/**
 * @author savan
 *
 */
@Repository
public interface CoreTabFieldsDAO extends PagingAndSortingRepository<CoreTabFieldsModel, UUID> {

	List<CoreTabFieldsModel> findByTcode(UUID tcode);

	List<CoreTabFieldsModel> findByUuidIn(List<UUID> list);

	Optional<List<CoreTabFieldsModel>> findByTcodeAndTenantId(UUID tcode,String tenantId);

	Optional<CoreTabFieldsModel> findByTcodeAndUuid(UUID tcode,UUID tabFieldCode);

	Optional<List<CoreTabFieldsModel>> findByTcodeIn(List<UUID> tcode);

	List<CoreTabFieldsModel> findByTcodeAndUuidNotIn(UUID tCode,List<UUID> uuid);


	CoreTabFieldsModel findByFieldIdAndTcode(String fieldId, UUID tCode);

	Optional<CoreTabFieldsModel> findByFieldIdAndTcodeAndTenantId(String fieldId, UUID tCode,String tenantId);

	@Query(TAB_FIELD_SEARCH)
	List<TabFieldDetailsDTO> searchTabFieldsByDesc(String searchTerm, String language,UUID layoutId, Pageable pageable);

	@Query(FIND_BY_TCODE_AND_LAYOUT)
	List<CoreTabFieldsModel> findBytCodeandLayoutId(UUID layoutId);

	List<CoreTabFieldsModel> findByTcodeAndTenantIdAndModuleId(UUID tCode,String tenantCode,Long moduleId,Pageable pageable);

	List<CoreTabFieldsModel> findByTcodeAndTenantIdAndModuleIdAndStructureId(UUID tCode,String tenantCode,Long moduleId,Short structureId,Pageable pageable);
}
