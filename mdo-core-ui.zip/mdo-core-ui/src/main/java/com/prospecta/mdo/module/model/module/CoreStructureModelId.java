/**
 * 
 */
package com.prospecta.mdo.module.model.module;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data 
@NoArgsConstructor
public class CoreStructureModelId implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -253546947944243274L;

	private Short structureId;
	
	private Long moduleId;
	
	private String tenantId;

	public CoreStructureModelId(Short structureId, Long moduleId, String tenantId) {
		super();
		this.structureId = structureId;
		this.moduleId = moduleId;
		this.tenantId = tenantId;
	}
	
}
