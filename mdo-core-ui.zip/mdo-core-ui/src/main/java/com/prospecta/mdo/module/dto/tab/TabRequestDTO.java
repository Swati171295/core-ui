/**
 * 
 */
package com.prospecta.mdo.module.dto.tab;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TabRequestDTO {
	@ApiModelProperty(
			name = "moduleId",
			value = "Module Id",
			dataType = "java.lang.String"
	)
	@Schema(description = "")
	private String moduleid;
	@ApiModelProperty(
			name = "description",
			value = "Map representing description",
			dataType = "Object",
			required = true
	)
	private Map<String, String> description;
	@ApiModelProperty(
			name = "information",
			value = "Map representing information",
			dataType = "Object",
			required = true
	)
	private Map<String, String> information;
	
}
