/**
 * 
 */
package com.prospecta.mdo.module.model.layout;

import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.UUID;

/**
 * @author satyam
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_LAYOUT_RULES_MAPPING")
public class CoreLayoutRuleMappingModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2427727024549974366L;

	@Id 
	@Type(type = "uuid-char")
	@Column(name = "UUID", columnDefinition = "uuid")
	private UUID uuid;
	
	@Type(type = "uuid-char")
	@Column(name = "LAYOUTID", columnDefinition = "uuid")
	private UUID layoutId;
	
	@Type(type = "uuid-char")
	@Column(name = "RULE_MAPPING_ID", columnDefinition = "uuid")
	private UUID ruleMappingId;
	
	@Column(name = "MODULEID")
	private Long moduleId;
	
	@Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
	private String tenantId;
	
}
