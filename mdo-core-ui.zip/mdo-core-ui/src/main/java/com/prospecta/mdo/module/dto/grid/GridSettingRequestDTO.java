package com.prospecta.mdo.module.dto.grid;

import com.prospecta.mdo.module.enums.SortType;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

/**
 * @author jaineet.singh
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GridSettingRequestDTO implements Serializable {

    private static final long serialVersionUID = -1916839950886547232L;

    @ApiModelProperty(
            name = "fieldId",
            value = "Field Id",
            dataType = "java.lang.String"
    )
    @NotEmpty(message = "FieldId must not be null")
    @Pattern(regexp = "[a-zA-z0-9]*", message = "wrong format for field id,no special characters allowed except underscore")
    private String fieldId;

    @ApiModelProperty(
            name = "isHide",
            value = "Is Hide",
            dataType = "java.lang.Boolean"
    )
    @NotNull(message = "isHide must not be null")
    private Boolean isHide;

    @ApiModelProperty(
            name = "isDisplayOnly",
            value = "isDisplayOnly",
            dataType = "java.lang.Boolean"
    )
    @NotNull(message = "isDisplayOnly must not be null")
    private Boolean isDisplayOnly;

    @ApiModelProperty(
            name = "order",
            value = "Field Order",
            dataType = "java.lang.Byte"
    )
    @NotNull(message = "order must not be null")
    private Byte order;

    @ApiModelProperty(
            name = "isSort",
            value = "Depicts whether field is sortable,default value is false",
            dataType = "java.lang.Boolean"
    )
    private Boolean isSort=false;

    @ApiModelProperty(
            name = "isSequence",
            value = "Depicts whether field is sequence enabled,default value is false",
            dataType = "java.lang.Boolean"
    )
    private Boolean isSequence=false;

    @ApiModelProperty(
            name = "isUnique",
            value = "Depicts whether field is unique,default value is false",
            dataType = "java.lang.Boolean"
    )
    private Boolean isUnique=false;

    @ApiModelProperty(
            name = "isEditable",
            value = "Depicts whether field is editable,default value is false",
            dataType = "java.lang.Boolean"
    )
    private Boolean isEditable=false;

    @ApiModelProperty(
            name = "isMandatory",
            value = "Depicts whether field is mandatory,default value is false",
            dataType = "java.lang.Boolean"
    )
    private Boolean isMandatory=false;

    @ApiModelProperty(
            name = "sortType",
            value = "Depicts How the grid fields will be sorted",
            dataType = "com.prospecta.mdo.module.enums.SortType"
    )
    private SortType sortType;
}
