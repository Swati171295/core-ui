package com.prospecta.mdo.module.exception;

public class NotFound404Exception extends RuntimeException {

    private String message;

    public NotFound404Exception(String message) {
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
