/**
 * 
 */
package com.prospecta.mdo.module.dto.layout;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LayoutRequestDTO {
	@ApiModelProperty(
			name = "description",
			value = "Description",
			dataType = "java.lang.String"
	)
	private String description;
	@ApiModelProperty(
			name = "type",
			value = "Type",
			dataType = "java.lang.String"
	)
	private String type;
	@ApiModelProperty(
			name = "usage",
			value = "Usage",
			dataType = "java.lang.String"
	)
	private String usage;
	@ApiModelProperty(
			name = "helpText",
			value = "URL Helptext",
			dataType = "java.lang.String"
	)
	private String helpText;
	@ApiModelProperty(
			name = "labels",
			value = "Comma Separated Labels",
			dataType = "java.lang.String"
	)
	private String labels;
	
}
