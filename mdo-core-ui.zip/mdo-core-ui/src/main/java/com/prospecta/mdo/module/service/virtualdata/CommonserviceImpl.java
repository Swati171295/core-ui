package com.prospecta.mdo.module.service.virtualdata;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpJoinInfoDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpTransInfoDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdHeaderDAO;
import com.prospecta.mdo.module.dto.virtualdata.*;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.model.virtualdata.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.springframework.beans.BeanUtils.copyProperties;

@Service
@Slf4j
@Transactional
public class CommonserviceImpl implements CommonService {

	@Autowired
	private CoreVdGroupsService coreVdGroupsService;

	@Autowired
	private CoreVdHeaderService coreVdHeaderService;

	@Autowired
	private CoreVdGrpJoinInfoService coreVdGrpJoinInfoService;

	@Autowired
	private CoreVdGrpJoinOnService coreVdGrpJoinOnService;

	@Autowired
	private CoreVdGrpResultsService coreVdGrpResultsService;

	@Autowired
	private CoreVdTransInfoService coreVdTransInfoService;

	@Autowired
	private CoreVdGrpJoinMappingService coreVdGrpJoinMappingService;

	@Autowired
	private CoreVdTransRuleConcatService coreVdTransRuleConcatService;

	@Autowired
	private CoreVdTransRuleReplaceService coreVdTransRuleReplaceService;

	@Autowired
	private CoreVdTransFieldSettingService coreVdTransFieldSettingService;

	@Autowired
	private CoreVdGrpJoinInfoDAO coreVdGrpJoinInfoDAO;

	@Autowired
	private CoreVdGrpTransInfoDAO coreVdGrpTransInfoDAO;

	@Autowired
	private CoreVdHeaderDAO coreVdHeaderDAO;

	@Autowired
	private WebClientImpl webClientImpl;

	/**
	 * This method is used to update virtual dataset.
	 * 
	 * @param request
	 * @param tenantCode
	 */
	@Override
	@Transactional
	public CommonResponseDTO updateVirtualDataset(VdHeaderRequestDTO request, String tenantCode) {

		StopWatch watch = new StopWatch();
		log.info("Update virtual dataset data");
		watch.start("Start updating virtual dataset data");
		log.info("save virtual dataset information");
		CoreVdGroupsModel coreVdGroupsModel = null;
		CoreVdHeaderModel coreVdHeader = coreVdHeaderService.updateVirtualDataset(request, tenantCode);
		if (coreVdHeader == null) {
			throw new CommonVirtualDatasetException("There is some error while updating virtual dataset.");
		}
		log.info("delete the corevdgroup information if any deleted by user");
		coreVdGroupsService.deleteCoreVdGroup(request.getGroupDetails(), coreVdHeader.getVdId());
		for (VdGroupsRequestDTO groupsRequestDTO : request.getGroupDetails()) {
			log.info("save and upadte corevdgroup information");
			coreVdGroupsModel = coreVdGroupsService.saveOrUpdateVdGroups(groupsRequestDTO, coreVdHeader, tenantCode);
			log.info("delete join group information if any deleted by user.");
			coreVdGrpJoinInfoService.deleteVdGroupInfo(groupsRequestDTO.getGroupJoinDetail(),
					coreVdGroupsModel.getGroupId());

			for (VdGroupJoinInfoRequestDTO groupJoinInfoRequestDTO : groupsRequestDTO.getGroupJoinDetail()) {
				log.info("save and update join group information ");
				CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = coreVdGrpJoinInfoService
						.saveAndUpdateGrpJoinInfo(groupJoinInfoRequestDTO, coreVdGroupsModel);
				log.info("delete group join mapping information if any deleted by users.");
				coreVdGrpJoinMappingService.deleteVdGrpJoinMapping(groupJoinInfoRequestDTO.getJoinMapping(),
						coreVdGrpJoinInfoModel.getUuid());

				for (VdGroupJoinMappingRequestDTO groupJoinMappingRequestDTO : groupJoinInfoRequestDTO
						.getJoinMapping()) {
					log.info("save and update group join mapping information");
					coreVdGrpJoinMappingService.saveAndUpdateJoinMapping(groupJoinMappingRequestDTO,
							coreVdGrpJoinInfoModel);
				}
			}
			log.info("delete group join on information if any deleted by user");
			coreVdGrpJoinOnService.deleteVdGrpJoinOn(groupsRequestDTO.getJoinColumns(), coreVdGroupsModel.getGroupId());
			for (VdGroupJoinOnRequestDTO groupJoinOnRequestDTO : groupsRequestDTO.getJoinColumns()) {
				log.info("save and update group join information");
				coreVdGrpJoinOnService.saveAndUpdateJoinOn(groupJoinOnRequestDTO, coreVdGroupsModel);
			}
			log.info("delete the core virtual dataset transformation group information if any deleted by user");
			coreVdTransInfoService.deleteVdTransInfo(groupsRequestDTO.getGroupTransDetail(),
					coreVdGroupsModel.getGroupId());

			for (VdGroupTransInfoRequestDTO transInfoRequestDTO : groupsRequestDTO.getGroupTransDetail()) {
				log.info("save and upadte core virtual dataset transformation information");
				CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = coreVdTransInfoService
						.saveOrUpdateVdTransInfo(transInfoRequestDTO, coreVdGroupsModel);
				log.info("delete transformation field setting if any deleted by user.");
				coreVdTransFieldSettingService.deleteVdTransFieldSetting(
						transInfoRequestDTO.getGroupTransFieldSetting(), coreVdGrpTransInfoModel.getUuid());

				for (VdTransFieldSettingRequestDTO groupTransFieldSettingRequestDTO : transInfoRequestDTO
						.getGroupTransFieldSetting()) {
					log.info("save and update transformation field setting");
					CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = coreVdTransFieldSettingService
							.saveAndUpdateTransFieldSetting(groupTransFieldSettingRequestDTO, coreVdGrpTransInfoModel);
					log.info("delete transformation rule concat if any deleted by users.");
					coreVdTransRuleConcatService.deleteVdTransRuleConcat(
							groupTransFieldSettingRequestDTO.getTransConcatDetail(),
							coreVdTransFieldSettingModel.getTransId());

					for (VdTransRuleConcatRequestDTO groupTransRuleConcatRequestDTO : groupTransFieldSettingRequestDTO
							.getTransConcatDetail()) {
						log.info("save and update transformation rule concat");
						coreVdTransRuleConcatService.saveAndUpdateRuleConcat(groupTransRuleConcatRequestDTO,
								coreVdTransFieldSettingModel);
					}
					log.info("delete transformation rule replace if any deleted by users.");
					coreVdTransRuleReplaceService.deleteVdTransRuleReplace(
							groupTransFieldSettingRequestDTO.getTransReplaceDetail(),
							coreVdTransFieldSettingModel.getTransId());
					for (VdTransRuleReplaceRequestDTO groupTransRuleReplaceRequestDTO : groupTransFieldSettingRequestDTO
							.getTransReplaceDetail()) {
						log.info("save and update transformation rule replace");
						coreVdTransRuleReplaceService.saveOrUpdateVdTransRuleReplace(groupTransRuleReplaceRequestDTO,
								coreVdTransFieldSettingModel);
					}
				}
			}

		}
		log.info("delete group results if any deleted by users.");
		coreVdGrpResultsService.deleteVdGroupResults(request.getGroupResult(), coreVdHeader.getVdId());
		for (VdGroupResultsRequestDTO groupResultsRequestDTO : request.getGroupResult()) {
			log.info("save and update group results");
			coreVdGrpResultsService.saveOrUpdateVdGroupResults(groupResultsRequestDTO, coreVdGroupsModel, coreVdHeader);
		}
		watch.stop();
		log.info(watch.prettyPrint());
		VdHeaderResponseDTO vdHeaderResponseDTO = new VdHeaderResponseDTO();
		copyProperties(coreVdHeader, vdHeaderResponseDTO);
		return new CommonResponseDTO(201, true, "virtual dataset saved sucessfully.", vdHeaderResponseDTO);
	}

	/**
	 * This method is used to get virtual dataset.
	 * 
	 * @param vdId
	 */
	@Override
	public ResponseDTO getVirtualDataset(UUID vdId, String tokenKey) {
		if (vdId != null) {
			StopWatch watch = new StopWatch();
			HeaderResponseDTO vdHeaderResponseDTO = new HeaderResponseDTO();
			try {
				log.info("Get virtual dataset data");
				watch.start("Start Getting virtual dataset data");
				log.info("Get virtual dataset information");
				CoreVdHeaderModel coreVdHeaderModel = coreVdHeaderService.getVirtualDataset(vdId);
				copyProperties(coreVdHeaderModel, vdHeaderResponseDTO);
				List<VdGroupsResponseDTO> vdGroupsResponseDTOList = new ArrayList<>();
				log.info("Map virtual dataset group information.");
				for (CoreVdGroupsModel coreVdGroupsModel : coreVdHeaderModel.getCoreVdGroups()) {
					VdGroupsResponseDTO vdGroupsResponseDTO = new VdGroupsResponseDTO();
					copyProperties(coreVdGroupsModel, vdGroupsResponseDTO);
					vdGroupsResponseDTO.setGroupType(coreVdGroupsModel.getGroupType().toString());
					List<VdGroupJoinInfoResponseDTO> vdGroupJoinInfoResponseDTOList = new ArrayList<>();

					log.info("Map virtual dataset group join information.");
					for (CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel : coreVdGroupsModel.getCoreVdGrpJoinInfo()) {
						VdGroupJoinInfoResponseDTO vdGroupJoinInfoResponseDTO = new VdGroupJoinInfoResponseDTO();
						copyProperties(coreVdGrpJoinInfoModel, vdGroupJoinInfoResponseDTO);
						vdGroupJoinInfoResponseDTO.setGroupJoinId(coreVdGrpJoinInfoModel.getUuid());
						vdGroupJoinInfoResponseDTO.setSourceOneModule(coreVdGrpJoinInfoModel.getSourceOneModuleId());
						vdGroupJoinInfoResponseDTO.setSourceTwoModule(coreVdGrpJoinInfoModel.getSourceTwoModuleId());
						vdGroupJoinInfoResponseDTO
								.setSourceOneType(coreVdGrpJoinInfoModel.getSourceOneType().toString());
						vdGroupJoinInfoResponseDTO
								.setSourceTwoType(coreVdGrpJoinInfoModel.getSourceTwoType().toString());
						vdGroupJoinInfoResponseDTO.setJoinType(coreVdGrpJoinInfoModel.getJoinType().toString());
						vdGroupJoinInfoResponseDTO.setJoinOperator(coreVdGrpJoinInfoModel.getJoinOperator().toString());
						vdGroupJoinInfoResponseDTO.setResultScopeUdr(webClientImpl.getVirtualDataUdrId(
								Long.parseLong(coreVdGrpJoinInfoModel.getResultScopeUdrId()), tokenKey));
						vdGroupJoinInfoResponseDTO.setSourceOneScopeUdr(webClientImpl.getVirtualDataUdrId(
								Long.parseLong(coreVdGrpJoinInfoModel.getSourceOneScopeUdrId()), tokenKey));
						vdGroupJoinInfoResponseDTO.setSourceTwoScopeUdr(webClientImpl.getVirtualDataUdrId(
								Long.parseLong(coreVdGrpJoinInfoModel.getSourceTwoScopeUdrId()), tokenKey));
						List<VdGroupJoinMappingResponseDTO> vdGroupJoinMappingResponseDTOList = new ArrayList<>();

						log.info("Map virtual dataset group join mapping information.");
						for (CoreVdGrpJoinMappingModel coreVdGrpJoinMappingModel : coreVdGrpJoinInfoModel
								.getCoreVdGrpJoinMapping()) {
							VdGroupJoinMappingResponseDTO vdGroupJoinMappingResponseDTO = new VdGroupJoinMappingResponseDTO();
							copyProperties(coreVdGrpJoinMappingModel, vdGroupJoinMappingResponseDTO);
							vdGroupJoinMappingResponseDTO.setJoinMappingId(coreVdGrpJoinMappingModel.getUuid());
							vdGroupJoinMappingResponseDTO
									.setOperator(coreVdGrpJoinMappingModel.getCompareOperator().toString());
							vdGroupJoinMappingResponseDTO.setOrderBy(coreVdGrpJoinMappingModel.getOrder());
							vdGroupJoinMappingResponseDTO
									.setSourceOneField(coreVdGrpJoinMappingModel.getSourceOneFieldId());
							vdGroupJoinMappingResponseDTO
									.setSourceTwoField(coreVdGrpJoinMappingModel.getSourceTwoFieldId());
							vdGroupJoinMappingResponseDTOList.add(vdGroupJoinMappingResponseDTO);
						}
						vdGroupJoinInfoResponseDTO.setJoinMapping(vdGroupJoinMappingResponseDTOList);
						vdGroupJoinInfoResponseDTOList.add(vdGroupJoinInfoResponseDTO);
					}
					vdGroupsResponseDTO.setGroupJoinDetail(vdGroupJoinInfoResponseDTOList);
					List<VdGroupJoinOnResponseDTO> vdGroupJoinOnResponseDTOList = new ArrayList<>();

					log.info("Map virtual dataset group join on information.");
					for (CoreVdGrpJoinOnModel coreVdGrpJoinOnModel : coreVdGroupsModel.getCoreVdGrpJoinOn()) {
						VdGroupJoinOnResponseDTO vdGroupJoinOnResponseDTO = new VdGroupJoinOnResponseDTO();
						copyProperties(coreVdGrpJoinOnModel, vdGroupJoinOnResponseDTO);
						vdGroupJoinOnResponseDTO.setCondition(coreVdGrpJoinOnModel.getCompareOperator().toString());
						vdGroupJoinOnResponseDTO.setJoinColumnId(coreVdGrpJoinOnModel.getJoinOnId());
						vdGroupJoinOnResponseDTO.setSourceField(coreVdGrpJoinOnModel.getSourceOne());
						vdGroupJoinOnResponseDTO.setSourceFieldId(coreVdGrpJoinOnModel.getSourceOneFieldId());
						vdGroupJoinOnResponseDTO.setTargetField(coreVdGrpJoinOnModel.getSourceTwo());
						vdGroupJoinOnResponseDTO.setTargetFieldId(coreVdGrpJoinOnModel.getSourceTwoFieldId());
						vdGroupJoinOnResponseDTOList.add(vdGroupJoinOnResponseDTO);
					}
					vdGroupsResponseDTO.setJoinColumns(vdGroupJoinOnResponseDTOList);
					List<VdGroupTransInfoResponseDTO> vdGroupTransInfoResponseDTOList = new ArrayList<>();

					log.info("Map virtual dataset group tranformation information.");
					for (CoreVdGrpTransInfoModel coreVdGrpTransInfoModel : coreVdGroupsModel.getCoreVdGrpTransInfo()) {
						VdGroupTransInfoResponseDTO vdGroupTransInfoResponseDTO = new VdGroupTransInfoResponseDTO();
						copyProperties(coreVdGrpTransInfoModel, vdGroupTransInfoResponseDTO);
						vdGroupTransInfoResponseDTO.setGroupTransId(coreVdGrpTransInfoModel.getUuid());
						vdGroupTransInfoResponseDTO.setSourceType(coreVdGrpTransInfoModel.getSourceType().toString());
						vdGroupTransInfoResponseDTO.setSourceModule(coreVdGrpTransInfoModel.getSourceModuleId());
						vdGroupTransInfoResponseDTO.setSourceScope(coreVdGrpTransInfoModel.getSourceScope().toString());
						vdGroupTransInfoResponseDTO.setResultScopeUdr(webClientImpl.getVirtualDataUdrId(
								Long.parseLong(coreVdGrpTransInfoModel.getResultScopeUdrId()), tokenKey));
						vdGroupTransInfoResponseDTO.setSourceScopeUdr(webClientImpl.getVirtualDataUdrId(
								Long.parseLong(coreVdGrpTransInfoModel.getSourceScopeUdrId()), tokenKey));
						List<VdTransFieldSettingResponseDTO> vdTransFieldSettingResponseDTOList = new ArrayList<>();

						log.info("Map virtual dataset field setting information.");
						for (CoreVdTransFieldSettingModel coreVdTransFieldSettingModel : coreVdGrpTransInfoModel
								.getCoreVdTransFieldSetting()) {
							VdTransFieldSettingResponseDTO vdTransFieldSettingResponseDTO = new VdTransFieldSettingResponseDTO();
							copyProperties(coreVdTransFieldSettingModel, vdTransFieldSettingResponseDTO);
							vdTransFieldSettingResponseDTO.setTransFieldId(coreVdTransFieldSettingModel.getTransId());
							vdTransFieldSettingResponseDTO.setTransRuleType(coreVdTransFieldSettingModel.getRuleType());
							List<VdTransRuleConcatResponseDTO> vdTransRuleConcatResponseDTOList = new ArrayList<>();

							log.info("Map virtual dataset tranformation rule concat information.");
							for (CoreVdTransRuleConcatModel coreVdTransRuleConcatModel : coreVdTransFieldSettingModel
									.getCoreVdTransRuleConcat()) {
								VdTransRuleConcatResponseDTO vdTransRuleConcatResponseDTO = new VdTransRuleConcatResponseDTO();
								copyProperties(coreVdTransRuleConcatModel, vdTransRuleConcatResponseDTO);
								vdTransRuleConcatResponseDTO
										.setFieldType(coreVdTransRuleConcatModel.getFieldType().toString());
								vdTransRuleConcatResponseDTOList.add(vdTransRuleConcatResponseDTO);
							}
							List<VdTransRuleReplaceResponseDTO> vdTransRuleReplaceResponseDTOList = new ArrayList<>();

							log.info("Map virtual dataset tranformation rule replace information.");
							for (CoreVdTransRuleReplaceModel coreVdTransRuleReplaceModel : coreVdTransFieldSettingModel
									.getCoreVdTransRuleReplace()) {
								VdTransRuleReplaceResponseDTO vdTransRuleReplaceResponseDTO = new VdTransRuleReplaceResponseDTO();
								copyProperties(coreVdTransRuleReplaceModel, vdTransRuleReplaceResponseDTO);
								vdTransRuleReplaceResponseDTOList.add(vdTransRuleReplaceResponseDTO);
							}
							vdTransFieldSettingResponseDTO.setTransConcatDetail(vdTransRuleConcatResponseDTOList);
							vdTransFieldSettingResponseDTO.setTransReplaceDetail(vdTransRuleReplaceResponseDTOList);
							vdTransFieldSettingResponseDTOList.add(vdTransFieldSettingResponseDTO);
						}
						vdGroupTransInfoResponseDTO.setGroupTransFieldSetting(vdTransFieldSettingResponseDTOList);
						vdGroupTransInfoResponseDTOList.add(vdGroupTransInfoResponseDTO);
					}
					vdGroupsResponseDTO.setGroupTransDetail(vdGroupTransInfoResponseDTOList);
					vdGroupsResponseDTOList.add(vdGroupsResponseDTO);
				}
				List<VdGroupResultsResponseDTO> vdGroupResultsResponseDTOList = new ArrayList<>();

				log.info("Map virtual dataset group result information.");
				for (CoreVdGrpResultsModel coreVdGrpResultsModel : coreVdHeaderModel.getCoreVdGrpResults()) {
					VdGroupResultsResponseDTO vdGroupResultsResponseDTO = new VdGroupResultsResponseDTO();
					copyProperties(coreVdGrpResultsModel, vdGroupResultsResponseDTO);
					vdGroupResultsResponseDTO.setResultId(coreVdGrpResultsModel.getUuid());
					vdGroupResultsResponseDTOList.add(vdGroupResultsResponseDTO);
				}
				vdHeaderResponseDTO.setGroupDetails(vdGroupsResponseDTOList);
				vdHeaderResponseDTO.setGroupResult(vdGroupResultsResponseDTOList);
			} catch (Exception e) {
				log.error("error while get Virtual Dataset Information: " + e.getMessage());
				throw new CommonVirtualDatasetException(e.getMessage());
			}
			watch.stop();
			log.info(watch.prettyPrint());
			return new ResponseDTO("Success", vdHeaderResponseDTO);
		} else {
			throw new CommonVirtualDatasetException("virtual dataset id not present while getting it.");
		}
	}

	@Override
	@Transactional
	public CommonResponseDTO deleteVirtualDataset(UUID vdId, String tokenKey) {
		if (null != vdId) {
			if (coreVdHeaderDAO.existsById(vdId)) {
				StopWatch watch = new StopWatch();
				List<String> udrIdList = new ArrayList<>();
				List<CoreVdGroupsModel> groupIdList = coreVdGroupsService.getVdGroupsbyvdId(vdId);
				try {
					log.info("Delete virtual dataset data");
					watch.start("Start deleting virtual dataset data");
					for (CoreVdGroupsModel coreVdGroupsModel : groupIdList) {
						for (CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel : coreVdGrpJoinInfoDAO
								.findByCoreVdGroups(coreVdGroupsModel)) {
							udrIdList.add(coreVdGrpJoinInfoModel.getSourceOneScopeUdrId());
							udrIdList.add(coreVdGrpJoinInfoModel.getSourceTwoScopeUdrId());
							udrIdList.add(coreVdGrpJoinInfoModel.getResultScopeUdrId());
						}
						for (CoreVdGrpTransInfoModel coreVdGrpTransInfoModel : coreVdGrpTransInfoDAO
								.findByCoreVdGroups(coreVdGroupsModel)) {
							udrIdList.add(coreVdGrpTransInfoModel.getSourceScopeUdrId());
							udrIdList.add(coreVdGrpTransInfoModel.getResultScopeUdrId());
						}
					}
					coreVdHeaderService.deleteVirtualDataset(vdId);
					log.info("Start deleting udrid");
					for (String udrId : udrIdList) {
						webClientImpl.deleteUdrId(udrId, tokenKey);
						log.info("Delete udr id is:" + udrId);
					}
				} catch (Exception e) {
					log.error(e.getMessage());
					throw new CommonVirtualDatasetException("error during deleting virtual dataset.");
				}
				watch.stop();
				log.info(watch.prettyPrint());
				return new CommonResponseDTO(200, true, "virtual dataset delete sucessfully.", "");
			} else {
				log.error("error occured while deleting with vdId " + vdId);
				throw new CommonVirtualDatasetException("virtual dataset are not found.");
			}
		} else {
			log.error("vdId can not be null.");
			throw new CommonVirtualDatasetException("vdId can not be null.");
		}

	}
}
