/**
 *
 */
package com.prospecta.mdo.module.rest.module;

import com.prospecta.mdo.module.dto.JWTToken;
import com.prospecta.mdo.module.dto.module.*;
import com.prospecta.mdo.module.model.module.CoreModuleModel;
import com.prospecta.mdo.module.model.module.CoreStructureModel;
import com.prospecta.mdo.module.service.module.CoreModuleService;
import com.prospecta.mdo.module.util.FieldValidations;
import io.swagger.annotations.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author paras.miglani
 */
@RestController
@RequestMapping(value = "/module")
@Api(tags = {"Module"}, description = "Module Resource")
public class ModuleRestController {

    @Autowired
    private CoreModuleService coreModuleService;

    /**
     * This API is used to save the module based on the data provided into the request
     *
     * @param requestDto
     * @return
     */
    @ApiOperation(value = "Save Module.", notes = "This Api is used to save the module")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = ModuleResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @PostMapping(value = "/save")
    public ResponseEntity<ModuleResponseDTO> saveModule(
            @ApiParam(
                    name = "",
                    value = "Json Object representing ModuleRequest",
                    type = "body",
                    required = true
            )
            @Validated(FieldValidations.class) @RequestBody ModuleRequestDTO requestDto) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        ModuleResponseDTO responseDTO = coreModuleService.saveModel(requestDto, jwtToken.getTenantCode());

        if (responseDTO.isAcknowledge()) {
            return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This API is used to save Fields
     *
     * @param moduleid
     * @param field
     * @return
     */
    @ApiOperation(value = "Save Field", notes = "This Api is used to save fields against a module id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = FieldResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @PostMapping("/fields/{moduleId}/save")
    public ResponseEntity<FieldResponseDTO> saveField(
            @ApiParam(
                    name = "moduleId",
                    value = "ModuleId against which filed needs to be saved",
                    required = true,
                    type = "number",
                    format = "integer",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleid,
            @ApiParam (
                    name = "",
                    value = "Json Object representing FieldRequest",
                    type = "body",
                    required = true
            )
            @Validated(FieldValidations.class) @RequestBody FieldDTO field) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        FieldResponseDTO responseDTO = coreModuleService.saveField(field, jwtToken.getTenantCode(), moduleid);

        if (responseDTO.isAcknowledge()) {
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This API is used to get All the fieldIds related to structure id.
     *
     * @param requestDTO
     * @param moduleid
     * @param language
     * @param fetchcount
     * @param fetchsize
     * @return
     */
    @ApiOperation(value = "Get All fieldIds with StructureId.", notes = "Get All fieldIds with StructureId")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = FieldIdsWithStructureResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @PostMapping("/fields/{moduleId}/{lang}/listFieldIdByStructure")
    public ResponseEntity<FieldIdsWithStructureResponseDTO> getFieldIdsWithStructure(
            @ApiParam(
                    name = "",
                    value = "Json Object representing FieldIdsWithStructureRequest",
                    type = "body",
                    required = true
            )
            @RequestBody FieldIdsWithStructureRequestDTO requestDTO,
            @ApiParam (
                    name = "moduleId",
                    value = "ModuleId against which fields needs to be fetched",
                    required = true,
                    type = "number",
                    format = "integer",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleid,
            @ApiParam (
                    name = "lang",
                    value = "Language",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "en"))
            )
            @PathVariable(name = "lang") String language,
            @ApiParam (
                    name = "fetchcount",
                    value = "Fetch Count",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "0"))
            )
            @RequestParam(name = "fetchcount") String fetchcount,
            @ApiParam (
                    name = "fetchsize",
                    value = "Fetch Size",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "10"))
            )
            @RequestParam(name = "fetchsize") String fetchsize) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();
        

        FieldIdsWithStructureResponseDTO responseDTO = coreModuleService.getFieldsWithStructure(requestDTO.getStructureId(), moduleid, language, fetchcount, fetchsize, jwtToken.getTenantCode());

        if (responseDTO.isAcknowledge()) {
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This method is used to Get All fieldId, MaxChar and shorttext based on pickList and searched description and Language
     *
     * @param requestDTO
     * @param language
     * @param moduleid
     * @param fetchcount
     * @param fetchsize
     * @return
     */
    @Operation(description = "Get All Picklist fields.", tags = {})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = PickListFieldsResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @PostMapping(value = "/fields/{moduleId}/{lang}/listByPicklist")
    public ResponseEntity<PickListFieldsResponseDTO> getAllPicklistFields(
            @ApiParam(
                    name = "",
                    value = "Json Object representing PicklistFieldsRequest",
                    type = "body",
                    required = true
            )
            @RequestBody PicklistFieldsRequestDTO requestDTO,
            @ApiParam (
                    name = "lang",
                    value = "Language",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "en"))
            )
            @PathVariable(name = "lang") String language,
            @ApiParam (
                    name = "moduleId",
                    value = "ModuleId against which picklist fields needs to be fetched",
                    required = true,
                    type = "number",
                    format = "integer",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleid,
            @ApiParam (
                    name = "fetchcount",
                    value = "Fetch Count",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "0"))
            )
            @RequestParam(name = "fetchcount") String fetchcount,
            @ApiParam (
                    name = "fetchsize",
                    value = "Fetch Size",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "10"))
            )
            @RequestParam(name = "fetchsize") String fetchsize) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        PickListFieldsResponseDTO responseDTO = coreModuleService.getAllPicklistFields(requestDTO, moduleid, language,
                fetchcount, fetchsize, jwtToken.getTenantCode());

        if (responseDTO.isAcknowledge()) {
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This method is used to Get All fieldId, MaxChar, DataType, pickList, structureId and shortText based on dataType and searched description and Language
     *
     * @param requestDTO
     * @param language
     * @param moduleid
     * @param fetchcount
     * @param fetchsize
     * @return
     */
    @Operation(description = "Get All Data Type fields.", tags = {})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = DataTypeFieldsResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @PostMapping(value = "/fields/{moduleId}/{lang}/listByDataType")
    public ResponseEntity<DataTypeFieldsResponseDTO> getAllDataTypefields(
            @ApiParam(
                    name = "",
                    value = "Json Object representing DataTypeFieldsRequestRequest",
                    type = "body",
                    required = true
            )
            @RequestBody DataTypeFieldsRequestDTO requestDTO,
            @ApiParam (
                    name = "lang",
                    value = "Language",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "en"))
            )
            @PathVariable(name = "lang") String language,
            @ApiParam (
                    name = "moduleId",
                    value = "ModuleId against which fields needs to be fetched",
                    required = true,
                    type = "number",
                    format = "integer",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleid,
            @ApiParam (
                    name = "fetchcount",
                    value = "Fetch Count",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "0"))
            )
            @RequestParam(name = "fetchcount") String fetchcount,
            @ApiParam (
                    name = "fetchsize",
                    value = "Fetch Size",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "10"))
            )
            @RequestParam(name = "fetchsize") String fetchsize) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        DataTypeFieldsResponseDTO responseDTO = coreModuleService.getAllDataTypefields(requestDTO, moduleid, language,
                fetchcount, fetchsize, jwtToken.getTenantCode());

        if (responseDTO.isAcknowledge()) {
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This API is used to update the module description
     *
     * @param requestDto
     * @return
     */
    @ApiOperation(value = "Update Module Description", notes = "This Api is used update Module Struture")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = ModuleResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @PutMapping(value = "/{moduleId}/update/description")
    public ResponseEntity<ModuleResponseDTO> updateModuleDescription(
            @ApiParam(
                    name = "",
                    value = "Object representing ModuleDescriptionRequest",
                    type = "body",
                    required = true
            )
            @RequestBody Map<String, ModuleDescriptionInformationRequestDTO> requestDto,
            @ApiParam(
                    name = "moduleId",
                    value = "ModuleId against which filed needs to be saved",
                    required = true,
                    type = "number",
                    format = "integer",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleid) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        if (requestDto != null) {
            ModuleResponseDTO responseDTO = coreModuleService.updateModuleDescription(requestDto, jwtToken.getTenantCode(), moduleid);
            if (Objects.nonNull(responseDTO))
                if (responseDTO.isAcknowledge()) {
                    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
                } else {
                    return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
                }
        } else {
            return new ResponseEntity<>(new ModuleResponseDTO(), HttpStatus.INTERNAL_SERVER_ERROR);

        }
        return new ResponseEntity<>(new ModuleResponseDTO(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * This API is used to get All the fieldIds related to structure.
     *
     * @param moduleid
     * @param language
     * @param fetchcount
     * @param fetchsize
     * @return
     */
    @ApiOperation(value = "Get All fields by Structure", notes= "Get All fields by Structure")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = ArrayList.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @GetMapping("/fields/{moduleId}/{lang}/listFieldIdyStructure/{structureId}")
    public ResponseEntity<List<FieldDTO>> getAllFieldsByStructure(
            @ApiParam (
                    name = "moduleId",
                    value = "ModuleId against which fields needs to be fetched",
                    required = true,
                    type = "number",
                    format = "integer",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleid,
            @ApiParam (
                    name = "lang",
                    value = "Language",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "en"))
            )
            @PathVariable(name = "lang") String language,
            @ApiParam (
                    name = "structureId",
                    value = "Structure Id against which fields needs to be fetched",
                    required = true,
                    type = "number",
                    format = "integer",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "structureId") String structureId,
            @ApiParam (
                    name = "fetchcount",
                    value = "Fetch Count",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "0"))
            )
            @RequestParam(name = "fetchcount") String fetchcount,
            @ApiParam (
                    name = "fetchsize",
                    value = "Fetch Size",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "10"))
            )
            @RequestParam(name = "fetchsize") String fetchsize) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        List<FieldDTO> response = coreModuleService.getAllFieldsByStructure(moduleid, language,
                structureId, fetchcount, fetchsize, jwtToken.getTenantCode());

        if (null != response && !response.isEmpty()) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This method is used to get List of all Modules.
     *
     * @param fetchcount
     * @param fetchsize
     * @return
     */
    @ApiOperation(value = "List of all Modules", notes ="List of all Modules")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = ArrayList.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @GetMapping("/get-all-modules")
    public ResponseEntity<List<CoreModuleModel>> getAllModules(
            @ApiParam (
                    name = "lang",
                    value = "Language",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "en"))
            )
            @RequestParam(name = "language") String language,
            @ApiParam (
                    name = "fetchcount",
                    value = "Fetch Count",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "0"))
            )
            @RequestParam(name = "fetchcount") String fetchcount,
            @ApiParam (
                    name = "fetchsize",
                    value = "Fetch Size",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "10"))
            )
            @RequestParam(name = "fetchsize") String fetchsize) {


        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        List<CoreModuleModel> response = coreModuleService.getAllModules(language, fetchcount, fetchsize,
                jwtToken.getTenantCode());

        if (null != response && !response.isEmpty()) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This method is used to get the module tree based on the search keyword.
     *
     * @param language
     * @param description
     * @return
     */
    @ApiOperation(value = "Get Object and Fields", notes = "Get Object and Fields by description")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = ArrayList.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @GetMapping("/getbydescription/{lang}/{description}")
    public ResponseEntity<List<ModuleTreeDTO>> getObjectAndFieldsByDescription(
            @ApiParam (
                    name = "lang",
                    value = "Language",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "en"))
            )
            @PathVariable(name = "lang") String language,
            @ApiParam (
                    name = "description",
                    value = "Description against which fields needs to be fetched",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "white"))
            )
            @PathVariable(name = "description") String description) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        List<ModuleTreeDTO> response = coreModuleService.getModuleTree(language, description, jwtToken.getTenantCode());

        if (null != response) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This method is used to get the module tree based on the search keyword.
     *
     * @param language
     * @return
     */
    @ApiOperation(value = "Get Module Description", notes ="Get Module Description based on moduleid")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = ModuleDescriptionDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @GetMapping("/get-module-desc/{moduleId}/{lang}")
    public ResponseEntity<ModuleDescriptionDTO> getModuleDescriptionBasedOnModuleid(
            @ApiParam (
                    name = "moduleId",
                    value = "ModuleId against which description needs to be fetched",
                    required = true,
                    type = "number",
                    format = "integer",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleid,
            @ApiParam (
                    name = "lang",
                    value = "Language",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "en"))
            )
            @PathVariable(name = "lang") String language) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        ModuleDescriptionDTO response = coreModuleService.getModuleDescriptionBasedOnModuleid(moduleid, language, jwtToken.getTenantCode());

        if (null != response) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get All Modules Based On Search Details.
     *
     * @param language
     * @param description
     * @return
     */
    @ApiOperation(value = "Get All Modules", notes = "Get All Modules Based On Search Details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = ArrayList.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @GetMapping("{lang}/get-modules")
    public ResponseEntity<List<CoreModuleModel>> getAllModulesBasedOnSearchDetails(
            @ApiParam (
                    name = "lang",
                    value = "Language",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "en"))
            )
            @PathVariable(name = "lang") String language,
            @ApiParam (
                    name = "description",
                    value = "Description",
                    required = true,
                    type = "String",
                    format = "String",
                    examples = @Example(value = @ExampleProperty(value = "white"))
            )
            @RequestParam(name = "description") String description) {


        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        List<CoreModuleModel> response = coreModuleService.getAllModulesBasedOnSearchDetails(language, description,
                jwtToken.getTenantCode());

        if (null != response && !response.isEmpty()) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get All Modules Based On Search Details.
     *
     * @param moduleId
     * @return
     */
    @ApiOperation(value = "Get Module Details", notes = "Get Modules Details Based On ModuleID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = ArrayList.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @GetMapping("{moduleId}/getDetails")
    public ResponseEntity<CoreModuleResponse> getDetails(
            @ApiParam (
                    name = "moduleId",
                    value = "ModuleId against which module needs to be fetched",
                    required = true,
                    type = "number",
                    format = "integer",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleId) {
        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();
        CoreModuleResponse response = coreModuleService.getDetailsByModuleId(jwtToken.getTenantCode(), moduleId);
        if (null != response) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(new CoreModuleResponse(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This API is used to save the module based on the data provided into the request
     *
     * @param requestDto
     * @return
     */
    @ApiOperation(value = "Save Module Structure", notes = "This Api is used to save Module Structure")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Created/Updated", content = @Content(schema = @Schema(implementation = ModuleResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @PostMapping(value = "/saveAndUpdateStructure")
    public ResponseEntity<CoreStructureModel> saveAndUpdateStructure(
            @ApiParam(
                    name = "",
                    value = "Json Object representing ModuleStructureRequest",
                    type = "body",
                    required = true
            )
            @Valid @RequestBody ModuleStructureDTO requestDto) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        return new ResponseEntity<>(coreModuleService.saveAndUpdateStructure(requestDto, jwtToken.getTenantCode()), new HttpHeaders(), HttpStatus.OK);

    }
    
    
    /**
     * This API is used to update the module
     *
     * @param requestDto
     * @return
     */
    @ApiOperation(value = "Update Module", notes = "This Api is used to update Module")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = ModuleResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header")})
    @PutMapping(value = "/update/{moduleId}")
    public ResponseEntity<ModuleResponseDTO> updateModule(
            @ApiParam(
                    name = "",
                    value = "Json Object representing ModuleRequest",
                    type = "body",
                    required = true
            )
            @Validated(FieldValidations.class) @RequestBody ModuleRequestDTO requestDto,
            @ApiParam (
                    name = "moduleId",
                    value = "ModuleId against which module needs to be updated",
                    required = true,
                    type = "number",
                    format = "integer",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleid) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        if (requestDto != null) {
            ModuleResponseDTO responseDTO = coreModuleService.updateModule(requestDto, jwtToken.getTenantCode(), moduleid);
            if (Objects.nonNull(responseDTO))
                if (responseDTO.isAcknowledge()) {
                    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
                } else {
                    return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
                }
        } else {
            return new ResponseEntity<>(new ModuleResponseDTO(), HttpStatus.INTERNAL_SERVER_ERROR);

        }
        return new ResponseEntity<>(new ModuleResponseDTO(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * This method is used to delete Module.
     *
     * @param moduleId
     * @return
     */
    @ApiOperation(value= "Delete Module", notes = "Api to Delete Module")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = ModuleResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong") })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
    @DeleteMapping("/delete")
    public ResponseEntity<ModuleResponseDTO> deleteModule(

            @ApiParam(
                    name = "moduleId",
                    value = "Module Id against which the Module needs to be deleted",
                    required = true,
                    type = "Long",
                    format = "Long",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @RequestParam(name = "moduleId") Long moduleId) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        ModuleResponseDTO responseDTO = coreModuleService.deleteModule(moduleId,
                jwtToken.getTenantCode());

        return new ResponseEntity<>(responseDTO,HttpStatus.OK);
    }

    /**
     * This method is used to delete Structure.
     *
     * @param moduleId
     * @return
     */
    @ApiOperation(value= "Delete Structure", notes = "Api to Delete Structure")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = ModuleResponseDTO.class))),
            @ApiResponse(responseCode = "500", description = "Something went wrong") })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
    @DeleteMapping("/{moduleId}/delete-structure/{structureId}")
    public ResponseEntity<ModuleResponseDTO> deleteStructure(

            @ApiParam(
                    name = "moduleId",
                    value = "Module Id against which the Structure needs to be deleted",
                    required = true,
                    type = "Long",
                    format = "Long",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleId,
            @ApiParam(
                    name = "structureId",
                    value = "Structure Id against which the Structure needs to be deleted",
                    required = true,
                    type = "Short",
                    format = "Short",
                    examples = @Example(value = @ExampleProperty(value = "1"))
            )
            @PathVariable(name = "structureId") Short structureId) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

        ModuleResponseDTO responseDTO = coreModuleService.deleteStructure(moduleId,structureId,
                jwtToken.getTenantCode());

        return new ResponseEntity<>(responseDTO,HttpStatus.OK);
    }

    /**
     * This method is used to get all Structures in a module.
     *
     */
    @ApiOperation(value= "Get Structures", notes = "Get all Structures in a module")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = ModuleStructureDTO.class))
            )}),
            @ApiResponse(responseCode = "500", description = "Something went wrong") })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
    @GetMapping("/{moduleId}/get-all-structures/{language}")
    public ResponseEntity<List<ModuleStructureDTO>> getStructures(

            @ApiParam(
                    name = "moduleId",
                    value = "Module Id against which the Structure needs tbe fetched",
                    required = true,
                    type = "Long",
                    format = "Long",
                    examples = @Example(value = @ExampleProperty(value = "1")),
                    allowableValues = "range[0, infinity]"
            )
            @PathVariable(name = "moduleId") Long moduleId,
            @ApiParam(
                    name = "language",
                    value = "Language for search",
                    required = true,
                    type = "String",
                    format = "String"
            )
            @PathVariable(name = "language") String language,
            @ApiParam(
                    name = "searchTerm",
                    value = "Filter using structure description",
                    required = true,
                    type = "String",
                    format = "String"
            )
            @RequestParam(name = "searchTerm") String searchTerm,
            @ApiParam(
                    name = "fetchCount",
                    value = "Offset",
                    required = true,
                    type = "Integer",
                    format = "number"
            )
            @RequestParam(name = "fetchCount") Integer fetchCount,
            @ApiParam(
                    name = "fetchSize",
                    value = "Limit",
                    required = true,
                    type = "Integer",
                    format = "Number"
            )
            @RequestParam(name = "fetchSize") Integer fetchSize) {

        // Extract JWTToken
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        JWTToken jwtToken = (JWTToken) auth.getDetails();

       List<ModuleStructureDTO> responseDTO = coreModuleService.getAllStructures(moduleId,jwtToken.getTenantCode(),searchTerm,
                language,fetchCount,fetchSize);

        return new ResponseEntity<>(responseDTO,HttpStatus.OK);
    }
}