/**
 * 
 */
package com.prospecta.mdo.module.dao.metadata;

import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

import static com.prospecta.mdo.module.util.QueryConstants.*;

/**
 * @author savan
 *
 */
@Repository
public interface CoreMetadataLangDAO extends PagingAndSortingRepository<CoreMetadataLangModel, UUID> {

	List<CoreMetadataLangModel> findByFieldIdAndTenantId(String fieldId, String tenantCode);

	CoreMetadataLangModel findByFieldIdAndLanguageAndTenantIdAndModuleId(String fieldId, String language, String tenantCode, Long moduleId);

	List<CoreMetadataLangModel> findByLanguageAndTenantIdAndShortTextLike(String language, String tenantCode, String description);

	@Query(IS_SEARCH_QUERY)
	List<CoreMetadataLangModel> findByIsSearchableAndSearchTerm(Long moduleid, String language,
																String tenantCode, String searchterm, Pageable pageable);

	@Query(SEARCH_BY_DESC)
	List<CoreMetadataLangModel> findBySearchTerm(Long moduleid, String language,
																String tenantCode, String searchterm, Pageable pageable);

	List<CoreMetadataLangModel> findByFieldIdAndTenantIdAndModuleId(String fieldId, String tenantCode, Long moduleId);

	@Query(UNASSIGNED_TAB_FIELDS)
	List<CoreMetadataLangModel> searchByFieldidNotIn(@Param("list") List<String> fields, @Param("search") String searchterm,
													 @Param("lang") String language, @Param("moduleId") Long moduleId,
													 @Param("tenantId") String tenantId, Pageable pageable);

	void deleteByFieldIdInAndModuleIdAndTenantId(List<String> fields,Long moduleId,String tenantCode);

}
