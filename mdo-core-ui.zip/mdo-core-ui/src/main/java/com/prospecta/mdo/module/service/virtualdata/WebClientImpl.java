
package com.prospecta.mdo.module.service.virtualdata;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.prospecta.mdo.module.dto.virtualdata.RestJobRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.SyncReqDTO;

import com.prospecta.mdo.module.dto.virtualdata.DeleteUdrResponse;

import com.prospecta.mdo.module.dto.virtualdata.UdrResponseDTO;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class WebClientImpl {

	@Value("${server.canonical.url:localhost}")
	private String serverUrl;

	@Value("${spark.endpoint:localhost}")
	private String sparkEndPoint;

	private final WebClient webClient;

	public WebClientImpl(WebClient.Builder webClientBuilder) {
		this.webClient = webClientBuilder.build();
	}

	/**
	 * This method is used to delete virtual data using udrId from webClient
	 * 
	 * @param udrId
	 * @param jwtToken
	 * @return DeleteUdrResponse
	 */
	public DeleteUdrResponse deleteUdrId(String udrId, String tokenKey) {
		try {
			return webClient.delete().uri(serverUrl.replace("/core", "") + "/rule/schema/metadata/delete-udr/" + udrId)
					.header("Authorization", "Bearer " + tokenKey).retrieve()
					.onStatus(status -> status.value() == HttpStatus.UNAUTHORIZED.value(),
							response -> Mono.error(new RuntimeException("token is expired" + response.statusCode())))
					.onStatus(status -> status.isError() && status.value() != HttpStatus.NOT_FOUND.value(),
							response -> Mono.error(new RuntimeException(
									"something went wrong while deleting udrId: " + response.statusCode())))
					.onStatus(status -> status.value() == HttpStatus.NOT_FOUND.value(), response -> Mono.empty())
					.bodyToFlux(DeleteUdrResponse.class).blockFirst();

		} catch (Exception ex) {
			log.error(ex.getMessage());
			throw new CommonVirtualDatasetException("error during deleting udr id.");
		}
	}

	/**
	 * This method is used to get virtual dataset udrIds details
	 * 
	 * @param udrId
	 * @param jwtToken
	 * @return UdrResponseDTO
	 */
	public UdrResponseDTO getVirtualDataUdrId(Long udrId, String tokenKey) {
		try {
			return webClient.get().uri(serverUrl.replace("/core", "") + "/rule/schema/metadata/udr/info/" + udrId)
					.header("Authorization", "Bearer " + tokenKey).retrieve()
					.onStatus(status -> status.value() == HttpStatus.UNAUTHORIZED.value(),
							response -> Mono.error(new RuntimeException("token is expired" + response.statusCode())))
					.onStatus(status -> status.isError(),
							response -> Mono.error(new RuntimeException(
									"something went wrong while getting udrId" + response.statusCode())))
					.bodyToFlux(UdrResponseDTO.class).blockFirst();

		} catch (Exception ex) {
			log.error(ex.getMessage());
			throw new CommonVirtualDatasetException(ex.getMessage());
		}

	}

	/**
	 * This method is used to schedule a job
	 * 
	 * @param dto
	 * @param jwtToken
	 */
	public void saveScheduleJob(RestJobRequestDTO restJobRequestdto, String tokenKey) {
		try {
			webClient.post().uri(serverUrl.replace("/core", "") + "/sched/api/v1.0/schedule/virtualdataset")
					.header("Authorization", "Bearer " + tokenKey).bodyValue(restJobRequestdto).retrieve()
					.onStatus(status -> status.value() == HttpStatus.UNAUTHORIZED.value(),
							response -> Mono.error(new RuntimeException("token is expired" + response.statusCode())))
					.onStatus(status -> status.isError(),
							response -> Mono.error(new RuntimeException(
									"something went wrong while schedule job" + response.statusCode())))
					.bodyToFlux(void.class).blockFirst();

		} catch (Exception ex) {
			log.error(ex.getMessage());
			throw new CommonVirtualDatasetException(ex.getMessage());
		}

	}

	/**
	 * This method is used to send scheduler to spark
	 * 
	 * @param syncReq
	 * @param jwtToken
	 */
	public ResponseEntity<HashMap> sendToSpark(SyncReqDTO syncReq, String tokenKey) {

		try {
			return webClient.post().uri(sparkEndPoint).header("Authorization", "Bearer " + tokenKey).bodyValue(syncReq)
					.retrieve()
					.onStatus(status -> status.value() == HttpStatus.UNAUTHORIZED.value(),
							response -> Mono.error(new RuntimeException("token is expired" + response.statusCode())))
					.onStatus(status -> status.isError(),
							response -> Mono.error(new RuntimeException(
									"something went wrong while send scheduler to spark." + response.statusCode())))
					.toEntity(HashMap.class).block();

		} catch (Exception ex) {
			log.error(ex.getMessage());
			throw new CommonVirtualDatasetException(ex.getMessage());
		}

	}

}
