package com.prospecta.mdo.module.wrapper;

import lombok.Data;

@Data
public class ObjectTypeDTO {

	private String objectid;

	private String objectdesc;
}
