/**
 * 
 */
package com.prospecta.mdo.module.model.tab;

import com.prospecta.mdo.module.enums.FieldType;
import lombok.Data;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.io.Serializable;
import java.util.UUID;

/**
 * @author savan
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_TAB_FIELDS")
@DynamicInsert
public class CoreTabFieldsModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7624304217917750616L;

	@Id 
	@Type(type = "uuid-char")
	@Column(name = "UUID")
	private UUID uuid;
	
	@Type(type = "uuid-char")
	@Column(name = "TCODE")
	private UUID tcode;
	
	@Column(name = "FIELDID", columnDefinition = "nvarchar(50)")
	private String fieldId;
	
	@Column(name = "STRUCTUREID", columnDefinition = "tinyint")
	private Short structureId;
	
	@Column(name = "FIELD_ORDER", columnDefinition = "tinyint")
	private Short order;
	
	@Column(name = "IS_MANDATORY")
	private Boolean isMandatory;
	
	@Column(name = "IS_READONLY")
	private Boolean isReadOnly;
	
	@Column(name = "IS_HIDDEN")
	private Boolean isHidden;
	
	@Column(name = "MODULEID")
	private Long moduleId;
	
	@Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
	private String tenantId;
	
	@Column(name = "IS_ADD")
	private Boolean isAdd;
	
	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@Column(name= "FIELD_TYPE")
	@Enumerated(EnumType.STRING)
	private FieldType fieldType;

	@Column(name= "DESCRIPTION",columnDefinition = "clob")
	private String description;

	@Column(name= "URL")
	private String url;
	
}
