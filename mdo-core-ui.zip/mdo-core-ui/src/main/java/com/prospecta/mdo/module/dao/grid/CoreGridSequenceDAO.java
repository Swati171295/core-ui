package com.prospecta.mdo.module.dao.grid;

import com.prospecta.mdo.module.model.grid.CompositeSequenceSettingId;
import com.prospecta.mdo.module.model.grid.CoreGridSequenceSetting;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface CoreGridSequenceDAO extends PagingAndSortingRepository<CoreGridSequenceSetting, CompositeSequenceSettingId> {
}
