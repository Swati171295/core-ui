package com.prospecta.mdo.module.service.virtualdata;

import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpJoinOnDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinOnRequestDTO;
import com.prospecta.mdo.module.enums.CompareOperator;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinOnModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class CoreVdGrpJoinOnServiceImpl implements CoreVdGrpJoinOnService {

	@Autowired
	private CoreVdGrpJoinOnDAO coreVdGrpJoinOnDAO;
	
	@Autowired
	private CoreVdGroupsDAO coreVdGroupsDAO;
	
	String message = "Virtual dataset group join on not found";
	/**
     * This method is used to get the virtual dataset join on by join id.
     * @param joinId
     */
	@Override
	public CoreVdGrpJoinOnModel getVdGroupJoinOnbyGrpJoinId(UUID joinId) {
		StopWatch watch = new StopWatch();
		watch.start("Get Core vd Group Join On");
		Optional<CoreVdGrpJoinOnModel> coreVdGrpJoinOnModel=coreVdGrpJoinOnDAO.findById(joinId);
		if (!coreVdGrpJoinOnModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGrpJoinOnModel.get();
	}
	
	/**
     * This method is used to get the virtual dataset join on by group info id.
     * @param groupInfoId
     */
	@Override
	public List<CoreVdGrpJoinOnModel> getVdGroupJoinOnbygroupInfoId(UUID groupInfoId) {
		StopWatch watch = new StopWatch();
		watch.start("Get List of Core vd Group Join On");
		Optional<CoreVdGroupsModel> coreVdGroupsModel=coreVdGroupsDAO.findById(groupInfoId);
		if (!coreVdGroupsModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		List<CoreVdGrpJoinOnModel> coreVdGrpJoinOnModel=coreVdGrpJoinOnDAO.findByCoreVdGroups(coreVdGroupsModel.get());
		if (coreVdGrpJoinOnModel.isEmpty()) {
			throw new NotFound404Exception(message);
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdGrpJoinOnModel;
	}
	
	/**
     * This method is used to delete the virtual dataset join on by join id.
     * @param joinId
     */
	@Override
	public void deleteVdGroupJoinOnbyGrpJoinId(UUID joinId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Join On Information");
		watch.start("Delete vd groups");
		coreVdGrpJoinOnDAO.deleteById(joinId);
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to delete the virtual dataset join on by group info id.
     * @param groupInfoId
     */
	@Override
	public void deleteVdGroupJoinOnbygroupInfoId(UUID groupInfoId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Join On by groin info id started");
		watch.start("Delete vd groups");
		Optional<CoreVdGroupsModel> coreVdGroupsModel=coreVdGroupsDAO.findById(groupInfoId);
		if (!coreVdGroupsModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		coreVdGrpJoinOnDAO.deleteByCoreVdGroups(coreVdGroupsModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
	}

	/**
     * This method is used to delete the virtual dataset join on by group info id.
     * @param joinColumns
     * @param groupId
     */
	@Override
	public void deleteVdGrpJoinOn(List<VdGroupJoinOnRequestDTO> joinColumns, UUID groupId) {
		StopWatch watch = new StopWatch();
		try {
			watch.start("Delete vd group join on information");
			log.info("Fetch the all group join on information with vdId and compare with new data");
			Optional<CoreVdGroupsModel> coreVdGroupsModel = coreVdGroupsDAO.findById(groupId);
			if (!coreVdGroupsModel.isPresent()) {
				log.error(message);
				throw new NotFound404Exception(message);
			}
			List<UUID> newJoinOnIds = joinColumns.stream().filter(g -> g.getJoinColumnId() != null)
					.map(VdGroupJoinOnRequestDTO::getJoinColumnId).collect(Collectors.toList());
			List<UUID> joinOnIds = coreVdGrpJoinOnDAO.findByCoreVdGroups(coreVdGroupsModel.get()).stream()
					.filter(grp -> !newJoinOnIds.contains(grp.getJoinOnId())).map(CoreVdGrpJoinOnModel::getJoinOnId)
					.collect(Collectors.toList());
			log.info("Delete all the group join information data if user deleted any");
			coreVdGrpJoinOnDAO.deleteByJoinOnIdIn(joinOnIds);
			watch.stop();
			log.info(watch.prettyPrint());
		} catch (Exception e) {
			log.error("error while Delete vd group join on information: " + e.getMessage());
			throw new CommonVirtualDatasetException(e.getMessage());
		}
	}

	@Override
	public CoreVdGrpJoinOnModel saveAndUpdateJoinOn(VdGroupJoinOnRequestDTO groupJoinOnRequestDTO,
			CoreVdGroupsModel coreVdGroupsModel) {
		if (groupJoinOnRequestDTO != null) {
			if (coreVdGroupsModel != null) {
				StopWatch watch = new StopWatch();
				CoreVdGrpJoinOnModel coreVdGrpJoinOnModel = new CoreVdGrpJoinOnModel();
				try {
					log.info("Store virtal dataset group join mapping information Started");
					watch.start("Store virtal dataset group join mapping information.");
					copyProperties(groupJoinOnRequestDTO, coreVdGrpJoinOnModel);
					if (groupJoinOnRequestDTO.getJoinColumnId() == null) {
						coreVdGrpJoinOnModel.setJoinOnId(UUID.randomUUID());
					} else {
						coreVdGrpJoinOnModel.setJoinOnId(groupJoinOnRequestDTO.getJoinColumnId());
					}
					coreVdGrpJoinOnModel.setCoreVdGroups(coreVdGroupsModel);
					coreVdGrpJoinOnModel.setSourceOne(groupJoinOnRequestDTO.getSourceField());
					coreVdGrpJoinOnModel.setSourceOneFieldId(groupJoinOnRequestDTO.getSourceFieldId());
					coreVdGrpJoinOnModel.setSourceTwo(groupJoinOnRequestDTO.getTargetField());
					coreVdGrpJoinOnModel.setSourceTwoFieldId(groupJoinOnRequestDTO.getTargetFieldId());
					coreVdGrpJoinOnModel
							.setCompareOperator(CompareOperator.fromValue(groupJoinOnRequestDTO.getCondition().toUpperCase()));
					coreVdGrpJoinOnModel = coreVdGrpJoinOnDAO.save(coreVdGrpJoinOnModel);
					watch.stop();
				} catch (Exception e) {
					log.error("error while Store virtal dataset group join mapping information: " + e.getMessage());
					throw new CommonVirtualDatasetException(e.getMessage());
				}
				log.info(watch.prettyPrint());
				return coreVdGrpJoinOnModel;
			} else {
				log.error("Virtual group data is not present while storing group join on information.");
				throw new NotFound404Exception(
						"Virtual group data is not present while storing group join on information.");
			}
		} else {
			log.error("Virtual group join on is not present while storing it.");
			throw new NotFound404Exception("Virtual group join on is not present while storing it.");
		}

	}

}
