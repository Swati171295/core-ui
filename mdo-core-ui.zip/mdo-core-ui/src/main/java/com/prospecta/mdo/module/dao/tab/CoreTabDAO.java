/**
 * 
 */
package com.prospecta.mdo.module.dao.tab;

import com.prospecta.mdo.module.model.tab.CoreTabModel;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * @author savan
 *
 */
@Repository
public interface CoreTabDAO extends PagingAndSortingRepository<CoreTabModel, UUID> {

	CoreTabModel findByTcodeAndLayoutIdAndModuleIdAndTenantId(UUID tcode, UUID layoutId, long parseLong,
			String tenantCode);

	CoreTabModel findByLayoutIdAndModuleIdAndTenantId(UUID fromString, Long moduleid, String tenantCode);

	Optional<List<CoreTabModel>> findByLayoutIdAndTenantId(UUID uuid, String tenantId);
}
