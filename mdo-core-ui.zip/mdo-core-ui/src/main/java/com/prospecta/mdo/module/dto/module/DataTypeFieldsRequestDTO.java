/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DataTypeFieldsRequestDTO {
	@ApiModelProperty(
			name = "datatype",
			value = "String representing Data Type",
			dataType = "java.lang.String"
	)
	private String datatype;
	@ApiModelProperty(
			name = "description",
			value = "String representing description",
			dataType = "java.lang.String"
	)
	private String description;
	
}
