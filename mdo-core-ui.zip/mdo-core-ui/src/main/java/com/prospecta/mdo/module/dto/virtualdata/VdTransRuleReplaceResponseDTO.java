package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import lombok.Data;

@Data
public class VdTransRuleReplaceResponseDTO {
	
	private UUID vdReplaceId;
	
	private String replaceFrom;
	
	private String replaceWith;

}
