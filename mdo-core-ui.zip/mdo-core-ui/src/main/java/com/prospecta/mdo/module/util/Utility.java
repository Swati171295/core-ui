package com.prospecta.mdo.module.util;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import static com.prospecta.mdo.module.util.Constants.NINE_DIGIT_LIMIT;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Utility {
    private static long last = 0;

    /**
     * This method is used to generate random 9 digit number id
     */
    public static long getRandomNumberId() {
        long id = (System.currentTimeMillis() / 100) % NINE_DIGIT_LIMIT;
        if (id <= last) {
            id = (last + 1) % NINE_DIGIT_LIMIT;
        }
        return last = id;
    }

}
