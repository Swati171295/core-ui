/**
 * 
 */
package com.prospecta.mdo.module.dto.elastic;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import lombok.Data;



/**
 * @author nikhil.channawar
 *
 */
@Data
public class GridValueES implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7574971250848081655L;

	/***
	* The grid id
	*/
	private String gId;

	 /***
	* The label for the grid field based on language
	*/
	private String ls;

	 /***
	* The row data for the grid, key being the objnr field on the META_TT table
	*/

	 private LinkedList<LinkedHashMap<String, FieldValue>> rows;
}
