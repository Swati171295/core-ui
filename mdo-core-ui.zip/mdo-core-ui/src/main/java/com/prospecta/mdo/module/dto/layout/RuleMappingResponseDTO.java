/**
 * 
 */
package com.prospecta.mdo.module.dto.layout;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author satyam
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RuleMappingResponseDTO {

	private boolean acknowledge;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String errorMsg;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String successMsg;
	
}
