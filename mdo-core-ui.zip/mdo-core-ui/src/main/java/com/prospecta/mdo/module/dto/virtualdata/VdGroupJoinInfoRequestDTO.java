package com.prospecta.mdo.module.dto.virtualdata;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.prospecta.mdo.module.validator.ValidateSourceOneModule;
import com.prospecta.mdo.module.validator.ValidateSourceTwoModule;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ValidateSourceOneModule(fieldName = "sourceOneType", fieldValue = "module", dependFieldName = "sourceOneModule")
@ValidateSourceTwoModule(fieldName = "sourceTwoType", fieldValue = "module", dependFieldName = "sourceTwoModule")
public class VdGroupJoinInfoRequestDTO {
	
	@ApiModelProperty(
			name = "groupJoinId",
			value = "Id of group join",
			dataType = "java.util.UUID;",
			required = true
	)
	public UUID groupJoinId;
	
	@ApiModelProperty(
			name = "sourceOne",
			value = "Source one can be a TABLENAME or GROUPID",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message= "source field tablename or groupid must not be empty while joining")
	public String sourceOne;
	
	@ApiModelProperty(
			name = "sourceOneType",
			value = "Source one type e.g SYSTABLE(0), MODULE(1), GROUP(2), VIRTUALDATASET(3)",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message= "source field type must not be empty while joining")
	public String sourceOneType;
	
	@ApiModelProperty(
			name = "sourceOneModuleId",
			value = "If sourceOneType is 1 then this field will contain module id",
			dataType = "java.lang.Long",
			required = true
	)
	public Long sourceOneModule;
	
	@ApiModelProperty(
			name = "sourceTwo",
			value = "Source two can be a TABLENAME or GROUPID",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message= "target field tablename or groupid must not be empty while joining")
	public String sourceTwo;
	
	@ApiModelProperty(
			name = "sourceTwoType",
			value = "Source two type e.g SYSTABLE(0), MODULE(1), GROUP(2), VIRTUALDATASET(3)",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message= "target field type must not be empty while joining")
	public String sourceTwoType;
	
	@ApiModelProperty(
			name = "sourceTwoModuleId",
			value = "If sourceTwoType is 1 then this field will contain module id",
			dataType = "java.lang.Long",
			required = true
	)
	public Long sourceTwoModule;	
	
	@ApiModelProperty(
			name = "sourceOneScopeUdr",
			value = "UDR id of source one",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message = "Source one scope UDR ID must not be null in group information")
	public String sourceOneScopeUdr;
	
	@ApiModelProperty(
			name = "sourceTwoScopeUdr",
			value = "UDR id of source two",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message = "Source two scope UDR ID must not be null in group information")
	public String sourceTwoScopeUdr;
	
	@ApiModelProperty(
			name = "resultScopeUdr",
			value = "UDR id of result",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message = "Result scope UDR ID must not be null in group information")
	public String resultScopeUdr;
	
	@ApiModelProperty(
			name = "joinType",
			value = "Join type, which has (LEFT,RIGHT,INNER,OUTER,UNION)",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message= "join type must not be null while joining two field")
	public String joinType;
	
	@ApiModelProperty(
			name = "joinOperator",
			value = "Join operator can be of two type (AND, OR)",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message= "join operator must not be null while joining two field")
	public String joinOperator;
	
	List<@Valid VdGroupJoinMappingRequestDTO> joinMapping = new ArrayList<>();
	
}