/**
 * 
 */
package com.prospecta.mdo.module.model.metadata;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data 
@NoArgsConstructor 
public class CoreMetadataModelId implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2452690941988343194L;

	private String fieldId;
	
	private Long moduleId;
	
	private String tenantId;

	public CoreMetadataModelId(String fieldId, Long moduleId, String tenantId) {
		super();
		this.fieldId = fieldId;
		this.moduleId = moduleId;
		this.tenantId = tenantId;
	}
}
