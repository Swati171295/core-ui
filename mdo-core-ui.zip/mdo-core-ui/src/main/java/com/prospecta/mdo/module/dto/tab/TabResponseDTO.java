/**
 * 
 */
package com.prospecta.mdo.module.dto.tab;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TabResponseDTO {

	@Schema(description = "", example = "", defaultValue = "")
	private String tcode;

	private boolean acknowledge;

	private String errorMsg;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String successMsg;
	
}
