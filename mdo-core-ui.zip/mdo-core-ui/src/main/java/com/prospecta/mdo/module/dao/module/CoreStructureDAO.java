/**
 * 
 */
package com.prospecta.mdo.module.dao.module;

import com.prospecta.mdo.module.model.module.CoreStructureModel;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

import static com.prospecta.mdo.module.util.QueryConstants.GET_ALL_STRUCTURES;

/**
 * @author savan
 *
 */
@Repository
public interface CoreStructureDAO extends PagingAndSortingRepository<CoreStructureModel, Short> {

	CoreStructureModel findTopByModuleIdOrderByStructureIdDesc(Long moduleid);
	
	List<CoreStructureModel> findByModuleIdAndStructureIdInAndTenantId(Long moduleid, List<Short> structureIds,
	        String tenantCode);

	@Query("SELECT s.structureId from CoreStructureModel s where s.moduleId=?1 and s.tenantId=?2")
	List<String> findIdByModuleIdAndTenantId(Long moduleId,String tenantId);

	@Query("SELECT s.structureId from CoreStructureModel s where s.parentStrucId in ?1 and s.moduleId=?2 and s.tenantId=?3")
	List<Short> findChildStructureByStructureIdAndModuleIdAndTenantId(List<Short> structureId,Long moduleId,String tenantId);

	@Query("SELECT s.parentStrucId from CoreStructureModel s where s.structureId = ?1 and s.moduleId=?2 and s.tenantId=?3 and s.isHeader = ?4 and s.parentStrucId <> 1")
	String findParentStructureByStructureIdAndModuleIdAndTenantId(Short structureId,Long moduleId,String tenantId,boolean isHeader);

	void deleteAllByStructureIdInAndModuleIdAndAndTenantId(List<Short> ids,Long moduleId,String tenant);

	@Query(GET_ALL_STRUCTURES)
	List<CoreStructureModel> findByModuleIdandTenantId(@Param("moduleId") Long moduleId, @Param("tenantId") String tenantId,
													   @Param("search") String searchTerm, @Param("lang") String lang,
													   Pageable pageable);
}
