package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import lombok.Data;
@Data
public class VdGroupJoinOnResponseDTO {
	
	private UUID joinColumnId;
	
	private String sourceField;
	
	private String sourceFieldId;
	
	private String targetField;
	
	private String targetFieldId;	
	
	private String condition;

}
