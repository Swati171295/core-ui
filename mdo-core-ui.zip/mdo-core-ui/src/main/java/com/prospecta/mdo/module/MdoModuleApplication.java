package com.prospecta.mdo.module;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.elasticsearch.ReactiveElasticsearchRestClientAutoConfiguration;

@SpringBootApplication(exclude = ReactiveElasticsearchRestClientAutoConfiguration.class)
public class MdoModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MdoModuleApplication.class);
	}

}
