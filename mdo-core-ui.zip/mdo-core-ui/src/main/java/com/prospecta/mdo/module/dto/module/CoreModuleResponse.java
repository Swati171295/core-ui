package com.prospecta.mdo.module.dto.module;

import com.prospecta.mdo.module.enums.ModuleType;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class CoreModuleResponse {

    @ApiModelProperty(
            name = "shortText",
            value = "Map representing ModuleDescription",
            dataType = "Object"
    )
    private Map<String , List<ModuleDescriptionInformationRequestDTO>> moduleDescriptionMap;

    @ApiModelProperty(
            name = "usermodified",
            value = "String",
            dataType = "java.lang.String"
    )
    private String usermodified;

    @ApiModelProperty(
            name = "displayCriteria",
            value = "Display Criteria",
            dataType = "java.lang.Short"
    )
    private Short displayCriteria;

    @ApiModelProperty(
            name = "industry",
            value = "String",
            dataType = "java.lang.String"
    )
    private String industry;

    @ApiModelProperty(
            name = "isSingleRecord",
            value = "Is Single Record",
            dataType = "java.lang.Boolean"
    )
    private Boolean isSingleRecord;

    private String systemType;

    @ApiModelProperty(
            name = "owner",
            value = "owner",
            dataType = "java.lang.Short"
    )
    private Short owner;

    @ApiModelProperty(
            name = "dataType",
            value = "DataType",
            dataType = "java.lang.Short"
    )
    private Short dataType;

    @ApiModelProperty(
            name = "persistent",
            value = "persistent",
            dataType = "java.lang.Short"
    )
    private Short persistent;

    @ApiModelProperty(
            name = "dataPrivacy",
            value = "Data Privacy",
            dataType = "java.lang.Short"
    )
    private Short dataPrivacy;

    @ApiModelProperty(
            name = "parentModuleIds",
            value = "List of Parent Module Ids",
            dataType = "java.util.List"
    )
    private List<Long> parentModuleIds;
    @ApiModelProperty(
            name = "tenantId",
            value = "Tenant Id",
            dataType = "java.lang.String"
    )
    private String tenantId;
    @ApiModelProperty(
            name = "dateModified",
            value = "Date Modified",
            dataType = "java.lang.Long"
    )
    private Long dateModified;

    @ApiModelProperty(
            name = "type",
            value = "Type Of DataSet",
            dataType = "com.prospecta.mdo.module.enums.ModuleType"
    )
    private ModuleType type;
}
