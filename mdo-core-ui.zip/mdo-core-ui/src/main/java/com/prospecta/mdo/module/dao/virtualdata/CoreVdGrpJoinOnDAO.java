package com.prospecta.mdo.module.dao.virtualdata;

import java.util.List;
import java.util.UUID;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinOnModel;

@Repository
public interface CoreVdGrpJoinOnDAO extends PagingAndSortingRepository<CoreVdGrpJoinOnModel, UUID>{

	List<CoreVdGrpJoinOnModel> findByCoreVdGroups(CoreVdGroupsModel coreVdGroupsModel);

	void deleteByCoreVdGroups(CoreVdGroupsModel coreVdGroupsModel);

	List<CoreVdGrpJoinOnModel> findByJoinOnIdIn(List<UUID> joinOnIds);

	void deleteByJoinOnIdIn(List<UUID> joinOnIds);

}
