package com.prospecta.mdo.module.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum SourceScope {
	
	ALL('0'),  DISTINCT('1');
	
	public char asChar() {
        return asChar;
    }

    private final char asChar;

    SourceScope(char asChar) {
        this.asChar = asChar;
    }
    
    @JsonCreator
	public static SourceScope fromValue(String value) {
		return Enum.valueOf(SourceScope.class, value);
	}

}
