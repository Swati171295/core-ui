package com.prospecta.mdo.module.dto.module;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
public class ModuleTreeDTO extends ModuleDescriptionRequestDTO {
	
	private Long moduleId;  
	
	private String tenantId;
	
	private String userModified; 
	
	private Long dateModified;
	
	private Short dispCriteria;
	
	private List<FieldListDTO> fields;
	
}
