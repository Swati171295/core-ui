/**
 * 
 */
package com.prospecta.mdo.module.model.tab;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import lombok.Data;

/**
 * @author savan
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_TAB_LABELS")
public class CoreTabLabelsModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2243783481265871532L;

	@Id 
	@Type(type = "uuid-char")
	@Column(name = "UUID", columnDefinition = "uuid")
	private UUID uuid;
	
	@Type(type = "uuid-char")
	@Column(name = "TCODE", columnDefinition = "uuid")
	private UUID tcode;
	
	@Column(name = "TAB_TEXT", columnDefinition = "nvarchar(200)")
	private String tabText;
	
	@Column(name = "INFORMATION", columnDefinition = "clob")
	private String information;
	
	@Column(name = "LANGUAGE")
	private String language;
	
}
