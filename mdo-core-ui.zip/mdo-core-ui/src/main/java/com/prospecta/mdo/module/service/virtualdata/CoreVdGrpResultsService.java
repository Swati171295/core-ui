package com.prospecta.mdo.module.service.virtualdata;

import java.util.List;
import java.util.UUID;

import com.prospecta.mdo.module.dto.virtualdata.VdGroupResultsRequestDTO;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpResultsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

public interface CoreVdGrpResultsService {
	
  	CoreVdGrpResultsModel getVdResultbyresultId(UUID resultId);
	
	List<CoreVdGrpResultsModel> getVdResultbyvdId(UUID vdId);
	
	List<CoreVdGrpResultsModel> getVdResultbygroupId(UUID groupId);
	
	void deleteVdResultbyresultId(UUID resultId);
	
	void deleteVdResultbyvdId(UUID vdId);
	
	void deleteVdResultbygroupId(UUID groupId);

	void deleteVdGroupResults(List<VdGroupResultsRequestDTO> groupResult, UUID uuid);

	CoreVdGrpResultsModel saveOrUpdateVdGroupResults(VdGroupResultsRequestDTO groupResultsRequestDTO,
			CoreVdGroupsModel coreVdGroupsModel, CoreVdHeaderModel coreVdHeader);

}