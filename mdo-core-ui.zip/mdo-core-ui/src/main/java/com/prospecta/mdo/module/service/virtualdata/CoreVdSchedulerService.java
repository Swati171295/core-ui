package com.prospecta.mdo.module.service.virtualdata;

import java.util.UUID;

import com.prospecta.mdo.module.dto.virtualdata.CommonResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.CoreVdSchedulerRequestDTO;

public interface CoreVdSchedulerService {
	
	CommonResponseDTO scheduleJob(CoreVdSchedulerRequestDTO coreVdSchedulerRequestDTO,String tokenKey);

	CommonResponseDTO sendToSparkJob(UUID vdId, String tokenKey);
}
