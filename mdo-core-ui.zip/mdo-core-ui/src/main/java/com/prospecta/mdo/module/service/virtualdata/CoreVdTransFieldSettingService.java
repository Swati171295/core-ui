package com.prospecta.mdo.module.service.virtualdata;

import java.util.List;
import java.util.UUID;

import com.prospecta.mdo.module.dto.virtualdata.VdTransFieldSettingRequestDTO;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;

public interface CoreVdTransFieldSettingService {
	
	CoreVdTransFieldSettingModel getVdTransFieldSettingbyFieldId(UUID fieldId);
	
	List<CoreVdTransFieldSettingModel> getVdTransFieldSettingbygroupId(UUID groupId);
	
	List<CoreVdTransFieldSettingModel> getVdTransFieldSettingbytransformationId(UUID transformationId);
	
	void deleteVdTransFieldSettingbyFieldId(UUID fieldId);
	
	void deleteVdTransFieldSettingbygroupId(UUID groupId);
	
	void deleteVdTransFieldSettingbytransformationId(UUID transformationId);

	void deleteVdTransFieldSetting(List<VdTransFieldSettingRequestDTO> groupTransFieldSetting, UUID uuid);

	CoreVdTransFieldSettingModel saveAndUpdateTransFieldSetting(
			VdTransFieldSettingRequestDTO groupTransFieldSettingRequestDTO,
			CoreVdGrpTransInfoModel coreVdGrpTransInfoModel);
}