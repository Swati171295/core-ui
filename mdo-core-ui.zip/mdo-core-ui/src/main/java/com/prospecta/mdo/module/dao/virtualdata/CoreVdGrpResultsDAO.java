package com.prospecta.mdo.module.dao.virtualdata;

import java.util.List;
import java.util.UUID;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpResultsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

@Repository
public interface CoreVdGrpResultsDAO extends PagingAndSortingRepository<CoreVdGrpResultsModel, UUID>{

	List<CoreVdGrpResultsModel> findByCoreVdHeader(CoreVdHeaderModel coreVdHeaderModel);

	List<CoreVdGrpResultsModel> findByCoreVdGroups(CoreVdGroupsModel coreVdGroupsModel);

	void deleteByCoreVdHeader(CoreVdHeaderModel coreVdHeaderModel);

	void deleteByCoreVdGroups(CoreVdGroupsModel coreVdGroupsModel);

	List<CoreVdGrpResultsModel> findByUuidIn(List<UUID> resultId);

	void deleteByUuidIn(List<UUID> resultId);

}
