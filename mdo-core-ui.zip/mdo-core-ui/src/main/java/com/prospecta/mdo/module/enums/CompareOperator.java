package com.prospecta.mdo.module.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum CompareOperator {
	
	EQUALS('0'),NOTEQUALS('1'),LIKE('2'),NOTLIKE('3');
	
	public char asChar() {
        return asChar;
    }

    private final char asChar;

    CompareOperator(char asChar) {
        this.asChar = asChar;
    }
    
    @JsonCreator
	public static CompareOperator fromValue(String value) {
		return Enum.valueOf(CompareOperator.class, value);
	}
}
