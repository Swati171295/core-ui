package com.prospecta.mdo.module.dto.layout;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class LayoutListRequestDTO {

    @ApiModelProperty(
            name = "type",
            value = "Type of Layout"
    )
    private List<Short> type;
    @ApiModelProperty(
            name = "userModified",
            value = "Modified By"
    )
    private List<String> userModified;
    @ApiModelProperty(
            name = "userCreated",
            value = "Created by"
    )
    private List<String> userCreated;
}
