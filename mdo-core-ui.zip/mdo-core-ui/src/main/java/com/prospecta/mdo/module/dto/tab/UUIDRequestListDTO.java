package com.prospecta.mdo.module.dto.tab;

import lombok.Data;

import java.util.List;

@Data
public class UUIDRequestListDTO {

    private List<String> uuidList;
}
