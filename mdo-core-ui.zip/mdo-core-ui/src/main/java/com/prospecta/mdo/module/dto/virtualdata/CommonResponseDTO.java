package com.prospecta.mdo.module.dto.virtualdata;

import lombok.Data;

@Data
public class CommonResponseDTO {
	

	public CommonResponseDTO(int status, boolean success, String message, Object data) {
		super();
		this.status = status;
		this.success = success;
		this.message = message;
		this.data = data;
	}

	public CommonResponseDTO(int status, boolean success, String message) {
		super();
		this.status = status;
		this.success = success;
		this.message = message;
	}
	
	public CommonResponseDTO(String message, Object data) {
		super();
		this.message = message;
		this.data = data;
	}
	
	public CommonResponseDTO() {
		super();
	}
	
	public CommonResponseDTO(String message) {
		super();
		this.message = message;
	}

	// HttpStatus response code
	private int status;

	// success
	private boolean success;

	// General error message about nature of error
	private String message;

	// data to send in response
	private Object data;	


}
