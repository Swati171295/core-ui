/**
 * 
 */
package com.prospecta.mdo.module.model.module;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.envers.Audited;

import lombok.Data;

/**
 * @author savan
 *
 */
@Data
@Entity
@Table(name = "CORE_MODULE_DESCRIPTION")
@Audited
@IdClass(CoreModuleDescriptionModelId.class)
public class CoreModuleDescriptionModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1770581951791374553L;

	@Id
	@Column(name = "MODULEID")
	private Long moduleId;
	
	@Id
	@Column(name = "LANGUAGE")
	private String language;
	
	@Id
	@Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
	private String tenantId;
	
	@Column(name = "DESCRIPTION", columnDefinition = "nvarchar(200)")
	private String description;

	@Column(name = "INFORMATION",columnDefinition = "clob")
	private String information;

}
