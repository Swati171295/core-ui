/**
 * 
 */
package com.prospecta.mdo.module.dto.layout;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.prospecta.mdo.module.dto.metadata.FieldWithDescriptionResponseDTO;
import com.prospecta.mdo.module.dto.tab.TabFieldDTO;
import com.prospecta.mdo.module.enums.FieldType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

import static org.springframework.beans.BeanUtils.copyProperties;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class LayoutFieldsDTO {

	private List<FieldWithDescriptionResponseDTO> metadata;
	
	private Boolean isMandatory;
	
	private Boolean isReadOnly;
	
	private Boolean isHidden;
	
	private Long moduleId;
	
	private Boolean isAdd;
	
	private Boolean isDelete;
	
	private Short order;

	private String url;

	private String description;

	private FieldType fieldType;

	private UUID tabFieldUuid;

	private String fieldId;

	private Short structureId;

	public LayoutFieldsDTO(TabFieldDTO tabFieldDTO) {
		copyProperties(tabFieldDTO,this);
		this.isReadOnly=tabFieldDTO.getIsReadonly();
	}
}
