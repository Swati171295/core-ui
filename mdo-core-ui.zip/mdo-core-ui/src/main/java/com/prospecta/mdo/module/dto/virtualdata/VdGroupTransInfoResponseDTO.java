package com.prospecta.mdo.module.dto.virtualdata;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import lombok.Data;

@Data
public class VdGroupTransInfoResponseDTO {
	
	private UUID groupTransId;
	
	private String source;
	
	private String sourceType;
	
	private Long sourceModule;

	private String sourceScope;
	
	private UdrResponseDTO sourceScopeUdr;

	private UdrResponseDTO resultScopeUdr;
	
	List<VdTransFieldSettingResponseDTO> groupTransFieldSetting = new ArrayList<>();

}
