package com.prospecta.mdo.module.util;

public class Constants {

    public static final String FIELD_ID_PREFIX = "FLD_";
    public static final Long NINE_DIGIT_LIMIT = 1000000000L;

    //Module
    public static final String MODULE_DELETE_SUCCESS = "Module Deleted Successfully";
    public static final String MODULE_NOT_FOUND = "Module Id Not Found";


    //Layout
    public static final String LAYOUT_DELETE_SUCCESS = "Layout Deleted Successfully";

    //Tab
    public static final String TAB_FIELD_DELETE_SUCCESS = "Tab Field Deleted Successfully";
    public static final String TAB_FIELD_NOT_FOUND = "Tab Field Not Found";

    //GRPC
    public static final Integer DEADLINE_TIME = 10;
}
