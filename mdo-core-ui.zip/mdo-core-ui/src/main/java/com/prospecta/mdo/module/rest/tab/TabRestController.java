/**
 * 
 */
package com.prospecta.mdo.module.rest.tab;

import com.prospecta.mdo.module.dto.JWTToken;
import com.prospecta.mdo.module.dto.layout.LayoutTabDTO;
import com.prospecta.mdo.module.dto.tab.*;
import com.prospecta.mdo.module.service.tab.CoreTabModelService;
import io.swagger.annotations.*;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author savan
 *
 */
@RestController
@RequestMapping(value = "/tab")
@Api(tags = {"Tab"}, description = "Tab Resource")
public class TabRestController {
	
	@Autowired
	private CoreTabModelService coreTabModelService;

	/**
	 * This method is used to create Tab.
	 * 
	 * @param layoutId
	 * @param requestDTO
	 * @return
	 */
	@ApiOperation(value = "Create Tab", notes = "Api to create Tabs")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "CREATE", content = @Content(schema = @Schema(implementation = TabResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/{layoutId}/create")
	public ResponseEntity<TabResponseDTO> createTab(
			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the layout tab needs to be updated/saved",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "layoutId") String layoutId,
			@ApiParam(
					name = "",
					value = "Json Object representing TabRequest",
					type = "body",
					required = true
			)
			@RequestBody TabRequestDTO requestDTO){

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();
		
		TabResponseDTO responseDTO = coreTabModelService.createTab(requestDTO,UUID.fromString(layoutId),jwtToken.getTenantCode(), jwtToken.getUsername());
		
		if (responseDTO.isAcknowledge()) {
			return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * This method is used to fetch Tab.
	 *
	 * @param layoutId
	 * @param tCode
	 * @return
	 */
	@ApiOperation(value = "Fetch Layout Tab", notes = "Api to Fetch Layout Tab")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = LayoutTabDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/{layoutId}/get-layout-tab")
	public ResponseEntity<LayoutTabDTO> getTab(
			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the layout tab needs to be fetched",
					required = true,
					type = "String",
					format = "UUID",
					examples = @Example(value = @ExampleProperty(value = "11223-rgr55-ffr45"))
			)
			@PathVariable(name = "layoutId") String layoutId,
			@ApiParam(
					name = "Tab Code",
					value = "Tab UUID",
					type = "UUID",
					required = true
			)
			@RequestParam("tCode") UUID tCode){

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		LayoutTabDTO responseDTO = coreTabModelService.getLayoutTab(tCode,UUID.fromString(layoutId),jwtToken.getTenantCode());

		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}


	/**
	 * This method is used to fetch Layout Tabs.
	 *
	 * @param layoutId
	 * @return
	 */
	@ApiOperation(value = "Fetch Layout Tab List", notes = "Api to Fetch Layout Tabs")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
					mediaType = "application/json",
					array = @ArraySchema(schema = @Schema(implementation = LayoutTabDTO.class))
			)}),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/{layoutId}/get-layout-tab-list/{language}")
	public ResponseEntity<List<LayoutTabDTO>> getTabs(
			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the layout tab needs to be fetched",
					required = true,
					type = "String",
					format = "UUID",
					examples = @Example(value = @ExampleProperty(value = "11223-rgr55-ffr45"))
			)
			@PathVariable(name = "layoutId") UUID layoutId,

			@ApiParam(
					name = "searchTerm",
					value = "Search",
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "FLD_234"))
			)
			@RequestParam(name = "searchTerm") String searchTerm,
			@ApiParam(
					name = "language",
					value = "Language For Tab description",
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "en"))
			)
			@PathVariable(name = "language") String language,

			@ApiParam(
					name = "fetchSize",
					value = "Limit",
					required = true,
					type = "Integer",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@RequestParam(name = "fetchSize") Integer fetchSize,

			@ApiParam(
					name = "fetchCount",
					value = "Offset",
					required = true,
					type = "Integer",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "0"))
			)
			@RequestParam(name = "fetchCount") Integer fetchCount){

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		List<LayoutTabDTO> responseDTO = coreTabModelService.getLayoutTabList(layoutId,searchTerm,language,fetchCount,fetchSize,jwtToken.getTenantCode());

		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	/**
	 * This method is used to Update Tab.
	 * 
	 * @param layoutId
	 * @param tcode
	 * @param requestDTO
	 * @return
	 */
	@ApiOperation(value = "Update Tab.", notes = "Api to update Tab")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = TabResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PutMapping("/{layoutId}/update/{tCode}")
	public ResponseEntity<TabResponseDTO> updateTab(
			@ApiParam(
					name = "layoutId",
					value = "Layout Id against which the Tab needs to be updated",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "layoutId") String layoutId,
			@ApiParam(
					name = "tCode",
					value = "Tab Code against which the Tab needs to be updated",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "tCode") String tcode,
			@ApiParam(
					name = "",
					value = "Json Object representing TabRequest",
					type = "body",
					required = true
			)
			@RequestBody TabRequestDTO requestDTO){

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();
		
		TabResponseDTO responseDTO = coreTabModelService.updateTab(requestDTO,UUID.fromString(layoutId),UUID.fromString(tcode),jwtToken.getTenantCode(), jwtToken.getUsername());
		
		if (responseDTO.isAcknowledge()) {
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * This method is used to Assign Field To Tab.
	 * 
	 * @param tcode
	 * @param requestDTO
	 * @return
	 */
	@ApiOperation(value = "Assign Field To Tab.", notes = "This Api will assign field to tab")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
					mediaType = "application/json",
					array = @ArraySchema(schema = @Schema(implementation = TabFieldDTO.class))
			)}),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/{tCode}/assignfield")
	public ResponseEntity<List<TabFieldDTO>> assignFieldToTab(
			@ApiParam(
					name = "tCode",
					value = "Tab Code",
					required = true,
					type = "number",
					format = "integer",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "tCode") String tcode,
			@ApiParam(
					name = "",
					value = "List Of Objects representing Tab Field",
					type = "body",
					required = true
			)
			@RequestBody List<TabFieldDTO> requestDTO){

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();
		
		List<TabFieldDTO> responseDTO = coreTabModelService.assignFieldToTab(requestDTO,UUID.fromString(tcode),jwtToken.getTenantCode());

		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	/**
	 * This method is used to update Assigned Field To Tab.
	 *
	 * @param requestDTO
	 * @return
	 */
	@ApiOperation(value = "Update Assigned Fields To Tab.", notes = "This Api will update assigned field to tab")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = TabFieldResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@PostMapping("/{tCode}/field/update")
	public ResponseEntity<TabFieldResponseDTO> assignFieldToTabUpdate(
			@ApiParam(
					name = "tCode",
					value = "Tab Code",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "1")),
					allowableValues = "range[0, infinity]"
			)
			@PathVariable(name = "tCode") String tCode,
			@ApiParam(
					name = "",
					value = "List Of Objects representing Tab Field",
					type = "body",
					required = true
			)
			@RequestBody List<TabFieldDTO> requestDTO){

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		TabFieldResponseDTO responseDTO = coreTabModelService.assignFieldToTabUpdate(requestDTO,UUID.fromString(tCode),jwtToken.getTenantCode());

		if (responseDTO.isAcknowledge()) {
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(responseDTO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * This method is used to delete Tab Field.
	 *
	 * @param tCode
	 * @param fieldId
	 * @return
	 */
	@ApiOperation(value= "Delete Tab Field", notes = "Api to Delete Tab Field Assignment")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = TabFieldResponseDTO.class))),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@DeleteMapping("/delete/{tCode}")
	public ResponseEntity<TabFieldResponseDTO> deleteTabField(

			@ApiParam(
					name = "tCode",
					value = "Tab Code against which tab field needs to be deleted",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "444a553-1d90-4ee1-9b83-eaa68a28f17a"))
			)
			@PathVariable(name = "tCode") String tCode,
			@ApiParam(
					name = "UUID List",
					value = "Object"
			)
			@RequestBody UUIDRequestListDTO list) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		TabFieldResponseDTO responseDTO = coreTabModelService.deleteTabField(UUID.fromString(tCode),
				list,jwtToken.getTenantCode());

		return new ResponseEntity<>(responseDTO,HttpStatus.OK);
	}

	/**
	 * This method is used to search Assigned Field To Tab.
	 *
	 * @return
	 */
	@ApiOperation(value= "Search Tab Fields", notes = "Api to Search Tab Fields By Description")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
					mediaType = "application/json",
					array = @ArraySchema(schema = @Schema(implementation = TabSearchDTO.class))
			)}),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/fields/{moduleId}/search-by-description/{language}/{layoutId}")
	public ResponseEntity<List<TabSearchDTO>> searchByDesc(

			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which tab field needs to be searched",
					required = true,
					type = "Long",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "searchTerm",
					value = "Search",
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "FLD_234"))
			)
			@RequestParam(name = "searchTerm") String searchTerm,

			@ApiParam(
					name = "fetchSize",
					value = "Limit",
					required = true,
					type = "Integer",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@RequestParam(name = "fetchSize") Integer fetchSize,

			@ApiParam(
					name = "fetchCount",
					value = "Offset",
					required = true,
					type = "Integer",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "0"))
			)
			@RequestParam(name = "fetchCount") Integer fetchCount,

			@ApiParam(
					name = "language",
					value = "Language against which tab fields will be searched",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "en"))
			)
			@PathVariable("language") String language,
			@ApiParam(
					name = "layoutId",
					value = "LayoutId against which tab fields will be searched",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "uuid"))
			)
			@PathVariable("layoutId") UUID layoutId) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		List<TabSearchDTO>  response= coreTabModelService.searchByDesc(moduleId,searchTerm,fetchCount,fetchSize,
				jwtToken.getTenantCode(),language,layoutId);

		return new ResponseEntity<>(response,HttpStatus.OK);
	}

	/**
	 * This method is used to search UnAssigned Tab Fields.
	 *
	 * @return
	 */
	@ApiOperation(value= "Search Unassigned Tab Fields", notes = "Api to Search Unassigned Tab Fields By Description")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
					mediaType = "application/json",
					array = @ArraySchema(schema = @Schema(implementation = TabFieldDetailsDTO.class))
			)}),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("{moduleId}/fields/search-unassigned-fields/{language}/{layoutId}")
	public ResponseEntity<Map<Object, Object>> searchUnassignedFields(
			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which field needs to be searched",
					required = true,
					type = "Long",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "searchTerm",
					value = "Search",
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "FLD_234"))
			)
			@RequestParam(name = "searchTerm") String searchTerm,

			@ApiParam(
					name = "fetchSize",
					value = "Limit",
					required = true,
					type = "Integer",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@RequestParam(name = "fetchSize") Integer fetchSize,

			@ApiParam(
					name = "fetchCount",
					value = "Offset",
					required = true,
					type = "Integer",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "0"))
			)
			@RequestParam(name = "fetchCount") Integer fetchCount,

			@ApiParam(
					name = "language",
					value = "Language against which tab fields will be searched",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "en"))
			)
			@PathVariable("language") String language,
			@ApiParam(
					name = "layoutId",
					value = "LayoutId against which tab fields will be searched",
					required = true,
					type = "String",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "uuid"))
			)
			@PathVariable("layoutId") UUID layoutId) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		Map<Object, Object> response= coreTabModelService.searchUnassignedTabFields(moduleId,searchTerm,fetchCount,fetchSize,
				jwtToken.getTenantCode(),language,layoutId);

		return new ResponseEntity<>(response,HttpStatus.OK);
	}

	/**
	 * This method is used to Get Assigned Tab Fields.
	 *
	 * @return
	 */
	@ApiOperation(value= "Get Tab Fields", notes = "Api to Get Tab fields")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = {@Content(
					mediaType = "application/json",
					array = @ArraySchema(schema = @Schema(implementation = TabFieldDTO.class))
			)}),
			@ApiResponse(responseCode = "500", description = "Something went wrong") })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization Bearer {token}", required = true, dataType = "string", paramType = "header") })
	@GetMapping("/fields/{moduleId}/get-tab-fields/{tCode}")
	public ResponseEntity<List<TabFieldDTO>> getTabFields(

			@ApiParam(
					name = "moduleId",
					value = "ModuleId against which tab field needs to be fetched",
					required = true,
					type = "Long",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@PathVariable(name = "moduleId") Long moduleId,
			@ApiParam(
					name = "tCode",
					value = "Tab Code against which tab field needs to be fetched",
					required = true,
					type = "UUID",
					format = "String",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@PathVariable(name = "tCode") UUID tCode,
			@ApiParam(
					name = "fetchSize",
					value = "Limit",
					required = true,
					type = "Integer",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@RequestParam(name = "fetchSize") Integer fetchSize,

			@ApiParam(
					name = "fetchCount",
					value = "Offset",
					required = true,
					type = "Integer",
					format = "Number",
					examples = @Example(value = @ExampleProperty(value = "0"))
			)
			@RequestParam(name = "fetchCount") Integer fetchCount,
			@ApiParam(
					name = "structureId",
					value = "Filter Tab fields by StructureId",
					type = "Short",
					format = "number",
					examples = @Example(value = @ExampleProperty(value = "1"))
			)
			@RequestParam("structureId") Short structureId) {

		// Extract JWTToken
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		JWTToken jwtToken = (JWTToken) auth.getDetails();

		List<TabFieldDTO> response= coreTabModelService.getTabFields(moduleId,tCode,fetchCount,fetchSize,
				jwtToken.getTenantCode(),structureId);

		return new ResponseEntity<>(response,HttpStatus.OK);
	}
}
