package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
@Data
public class VdTransRuleReplaceRequestDTO {

	@ApiModelProperty(
			name = "vdReplaceId",
			value = "vdReplaceId is the Virtual dataset replace id",
			dataType = "java.util.UUID;",
			required = true
	)
	public UUID vdReplaceId;
	
	@ApiModelProperty(
			name = "replaceFrom",
			value = "Field value to replace from",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "replaceFrom value must not be empty")
	public String replaceFrom;
	
	@ApiModelProperty(
			name = "replaceWith",
			value = "Field value to replace with",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "replaceWith field value must not be empty")
	public String replaceWith;
	
}