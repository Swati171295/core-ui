/**
 *
 */
package com.prospecta.mdo.module.exception;

import com.prospecta.mdo.module.dto.module.ModuleResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.CommonResponseDTO;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.Map;

import static org.springframework.http.HttpStatus.*;


/**
 * @author savan
 *
 */
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
                                                                  HttpHeaders headers, HttpStatus status, WebRequest request) {

        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });

        ModuleResponseDTO responseDTO = new ModuleResponseDTO();
        responseDTO.setAcknowledge(false);
        responseDTO.setErrorMsg("Field validation error occured");
        responseDTO.setFieldsErrors(errors);

        return new ResponseEntity<>(responseDTO, HttpStatus.BAD_REQUEST);
    }

    @ResponseStatus(value = NOT_FOUND)
    @ExceptionHandler(value = {NotFound404Exception.class, CommonVirtualDatasetException.class})
    public ResponseEntity<Object> exceptionNotFound(NotFound404Exception ex) {
        return new ResponseEntity<>(new ModuleResponseDTO(ex), HttpStatus.NOT_FOUND);
    }

    @ResponseStatus(value = INTERNAL_SERVER_ERROR)
    @ExceptionHandler(AlreadyExistsException.class)
    public ResponseEntity<Object> exceptionAlreadyExists(AlreadyExistsException ex) {
        return new ResponseEntity<>(new ModuleResponseDTO(ex), INTERNAL_SERVER_ERROR);
    }

    @ResponseStatus(value = INTERNAL_SERVER_ERROR)
    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<Object> resourceException(DataAccessResourceFailureException ex) {
        return new ResponseEntity<>(new ModuleResponseDTO(ex), INTERNAL_SERVER_ERROR);
    }

    @ResponseStatus(value = INTERNAL_SERVER_ERROR)
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Object> illegalArgException(IllegalArgumentException ex) {
        return new ResponseEntity<>(new ModuleResponseDTO(ex), INTERNAL_SERVER_ERROR);
    }

    @ResponseStatus(value = INTERNAL_SERVER_ERROR)
    @ExceptionHandler(JpaSystemException.class)
    public ResponseEntity<Object> jpaException(JpaSystemException ex) {
        return new ResponseEntity<>(new ModuleResponseDTO(ex), INTERNAL_SERVER_ERROR);
    }


    @Override
    @ResponseStatus(value = BAD_REQUEST)
    public ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        return new ResponseEntity<>(new ModuleResponseDTO(ex), BAD_REQUEST);
    }
    
    @ResponseStatus(value = INTERNAL_SERVER_ERROR)
    @ExceptionHandler(VDNameExistsException.class)
    public ResponseEntity<CommonResponseDTO> exceptionAlreadyExists(VDNameExistsException ex) {
		CommonResponseDTO commonResponseDTO = new CommonResponseDTO();
		commonResponseDTO.setData(null);
		commonResponseDTO.setMessage("Virtual dataset name is exists try with another!!");
		commonResponseDTO.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		commonResponseDTO.setSuccess(false);
        return new ResponseEntity<CommonResponseDTO>(commonResponseDTO, INTERNAL_SERVER_ERROR);
    }
	
	@ResponseStatus(value = INTERNAL_SERVER_ERROR)
    @ExceptionHandler(NoMatchFoundException.class)
    public ResponseEntity<CommonResponseDTO> exceptionNoMatch(NoMatchFoundException ex) {
		CommonResponseDTO commonResponseDTO = new CommonResponseDTO();
		commonResponseDTO.setData(null);
		commonResponseDTO.setMessage("No match found.");
		commonResponseDTO.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		commonResponseDTO.setSuccess(false);
        return new ResponseEntity<CommonResponseDTO>(commonResponseDTO, INTERNAL_SERVER_ERROR);
    }
	
	@ResponseStatus(value = INTERNAL_SERVER_ERROR)
    @ExceptionHandler(TenanatIdNotFoundException.class)
    public ResponseEntity<CommonResponseDTO> exceptionTenantIdNotFound(TenanatIdNotFoundException ex) {
		CommonResponseDTO commonResponseDTO = new CommonResponseDTO();
		commonResponseDTO.setData(null);
		commonResponseDTO.setMessage("TenantId not Found!");
		commonResponseDTO.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		commonResponseDTO.setSuccess(false);
        return new ResponseEntity<CommonResponseDTO>(commonResponseDTO, INTERNAL_SERVER_ERROR);
    }

    @ResponseStatus(value = INTERNAL_SERVER_ERROR)
    @ExceptionHandler(GRPCException.class)
    public ResponseEntity<Object> exceptionGrpc(GRPCException ex) {
        return new ResponseEntity<>(new ModuleResponseDTO(ex), INTERNAL_SERVER_ERROR);
    }
}
