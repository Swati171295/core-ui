package com.prospecta.mdo.module.dao.module;

import com.prospecta.mdo.module.model.module.CoreSubModuleModel;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * @author Lakshay Saini
 */
@Repository
public interface CoreSubModuleDao extends PagingAndSortingRepository<CoreSubModuleModel, UUID> {

    List<CoreSubModuleModel> findAllByModuleId(Long moduleId);
    
	void deleteByModuleId(Long moduleId);

	void deleteByModuleIdAndParentModuleId(Long moduleId, Long parentModuleId);
}
