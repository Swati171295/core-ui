/**
 * 
 */
package com.prospecta.mdo.module.dto.metadata;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiParam;
import java.util.List;

import javax.validation.Valid;

import com.prospecta.mdo.module.dto.module.FieldsRequestDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateFieldRequestDTO {

	@ApiModelProperty(
			name = "fields",
			value = "Arrays of fields objects",
			required = true
	)
	@Valid
	private List<FieldsRequestDTO> fields;
	
}
