/**
 * 
 */
package com.prospecta.mdo.module.service.module;

import com.prospecta.mdo.module.dto.module.*;
import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;
import com.prospecta.mdo.module.model.module.CoreModuleModel;
import com.prospecta.mdo.module.model.module.CoreStructureModel;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;


/**
 * @author savan
 *
 */
public interface CoreModuleService {

	ModuleResponseDTO saveModel(ModuleRequestDTO requestDto, String tenantCode);

	void saveSubModule(Long moduleId, List<Long> parentModuleIds);

	FieldResponseDTO saveField(@Valid FieldDTO field, String tenantCode, Long moduleid);
	
	FieldIdsWithStructureResponseDTO getFieldsWithStructure(String structureId, Long moduleid, String language, String fetchcount,
			String fetchsize, String tenantCode);

	PickListFieldsResponseDTO getAllPicklistFields(PicklistFieldsRequestDTO requestDTO, Long moduleid, String language,
			String fetchcount, String fetchsize, String tenantCode);

	DataTypeFieldsResponseDTO getAllDataTypefields(DataTypeFieldsRequestDTO requestDTO, Long moduleid, String language,
			String fetchcount, String fetchsize, String tenantCode);

	ModuleResponseDTO updateModuleDescription(@Valid Map<String, ModuleDescriptionInformationRequestDTO> requestDto, String tenantCode,
											  Long moduleid);

	List<Iterable<CoreMetadataModel>> saveModuleFields(ModuleRequestDTO requestDto, Long moduleid, String tenantCode,
			String username);

	void constructHelpText(List<CoreMetadataLangModel> langList, FieldDTO field, String tenantCode, Long moduleid);

	void constructShortText(List<CoreMetadataLangModel> langList, FieldDTO field, String tenantCode, Long moduleid);

	void constructLongText(List<CoreMetadataLangModel> langList, FieldDTO field, String tenantCode, Long moduleid);

	List<ModuleTreeDTO> getModuleTree(String language, String description, String tenantCode);

	List<FieldDTO> getAllFieldsByStructure(Long moduleid, String language, String structureId,
	        String fetchcount, String fetchsize, String tenantCode);

	List<CoreModuleModel> getAllModules(String language, String fetchcount, String fetchsize, String tenantCode);

	ModuleDescriptionDTO getModuleDescriptionBasedOnModuleid(Long moduleid, String language, String tenantCode);

	List<CoreModuleModel> getAllModulesBasedOnSearchDetails(String language, String description, String tenantCode);

	CoreModuleResponse getDetailsByModuleId(String tenantCode, Long moduleId);

	CoreStructureModel saveAndUpdateStructure(ModuleStructureDTO requestDto, String tenantCode);
	
	ModuleResponseDTO updateModule(ModuleRequestDTO requestDto, String tenantCode, Long moduleId);

	ModuleResponseDTO deleteModule(Long moduleId, String tenantId);

    ModuleResponseDTO deleteStructure(Long moduleId, Short structureId, String tenantCode);

	List<ModuleStructureDTO> getAllStructures(Long moduleId,String tenantId,String searchTerm,String lang,Integer fetchCount,Integer fetchSize);
}
	