package com.prospecta.mdo.module.dao.virtualdata;

import java.util.List;
import java.util.UUID;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransRuleConcatModel;

@Repository
public interface CoreVdTransRuleConcatDAO extends PagingAndSortingRepository<CoreVdTransRuleConcatModel, UUID>{

	List<CoreVdTransRuleConcatModel> findByCoreVdTransFieldSetting(
			CoreVdTransFieldSettingModel coreVdTransFieldSettingModel);

	void deleteByCoreVdTransFieldSetting(CoreVdTransFieldSettingModel coreVdTransFieldSettingModel);

	List<CoreVdTransRuleConcatModel> findByVdConcatIdIn(List<UUID> vdConcatId);

	void deleteByVdConcatIdIn(List<UUID> vdConcatId);

}
