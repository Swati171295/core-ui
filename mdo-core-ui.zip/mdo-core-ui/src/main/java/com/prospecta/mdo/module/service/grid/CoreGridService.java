package com.prospecta.mdo.module.service.grid;

import com.prospecta.mdo.module.dto.grid.GridResponseDTO;
import com.prospecta.mdo.module.dto.grid.GridSettingRequestDTO;
import com.prospecta.mdo.module.dto.grid.GridSettingResponseDTO;
import com.prospecta.mdo.module.dto.grid.SequenceSettingRequestDTO;

import java.util.List;

/**
 * @author jaineet.singh
 *
 */
public interface CoreGridService {

    GridResponseDTO saveUpdateGridSetting(List<GridSettingRequestDTO> requestDTO, Long moduleId, String gridFieldId, String tenantCode);

    List<GridSettingResponseDTO> getGridSetting(Long moduleId, String gridFieldId, String tenantCode);

    List<GridSettingResponseDTO> getSortableGridFields(Long moduleId, String gridFieldId, String search, Integer fetchCount, Integer fetchSize,String lang ,String tenantCode);

    List<GridSettingResponseDTO> getSequenceGridFields(Long moduleId, String gridFieldId, String search, Integer fetchCount,
                                                       Integer fetchSize, String lang, String tenantCode);

    GridResponseDTO saveUpdateSequenceSetting(List<SequenceSettingRequestDTO> requestDTO, Long moduleId, String tenantCode);

}
