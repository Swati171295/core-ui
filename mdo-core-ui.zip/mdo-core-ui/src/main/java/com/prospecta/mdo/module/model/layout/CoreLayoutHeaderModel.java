/**
 * 
 */
package com.prospecta.mdo.module.model.layout;

import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.UUID;

/**
 * @author savan
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_LAYOUT_HEADER")
public class CoreLayoutHeaderModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3318602228329547931L;

	@Id 
	@Type(type = "uuid-char")
	@Column(name = "LAYOUTID")
	private UUID layoutId;
	
	@Column(name = "MODULEID")
	private Long moduleId;
	
	@Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
	private String tenantId;
	
	@Column(name = "USERMODIFIED", columnDefinition = "nvarchar(150)")
	private String userModified; 
	
	@Column(name = "DATEMODIFIED")
	private Long dateModified;

	@Column(name = "USERCREATED")
	private String userCreated;

	@Column(name = "DATECREATED")
	private Long dateCreated;
	
	@Column(name = "DESCRIPTION", columnDefinition = "nvarchar(200)")
	private String description;
	
	@Column(name = "TYPE", columnDefinition = "tinyint")
	private Short type;

	@Column(name= "LABELS")
	private String Labels;

	@Column(name="USAGE",columnDefinition = "clob")
	private String usage;

	@Column(name="HELP_TEXT")
	private String helpText;

}
