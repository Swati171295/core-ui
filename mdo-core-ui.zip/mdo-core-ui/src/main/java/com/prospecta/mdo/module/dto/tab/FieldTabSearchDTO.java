package com.prospecta.mdo.module.dto.tab;

import com.prospecta.mdo.module.enums.FieldType;
import lombok.Data;

@Data
public class FieldTabSearchDTO {

    private String fieldId;
    private String description;
    private FieldType type;

    public FieldTabSearchDTO(String fieldId,String description,FieldType type){
        this.description=description;
        this.fieldId=fieldId;
        this.type=type;
    }
}
