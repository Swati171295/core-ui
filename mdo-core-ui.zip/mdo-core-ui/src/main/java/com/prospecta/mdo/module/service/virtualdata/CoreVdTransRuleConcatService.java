package com.prospecta.mdo.module.service.virtualdata;

import java.util.List;
import java.util.UUID;

import com.prospecta.mdo.module.dto.virtualdata.VdTransRuleConcatRequestDTO;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransRuleConcatModel;

public interface CoreVdTransRuleConcatService {
	
	CoreVdTransRuleConcatModel getVdTransRuleConcatbyConcatId(UUID vdConcatId);
	
	List<CoreVdTransRuleConcatModel> getVdTransRuleConcatbytransFieldId(UUID transFieldId);
	
	void deleteVdTransRuleConcatbyConcatId(UUID vdConcatId);

	void deleteVdTransRuleConcatbytransFieldId(UUID transFieldId);

	void deleteVdTransRuleConcat(List<VdTransRuleConcatRequestDTO> transConcatDetail, UUID transId);

	CoreVdTransRuleConcatModel saveAndUpdateRuleConcat(VdTransRuleConcatRequestDTO groupTransRuleConcatRequestDTO,
			CoreVdTransFieldSettingModel coreVdTransFieldSettingModel);

}