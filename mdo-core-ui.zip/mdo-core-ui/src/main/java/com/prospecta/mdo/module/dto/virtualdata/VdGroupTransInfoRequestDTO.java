package com.prospecta.mdo.module.dto.virtualdata;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.prospecta.mdo.module.validator.ValidateSourceOneModule;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
@Data
@ValidateSourceOneModule(fieldName = "sourceType", fieldValue = "module", dependFieldName = "sourceModule")
public class VdGroupTransInfoRequestDTO {
	
	@ApiModelProperty(
			name = "groupTransId",
			value = "groupTransId is the transformation id of the group",
			dataType = "java.util.UUID",
			required = true
	)
	public UUID groupTransId;
	
	@ApiModelProperty(
			name = "source",
			value = "Source can be a TABLENAME or GROUPID",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "source must not be empty in group tranformation")
	public String source;
	
	@ApiModelProperty(
			name = "sourceType",
			value = "Source type e.g SYSTABLE(0), MODULE(1), GROUP(2), VIRTUALDATASET(3)",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "Source type must not be empty in group transformation")
	public String sourceType;
	
	@ApiModelProperty(
			name = "sourceModule",
			value = "If sourceType is 1 then this field will contain module id",
			dataType = "java.lang.Long",
			required = true
	)
	public Long sourceModule;

	@ApiModelProperty(
			name = "sourceScope",
			value = "Source scope which is ALL,DISTINCT",
			dataType = "java.util.String",
			required = true
	)
	public String sourceScope;
	
	@ApiModelProperty(
			name = "sourceScopeUdr",
			value = "MDO Rule framework UDR ID and would be given by frontend",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "Source scope UDR ID must not be null in group transformation")
	public String sourceScopeUdr;

	@ApiModelProperty(
			name = "resultScopeUdr",
			value = "String representing source result scope udr id",
			dataType = "java.util.String",
			required = true
	)
	@NotNull(message = "Result scope UDR ID must not be null in group transformation")
	public String resultScopeUdr;
	
	List<@Valid VdTransFieldSettingRequestDTO> groupTransFieldSetting = new ArrayList<>();
	
}