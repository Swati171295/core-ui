/**
 * 
 */
package com.prospecta.mdo.module.service.metadata;

import static com.prospecta.mdo.module.util.Constants.FIELD_ID_PREFIX;
import static java.util.stream.Collectors.groupingBy;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataLangDAO;
import com.prospecta.mdo.module.dao.metadata.referencerule.CoreMetadataReferenceRuleDAO;
import com.prospecta.mdo.module.dao.module.CoreModuleDAO;
import com.prospecta.mdo.module.dao.module.CoreStructureDAO;
import com.prospecta.mdo.module.dto.metadata.BaseFieldDetailsDTO;
import com.prospecta.mdo.module.dto.metadata.CreateFieldRequestDTO;
import com.prospecta.mdo.module.dto.metadata.CreateFieldResponseDTO;
import com.prospecta.mdo.module.dto.metadata.FieldIdsRequestDTO;
import com.prospecta.mdo.module.dto.metadata.FieldWithDescriptionResponseDTO;
import com.prospecta.mdo.module.dto.metadata.ReferenceRuleRequestDTO;
import com.prospecta.mdo.module.dto.metadata.ReferenceRuleResponseDTO;
import com.prospecta.mdo.module.dto.module.ChildFieldsDTO;
import com.prospecta.mdo.module.dto.module.FieldDTO;
import com.prospecta.mdo.module.dto.module.FieldsRequestDTO;
import com.prospecta.mdo.module.dto.module.ModuleDescriptionInformationRequestDTO;
import com.prospecta.mdo.module.dto.module.ModuleRequestDTO;
import com.prospecta.mdo.module.exception.AlreadyExistsException;
import com.prospecta.mdo.module.exception.GRPCException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.grpc.DynamicCrudGenerationImpl;
import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;
import com.prospecta.mdo.module.model.metadata.elastic.UserFieldMetadata;
import com.prospecta.mdo.module.model.metadata.referencerule.CoreMetadataReferenceRuleModel;
import com.prospecta.mdo.module.model.module.CoreModuleModel;
import com.prospecta.mdo.module.model.module.CoreStructureModel;
import com.prospecta.mdo.module.repository.metadata.UserFieldMetadataRepository;
import com.prospecta.mdo.module.service.layout.CoreLayoutHeaderService;
import com.prospecta.mdo.module.service.module.CoreModuleService;
import com.prospecta.mdo.module.util.Utility;
import lombok.extern.slf4j.Slf4j;

/**
 * @author savan
 *
 */
@Service
@Slf4j
@Transactional
public class CoreMetadataServiceImpl implements CoreMetadataService {
	
	@Autowired
	private CoreModuleService coreModuleService;
	
	@Autowired
	private CoreModuleDAO coreModuleDAO;
	
	@Autowired
	private CoreMetadataDAO coreMetadataDAO;
	
	@Autowired
	private CoreMetadataLangDAO coreMetadataLangDAO;
	
	@Autowired
	private CoreLayoutHeaderService coreLayoutHeaderService;
	
	@Autowired
	private CoreStructureDAO coreStructureDAO;
	
	@Autowired
	private CoreMetadataReferenceRuleDAO coreMetadataReferenceRuleDAO;

	@Autowired
	UserFieldMetadataRepository userFieldMetadataRepository;

	@Autowired
	DynamicCrudGenerationImpl generationImpl;
	
	public static final String ERROR = "Error while executing api: ";
	
	@Override
	public CreateFieldResponseDTO createField(@Valid CreateFieldRequestDTO fields, String tenantCode, String username,
	        Long moduleid) {
		StopWatch watch = new StopWatch();
		
		CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();
		
		watch.start("Create metadata fields.");
		try {
			
			CoreModuleModel module = coreModuleDAO.findByModuleIdAndTenantId(moduleid, tenantCode);
			if (null == module) {
				throw new NoSuchElementException("No module data available for this request.");
			}
				
			int isDescriptionCounter = 0;
			
			for (FieldsRequestDTO fieldsRequestDTO : fields.getFields()) {
				for (FieldDTO fieldDTO : fieldsRequestDTO.getFieldlist()) {
					if (fieldDTO.getIsDescription()) {
						isDescriptionCounter++;
					}
					if (isDescriptionCounter > 1) {
						throw new AlreadyExistsException("Module request cannot have more than 1 isDescription field");
					}
				}
			}
			
			if (isDescriptionCounter == 1L) {
				List<CoreMetadataModel> coreMetadataModels = coreMetadataDAO
						.findByModuleIdAndTenantIdAndIsDescription(moduleid, tenantCode, true);

				if (!CollectionUtils.isEmpty(coreMetadataModels)) {
					throw new AlreadyExistsException(
							"IsDescription field is already present in core metadata table");
				}
			}
			
			ModuleRequestDTO requestDto = new ModuleRequestDTO();
			requestDto.setFields(fields.getFields());

			List<String> dynamicFields=createDynamicFieldIds(requestDto,moduleid,tenantCode,true);

			coreModuleService.saveModuleFields(requestDto, moduleid, tenantCode, username);

			getKeyFields(fields,moduleid,tenantCode);
			fields = setKeyFields(fields, tenantCode, moduleid);

			responseDTO.setAcknowledge(true);

			responseDTO.setDynamicFieldIds(dynamicFields);

			watch.stop();
			log.info(watch.prettyPrint());

		} catch (Exception e) {
			log.error(ERROR, e);
			responseDTO.setErrorMsg(e.getMessage());
			responseDTO.setAcknowledge(false);
			return responseDTO;
		}

			if (!generationImpl.generateDynamicTables(moduleid, tenantCode, fields)
					|| !generationImpl.createUpdateDynamicIndex(moduleid, tenantCode, fields)) {
				throw new GRPCException("Failed to Create dynamic table or index");
			}

		return responseDTO;
	}

	private void getKeyFields(CreateFieldRequestDTO fields,Long moduleid,String tenantCode) {

		fields.getFields().stream().forEach(list -> {

			String structureId = list.getStructureid();

			List<Short> parentStrucIds = getParentStrucIds(moduleid, tenantCode, structureId);
			List<CoreMetadataModel> keyList = coreMetadataDAO.findByStructureIdInAndModuleIdAndTenantIdAndIsKeyField(parentStrucIds,moduleid,tenantCode,true);

			List<FieldDTO> keyFields = keyList.stream().map(field -> {
				FieldDTO dto = new FieldDTO(field);
				dto.setExistingKey(true);
				return  dto;
			}).collect(Collectors.toList());
			list.getFieldlist().addAll(keyFields);

		});
	}

	private List<Short> getParentStrucIds(Long moduleid, String tenantCode, String structureId) {
		List<String> parentStrucIds = new ArrayList<>();
		String parentStructId = structureId;
		parentStrucIds.add(structureId);
		while (!StringUtils.isEmpty(parentStructId)) {
			parentStructId = coreStructureDAO.findParentStructureByStructureIdAndModuleIdAndTenantId(Short.parseShort(parentStructId), moduleid, tenantCode,false);
			parentStrucIds.add(parentStructId);

		}
		return parentStrucIds.stream().filter(Objects::nonNull).map(Short::parseShort).collect(Collectors.toList());
	}

	/**
	 * This method is used to set key fields to request dto
	 */
	private CreateFieldRequestDTO setKeyFields(CreateFieldRequestDTO fields, String tenantCode, Long moduleid) {

		List<FieldsRequestDTO> keyFields = new ArrayList<>();

		fields.getFields().forEach(request -> {
			String structureId = request.getStructureid();
			List<FieldDTO> keys = request.getFieldlist().stream().filter(FieldDTO::getIsKeyField).collect(Collectors.toList());
			if (keys.isEmpty() || structureId.equals("1")) {
				return;
			}
			List<String> childStrucIds = getChildStrucIds(tenantCode, moduleid, structureId);

			childStrucIds.stream().forEach(id -> {

				List<FieldDTO> newKeys= keys.stream().filter(key -> !key.getExistingKey()).collect(Collectors.toList());
				if(!newKeys.isEmpty()) {
					FieldsRequestDTO keyDto = new FieldsRequestDTO();
					keyDto.setStructureid(id);
					keyDto.setFieldlist(newKeys);
					keyFields.add(keyDto);
				}
			});
			List<String> strucIds = new ArrayList<>(childStrucIds);
			strucIds.add(structureId);
			setExistingGridKeyField(request,keys);
			setGridKeyFields(strucIds, keys, fields, keyFields, tenantCode, moduleid,structureId);
            request.getFieldlist().removeAll(request.getFieldlist().stream().filter(FieldDTO::getExistingKey).collect(Collectors.toList()));
		});
		fields.getFields().addAll(keyFields);

		Map<String, List<FieldsRequestDTO>> group = fields.getFields().stream()
				.collect(groupingBy(FieldsRequestDTO::getStructureid));

		CreateFieldRequestDTO modifiedFields = new CreateFieldRequestDTO();

		List<FieldsRequestDTO> dtoList = new ArrayList<>() ;

		group.entrySet().stream().forEach(list -> {
			List<FieldDTO>fieldDTOList = list.getValue().stream().flatMap( req -> req.getFieldlist().stream()).collect(Collectors.toList()) ;
			FieldsRequestDTO dto = new FieldsRequestDTO();
			dto.setStructureid(list.getKey());
			dto.setFieldlist(fieldDTOList);
			dtoList.add(dto);
		});

		modifiedFields.setFields(dtoList);

		return modifiedFields;
	}

	private void setExistingGridKeyField(FieldsRequestDTO requestDTO, List<FieldDTO> keys) {

		List<ChildFieldsDTO> existingKeys = keys.stream().filter(FieldDTO::getExistingKey).map(ChildFieldsDTO::new).collect(Collectors.toList());
        List<ChildFieldsDTO> newKeys = keys.stream().filter(field -> !field.getExistingKey()).map(ChildFieldsDTO::new).collect(Collectors.toList());
		if (existingKeys.isEmpty() || !newKeys.isEmpty()) {
			return;
		}

		List<FieldDTO> fieldDTOList = requestDTO.getFieldlist().stream().filter( field-> field.getPickList().equals("15")).collect(Collectors.toList());

		fieldDTOList.forEach(parent -> parent.getChildfields().addAll(existingKeys));
	}

	private void setGridKeyFields(List<String> childStrucIds,List<FieldDTO> keys,CreateFieldRequestDTO fields,
								  List<FieldsRequestDTO> keyFields,String tenantCode,Long moduleId,String structureId) {

		List<FieldDTO> newKeys = keys.stream().filter(field -> !field.getExistingKey()).collect(Collectors.toList());

		if (newKeys.isEmpty()) {
			return;
		}
	   List<Short> strucIds = childStrucIds.stream().map(Short::parseShort).collect(Collectors.toList());

	   List<CoreMetadataModel> model =  coreMetadataDAO
				.findByPickListAndModuleIdAndTenantIdAndIsSubGridAndStructureIdIn("15",moduleId,tenantCode,false,strucIds);

	    ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		for (CoreMetadataModel metadata : model) {

			    FieldDTO parentField = generateFieldMetadata(tenantCode, mapper, metadata);
			    List<ChildFieldsDTO> child= keys.stream().map(ChildFieldsDTO::new).collect(Collectors.toList());

		        fields.getFields().stream()
						.filter(list -> list.getStructureid().equals(structureId))
						.forEach(list->
						list.getFieldlist().stream()
								.filter(field -> field.getFieldId().equals(parentField.getFieldId()))
								.forEach(field -> {field.getChildfields().addAll(child);parentField.setFieldId(null);})
				);
		        if( parentField.getFieldId() != null) {
					parentField.setChildfields(child);
					FieldsRequestDTO keyDto = new FieldsRequestDTO();
					keyDto.setStructureid(metadata.getStructureId().toString());
					keyDto.setFieldlist(Collections.singletonList(parentField));
					keyFields.add(keyDto);
				}
		}
	}

	/**
	 * This method is used to get child structure ids
	 */
	public List<String> getChildStrucIds(String tenantCode, Long moduleid, String structureId) {
		List<Short> childStrucIds = new ArrayList<>();
		List<Short> childStructId = List.of(Short.parseShort(structureId));
		while (!childStructId.isEmpty()) {
			childStructId = coreStructureDAO.findChildStructureByStructureIdAndModuleIdAndTenantId(childStructId, moduleid, tenantCode);
			childStrucIds.addAll(childStructId);
		}
		return childStrucIds.stream().filter(Objects::nonNull).map(Object::toString).collect(Collectors.toList());
	}

	@Override
	public List<FieldDTO> getkeyFields(Short structureId, String tenantCode, String username, Long moduleId,
												   String searchTerm,Integer fetchCount,Integer fetchSize) {

		StopWatch watch=new StopWatch();
		watch.start("Get Key Fields");

		Pageable pageable = PageRequest.of(fetchCount,fetchSize);

		List<Short> parentStructs = getParentStrucIds(moduleId,tenantCode,structureId.toString());

		parentStructs.add(structureId);

		List<CoreMetadataModel> models = coreMetadataDAO.findKeyFieldByStructureList(searchTerm,parentStructs,moduleId,tenantCode,true,pageable);

		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		List<FieldDTO> fields = new ArrayList<>();
		for (CoreMetadataModel model :models) {
			FieldDTO field = generateFieldMetadata(tenantCode,mapper, model);
			fields.add(field);
		}

		watch.stop();
		log.info(watch.prettyPrint());
		return fields;
	}

	/**
	 * This method is used to update the metadata fields.
	 */
	@Override
	public CreateFieldResponseDTO updateField(@Valid CreateFieldRequestDTO fieldData, String tenantCode,
	        String username, Long moduleid, String fieldId) {
		StopWatch watch = new StopWatch();
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		
		CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();
		
		watch.start("Update metadata fields.");
		try {
			
			List<CoreMetadataModel> metadataModelList = coreMetadataDAO
			        .findByModuleIdAndTenantIdAndFieldIdOrParentField(moduleid, tenantCode, fieldId, fieldId);
			
			if (null == metadataModelList) {
				throw new NoSuchElementException("No metadata available for this request.");
			}
			
			fieldData.getFields().stream().forEach(fields -> {
				
				List<CoreMetadataModel> metadataList = new ArrayList<>();
				
				fields.getFieldlist().stream().forEach(field -> {
					
					if (!field.getIsGridColumn()) {
						
						field.getChildfields().stream().forEach(child -> {
							
							if (child.getParentField().equals(field.getFieldId())) {
								
								FieldDTO childlist = mapper.convertValue(child, new TypeReference<FieldDTO>() {
								});
								
								updatedLangMetadata(childlist, tenantCode, mapper, moduleid);
								
								constructUpdatesMetadata(mapper, metadataModelList, metadataList, childlist, moduleid,
								        tenantCode, username);
							}
							
						});
					}
					
					updatedLangMetadata(field, tenantCode, mapper, moduleid);
					
					constructUpdatesMetadata(mapper, metadataModelList, metadataList, field, moduleid, tenantCode,
					        username);
					
				});
				coreMetadataDAO.saveAll(metadataList);
			});

			fieldData=setKeyFields(fieldData,tenantCode,moduleid);
			responseDTO.setAcknowledge(true);
			
			watch.stop();
			log.info(watch.prettyPrint());
			
		} catch (Exception e) {
			responseDTO.setAcknowledge(false);
			responseDTO.setErrorMsg(e.getMessage());
			log.error(ERROR, e);
			return responseDTO;
		}

			if (!generationImpl.alterColumns(moduleid, tenantCode, fieldData)
					|| !generationImpl.createUpdateDynamicIndex(moduleid, tenantCode, fieldData)) {
				throw new GRPCException("Failed to alter dynamic table or index");
			}

		return responseDTO;
	}

	/**
	 * This method is used to update the language metadata
	 * 
	 * @param field
	 * @param tenantCode
	 * @param mapper
	 * @param moduleid
	 */
	private void updatedLangMetadata(FieldDTO field, String tenantCode, ObjectMapper mapper, Long moduleid) {
		
		List<CoreMetadataLangModel> metadataLangModelList = coreMetadataLangDAO
		        .findByFieldIdAndTenantId(field.getFieldId(), tenantCode);
		
		List<CoreMetadataLangModel> langList = new ArrayList<>();
		
		if (null != field.getShortText() && !field.getShortText().isEmpty()) {
			coreModuleService.constructShortText(langList, field, tenantCode, moduleid);
		}
		

		coreModuleService.constructHelpText(langList, field, tenantCode, moduleid);

		
		if (null != field.getLongtexts() && !field.getLongtexts().isEmpty()) {
			coreModuleService.constructLongText(langList, field, tenantCode, moduleid);
		}
		
		List<String> metadataLang = langList.stream().map(CoreMetadataLangModel::getLanguage)
		        .collect(Collectors.toList());
		
		metadataLangModelList.removeIf(list -> !metadataLang.contains(list.getLanguage()));
		
		List<CoreMetadataLangModel> dataList = metadataLangModelList;
		
		langList=langList.stream()
		        .peek(lang -> lang.setUuid(dataList.stream()
		                .filter(model -> model.getLanguage().equals(lang.getLanguage())
		                        && model.getFieldId().equals(lang.getFieldId()))
		                .findFirst().orElse(lang).getUuid())).collect(Collectors.toList());
		
		metadataLangModelList = mapper.convertValue(langList, new TypeReference<List<CoreMetadataLangModel>>() {
		});
		coreMetadataLangDAO.saveAll(metadataLangModelList);
	}
	
	/**
	 * This method is used the create the updated metadata
	 * 
	 * @param mapper
	 * @param metadataModelList
	 * @param metadataList
	 * @param field
	 * @param username
	 * @param tenantCode
	 * @param moduleid
	 */
	private void constructUpdatesMetadata(ObjectMapper mapper, List<CoreMetadataModel> metadataModelList,
	        List<CoreMetadataModel> metadataList, FieldDTO field, Long moduleid, String tenantCode, String username) {
		
		CoreMetadataModel metadataModel = metadataModelList.stream()
		        .filter(metadata -> field.getFieldId().equals(metadata.getFieldId())).findAny().orElse(null);
		
		if (null != metadataModel) {
			
			Short structureId = metadataModel.getStructureId();
			
			metadataModel = mapper.convertValue(field, new TypeReference<CoreMetadataModel>() {
			});
			
			metadataModel.setStructureId(structureId);
			metadataModel.setTenantId(tenantCode);
			metadataModel.setModuleId(moduleid);
			metadataModel.setUserModified(username);
			metadataModel.setDateModified(Instant.now().toEpochMilli());
			
			metadataList.add(metadataModel);
		}
	}
	
	@Override
	public CreateFieldResponseDTO removeField(String tenantCode, String username, Long moduleid, String fieldId) {
		StopWatch watch = new StopWatch();


		CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();
		Boolean isKeyField = false;
		
		watch.start("Remove metadata fields.");

		List<CoreMetadataModel> list = new ArrayList<>();
		List<CoreMetadataModel> metadataModelList = coreMetadataDAO
				.findByModuleIdAndTenantIdAndFieldIdOrParentField(moduleid, tenantCode, fieldId, fieldId);

		if (metadataModelList != null && metadataModelList.size() == 2) {
			List<String> childField = metadataModelList.stream()
					.map(CoreMetadataModel::getFieldId)
					.filter(id -> !id.equals(fieldId))
					.collect(Collectors.toList());

			metadataModelList.addAll(coreMetadataDAO
					.findByModuleIdAndTenantIdAndParentFieldIn(moduleid, tenantCode,childField));
		}

		try {

			if (metadataModelList.isEmpty()) {
				throw new NoSuchElementException("No metadata available for this request.");
			}

			for (CoreMetadataModel metadta : metadataModelList) {
				
				List<CoreMetadataLangModel> langList = coreMetadataLangDAO
				        .findByFieldIdAndTenantId(metadta.getFieldId(), tenantCode);
				
				if (null != langList) {
					coreMetadataLangDAO.deleteAll(langList);
				}

				if(metadta.getIsKeyField() && StringUtils.isEmpty(metadta.getParentField())) {
					isKeyField=true;
				}
				
			}
			
			coreMetadataDAO.deleteAll(metadataModelList);
			
			responseDTO.setAcknowledge(true);
			
			watch.stop();
			log.info(watch.prettyPrint());

			
		} catch (Exception e) {
			responseDTO.setAcknowledge(false);
			responseDTO.setErrorMsg(e.getMessage());
			log.error(ERROR, e);
			return responseDTO;
		}

		String keyField ="";
		List<String> fields;
		String structureId=metadataModelList.get(0).getStructureId().toString();
		List<String> childIds = new ArrayList<>();
		childIds.add(structureId);
		if (isKeyField) {
			childIds.addAll(getChildStrucIds(tenantCode, moduleid, structureId));
			List<Short> dataStrucList = childIds.stream().map(child-> Short.parseShort(child)).collect(Collectors.toList());
			List<CoreMetadataModel> model =  coreMetadataDAO
					.findByPickListAndModuleIdAndTenantIdAndIsSubGridAndStructureIdIn("15",moduleid,tenantCode,false,dataStrucList);
			fields = model.stream().map(CoreMetadataModel::getFieldId).collect(Collectors.toList());
			keyField = fieldId;
		}
        else {
        	fields = Collections.singletonList(fieldId);
		}

			if (!generationImpl.deleteColumn(childIds, fields, moduleid, tenantCode,keyField)) {
				throw new GRPCException("Unable to delete dynamic columns");
			}
		return responseDTO;
	}
	
	/**
	 * This method is used to Get Searchable fields with field description.
	 */
	@Override
	public Map<Object, Object> getSearchablefieldswithdescription(Long moduleid,
	        String language, String searchterm, String fetchcount, String fetchsize, String tenantCode) {
		StopWatch watch = new StopWatch();
		
		Map<Object, Object> finalMap = new HashMap<>();

		watch.start("Get Searchable fields with field description");
		try {
			
			Pageable pageable = PageRequest.of(Integer.parseInt(fetchcount), Integer.parseInt(fetchsize));
			
			// find in field description
			List<CoreMetadataLangModel> metadataLang = coreMetadataLangDAO
			        .findByIsSearchableAndSearchTerm(moduleid, language, tenantCode,
			                searchterm, pageable);

			finalMap = this.getHierachyFieldMap(moduleid, language, metadataLang, tenantCode);

			watch.stop();
			log.info(watch.prettyPrint());
			return finalMap;
			
		} catch (Exception e) {
			log.error(ERROR, e);
			return finalMap;
		}
	}

	public Map<Object, Object> getHierachyFieldMap(Long moduleid,
					 String language, List<CoreMetadataLangModel> metadataLang, String tenantCode){

		Map<Object, Object> finalMap = new HashMap<>();
		Map<String, Object> dataMap = new HashMap<>();

		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		List<FieldWithDescriptionResponseDTO> responsefieldsList = getFieldWithDescriptionResponseDTO(moduleid, language, tenantCode, mapper, metadataLang);

		List<Short> structureIds = responsefieldsList.stream().map(FieldWithDescriptionResponseDTO::getStructureId).collect(Collectors.toList());

		List<CoreStructureModel> structures = coreStructureDAO.findByModuleIdAndStructureIdInAndTenantId(moduleid,structureIds,tenantCode);

		structures.stream().forEach(struct -> {

			if (struct.getIsHeader()) {
				List<FieldWithDescriptionResponseDTO> headerList = responsefieldsList.stream()
						.filter(f -> f.getStructureId().equals(struct.getStructureId())).collect(Collectors.toList());

				headerList.stream().forEach(field ->

						dataMap.put(field.getFieldId(), new BaseFieldDetailsDTO(field.getDescription(), field.getDataType(),
								field.getPickList(), field.getMaxChar(), field.getStructureId()))
				);
				responsefieldsList.removeAll(headerList);
			}

		});

		// separate metadata based on the structureId
		Map<Short, List<FieldWithDescriptionResponseDTO>> responsefieldsMap = responsefieldsList.stream()
				.collect(Collectors.groupingBy(FieldWithDescriptionResponseDTO::getStructureId));

		responsefieldsMap.keySet().stream().forEach(key -> {

			List<FieldWithDescriptionResponseDTO> fieldData = responsefieldsMap.get(key);

			Map<String, Object> fieldDataMap = new HashMap<>();

			fieldData.stream().forEach(field ->

					fieldDataMap.put(field.getFieldId(), new BaseFieldDetailsDTO(field.getDescription(),
							field.getDataType(), field.getPickList(), field.getMaxChar(), field.getStructureId()))

			);

			finalMap.put(key, fieldDataMap);
		});
		finalMap.putAll(dataMap);

		return finalMap;
	}

	private List<FieldWithDescriptionResponseDTO> getFieldWithDescriptionResponseDTO(Long moduleid, String language, String tenantCode, ObjectMapper mapper, List<CoreMetadataLangModel> metadataLang) {
		// store available field data
		List<FieldWithDescriptionResponseDTO> responsefieldsList = new ArrayList<>();

		if (null != metadataLang) {

			// get all available fields
			List<String> metadataFieldIds = metadataLang.stream().map(CoreMetadataLangModel::getFieldId)
					.collect(Collectors.toList());

			// remove duplicate fields
			Set<String> set = new HashSet<>();
			metadataFieldIds.stream().filter(s -> !set.contains(s)).forEach(set::add);
			FieldDTO parentField;
			// create the parent and child fields structure based on the available fields in
			for (String field : set) {

				CoreMetadataModel metadata = coreMetadataDAO
						.findByModuleIdAndTenantIdAndFieldId(moduleid, tenantCode, field);

				// create fields
				parentField = coreLayoutHeaderService.generateMetadataField(language, tenantCode, mapper,
						metadata);
				if (parentField.getShortText() == null) {
					parentField.setFieldId(null);
				}

				// generate the response fields list
				generateResponseField(language, responsefieldsList, parentField, mapper);

			}
		}
		return responsefieldsList;
	}

	/**
	 * @param language
	 * @param responsefieldsList
	 * @param parentField
	 * @param mapper
	 */
	@Override
	public boolean generateResponseField(String language, List<FieldWithDescriptionResponseDTO> responsefieldsList,
	        FieldDTO parentField, ObjectMapper mapper) {
		if (parentField == null || parentField.getFieldId() == null
		        || responsefieldsList.stream().anyMatch(list -> list.getFieldId().equals(parentField.getFieldId()))) {
			return false;
		}
		
		List<FieldWithDescriptionResponseDTO> chieldList = new ArrayList<>();
		if (parentField.getChildfields() != null && !parentField.getChildfields().isEmpty()) {
			parentField.getChildfields().stream().forEach(chield -> {
				if (chieldList.stream().noneMatch(list -> list.getFieldId().equals(chield.getFieldId()))) {
					FieldDTO childField = mapper.convertValue(chield, new TypeReference<FieldDTO>() {
					});
					FieldWithDescriptionResponseDTO fieldDTO = constructFieldWithDescription(language, childField);
					chieldList.add(fieldDTO);
				}
			});
		}
		FieldWithDescriptionResponseDTO fieldResposeDTO = constructFieldWithDescription(language, parentField);
		fieldResposeDTO.setGrid(chieldList);
		responsefieldsList.add(fieldResposeDTO);
		return true;
	}

	/**
	 * This method is used to search fields with field description.
	 */
	@Override
	public List<FieldWithDescriptionResponseDTO> searchByDesc(Long moduleId,String tenantCode,String searchTerm,
							 Integer fetchCount,Integer fetchSize,String language) {


		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		log.info("Get fields with field description");

		Pageable pageable = PageRequest.of(fetchCount, fetchSize);

		// find in field description
		List<CoreMetadataLangModel> metadataLang = coreMetadataLangDAO
				.findBySearchTerm(moduleId, language, tenantCode,
						searchTerm, pageable);

		return getFieldWithDescriptionResponseDTO(moduleId,language,tenantCode,mapper,metadataLang);
	}
	/**
	 * @param language
	 * @param field
	 * @return
	 */
	private FieldWithDescriptionResponseDTO constructFieldWithDescription(String language, FieldDTO field) {
		FieldWithDescriptionResponseDTO fieldDTO = new FieldWithDescriptionResponseDTO();
		fieldDTO.setFieldId(field.getFieldId());
		fieldDTO.setDescription(field.getShortText() != null ? field.getShortText().get(language).getDescription() : null);
		fieldDTO.setDataType(field.getDataType());
		fieldDTO.setPickList(field.getPickList());
		fieldDTO.setMaxChar(field.getMaxChar());
		fieldDTO.setStructureId(Short.parseShort(field.getStructureId()));
		return fieldDTO;
	}
	

	/**
	 * This method is used to Get Metadata of fields based on field Id list.
	 */
	@Override
	public List<FieldWithDescriptionResponseDTO> getMetadataOfFieldsBasedOnFieldIdArrayList(FieldIdsRequestDTO reuestDTO,
	        String language, String tenantCode) {
		StopWatch watch = new StopWatch();
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		
		// store available field data
		List<FieldWithDescriptionResponseDTO> responsefieldsList = new ArrayList<>();

		watch.start("Get fields");
		try {
			
			// remove duplicate fields
			Set<String> set = new HashSet<>();
			reuestDTO.getFieldIds().stream().filter(s -> !set.contains(s)).forEach(set::add);
			
			// create the parent and child fields structure based on the available fields in
			for (String field : set) {
				
				// create fields
				FieldDTO parentField = new FieldDTO();
				
				List<ChildFieldsDTO> childfields = new ArrayList<>();

				List<CoreMetadataModel> metadataFields = coreMetadataDAO
				        .findByTenantIdAndFieldIdOrParentField(tenantCode, field, field);

				FieldDTO childfield=null;
				for (CoreMetadataModel metadata : metadataFields) {
					
					if (null == metadata.getParentField() || metadata.getParentField().isEmpty()) {
						parentField = coreLayoutHeaderService.generateMetadataField(language, tenantCode, mapper, metadata);
					} else {
						childfield = coreLayoutHeaderService.generateMetadataField(language, tenantCode, mapper,
						        metadata);
						childfield.setIsGridColumn(true);
						ChildFieldsDTO childField = mapper.convertValue(childfield,
						        new TypeReference<ChildFieldsDTO>() {
						        });
						
						childfields.add(childField);
					}
				}

				if (parentField.getFieldId()!=null) {
					parentField.setChildfields(childfields);
				}
				else {
					parentField = childfield;
				}
				
				// generate the response fields list
				generateResponseField(language, responsefieldsList, parentField, mapper);
			}
			
			watch.stop();
			log.info(watch.prettyPrint());
			return responsefieldsList;
			
		} catch (Exception e) {
			log.error(ERROR, e);
			return responsefieldsList;
		}
	}

	/**
	 * This method used to generate the fields based on the field id
	 */
	@Override
	public FieldDTO getFieldDetailsWithFieldId(Long moduleid, String fieldid, String tenantCode,String userName) {
		
		StopWatch watch = new StopWatch();
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		FieldDTO parentField = new FieldDTO();
		
		List<ChildFieldsDTO> childfields = new ArrayList<>();

		watch.start("Get Field Details with Field Id.");

		UserFieldMetadata draft=userFieldMetadataRepository.findByFieldIdAndModuleIdAndTenantIdAndUserId(fieldid,moduleid,tenantCode,userName)
				.orElse(null);

		if (draft != null) {
			FieldDTO dto = draft.getFieldData();
			dto.setIsDraft(true);
			dto.setIsPersisted(coreMetadataDAO.existsByFieldIdAndModuleIdAndTenantId(fieldid, moduleid, tenantCode));
			return dto;
		}

		try {
			
			if (null == fieldid || fieldid.isEmpty()) {
				throw new NullPointerException("Field Id is required.");
			}
			
			List<CoreMetadataModel> metadataFields = coreMetadataDAO.findByTenantIdAndFieldIdOrParentField(tenantCode,
			        fieldid, fieldid);
			
			if (null == metadataFields || metadataFields.isEmpty()) {
				throw new NotFound404Exception("There is no metadata available for this request.");
			}

			FieldDTO childfield=new FieldDTO();
			for (CoreMetadataModel metadata : metadataFields) {
				
				if (null == metadata.getParentField() || metadata.getParentField().isEmpty()) {
					parentField = generateFieldMetadata(tenantCode, mapper, metadata);
				} else {
					childfield = generateFieldMetadata(tenantCode, mapper, metadata);
					childfield.setIsGridColumn(true);
					ChildFieldsDTO childField = mapper.convertValue(childfield, new TypeReference<ChildFieldsDTO>() {
					});
					
					childfields.add(childField);
				}
			}
			if(parentField.getFieldId() == null) {

				childfield.setIsPersisted(true);
				return childfield;
			}
			parentField.setChildfields(childfields);
			parentField.setIsDraft(false);
			parentField.setIsPersisted(true);
			watch.stop();
			log.info(watch.prettyPrint());
			return parentField;
			
		} catch (Exception e) {
			log.error(ERROR, e);
			return null;
		}
	}

	/**
	 * This method is used to add the language metadata to the field
	 * 
	 * @param tenantCode
	 * @param mapper
	 * @param metadata
	 * @return
	 */
	private FieldDTO generateFieldMetadata(String tenantCode, ObjectMapper mapper, CoreMetadataModel metadata) {
		
		List<CoreMetadataLangModel> metadataLang = coreMetadataLangDAO
		        .findByFieldIdAndTenantIdAndModuleId(metadata.getFieldId(), tenantCode, metadata.getModuleId());
		
		FieldDTO field = mapper.convertValue(metadata, new TypeReference<FieldDTO>() {
		});

		if (metadataLang == null) {
			return field;
		}

		Map<String, String> longText = new HashMap<>();
		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();

		metadataLang.forEach(lang->{

			ModuleDescriptionInformationRequestDTO data = new ModuleDescriptionInformationRequestDTO();
			data.setDescription(lang.getShortText());
			data.setInformation(lang.getHelpText());
			moduledescription.put(lang.getLanguage(),data);
			longText.put(lang.getLanguage(),lang.getLongText());

		});

		field.setShortText(moduledescription);
		field.setLongtexts(longText);

		return field;
	}

	/**
	 * This method is used to create and assign random dynamic field id's
	 *
	 * @param requestDTO
	 * @param moduleId
	 * @param tenentId
	 */
	@Override
	public List<String> createDynamicFieldIds(ModuleRequestDTO requestDTO, Long moduleId, String tenentId,boolean checkFields) {
		List<String> allFields = new ArrayList<>();
        List<String> dynamicFields=new ArrayList<>();
		requestDTO.getFields().forEach(fieldList -> {

			fieldList.getFieldlist().forEach(field -> {

				if (field.getFieldId() == null || field.getFieldId().trim().isEmpty()) {
					field.setFieldId(createRandomFieldId(FIELD_ID_PREFIX, field.getShortText()));
					dynamicFields.add(field.getFieldId());
				}
				else if(!field.getFieldId().trim().equals(field.getFieldId())) {
					field.setFieldId(field.getFieldId().trim());
				}

				checkForGridColumns(field, allFields,dynamicFields);

				allFields.add(field.getFieldId());

			});

		});

		//check if combination of fieldId,moduleId,tenentId already Exists
		if (checkFields) {
			coreMetadataDAO.findFirstByFieldIdInAndModuleIdAndTenantId(allFields, moduleId, tenentId)
					.ifPresent(field ->
					{
						throw new AlreadyExistsException(field.getFieldId() + " already exists");
					});
		}
		return dynamicFields;
	}

	@Override
	public Map<String, Long> fieldCount(Long moduleId, String tenantCode) {

		StopWatch watch = new StopWatch();
		watch.start("Fetch Field Count");

		Map<String, Long> map = new HashMap<>();
		map.put("count",coreMetadataDAO.countByModuleIdAndTenantId(moduleId,tenantCode));

		watch.stop();
		log.info(watch.prettyPrint());
		return map;
	}

	/**
	 * This method is used to check and assign random dynamic field id's for Grid columns
	 *
	 * @param field
	 * @param allFields
	 */
	private void checkForGridColumns(FieldDTO field, List<String> allFields,List<String> dynamicFields) {

		List<ChildFieldsDTO> childList = field.getChildfields();
		if (childList!=null && !childList.isEmpty()) {
			childList.forEach(child -> {

				if(child.getParentField() == null || child.getParentField().isEmpty()) {
					child.setParentField(field.getFieldId());
				}
				if (child.getFieldId() == null || child.getFieldId().trim().isEmpty()) {
					child.setFieldId(createRandomFieldId(FIELD_ID_PREFIX, child.getShortText()));
					dynamicFields.add(child.getFieldId());

				}
				else if(!child.getFieldId().trim().equals(child.getFieldId())) {
					child.setFieldId(child.getFieldId().trim());
				}
				allFields.add(child.getFieldId());

			});
		}
	}

	/**
	 * This method is used to generate random field id
	 *
	 * @param prefix
	 * @param shortText
	 */
	private String createRandomFieldId(String prefix, Map<String, ModuleDescriptionInformationRequestDTO> shortText) {

		return  validateDescription(shortText)
				? prefix + Character.toUpperCase(shortText.get("en").getDescription().trim().charAt(0)) + Utility.getRandomNumberId()
				:
				prefix + Utility.getRandomNumberId();
	}

	private boolean validateDescription(Map<String, ModuleDescriptionInformationRequestDTO> shortText) {
		return shortText.get("en").getDescription() != null
				&& !shortText.get("en").getDescription().trim().isEmpty()
				&& (Character.isDigit(shortText.get("en").getDescription().trim().charAt(0))
				|| Character.isAlphabetic(shortText.get("en").getDescription().trim().charAt(0)));
	}

	@Override
	public ReferenceRuleResponseDTO createReferenceRule(@Valid ReferenceRuleRequestDTO referenceRule, String dataReferenceFieldId) {
		StopWatch watch = new StopWatch();
		ReferenceRuleResponseDTO responseDTO = new ReferenceRuleResponseDTO();
		watch.start("Create reference rule.");
		try {
			CoreMetadataReferenceRuleModel ruleModel = new CoreMetadataReferenceRuleModel();
			BeanUtils.copyProperties(referenceRule, ruleModel);
			ruleModel.setDataReferenceFieldId(dataReferenceFieldId);
			coreMetadataReferenceRuleDAO.save(ruleModel);
			
			responseDTO.setAcknowledge(true);
			responseDTO.setReference_uuid(ruleModel.getReferenceUuid() != null ? ruleModel.getReferenceUuid().toString() : null);
			responseDTO.setSuccessMsg("Rule created successfully");
			
			watch.stop();
			log.info(watch.prettyPrint());
			
		} catch (Exception e) {
			log.error(ERROR, e);
			responseDTO.setErrorMsg(e.getMessage());
			responseDTO.setAcknowledge(false);
			return responseDTO;
		}
		return responseDTO;
	}

	@Override
	public ReferenceRuleResponseDTO updateReferenceRule(@Valid ReferenceRuleRequestDTO referenceRule, String referenceUuid) {

		StopWatch watch = new StopWatch();
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		
		ReferenceRuleResponseDTO responseDTO = new ReferenceRuleResponseDTO();
		
		watch.start("Update reference rule.");
		try {
			
			Optional<CoreMetadataReferenceRuleModel> ruleModelObj = coreMetadataReferenceRuleDAO.findById(referenceUuid);
			
			if (!ruleModelObj.isPresent()) {
				throw new NoSuchElementException("No reference rule available for requested reference uuid.");
			}
			
			CoreMetadataReferenceRuleModel ruleModel = ruleModelObj.get();
			
			BeanUtils.copyProperties(referenceRule, ruleModel);
			
			coreMetadataReferenceRuleDAO.save(ruleModel);
			
			responseDTO.setAcknowledge(true);
			responseDTO.setReference_uuid(ruleModel.getReferenceUuid() != null ? ruleModel.getReferenceUuid().toString() : null);
			responseDTO.setSuccessMsg("Rule updated successfully");
			
			watch.stop();
			log.info(watch.prettyPrint());
			
		} catch (Exception e) {
			responseDTO.setAcknowledge(false);
			responseDTO.setErrorMsg(e.getMessage());
			log.error(ERROR, e);
			return responseDTO;
		}

		return responseDTO;
	
	}
}
