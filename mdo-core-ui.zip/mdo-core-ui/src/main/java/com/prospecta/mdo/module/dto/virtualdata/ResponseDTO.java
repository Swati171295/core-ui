package com.prospecta.mdo.module.dto.virtualdata;

import lombok.Data;

@Data
public class ResponseDTO {

		// General error message about nature of error
		private String message;

		// data to send in response
		private Object data;

		public ResponseDTO(String message, Object data) {
			super();
			this.message = message;
			this.data = data;
		}

		public ResponseDTO() {
			super();
		}
		
		
		
		
}
