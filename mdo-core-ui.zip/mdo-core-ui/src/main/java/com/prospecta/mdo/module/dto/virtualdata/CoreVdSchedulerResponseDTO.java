package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CoreVdSchedulerResponseDTO {
	
	private UUID schedulerId;
	private UUID vdId;

}
