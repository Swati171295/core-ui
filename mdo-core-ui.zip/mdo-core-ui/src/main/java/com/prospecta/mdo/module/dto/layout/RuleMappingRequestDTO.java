/**
 * 
 */
package com.prospecta.mdo.module.dto.layout;

import java.util.List;
import java.util.UUID;

import javax.validation.Valid;

import com.prospecta.mdo.module.dto.module.FieldsRequestDTO;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author satyam
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RuleMappingRequestDTO {
	@ApiModelProperty(
			name = "ruleMappingIds",
			value = "Arrays of rule mapping Ids",
			required = true
	)
	@Valid
	private List<UUID> ruleMappingIds;
	
}
