/**
 * 
 */
package com.prospecta.mdo.module.dao.metadata;

import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * @author savan
 *
 */
@Repository
public interface CoreMetadataDAO extends PagingAndSortingRepository<CoreMetadataModel, String> {

	Long countByModuleId(Long moduleid);

	@Query("SELECT fieldId from CoreMetadataModel WHERE structureid=:structureId AND moduleid=:moduleid AND tenantid=:tenantCode")
	List<String> findByStructureIdAndModuleIdAndTenantId(short structureId, Long moduleid, String tenantCode,
			Pageable pageable);

	@Query("SELECT metadata.fieldId as fieldId,metadata.maxChar as maxChar,lang.shortText as description from CoreMetadataModel as metadata join CoreMetadataLangModel as lang ON metadata.fieldId = lang.fieldId WHERE metadata.pickList=:pickList AND metadata.moduleId=:moduleid AND metadata.tenantId=:tenantCode AND lang.language=:language AND lang.shortText LIKE %:description%")
	List<Map<String, Object>> getpicklistFields(String pickList, String description, Long moduleid, String tenantCode, String language, Pageable pageable);

	@Query("SELECT metadata.fieldId as fieldId,metadata.maxChar as maxChar,metadata.dataType as dataType,metadata.pickList as pickList,metadata.structureId as structureId,lang.shortText as description from CoreMetadataModel as metadata join CoreMetadataLangModel as lang ON metadata.fieldId = lang.fieldId WHERE metadata.dataType=:datatype AND metadata.moduleId=:moduleid AND metadata.tenantId=:tenantCode AND lang.language=:language AND lang.shortText LIKE %:description%")
	List<Map<String, Object>> getDataTypeFields(String datatype, String description, Long moduleid, String tenantCode,String language, Pageable pageable);

	List<CoreMetadataModel> findByModuleIdAndTenantIdAndFieldIdOrParentField(Long moduleid, String tenantCode, String fieldId,
			String parentFieldId);

	List<CoreMetadataModel> findByModuleIdAndTenantIdAndFieldIdInOrParentFieldIn(Long moduleid, String tenantCode, List<String> fieldId,
																			 List <String> parentFieldId);

	@Query("from CoreMetadataModel as metadata join CoreMetadataLangModel as lang ON metadata.fieldId = lang.fieldId WHERE metadata.parentField='' AND metadata.moduleId=:moduleid AND metadata.tenantId=:tenantCode AND metadata.structureId=:structureId AND lang.language=:language ORDER BY lang.shortText ASC")
	List<Object> findAllFieldsByStructure(short structureId, Long moduleid, String tenantCode, String language, Pageable pageable);

	List<CoreMetadataModel> findByModuleIdAndTenantIdAndParentField(Long moduleid, String tenantCode, String parentFieldId);
	List<CoreMetadataModel> findByModuleIdAndTenantIdAndParentFieldIn(Long moduleid, String tenantCode, List<String> parentFields);
	List<CoreMetadataModel> findByTenantIdAndFieldIdOrParentField(String tenantCode, String field, String parentFieldId);
	List<CoreMetadataModel> findByStructureIdInAndModuleIdAndTenantId(List<Short> ids, Long moduleId, String tenantCode);

	@Query("SELECT c from CoreMetadataModel c,CoreMetadataLangModel m WHERE lower(m.shortText) like lower(concat('%',?1,'%')) AND c.structureId in ?2 AND c.moduleId = ?3 AND c.tenantId= ?4 AND c.isKeyField = ?5 AND c.fieldId = m.fieldId AND c.moduleId = m.moduleId AND c.tenantId = m.tenantId")
	List<CoreMetadataModel> findKeyFieldByStructureList(String searchTerm,List<Short> ids, Long moduleId, String tenantCode,boolean isKey,Pageable pageable);


	CoreMetadataModel findByModuleIdAndTenantIdAndFieldId(Long moduleId,String tenantId,String fieldId);
	Optional<CoreMetadataModel> findFirstByFieldIdInAndModuleIdAndTenantId(List<String> fieldIds, Long moduleId, String tenantId);

	List<CoreMetadataModel> findByStructureIdInAndModuleIdAndTenantIdAndIsKeyField(List<Short> ids,Long moduleId,String tenantCode,boolean isKeyField);

	@Query("SELECT m.fieldId FROM CoreMetadataModel m WHERE m.fieldId in ?1 and m.moduleId=?2 and m.tenantId=?3")
	List<String> findFieldIdByFieldIdInAndModuleIdAndTenantId(List<String> fieldIds, Long moduleId, String tenantId);

	Boolean existsByFieldIdAndModuleIdAndTenantId(String fieldId,Long moduleId,String tenantId);

	Long countByModuleIdAndTenantId(Long moduleId,String tenantId);

	@Query("SELECT s.structureId from CoreMetadataModel s where s.moduleId=?1 and s.tenantId=?2 and s.pickList=?3")
	List<String> findGridFieldByModuleIdAndTenantIdAndPickList(Long moduleId,String tenantId,String pickList);

	List<CoreMetadataModel> findByPickListAndModuleIdAndTenantIdAndIsSubGridAndStructureIdIn(String picklist,Long moduleId,String tenantId,boolean isSubGrid,List<Short> strucIds);

	List<CoreMetadataModel> findByFieldIdInAndModuleIdAndTenantId(List<String> fieldIds, Long moduleId, String tenantId);
	
	@Query("from CoreMetadataModel as s where s.moduleId=?1 and s.tenantId=?2 and s.isDescription=?3")
	List<CoreMetadataModel> findByModuleIdAndTenantIdAndIsDescription(Long moduleId,String tenantId,Boolean isDescription);
}
