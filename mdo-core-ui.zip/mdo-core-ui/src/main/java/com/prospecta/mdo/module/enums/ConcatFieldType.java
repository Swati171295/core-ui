package com.prospecta.mdo.module.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum ConcatFieldType {
	
	USERINPUT('0'), TABLECOLUMN('1');
	
	public char asChar() {
        return asChar;
    }

    private final char asChar;

    ConcatFieldType(char asChar) {
        this.asChar = asChar;
    }
    
    @JsonCreator
	public static ConcatFieldType fromValue(String value) {
		return Enum.valueOf(ConcatFieldType.class, value);
	}

}
