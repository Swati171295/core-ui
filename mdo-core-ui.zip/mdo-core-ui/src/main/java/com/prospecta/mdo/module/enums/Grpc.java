package com.prospecta.mdo.module.enums;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.TimeUnit;

@Slf4j
public enum Grpc {
    INSTANCE;

    private ManagedChannel channel;


    public ManagedChannel getChannel(String addressName,int addressPort) {
        try {
            if (channel == null) {
                channel = ManagedChannelBuilder.forAddress(addressName, addressPort)
                          .idleTimeout(10, TimeUnit.SECONDS)
                          .build();
            }
        } catch (Exception e) {
            log.error("Error in initializing GRPC Channel : {}", e.getMessage());
            return null;
        }
        return channel;
    }
}
