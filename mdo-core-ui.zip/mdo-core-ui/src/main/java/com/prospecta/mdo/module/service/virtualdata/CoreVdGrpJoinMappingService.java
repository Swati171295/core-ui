package com.prospecta.mdo.module.service.virtualdata;

import java.util.List;
import java.util.UUID;

import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinMappingRequestDTO;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinMappingModel;

public interface CoreVdGrpJoinMappingService {
	
	CoreVdGrpJoinMappingModel getVdGroupJoinMappingbyMappingId(UUID mappingId);
	
	List<CoreVdGrpJoinMappingModel> getVdGroupJoinMappingbygroupInfoId(UUID groupInfoId);
	
	void deleteVdGroupJoinMappingbyMappingId(UUID mappingId);
	
	void deleteVdGroupJoinMappingbygroupInfoId(UUID groupInfoId);

	void deleteVdGrpJoinMapping(List<VdGroupJoinMappingRequestDTO> joinMapping, UUID uuid);

	CoreVdGrpJoinMappingModel saveAndUpdateJoinMapping(VdGroupJoinMappingRequestDTO groupJoinMappingRequestDTO,
			CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel);

}
