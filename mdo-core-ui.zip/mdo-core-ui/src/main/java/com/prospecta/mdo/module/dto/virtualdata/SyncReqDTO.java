package com.prospecta.mdo.module.dto.virtualdata;

import java.util.List;

import lombok.Data;

@Data
public class SyncReqDTO {

	private String className;
	
	private String file;
	
	private List<String> args;

}