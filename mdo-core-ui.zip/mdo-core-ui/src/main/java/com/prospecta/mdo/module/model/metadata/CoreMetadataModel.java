/**
 * 
 */
package com.prospecta.mdo.module.model.metadata;

import lombok.Data;
import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author savan
 *
 */
@Data
@Entity
@Audited
@Table(name = "CORE_METADATA_MDO")
@IdClass(CoreMetadataModelId.class)
public class CoreMetadataModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5206538670400962972L;

	@Id
	@Column(name = "FIELDID", columnDefinition = "nvarchar(50)")
	private String fieldId;
	
	@Id
	@Column(name = "MODULEID")
	private Long moduleId;
	
	@Id
	@Column(name = "TENANTID", columnDefinition = "nvarchar(100)")
	private String tenantId;
	
	@Column(name = "DATATYPE", columnDefinition = "nvarchar(50)")
	private String dataType;
	
	@Column(name = "MAXCHAR")
	private Long maxChar;
	
	@Column(name = "PICKLIST", columnDefinition = "nvarchar(50)")
	private String pickList;
	
	@Column(name = "OUTPUTLEN", columnDefinition = "nvarchar(50)")
	private String outputLen;
	
	@Column(name = "STRUCTUREID", columnDefinition = "tinyint")
	private Short structureId;
	
	@Column(name = "PICKSERVICE", columnDefinition = "nvarchar(50)")
	private String pickService;
	
	@Column(name = "IS_KEYFIELD")
	private Boolean isKeyField;
	
	@Column(name = "PARENTFIELD", columnDefinition = "nvarchar(50)")
	private String parentField;
	
	@Column(name = "IS_CRITERIAFIELD")
	private Boolean isCriteriaField;
	
	@Column(name = "IS_REFERENCE")
	private Boolean isReference;
	
	@Column(name = "IS_DEFAULT")
	private Boolean isDefault;
	
	@Column(name = "IS_WORKFLOW")
	private Boolean isWorkFlow;
	
	@Column(name = "IS_HEIRARCHY")
	private Boolean isHeirarchy;
	
	@Column(name = "IS_DESCRIPTION")
	private Boolean isDescription;
	
	@Column(name = "IS_WORKFLOWCRITERIA")
	private Boolean isWorkFlowCriteria;
	
	@Column(name = "IS_NUMSETTINGCRITERIA")
	private Boolean isNumSettingCriteria;
	
	@Column(name = "IS_CHECKLIST")
	private Boolean isCheckList;
	
	@Column(name = "IS_COMPBASED")
	private Boolean isCompBased;
	
	@Column(name = "USERMODIFIED", columnDefinition = "nvarchar(150)")
	private String userModified;
	
	@Column(name = "DATEMODIFIED")
	private Long dateModified;
	
	@Column(name = "DECIMALVALUE", columnDefinition = "nvarchar(50)")
	private String decimalValue;
	
	@Column(name = "IS_TRANSIENT")
	private Boolean isTransient;
	
	@Column(name = "TEXTCASE")
	private String textCase;
	
	@Column(name = "ATTACHMENT_SIZE", columnDefinition = "nvarchar(50)")
	private String attachmentSize;
	
	@Column(name = "FILE_TYPES", columnDefinition = "nvarchar(200)")
	private String fileTypes;
	
	@Column(name = "IS_FUTURE_DATE")
	private Boolean isFutureDate;
	
	@Column(name = "IS_PAST_DATE")
	private Boolean isPastDate;
	
	@Column(name = "IS_SEARCHENGINE")
	private Boolean isSearchEngine;

	@Column(name = "IS_PERMISSION")
	private Boolean isPermission;

	@Column(name="IS_REJECTION")
	private Boolean isRejection;

	@Column(name="IS_REQUEST")
	private Boolean isRequest;

	@Column(name = "IS_SUB_GRID")
	private Boolean isSubGrid;
	
	@Column(name = "OPTIONS_LIMIT")
	private Short optionsLimit;
}
