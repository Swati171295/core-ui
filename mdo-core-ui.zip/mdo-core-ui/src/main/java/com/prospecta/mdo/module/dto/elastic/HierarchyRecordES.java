/**
 * 
 */
package com.prospecta.mdo.module.dto.elastic;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import lombok.Data;



/**
 * @author savan
 *
 */
@Data
public class HierarchyRecordES implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6620867654486648611L;

	/***
	 * Back reference to the key
	 */
	private String hId;
	
	 /***
	* The list of fields and values for the hierarchy combination
	*/
	private LinkedList<LinkedHashMap<String, FieldValue>> rows;
	
	/**
	 * Key fields of the hierarchy structure
	 */
	private LinkedList<String> keyFields;
}
