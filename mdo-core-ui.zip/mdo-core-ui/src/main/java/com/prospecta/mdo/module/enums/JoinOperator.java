package com.prospecta.mdo.module.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum JoinOperator {
	
	AND('0'), OR('1');
	
	public char asChar() {
        return asChar;
    }

    private final char asChar;

    JoinOperator(char asChar) {
        this.asChar = asChar;
    }
    
    @JsonCreator
	public static JoinOperator fromValue(String value) {
		return Enum.valueOf(JoinOperator.class, value);
	}
}
