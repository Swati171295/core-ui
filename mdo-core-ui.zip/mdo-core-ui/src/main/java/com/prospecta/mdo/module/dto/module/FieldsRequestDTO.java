/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiParam;
import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldsRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5436667774522847020L;


	@ApiModelProperty(
			name = "structureid",
			value = "String representing, Structure Id",
			dataType = "java.lang.String",
			required = true
	)
	private String structureid;
	
	@Valid
	@ApiModelProperty(
			name = "fieldlist",
			value = "Array of FieldDTO",
			required = true
	)
	private List<FieldDTO> fieldlist;

}
