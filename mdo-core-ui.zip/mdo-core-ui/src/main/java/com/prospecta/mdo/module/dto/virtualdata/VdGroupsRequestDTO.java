package com.prospecta.mdo.module.dto.virtualdata;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class VdGroupsRequestDTO {
	
	@ApiModelProperty(
			name = "groupId",
			value = "String representing group id",
			dataType = "java.util.UUID;",
			required = true
	)
	public UUID groupId;
	
	@ApiModelProperty(
			name = "groupType",
			value = "Group type where type of group can be of two types JOIN, TRANSFORMATION ",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message= "group type must not be null")
	public String groupType;
	
	@ApiModelProperty(
			name = "order",
			value = "Integer representing order by",
			dataType = "java.lang.Integer",
			required = true
	)
	public int order;
	
	@ApiModelProperty(
			name = "userCreated",
			value = "When user created the group information",
			dataType = "java.lang.String",
			required = true
	)
	public String userCreated;
	
	@ApiModelProperty(
			name = "dateCreated",
			value = "dateCreated is the date of creation",
			dataType = "java.lang.Long",
			required = true
	)
	public Long dateCreated;
	
	@ApiModelProperty(
			name = "userModified",
			value = "User who last modified the group information",
			dataType = "java.lang.String",
			required = true
	)
	public String userModified;
	
	@ApiModelProperty(
			name = "dateModified",
			value = "dateModified is the last date of modification",
			dataType = "java.lang.Long",
			required = true
	)
	public Long dateModified;

	@ApiModelProperty(
			name = "tenantId",
			value = "Tenant id of the client, which can’t be null or empty",
			dataType = "java.util.String",
			required = true
	)
	public String tenantId;
	
	@ApiModelProperty(
			name = "groupName",
			value = "Group name, e.g Join 1, Transformation 1 which will be auto generated and cannot be changed",
			dataType = "java.lang.String",
			required = true
	)
	@NotNull(message="groupName must not be empty")
	public String groupName;
	
	@ApiModelProperty(
			name = "groupDescription",
			value = "Description of the group created by user",
			dataType = "java.lang.String",
			required = true
	)
	public String groupDescription;
	
	List<@Valid VdGroupJoinInfoRequestDTO> groupJoinDetail=  new ArrayList<>();
	
	List<@Valid VdGroupJoinOnRequestDTO> joinColumns = new ArrayList<>();
	
	List<@Valid VdGroupTransInfoRequestDTO> groupTransDetail = new ArrayList<>();
	
}