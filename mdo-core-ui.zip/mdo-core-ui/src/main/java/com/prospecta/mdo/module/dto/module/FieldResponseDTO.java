/**
 * 
 */
package com.prospecta.mdo.module.dto.module;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author savan
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldResponseDTO {

	private boolean acknowledge;

	private String errorMsg;
	
	private String fieldId;
	
}
