package com.prospecta.mdo.module.dao.virtualdata;

import java.util.List;
import java.util.UUID;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;

@Repository
public interface CoreVdTransFieldSettingDAO extends PagingAndSortingRepository<CoreVdTransFieldSettingModel, UUID>{

	List<CoreVdTransFieldSettingModel> findByCoreVdGroups(CoreVdGroupsModel coreVdGroupsModel);

	List<CoreVdTransFieldSettingModel> findByCoreVdGrpTransInfo(CoreVdGrpTransInfoModel coreVdGrpTransInfoModel);

	void deleteByCoreVdGroups(CoreVdGroupsModel coreVdGroupsModel);

	void deleteByCoreVdGrpTransInfo(CoreVdGrpTransInfoModel coreVdGrpTransInfoModel);

	List<CoreVdTransFieldSettingModel> findByTransIdIn(List<UUID> transFieldId);

	void deleteByTransIdIn(List<UUID> transFieldId);

}
