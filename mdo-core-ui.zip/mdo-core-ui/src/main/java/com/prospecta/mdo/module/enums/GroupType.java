package com.prospecta.mdo.module.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum GroupType {
	
	JOIN('0'), TRANSFORMATION('1');
	
	public char asChar() {
        return asChar;
    }

    private final char asChar;

    GroupType(char asChar) {
        this.asChar = asChar;
    }
    
    @JsonCreator
	public static GroupType fromValue(String value) {
		return Enum.valueOf(GroupType.class, value);
	}

}
