package com.prospecta.mdo.module.dto.virtualdata;

import java.util.UUID;

import lombok.Data;

@Data
public class VdHeaderResponseDTO {
	
	private UUID vdId;

	private String vdName;
}
