package com.prospecta.mdo.module.dto.virtualdata;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import lombok.Data;

@Data
public class VdGroupsResponseDTO {
	
	private UUID groupId;
	
	private String groupType;
	
	private int order;
	
	private String userCreated;
	
	private Long dateCreated;
	
	private String userModified;
	
	private Long dateModified;

	private String tenantId;
	
	private String groupName;
	
	private String groupDescription;
	
	List<VdGroupJoinInfoResponseDTO> groupJoinDetail=  new ArrayList<>();
	
	List<VdGroupJoinOnResponseDTO> joinColumns = new ArrayList<>();
	
	List<VdGroupTransInfoResponseDTO> groupTransDetail = new ArrayList<>();

}
