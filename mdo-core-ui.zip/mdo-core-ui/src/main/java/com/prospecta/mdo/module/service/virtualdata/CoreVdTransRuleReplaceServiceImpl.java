package com.prospecta.mdo.module.service.virtualdata;

import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdTransFieldSettingDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdTransRuleReplaceDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdTransRuleReplaceRequestDTO;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransRuleReplaceModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class CoreVdTransRuleReplaceServiceImpl implements CoreVdTransRuleReplaceService {

	@Autowired
	private CoreVdTransRuleReplaceDAO coreVdTransRuleReplaceDAO;
	
	@Autowired
	private CoreVdTransFieldSettingDAO coreVdTransFieldSettingDAO;
	
	String message = "Virtual dataset header not found";

	/**
     * This method is used to get the virtual dataset transformation rule by replace id .
     * @param replaceId
     */
	@Override
	public CoreVdTransRuleReplaceModel getVdTransRuleReplacebyreplaceId(UUID replaceId) {
		StopWatch watch = new StopWatch();
		watch.start("Get Core vd Group Information");
		Optional<CoreVdTransRuleReplaceModel> coreVdTransRuleReplaceModel=coreVdTransRuleReplaceDAO.findById(replaceId);
		if (!coreVdTransRuleReplaceModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdTransRuleReplaceModel.get();
	}
	
	/**
     * This method is used to get the virtual dataset transformation rule by transformation field id .
     * @param transFieldId
     */
	@Override
	public List<CoreVdTransRuleReplaceModel> getVdTransRuleReplacebytransFieldId(UUID transFieldId) {
		StopWatch watch = new StopWatch();
		watch.start("Get List of Core vd Group Information");
		Optional<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModel=coreVdTransFieldSettingDAO.findById(transFieldId);
		if (!coreVdTransFieldSettingModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		List<CoreVdTransRuleReplaceModel> coreVdTransRuleReplaceModel=coreVdTransRuleReplaceDAO.findByCoreVdTransFieldSetting(coreVdTransFieldSettingModel.get());
		if (coreVdTransRuleReplaceModel.isEmpty()) {
			throw new NotFound404Exception("Virtual dataset group not found");
		}
		watch.stop();
		log.info(watch.prettyPrint());
		return coreVdTransRuleReplaceModel;
	}
	
	/**
     * This method is used to delete the virtual dataset transformation rule by replace id .
     * @param replaceId
     */
	@Override
	public void deleteVdTransRuleReplacebyreplaceId(UUID replaceId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Information");
		watch.start("Delete vd groups");
		coreVdTransRuleReplaceDAO.deleteById(replaceId);
		watch.stop();
		log.info(watch.prettyPrint());

	}
	
	/**
     * This method is used to delete the virtual dataset transformation rule by transformation field id .
     * @param transFieldId
     */
	@Override
	public void deleteVdTransRuleReplacebytransFieldId(UUID transFieldId) {
		StopWatch watch = new StopWatch();
		log.info("Delete Group Information by virtual dataset Started");
		watch.start("Delete vd groups");
		Optional<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModel=coreVdTransFieldSettingDAO.findById(transFieldId);
		if (!coreVdTransFieldSettingModel.isPresent()) {
			throw new NotFound404Exception(message);
		}
		coreVdTransRuleReplaceDAO.deleteByCoreVdTransFieldSetting(coreVdTransFieldSettingModel.get());
		watch.stop();
		log.info(watch.prettyPrint());
	}
	
	/**
     * This method is used to save/update the virtual dataset transformation rule by replace id .
     * @param ruleReplaceRequestDTO
     * @param coreVdTransFieldSetting
     */
	@Override
	public CoreVdTransRuleReplaceModel saveOrUpdateVdTransRuleReplace(VdTransRuleReplaceRequestDTO ruleReplaceRequestDTO, CoreVdTransFieldSettingModel coreVdTransFieldSetting) {
		if (ruleReplaceRequestDTO != null) {
			if (coreVdTransFieldSetting != null) {
				StopWatch watch = new StopWatch();
				CoreVdTransRuleReplaceModel coreVdTransRuleReplaceModel = new CoreVdTransRuleReplaceModel();
				try {
					log.info("Store virtal dataset transformation rule replace started");
					watch.start("Store virtal dataset transformation rule replace");
					copyProperties(ruleReplaceRequestDTO, coreVdTransRuleReplaceModel);
					if (ruleReplaceRequestDTO.getVdReplaceId() == null) {
						coreVdTransRuleReplaceModel.setVdReplaceId(UUID.randomUUID());
					}
					coreVdTransRuleReplaceModel.setCoreVdTransFieldSetting(coreVdTransFieldSetting);
					coreVdTransRuleReplaceModel = coreVdTransRuleReplaceDAO.save(coreVdTransRuleReplaceModel);
					watch.stop();
				} catch (Exception e) {
					log.error("error while store virtal dataset transformation rule replace: " + e.getMessage());
					throw new CommonVirtualDatasetException(e.getMessage());
				}
				log.info(watch.prettyPrint());
				return coreVdTransRuleReplaceModel;
			} else {
				throw new NotFound404Exception("Virtual transformation field setting data is not present while storing transformation rule replace information.");
			}
		} else {
			throw new NotFound404Exception("Virtual data transformation rule replace is not present while storing it.");
		}	
	}

	/**
     * This method is used to delete the virtual dataset transformation rule.
     * @param transReplaceDetail
     * @param transId
     */
	@Override
	public void deleteVdTransRuleReplace(List<VdTransRuleReplaceRequestDTO> transReplaceDetail, UUID transId) {
		StopWatch watch = new StopWatch();
		try {
			watch.start("Delete vd transformation rule replace information");
			log.info("Fetch the all transformation rule replace information with transId and compare with new data");
			Optional<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModel = coreVdTransFieldSettingDAO
					.findById(transId);
			if (!coreVdTransFieldSettingModel.isPresent()) {
				log.error("Virtual transformation field setting information not found");
				throw new NotFound404Exception("Virtual dataset header not found");
			}
			List<UUID> newVdReplaceId = transReplaceDetail.stream().filter(g -> g.getVdReplaceId() != null)
					.map(VdTransRuleReplaceRequestDTO::getVdReplaceId).collect(Collectors.toList());
			List<UUID> vdReplaceId = coreVdTransRuleReplaceDAO
					.findByCoreVdTransFieldSetting(coreVdTransFieldSettingModel.get()).stream()
					.filter(grp -> !newVdReplaceId.contains(grp.getVdReplaceId()))
					.map(CoreVdTransRuleReplaceModel::getVdReplaceId).collect(Collectors.toList());
			log.info("Delete all transformation rule replace information data if user deleted any");
			coreVdTransRuleReplaceDAO.deleteByVdReplaceIdIn(vdReplaceId);
			watch.stop();
			log.info(watch.prettyPrint());
		} catch (Exception e) {
			log.error("error while Delete vd transformation rule replace information: " + e.getMessage());
			throw new CommonVirtualDatasetException(e.getMessage());
		}
	}
}