package com.prospecta.mdo.module.service.virtualdata;

import java.util.List;
import java.util.UUID;

import com.prospecta.mdo.module.dto.virtualdata.VdGroupTransInfoRequestDTO;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;

public interface CoreVdTransInfoService {
	
	CoreVdGrpTransInfoModel getVdTransInfobyTransInfoId(UUID transId);
	
	List<CoreVdGrpTransInfoModel> getVdTransInfobygroupId(UUID groupId);
	
	CoreVdGrpTransInfoModel saveOrUpdateVdTransInfo(VdGroupTransInfoRequestDTO transinfoRequestDTO,
			CoreVdGroupsModel coreVdGroups);

	void deleteVdTransInfo(List<VdGroupTransInfoRequestDTO> groupTransDetail, UUID groupId);
	
	void deleteVdTransInfobygroupId(UUID groupId);

	void deleteVdTransInfobyTransInfoId(UUID transId);

}