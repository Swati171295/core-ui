package com.prospecta.mdo.module.dao.virtualdata;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpResultsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

@ActiveProfiles("test")
@DataJpaTest
class CoreVdGrpResultsDaoTest {
	
	@Autowired
    private TestEntityManager entityManager;
	
	@Autowired
    private CoreVdGrpResultsDAO coreVdGrpResultsDAO;

	@DisplayName("findByCoreVdHeaderTest -> find group results by virtual dataset header")
	@Test
	void findByCoreVdHeaderTest() {		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		CoreVdGrpResultsModel coreVdGrpResultsModel = new CoreVdGrpResultsModel();
		coreVdGrpResultsModel.setUuid(UUID.randomUUID());
		coreVdGrpResultsModel.setCoreVdHeader(coreVdHeaderModel);
		coreVdGrpResultsModel.setCoreVdGroups(coreVdGroupsModel);
		entityManager.persist(coreVdHeaderModel); 
		entityManager.persist(coreVdGroupsModel);
		entityManager.persist(coreVdGrpResultsModel);
		entityManager.flush();
		List<CoreVdGrpResultsModel> actualList = coreVdGrpResultsDAO.findByCoreVdHeader(coreVdHeaderModel);
		assertEquals(actualList.get(0).getCoreVdGroups().getGroupDescription(),coreVdGroupsModel.getGroupDescription(), "group results found is different than expected");
	}
	
	@DisplayName("findByCoreVdGroupsTest -> find group results by group information")
	@Test
	void findByCoreVdGroupsTest() {		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		CoreVdGrpResultsModel coreVdGrpResultsModel = new CoreVdGrpResultsModel();
		coreVdGrpResultsModel.setUuid(UUID.randomUUID());
		coreVdGrpResultsModel.setCoreVdHeader(coreVdHeaderModel);
		coreVdGrpResultsModel.setCoreVdGroups(coreVdGroupsModel);
		entityManager.persist(coreVdHeaderModel); 
		entityManager.persist(coreVdGroupsModel);
		entityManager.persist(coreVdGrpResultsModel);
		entityManager.flush();
		List<CoreVdGrpResultsModel> actualList = coreVdGrpResultsDAO.findByCoreVdGroups(coreVdGroupsModel);
		assertEquals(actualList.get(0).getCoreVdGroups().getGroupDescription(),coreVdGroupsModel.getGroupDescription(), "group results found is different than expected");
	}
	
	@DisplayName("deleteByCoreVdHeaderTest -> delete group result by virtual dataset header")
	@Test
	void deleteByCoreVdHeaderTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");				
		entityManager.persist(coreVdHeaderModel);
		entityManager.flush();
		coreVdGrpResultsDAO.deleteByCoreVdHeader(coreVdHeaderModel);
		List<CoreVdGrpResultsModel> actualList = coreVdGrpResultsDAO.findByCoreVdHeader(coreVdHeaderModel);
		assertTrue(actualList.isEmpty(),"core group result is deleted.");
	}
	
	@DisplayName("deleteByCoreVdGroupsTest -> delete group results by group information")
	@Test
	void deleteByCoreVdGroupsTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);	
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.flush();
		coreVdGrpResultsDAO.deleteByCoreVdGroups(coreVdGroupsModel);
		List<CoreVdGrpResultsModel> actualList = coreVdGrpResultsDAO.findByCoreVdGroups(coreVdGroupsModel);
		assertTrue(actualList.isEmpty(),"core group result is deleted.");
	}
}
