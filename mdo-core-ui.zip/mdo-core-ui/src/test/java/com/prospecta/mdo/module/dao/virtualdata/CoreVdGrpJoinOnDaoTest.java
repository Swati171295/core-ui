package com.prospecta.mdo.module.dao.virtualdata;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinOnModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

@ActiveProfiles("test")
@DataJpaTest
class CoreVdGrpJoinOnDaoTest {
	
	@Autowired
    private TestEntityManager entityManager;
	
	@Autowired
    private CoreVdGrpJoinOnDAO coreVdGrpJoinOnDAO;
	
	@DisplayName("findByCoreVdGroupsTest -> find group join on by group information")
	@Test
	void findByCoreVdGroupsTest() {		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		CoreVdGrpJoinOnModel coreVdGrpJoinOnModel = new CoreVdGrpJoinOnModel();
		coreVdGrpJoinOnModel.setJoinOnId(UUID.randomUUID());
		coreVdGrpJoinOnModel.setCoreVdGroups(coreVdGroupsModel);
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.persist(coreVdGrpJoinOnModel);
		entityManager.flush();
		List<CoreVdGrpJoinOnModel> actualList = coreVdGrpJoinOnDAO.findByCoreVdGroups(coreVdGroupsModel);
		assertEquals(actualList.get(0).getCoreVdGroups().getGroupDescription(),coreVdGroupsModel.getGroupDescription(), "group join on found is different than expected");
	}
	
	@DisplayName("deleteByCoreVdGroupsTest -> delete group join on by group information")
	@Test
	void deleteByCoreVdGroupsTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);		
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.flush();
		coreVdGrpJoinOnDAO.deleteByCoreVdGroups(coreVdGroupsModel);
		List<CoreVdGrpJoinOnModel> actualList = coreVdGrpJoinOnDAO.findByCoreVdGroups(coreVdGroupsModel);
		assertTrue(actualList.isEmpty(),"group join on is deleted.");
	}

}
