package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpTransInfoDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupTransInfoRequestDTO;
import com.prospecta.mdo.module.enums.SourceScope;
import com.prospecta.mdo.module.enums.SourceType;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class CoreVdTransInfoServiceImplTest {

	@InjectMocks
	private CoreVdTransInfoServiceImpl coreVdTransInfoServiceImpl;

	@Mock
	private CoreVdGrpTransInfoDAO coreVdGrpTransInfoDAO;

	@Mock
	private CoreVdGroupsDAO coreVdGroupsDAO;

	@BeforeAll
	void init() {
		coreVdTransInfoServiceImpl = new CoreVdTransInfoServiceImpl();
	}

	@Test
	@DisplayName("getVdTransInfobyTransInfoIdTest method test for get Trans Information")
	void getVdTransInfobyTransInfoIdTest() {
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = spy(CoreVdGrpTransInfoModel.class);
		UUID id = UUID.randomUUID();
		when(coreVdGrpTransInfoDAO.findById(id)).thenReturn(Optional.of(coreVdGrpTransInfoModel));
		coreVdGrpTransInfoModel = coreVdTransInfoServiceImpl.getVdTransInfobyTransInfoId(id);
		verify(coreVdGrpTransInfoDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("getVdTransInfobyTransInfoIdExceptionTest method test for test exception")
	void getVdTransInfobyTransInfoIdExceptionTest() {
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGrpTransInfoDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGrpTransInfoModel));
		assertThrows(NotFound404Exception.class, () -> coreVdTransInfoServiceImpl.getVdTransInfobyTransInfoId(id));
		verify(coreVdGrpTransInfoDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("getVdTransInfobygroupIdTest method test for get Trans Information by group id")
	void getVdTransInfobygroupIdTest() {
		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = spy(CoreVdGrpTransInfoModel.class);
		coreVdGrpTransInfoModel.setCoreVdGroups(coreVdGroupsModel);
		List<CoreVdGrpTransInfoModel> coreVdGrpTransInfoModelList = new ArrayList<>();
		coreVdGrpTransInfoModelList.add(coreVdGrpTransInfoModel);
		UUID id = UUID.randomUUID();
		when(coreVdGrpTransInfoDAO.findByCoreVdGroups(coreVdGroupsModel)).thenReturn(coreVdGrpTransInfoModelList);
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		List<CoreVdGrpTransInfoModel> coreVdGrpTransInfoList = coreVdTransInfoServiceImpl.getVdTransInfobygroupId(id);
		assertNotNull(coreVdGrpTransInfoList);
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		verify(coreVdGrpTransInfoDAO, atLeast(1)).findByCoreVdGroups(any());
	}

	@Test
	@DisplayName("getVdTransInfobygroupIdExceptionTest method test for test exception")
	void getVdTransInfobygroupIdExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class, () -> coreVdTransInfoServiceImpl.getVdTransInfobygroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("getVdTransInfobygroupIdListExceptionTest method test for test exception")
	void getVdTransInfobygroupIdListExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		List<CoreVdGrpTransInfoModel> coreVdGrpTransInfoModelList = new ArrayList<>();
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		when(coreVdGrpTransInfoDAO.findByCoreVdGroups(coreVdGroupsModel)).thenReturn(coreVdGrpTransInfoModelList);
		assertThrows(NotFound404Exception.class, () -> coreVdTransInfoServiceImpl.getVdTransInfobygroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		verify(coreVdGrpTransInfoDAO, atLeast(1)).findByCoreVdGroups(any());
	}

	@Test
	@DisplayName("deleteVdTransInfobyTransInfoIdTest method test for delete Trans Information")
	void deleteVdTransInfobyTransInfoIdTest() {
		UUID id = UUID.randomUUID();
		doNothing().when(coreVdGrpTransInfoDAO).deleteById(id);
		coreVdTransInfoServiceImpl.deleteVdTransInfobyTransInfoId(id);
		verify(coreVdGrpTransInfoDAO, atLeast(1)).deleteById(any());
	}

	@Test
	@DisplayName("deleteVdTransInfobygroupIdTest method test for delete Trans Information by groupId")
	void deleteVdTransInfobygroupIdTest() {
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		doNothing().when(coreVdGrpTransInfoDAO).deleteByCoreVdGroups(coreVdGroupsModel);
		coreVdTransInfoServiceImpl.deleteVdTransInfobygroupId(id);
		verify(coreVdGrpTransInfoDAO, atLeast(1)).deleteByCoreVdGroups(any());
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("deleteVdTransInfobygroupIdExceptionTest method test for test exception")
	void deleteVdTransInfobygroupIdExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class, () -> coreVdTransInfoServiceImpl.deleteVdTransInfobygroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("saveOrUpdateVdTransInfoWithExceptionTest method test for any exception")
	void saveOrUpdateVdTransInfoWithExceptionTest() {
		VdGroupTransInfoRequestDTO vdGroupTransInfoRequestDTO = new VdGroupTransInfoRequestDTO();
		vdGroupTransInfoRequestDTO.setGroupTransId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		vdGroupTransInfoRequestDTO.setSourceType("SYSTABLE");
		vdGroupTransInfoRequestDTO.setSourceScope("ALL");
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		coreVdGrpTransInfoModel.setUuid(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		coreVdGrpTransInfoModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdGrpTransInfoModel.setSourceScopeUdrId("ALL");
		coreVdGrpTransInfoModel.setSourceType(null);
		coreVdGrpTransInfoModel
				.setSourceScope(SourceScope.fromValue(vdGroupTransInfoRequestDTO.getSourceScope().toUpperCase()));
		copyProperties(vdGroupTransInfoRequestDTO, coreVdGrpTransInfoModel);
		when(coreVdGrpTransInfoDAO.save(coreVdGrpTransInfoModel)).thenReturn(coreVdGrpTransInfoModel);

		Assertions.assertThrows(Exception.class, () -> {
			coreVdTransInfoServiceImpl.saveOrUpdateVdTransInfo(vdGroupTransInfoRequestDTO, coreVdGroupsModel);
		});

	}

	@Test
	@DisplayName("saveOrUpdateVdTransInfoTest method test for null")
	void saveOrUpdateVdTransInfoWithUuidNullTest() {
		VdGroupTransInfoRequestDTO vdGroupTransInfoRequestDTO = new VdGroupTransInfoRequestDTO();
		vdGroupTransInfoRequestDTO.setGroupTransId(null);
		vdGroupTransInfoRequestDTO.setSourceType("SYSTABLE");
		vdGroupTransInfoRequestDTO.setSourceScope("ALL");
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		coreVdGrpTransInfoModel.setUuid(any());
		coreVdGrpTransInfoModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdGrpTransInfoModel.setSourceScopeUdrId("ALL");
		coreVdGrpTransInfoModel
				.setSourceType(SourceType.fromValue(vdGroupTransInfoRequestDTO.getSourceType().toUpperCase()));
		coreVdGrpTransInfoModel
				.setSourceScope(SourceScope.fromValue(vdGroupTransInfoRequestDTO.getSourceScope().toUpperCase()));
		copyProperties(vdGroupTransInfoRequestDTO, coreVdGrpTransInfoModel);
		when(coreVdGrpTransInfoDAO.save(coreVdGrpTransInfoModel)).thenReturn(coreVdGrpTransInfoModel);
		coreVdTransInfoServiceImpl.saveOrUpdateVdTransInfo(vdGroupTransInfoRequestDTO, coreVdGroupsModel);
		verify(coreVdGrpTransInfoDAO, atLeast(1)).save(any());
	}

	@Test
	@DisplayName("saveOrUpdateVdTransInfoWithNullDTOTest method test for null")
	void saveOrUpdateVdTransInfoWithNullDTOTest() {
		assertThrows(Exception.class,
				() -> coreVdTransInfoServiceImpl.saveOrUpdateVdTransInfo(null,  new CoreVdGroupsModel()));
	}

	@Test
	@DisplayName("saveOrUpdateVdTransInfoWithNullModelTest method test for null")
	void saveOrUpdateVdTransInfoWithNullModelTest() {
		assertThrows(Exception.class,
				() -> coreVdTransInfoServiceImpl.saveOrUpdateVdTransInfo(new VdGroupTransInfoRequestDTO(), null));
	}

	@Test
	@DisplayName("deleteVdTransInfoTest method test for test delete the virtual dataset transformation information")
	void deleteVdTransInfoTest() {

		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		List<VdGroupTransInfoRequestDTO> vdGroupTransInfoRequestDTO = new ArrayList<VdGroupTransInfoRequestDTO>();
		VdGroupTransInfoRequestDTO groupTransInfoRequestDTO = new VdGroupTransInfoRequestDTO();
		groupTransInfoRequestDTO.setGroupTransId(UUID.randomUUID());
		vdGroupTransInfoRequestDTO.add(groupTransInfoRequestDTO);
		List<CoreVdGrpTransInfoModel> coreVdGrpTransInfoModel = new ArrayList<CoreVdGrpTransInfoModel>();
		CoreVdGrpTransInfoModel vdGrpTransInfoModel=new CoreVdGrpTransInfoModel();
		vdGrpTransInfoModel.setUuid(UUID.randomUUID());
		coreVdGrpTransInfoModel.add(vdGrpTransInfoModel);
		when(coreVdGroupsDAO.findById(any())).thenReturn(Optional.of(coreVdGroupsModel));
		when(coreVdGrpTransInfoDAO.findByCoreVdGroups(any())).thenReturn(coreVdGrpTransInfoModel);
		doNothing().when(coreVdGrpTransInfoDAO).deleteByUuidIn(any());
		coreVdTransInfoServiceImpl.deleteVdTransInfo(vdGroupTransInfoRequestDTO, UUID.randomUUID());
		verify(coreVdGrpTransInfoDAO, atLeast(1)).deleteByUuidIn(any());
	}

	@Test
	@DisplayName("deleteVdTransInfoWithExceptionTest method test for any exception")
	void deleteVdTransInfoWithExceptionTest() {
		Assertions.assertThrows(Exception.class, () -> {
			coreVdTransInfoServiceImpl.deleteVdTransInfo(new ArrayList<VdGroupTransInfoRequestDTO>(), null);
		});
	}

}
