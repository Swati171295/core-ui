/**
 * 
 */
package com.prospecta.mdo.module.rest.metadata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.prospecta.mdo.module.component.JWTTokenProvider;
import com.prospecta.mdo.module.dto.metadata.CreateFieldRequestDTO;
import com.prospecta.mdo.module.dto.metadata.CreateFieldResponseDTO;
import com.prospecta.mdo.module.dto.metadata.FieldIdsRequestDTO;
import com.prospecta.mdo.module.dto.metadata.FieldWithDescriptionResponseDTO;
import com.prospecta.mdo.module.dto.metadata.ReferenceRuleRequestDTO;
import com.prospecta.mdo.module.dto.metadata.ReferenceRuleResponseDTO;
import com.prospecta.mdo.module.dto.module.*;
import com.prospecta.mdo.module.model.metadata.elastic.UserFieldMetadata;
import com.prospecta.mdo.module.service.metadata.CoreMetadataService;
import com.prospecta.mdo.module.service.metadata.elastic.CoreMetadataElasticService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * @author savan
 *
 */
@SpringBootTest
@ActiveProfiles("Test")
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
class MetadataRestControllerTest {

	private final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private JWTTokenProvider jWTTokenProvider;
	
	@MockBean
	private CoreMetadataService coreMetadataService;

	@MockBean
	private CoreMetadataElasticService coreMetadataElasticService;
	
	private static final String PAYLOAD = "{\"username\":\"Admin\",\"roles\":[],\"tenantCode\":\"0\"}";
	
	@Test
	@DisplayName("Test case for createFieldTest controller method to create metadata fields.")
	@WithMockUser
	void createFieldTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();
		responseDTO.setAcknowledge(true);
		
		when(coreMetadataService.createField(any(), any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/metadata/fields/{MODULEID}/createField", 1L)
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isCreated());
		
		verify(coreMetadataService).createField(any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for createFieldTest1 controller method to test internal server error.")
	@WithMockUser
	void createFieldTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();
		responseDTO.setAcknowledge(false);
		
		when(coreMetadataService.createField(any(), any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/metadata/fields/{MODULEID}/createField", 1L)
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());
		
		verify(coreMetadataService).createField(any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for updateFieldTest controller method to update metadata fields.")
	@WithMockUser
	void updateFieldTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();
		responseDTO.setAcknowledge(true);
		
		when(coreMetadataService.updateField(any(), any(), any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(put("/metadata/{MODULEID}/update/{FIELDID}", 1L,"FieldId")
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());
		
		verify(coreMetadataService).updateField(any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for updateFieldTest1 controller method to check for exception.")
	@WithMockUser
	void updateFieldTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();
		responseDTO.setAcknowledge(false);
		
		when(coreMetadataService.updateField(any(), any(), any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(put("/metadata/{MODULEID}/update/{FIELDID}", 1L,"FieldId")
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());
		
		verify(coreMetadataService).updateField(any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for removeFieldTest controller method to delete the metadata fields.")
	@WithMockUser
	void removeFieldTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();
		responseDTO.setAcknowledge(true);
		
		when(coreMetadataService.removeField(any(), any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(delete("/metadata/{MODULEID}/remove/{FIELDID}", 1L,"FieldId")
				.header("authorization", "Bearer " + token)).andExpect(status().isOk());
		
		verify(coreMetadataService).removeField(any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for removeFieldTest1 controller method to internal server error.")
	@WithMockUser
	void removeFieldTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();
		responseDTO.setAcknowledge(false);
		
		when(coreMetadataService.removeField(any(), any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(delete("/metadata/{MODULEID}/remove/{FIELDID}", 1L,"FieldId")
				.header("authorization", "Bearer " + token)).andExpect(status().isInternalServerError());
		
		verify(coreMetadataService).removeField(any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for getSearchablefieldswithdescriptionTest controller method to Get Searchable fields with field description.")
	@WithMockUser
	void getSearchablefieldswithdescriptionTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		Map<Object, Object> response = new HashMap<>();
		response.put("String", "String");
		
		when(coreMetadataService.getSearchablefieldswithdescription(any(), any(), any(), any(), any(), any())).thenReturn(response);
		
		this.mockMvc.perform(get("/metadata/fields/getSearchEngineFields/{MODULEID}/{LANGUAGE}", 1L, "en")
		        .header("authorization", "Bearer " + token).param("searchterm", "searchterm")
		        .param("fetchcount", "fetchcount").param("fetchsize", "fetchsize")).andExpect(status().isOk());
		
		verify(coreMetadataService).getSearchablefieldswithdescription(any(), any(), any(), any(), any(), any());
	}
	
	
	@Test
	@DisplayName("Test case for getSearchablefieldswithdescriptionTest1 controller method to check internal server error")
	@WithMockUser
	void getSearchablefieldswithdescriptionTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		
		when(coreMetadataService.getSearchablefieldswithdescription(any(), any(), any(), any(), any(), any())).thenReturn(null);
		
		this.mockMvc.perform(get("/metadata/fields/getSearchEngineFields/{MODULEID}/{LANGUAGE}", 1L, "en")
		        .header("authorization", "Bearer " + token).param("searchterm", "searchterm")
		        .param("fetchcount", "fetchcount").param("fetchsize", "fetchsize")).andExpect(status().isInternalServerError());
		
		verify(coreMetadataService).getSearchablefieldswithdescription(any(), any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for getSearchablefieldswithdescriptionTest2 controller method to check if respons is e,pty")
	@WithMockUser
	void getSearchablefieldswithdescriptionTest2() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		Map<Object, Object> response = new HashMap<>();
		
		when(coreMetadataService.getSearchablefieldswithdescription(any(), any(), any(), any(), any(), any())).thenReturn(response);
		
		this.mockMvc.perform(get("/metadata/fields/getSearchEngineFields/{MODULEID}/{LANGUAGE}", 1L, "en")
		        .header("authorization", "Bearer " + token).param("searchterm", "searchterm")
		        .param("fetchcount", "fetchcount").param("fetchsize", "fetchsize")).andExpect(status().isInternalServerError());
		
		verify(coreMetadataService).getSearchablefieldswithdescription(any(), any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for getMetadataOfFieldsBasedOnFieldIdArrayListTest controller method to Get Metadata of fields based on field Id array list.")
	@WithMockUser
	void getMetadataOfFieldsBasedOnFieldIdArrayListTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		FieldIdsRequestDTO request = new FieldIdsRequestDTO();
		List<String> fieldIds = new ArrayList<>();
		fieldIds.add("fieldId");
		request.setFieldIds(fieldIds);
		
		List<FieldWithDescriptionResponseDTO> response = new ArrayList<>();
		FieldWithDescriptionResponseDTO dto = new FieldWithDescriptionResponseDTO();
		dto.setFieldId("fieldId");
		response.add(dto);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(request);
		
		when(coreMetadataService.getMetadataOfFieldsBasedOnFieldIdArrayList(request,"en","0")).thenReturn(response);
		
		this.mockMvc.perform(post("/metadata/fields/get-fields-by-fields").header("authorization", "Bearer " + token)
		        .param("searchterm", "searchterm").param("fetchcount", "fetchcount").param("LANGUAGE", "en")
		        .contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());
		
		verify(coreMetadataService).getMetadataOfFieldsBasedOnFieldIdArrayList(request,"en","0");
	}
	
	@Test
	@DisplayName("Test case for getMetadataOfFieldsBasedOnFieldIdArrayListTest1 controller method to check internal server error")
	@WithMockUser
	void getMetadataOfFieldsBasedOnFieldIdArrayListTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		FieldIdsRequestDTO request = new FieldIdsRequestDTO();
		List<String> fieldIds = new ArrayList<>();
		fieldIds.add("fieldId");
		request.setFieldIds(fieldIds);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(request);
		
		when(coreMetadataService.getMetadataOfFieldsBasedOnFieldIdArrayList(request,"en","0")).thenReturn(null);
		
		this.mockMvc.perform(post("/metadata/fields/get-fields-by-fields").header("authorization", "Bearer " + token)
		        .param("searchterm", "searchterm").param("fetchcount", "fetchcount").param("LANGUAGE", "en")
		        .contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());
		
		verify(coreMetadataService).getMetadataOfFieldsBasedOnFieldIdArrayList(request,"en","0");
	}
	
	@Test
	@DisplayName("Test case for getFieldDetailsWithFieldIdTest controller method to Get Field Details with Field Id.")
	@WithMockUser
	void getFieldDetailsWithFieldIdTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		FieldDTO response = new FieldDTO();
		response.setFieldId("fieldId");
		
		when(coreMetadataService.getFieldDetailsWithFieldId(1L,"fieldId","0","Admin")).thenReturn(response);
		
		this.mockMvc.perform(get("/metadata/fields/{MODULEID}/getFieldDetails", 1L).header("authorization", "Bearer " + token)
		        .param("fieldid", "fieldId")).andExpect(status().isOk());
		
		verify(coreMetadataService).getFieldDetailsWithFieldId(1L,"fieldId","0","Admin");
	}
	
	@Test
	@DisplayName("Test case for getFieldDetailsWithFieldIdTest1 controller method to chek internal server error")
	@WithMockUser
	void getFieldDetailsWithFieldIdTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		FieldDTO response = new FieldDTO();
		response.setFieldId("fieldId");
		
		when(coreMetadataService.getFieldDetailsWithFieldId(1L,"fieldId","0","Admin")).thenReturn(null);
		
		this.mockMvc.perform(get("/metadata/fields/{MODULEID}/getFieldDetails", 1L).header("authorization", "Bearer " + token)
		        .param("fieldid", "fieldId")).andExpect(status().isInternalServerError());
		
		verify(coreMetadataService).getFieldDetailsWithFieldId(1L,"fieldId","0","Admin");
	}
	@Test
	@DisplayName("Test to check special characters in field id exception")
	void createFieldControllerTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

		List<FieldsRequestDTO> fields = new ArrayList<>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription("test");

		FieldDTO fieldDTO = createFieldDto(moduleDescription,"@te#st&");
		ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription," ");
		ChildFieldsDTO secondChildDto =createChildFieldDTO(moduleDescription," ");

		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(secondChildDto);

		fieldDTO.setChildfields(childList);

		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);

		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);

		fields.add(requestDTO);

		dto.setFields(fields);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);

		CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();
		responseDTO.setAcknowledge(true);

		Set<ConstraintViolation<FieldDTO>> violations = validator.validate(fieldDTO);
		violations.forEach(error-> Assertions.assertEquals(error.getMessage(),"wrong format for field id,no special characters allowed except underscore"));

		Set<ConstraintViolation<ChildFieldsDTO>> childViolations = validator.validate(childDTO);
		Assertions.assertTrue(childViolations.isEmpty());

		this.mockMvc.perform(post("/metadata/fields/{MODULEID}/createField", 1L)
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isBadRequest());

	}
	@Test
	@DisplayName("Test to check draft Field Creation")
	void createDraftFieldControllerTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

		List<FieldsRequestDTO> fields = new ArrayList<>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription("Test Draft");

		FieldDTO fieldDTO = createFieldDto(moduleDescription,"TestingField");
		ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription,"land");


		fieldDTO.setChildfields(new ArrayList<>(){{add(childDTO);}});

		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(new ArrayList<>(){{add(fieldDTO);}});
		UserFieldMetadata userFieldMetadata=new UserFieldMetadata(fieldDTO.getFieldId(),"0",1L,"admin");
		userFieldMetadata.setFieldData(fieldDTO);
		userFieldMetadata.setSearchString("");

		fields.add(requestDTO);
		dto.setFields(fields);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);

		CreateFieldResponseDTO responseDTO = new CreateFieldResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreMetadataElasticService.createDraftField(any(), any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc.perform(put("/metadata/fields/{moduleId}/draftField", 1L)
				.header("Authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isCreated());

	}

	@Test
	@DisplayName("Test case for getDraftField")
	@WithMockUser
	void getDraftField() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		FieldDTO response = new FieldDTO();
		response.setFieldId("fieldId");

		when(coreMetadataElasticService.getDraftField("fieldId", "0", "0",1L)).thenReturn(response);

		this.mockMvc.perform(get("/metadata/fields/{moduleId}/getDraftField", 1L).header("authorization", "Bearer " + token)
				.param("fieldId", "fieldId")).andExpect(status().isOk());

		verify(coreMetadataElasticService,atLeast(1)).getDraftField("fieldId","0","Admin",1L);
	}

	@Test
	@DisplayName("Count Field Test")
	@WithMockUser
	void countFieldTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		Map<String,Long> map = new HashMap<>(){{put("count",1L);}};

		when(coreMetadataService.fieldCount(any(),any())).thenReturn(map);

		this.mockMvc.perform(
				get("/metadata/1/count")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());

		verify(coreMetadataService, atLeast(1)).fieldCount(any(),any());
	}

	@Test
	@DisplayName("Test case for searchableFieldsWithDescriptionTest controller method to Search fields with field description.")
	@WithMockUser
	void searchFieldsWithDescriptionTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<FieldWithDescriptionResponseDTO> list = new ArrayList<>();
		FieldWithDescriptionResponseDTO responseDTO =new FieldWithDescriptionResponseDTO();
		responseDTO.setFieldId("field");
		list.add(responseDTO);

		when(coreMetadataService.searchByDesc(any(), any(), any(), any(), any(), any())).thenReturn(list);

		this.mockMvc.perform(get("/metadata/list-by-description/{moduleId}/{lanuage}", 1L, "en")
				.header("authorization", "Bearer " + token).param("searchTerm", "searchterm")
				.param("fetchCount", "0").param("fetchSize", "1")).andExpect(status().isOk());

		verify(coreMetadataService,atLeast(1)).searchByDesc(any(), any(), any(), any(), any(), any());
	}

	@Test
	@DisplayName("Test case for delete draft field")
	@WithMockUser
	void deleteDraft() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		this.mockMvc.perform(delete("/metadata/{moduleId}/draftField/delete", 1L)
				.header("authorization", "Bearer " + token).param("fieldId", "searchterm")
				).andExpect(status().isOk());

	}

	@Test
	@DisplayName("Test case for delete Bulk draft field")
	@WithMockUser
	void deleteBulkDraft() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		FieldIdsRequestDTO requestDTO = new FieldIdsRequestDTO();
		requestDTO.setFieldIds(new ArrayList<>(){{add("field");}});

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(requestDTO);

		this.mockMvc.perform(delete("/metadata/{moduleId}/draftField/bulk/delete", 1L)
				.header("authorization", "Bearer " + token).contentType(MediaType.APPLICATION_JSON).content(requestJson)
		).andExpect(status().isOk());

	}

	@Test
	@DisplayName("Get Key field Test")
	@WithMockUser
	void getKeyfields() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		ModuleResponseDTO responseDTO = new ModuleResponseDTO();
		when(coreMetadataService.getkeyFields(Short.parseShort("1"),"0", "Admin",1L,"",1,1)).thenReturn(new ArrayList<>());

		this.mockMvc.perform(get("/metadata/{moduleId}/get-key-fields/{structId}", 1L,"1")
				.param("searchTerm","")
				.param("fetchCount","1")
				.param("fetchSize","1")
				.header("authorization", "Bearer " + token)).andExpect(status().isOk());

		verify(coreMetadataService).getkeyFields(Short.parseShort("1"),"0", "Admin",1L,"",1,1);
	}

	private FieldDTO createFieldDto(Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription,String fieldId){

		FieldDTO fieldDTO = new FieldDTO();
		Map<String, String>longText =createMap();
		Map<String, String> helpText =createMap();
		fieldDTO.setFieldId(fieldId);
		fieldDTO.setShortText(moduleDescription);
		fieldDTO.setLongtexts(longText);
		fieldDTO.setHelptexts(helpText);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		return fieldDTO;
	}

	private ChildFieldsDTO createChildFieldDTO(Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription,String fieldId){

		ChildFieldsDTO childDTO = new ChildFieldsDTO();
		Map<String, String>longText =createMap();
		Map<String, String> helpText =createMap();
		childDTO.setFieldId(fieldId);
		childDTO.setShortText(moduleDescription);
		childDTO.setLongtexts(longText);
		childDTO.setHelptexts(helpText);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		return childDTO;
	}

	private Map<String, ModuleDescriptionInformationRequestDTO> createModuleDescription(String description) {

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription(description);
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);
		return  moduledescription;
	}

	private Map<String,String> createMap() {
		Map<String, String> text = new HashMap<>();
		text.put("en", "Material");
		text.put("fr", "matériel");
		text.put("sp", "tipo de material");
		text.put("gj", "tipo de material");
		return text;
	}
	
	@Test
	@DisplayName("Test case for saveReferenceRule controller method to create reference rule.")
	@WithMockUser
	void saveReferenceRuleTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		ReferenceRuleRequestDTO dto = new ReferenceRuleRequestDTO();
		
		dto.setFieldId("any");
		dto.setModuleId(1L);	
		Short orderData = 1;
		dto.setOrderData(orderData);
		dto.setReferencedFieldId("any");
		dto.setReferencedModuleId(1L);	
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		ReferenceRuleResponseDTO responseDTO = new ReferenceRuleResponseDTO();
		responseDTO.setAcknowledge(true);
		
		when(coreMetadataService.createReferenceRule(any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/metadata/save-reference-rule/{dataReferencefieldId}", "any")
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isCreated());
		
		verify(coreMetadataService).createReferenceRule(any(), any());
	}
	
	@Test
	@DisplayName("Test case for saveReferenceRule controller method to create reference rule.")
	@WithMockUser
	void saveReferenceRuleTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		ReferenceRuleRequestDTO dto = new ReferenceRuleRequestDTO();
		
		dto.setFieldId("any");
		dto.setModuleId(1L);	
		Short orderData = 1;
		dto.setOrderData(orderData);
		dto.setReferencedFieldId("any");
		dto.setReferencedModuleId(1L);	
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		ReferenceRuleResponseDTO responseDTO = new ReferenceRuleResponseDTO();
		responseDTO.setAcknowledge(false);
		
		when(coreMetadataService.createReferenceRule(any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/metadata/save-reference-rule/{dataReferencefieldId}", "any")
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());
		
		verify(coreMetadataService).createReferenceRule(any(), any());
	}
	
	@Test
	@DisplayName("Test case for updateReferenceRule controller method to create reference rule.")
	@WithMockUser
	void updateReferenceRuleTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		ReferenceRuleRequestDTO dto = new ReferenceRuleRequestDTO();
		
		dto.setFieldId("any");
		dto.setModuleId(1L);	
		Short orderData = 1;
		dto.setOrderData(orderData);
		dto.setReferencedFieldId("any");
		dto.setReferencedModuleId(1L);	
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		ReferenceRuleResponseDTO responseDTO = new ReferenceRuleResponseDTO();
		responseDTO.setAcknowledge(true);
		
		when(coreMetadataService.updateReferenceRule(any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(put("/metadata/update-reference-rule/{referencedUuid}", "any")
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());
		
		verify(coreMetadataService).updateReferenceRule(any(), any());
	}
	
	@Test
	@DisplayName("Test case for updateReferenceRule controller method to create reference rule.")
	@WithMockUser
	void updateReferenceRuleTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		ReferenceRuleRequestDTO dto = new ReferenceRuleRequestDTO();
		
		dto.setFieldId("any");
		dto.setModuleId(1L);	
		Short orderData = 1;
		dto.setOrderData(orderData);
		dto.setReferencedFieldId("any");
		dto.setReferencedModuleId(1L);	
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		ReferenceRuleResponseDTO responseDTO = new ReferenceRuleResponseDTO();
		responseDTO.setAcknowledge(false);
		
		when(coreMetadataService.updateReferenceRule(any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(put("/metadata/update-reference-rule/{referencedUuid}", "any")
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());
		
		verify(coreMetadataService).updateReferenceRule(any(), any());
	}
}
