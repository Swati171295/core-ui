package com.prospecta.mdo.module.component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.JWSVerifier;
import com.prospecta.mdo.module.dto.JWTToken;
import com.prospecta.mdo.module.exception.JWTExpiredException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ActiveProfiles;

import java.text.ParseException;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ActiveProfiles("Test")
class JWTTokenProviderTest {
	
	@InjectMocks
	JWTTokenProvider tokenProvider;

	@Autowired
	JWTTokenProvider jwtTokenProvider;
	
	@Mock
	private JWSSigner reqSigner;
	
	@Mock
	private JWSVerifier reqVerifier;
	
	@Test
	void createTokenTest() throws JOSEException {
		String payLoad = getJWTTokenPayload();
		String createToken = jwtTokenProvider.createToken(payLoad);
		
		assertNotNull(createToken);
	}
	
	@Test
	void getPayloadTest() throws JOSEException, ParseException, JWTExpiredException {
		String expectedPayLoad = getJWTTokenPayload();

		String token = jwtTokenProvider.createToken(expectedPayLoad);
		
		String actualyPayLoad = jwtTokenProvider.getPayload(token);
		
		assertNotNull(actualyPayLoad);
	}
	
	@Test
	void resolveTokenTest() throws Exception {
		String header = "Bearer ";
		String payLoad = getJWTTokenPayload();
		String createToken = jwtTokenProvider.createToken(payLoad);

		header = header + createToken;
		JWTToken actualToken = jwtTokenProvider.resolveToken(header);
		assertNotNull(actualToken);
	}

	@Test
	void resolveTokenTest1() throws Exception {
		String payLoad = getJWTTokenPayload();
		String createToken = jwtTokenProvider.createToken(payLoad);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "Bearer " + createToken);

		String actualToken = jwtTokenProvider.resolveToken(request);
		assertNotNull(actualToken);
	}

	@Test
	void resolveTokenTest2() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();

		String actualToken = jwtTokenProvider.resolveToken(request);
		assertNull(actualToken);
	}
	
	@Test
	void resolveTokenTest3() throws Exception {
		String payLoad = getJWTTokenPayload();
		String createToken = jwtTokenProvider.createToken(payLoad);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "er" + createToken);

		String actualToken = jwtTokenProvider.resolveToken(request);
		assertNull(actualToken);
	}
	

	private String getJWTTokenPayload() {
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode node = mapper.createObjectNode();

		node.put("username", "guest");
		node.set("roles", mapper.createArrayNode().add("USER"));
		node.put("tenantCode", "0");

		return node.toString();
	}

}
