package com.prospecta.mdo.module.grpc;

import com.prospecta.mdo.module.dto.metadata.CreateFieldRequestDTO;
import demo.interfaces.grpc.*;
import io.grpc.ManagedChannel;
import io.grpc.inprocess.InProcessChannelBuilder;
import io.grpc.inprocess.InProcessServerBuilder;
import io.grpc.stub.StreamObserver;
import io.grpc.testing.GrpcCleanupRule;
import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.AdditionalAnswers.delegatesTo;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class DynamicGenerationImplTest {

    @Rule
    public final GrpcCleanupRule grpcCleanup = new GrpcCleanupRule();

    private final DynamicGenerationServiceGrpc.DynamicGenerationServiceImplBase serviceImpl =
            mock(DynamicGenerationServiceGrpc.DynamicGenerationServiceImplBase.class, delegatesTo(
                    new DynamicGenerationServiceGrpc.DynamicGenerationServiceImplBase() {
                        @Override
                        public void generateDynamicTable(DynamicTableGenerateRequest request,
                                                         StreamObserver<DynamicTableGenerateResponse> response) {
                            DynamicTableGenerateResponse responseDTO = DynamicTableGenerateResponse.newBuilder().setResponse(true)
                                    .build();
                            response.onNext(responseDTO);
                            response.onCompleted();
                        }

                        @Override
                        public void alterColumns(DynamicTableGenerateRequest request,
                                                 StreamObserver<DynamicTableGenerateResponse> response) {
                            DynamicTableGenerateResponse responseDTO = DynamicTableGenerateResponse.newBuilder().setResponse(true)
                                    .build();
                            response.onNext(responseDTO);
                            response.onCompleted();
                        }

                        @Override
                        public void generateDynamicIndex(DynamicTableGenerateRequest request,
                                                         StreamObserver<DynamicTableGenerateResponse> response) {
                            DynamicTableGenerateResponse responseDTO = DynamicTableGenerateResponse.newBuilder().setResponse(true)
                                    .build();
                            response.onNext(responseDTO);
                            response.onCompleted();
                        }

                        @Override
                        public void deleteTable(DynamicTableDeletionRequest request,
                                                StreamObserver<DynamicTableGenerateResponse> response) {
                            DynamicTableGenerateResponse responseDTO = DynamicTableGenerateResponse.newBuilder().setResponse(true)
                                    .build();
                            response.onNext(responseDTO);
                            response.onCompleted();
                        }

                        @Override
                        public void deleteIndex(DynamicTableDeletionRequest request,
                                                StreamObserver<DynamicTableGenerateResponse> response) {
                            DynamicTableGenerateResponse responseDTO = DynamicTableGenerateResponse.newBuilder().setResponse(true)
                                    .build();
                            response.onNext(responseDTO);
                            response.onCompleted();
                        }

                        @Override
                        public void deleteColumn(DeleteColumnRequest request,
                                                 StreamObserver<DynamicTableGenerateResponse> response) {
                            DynamicTableGenerateResponse responseDTO = DynamicTableGenerateResponse.newBuilder().setResponse(true)
                                    .build();
                            response.onNext(responseDTO);
                            response.onCompleted();
                        }
                    }));


    ManagedChannel channel;
    private DynamicCrudGenerationImpl impl;

    @BeforeAll
    public void setUp() throws Exception {
        // Generate a unique in-process server name.
        String serverName = InProcessServerBuilder.generateName();

        // Create a server, add service, start, and register for automatic graceful shutdown.
        grpcCleanup.register(InProcessServerBuilder
                .forName(serverName).directExecutor().addService(serviceImpl).build().start());

        // Create a client channel and register for automatic graceful shutdown.
        channel = grpcCleanup.register(
                InProcessChannelBuilder.forName(serverName).directExecutor().build());

        // Create a Client using the in-process channel;
        impl = new DynamicCrudGenerationImpl();
        impl.setChannel(channel);
    }

    @Test
    void generateDynamicTables() {

        CreateFieldRequestDTO dto = new CreateFieldRequestDTO();


        impl.generateDynamicTables(1L, "0", dto);
        ArgumentCaptor<DynamicTableGenerateRequest> requestCaptor = ArgumentCaptor.forClass(DynamicTableGenerateRequest.class);

        verify(serviceImpl).generateDynamicTable(requestCaptor.capture(), ArgumentMatchers.any());
        assertEquals("1", requestCaptor.getValue().getModuleId());

    }

    @Test
    void alterColumns() {

        CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
        ArgumentCaptor<DynamicTableGenerateRequest> requestCaptor = ArgumentCaptor.forClass(DynamicTableGenerateRequest.class);
        Assertions.assertTrue(impl.alterColumns(1L, "0", dto));
        verify(serviceImpl).alterColumns(requestCaptor.capture(), ArgumentMatchers.any());


    }

    @Test
    void createUpdateDynamicIndex() {

        CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
        ArgumentCaptor<DynamicTableGenerateRequest> requestCaptor = ArgumentCaptor.forClass(DynamicTableGenerateRequest.class);
        Assertions.assertTrue(impl.createUpdateDynamicIndex(1L, "0", dto));
        verify(serviceImpl).generateDynamicIndex(requestCaptor.capture(), ArgumentMatchers.any());
    }

    @Test
    void deleteTable() {

        ArgumentCaptor<DynamicTableDeletionRequest> requestCaptor = ArgumentCaptor.forClass(DynamicTableDeletionRequest.class);
        Assertions.assertTrue(impl.deleteTable(new ArrayList<>() {{
            add("1");
        }}, new ArrayList<>() {{
            add("field");
        }}, 1L, "0"));
        verify(serviceImpl).deleteTable(requestCaptor.capture(), ArgumentMatchers.any());
    }

    @Test
    void deleteIndex() {

        ArgumentCaptor<DynamicTableDeletionRequest> requestCaptor = ArgumentCaptor.forClass(DynamicTableDeletionRequest.class);
        Assertions.assertTrue(impl.deleteIndex(new ArrayList<>() {{
            add("1");
        }}, new ArrayList<>() {{
            add("field");
        }}, 1L, "0"));
        verify(serviceImpl).deleteIndex(requestCaptor.capture(), ArgumentMatchers.any());
    }

    @Test
    void deleteColumn() {

        ArgumentCaptor<DeleteColumnRequest> requestCaptor = ArgumentCaptor.forClass(DeleteColumnRequest.class);
        Assertions.assertTrue(impl.deleteColumn(new ArrayList<>() {{
            add("1");
        }}, new ArrayList<>() {{
            add("field");
        }}, 1L, "0", "key"));
        verify(serviceImpl).deleteColumn(requestCaptor.capture(), ArgumentMatchers.any());
    }
}