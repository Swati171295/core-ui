package com.prospecta.mdo.module.validator;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import javax.validation.ConstraintValidatorContext;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dto.virtualdata.VdTransRuleConcatRequestDTO;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class ValidatorFieldValueTest {
	
	@Mock
	private ValidateFieldValue validateFieldValue;
	
	 @Mock
	 private ConstraintValidatorContext constraintValidatorContext;
	 
	 @Test
	 @DisplayName("isValidTest method test for custom validation exception")
	 void isValidTest() {
		 when(validateFieldValue.fieldName()).thenReturn("fieldType");
		 when(validateFieldValue.fieldValue()).thenReturn("USERINPUT");
		 when(validateFieldValue.dependFieldName()).thenReturn("fieldValue");
		 when(validateFieldValue.message()).thenReturn("Please provide valid field value.");
		 ValidatorFieldValue validatorFieldValue = new ValidatorFieldValue();
		 validatorFieldValue.initialize(validateFieldValue);
		 VdTransRuleConcatRequestDTO vdTransRuleConcatRequestDTO = new VdTransRuleConcatRequestDTO();
		 vdTransRuleConcatRequestDTO.setFieldName("test");
		 vdTransRuleConcatRequestDTO.setFieldType("USERINPUT");
		 vdTransRuleConcatRequestDTO.setFieldValue("abc @abc");
		 boolean result = validatorFieldValue.isValid(vdTransRuleConcatRequestDTO, constraintValidatorContext);
		 assertFalse(result);
	 }
	 
	 @Test
	 @DisplayName("isValidNullTest method test for custom validation exception")
	 void isValidNullTest() {
		 ValidatorFieldValue validatorFieldValue = new ValidatorFieldValue();
		 validatorFieldValue.initialize(validateFieldValue);
		 boolean result = validatorFieldValue.isValid(null, constraintValidatorContext);
		 assertTrue(result);
	 }

}
