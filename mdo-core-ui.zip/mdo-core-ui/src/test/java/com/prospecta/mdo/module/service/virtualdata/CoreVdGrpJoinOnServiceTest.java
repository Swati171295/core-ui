package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpJoinOnDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinOnRequestDTO;
import com.prospecta.mdo.module.enums.CompareOperator;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinOnModel;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class CoreVdGrpJoinOnServiceTest {
	
	@InjectMocks
	private CoreVdGrpJoinOnServiceImpl coreVdGrpJoinOnServiceImpl;
	
	@Mock
	private CoreVdGrpJoinOnDAO coreVdGrpJoinOnDAO;
	
	@Mock
	private CoreVdGroupsDAO coreVdGroupsDAO;
	
	@BeforeAll
	void init() {
		coreVdGrpJoinOnServiceImpl = new CoreVdGrpJoinOnServiceImpl();
	}
	
	@Test
	@DisplayName("getVdGroupJoinOnbyGrpJoinIdTest method test for getting virtual dataset join on by GrpJoinId")
	void getVdGroupJoinOnbyGrpJoinIdTest() {
		CoreVdGrpJoinOnModel coreVdGrpJoinOnModel = spy(CoreVdGrpJoinOnModel.class);
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinOnDAO.findById(id)).thenReturn(Optional.of(coreVdGrpJoinOnModel));
		coreVdGrpJoinOnModel = coreVdGrpJoinOnServiceImpl.getVdGroupJoinOnbyGrpJoinId(id);
		verify(coreVdGrpJoinOnDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdGroupJoinOnbyGrpJoinIdExceptionTest method test for exception")
	void getVdGroupJoinOnbyGrpJoinIdExceptionTest() {
		CoreVdGrpJoinOnModel coreVdGrpJoinOnModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinOnDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGrpJoinOnModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinOnServiceImpl.getVdGroupJoinOnbyGrpJoinId(id));
		verify(coreVdGrpJoinOnDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdGroupJoinOnbygroupInfoIdTest method test for getting virtual dataset join on by groupInfoId")
	void getVdGroupJoinOnbygroupInfoIdTest() {
		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		CoreVdGrpJoinOnModel coreVdGrpJoinOnModel = spy(CoreVdGrpJoinOnModel.class);
		coreVdGrpJoinOnModel.setCoreVdGroups(coreVdGroupsModel);
		List<CoreVdGrpJoinOnModel> coreVdGrpJoinOnModelList = new ArrayList<>();
		coreVdGrpJoinOnModelList.add(coreVdGrpJoinOnModel);
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinOnDAO.findByCoreVdGroups(coreVdGroupsModel)).thenReturn(coreVdGrpJoinOnModelList);
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		List<CoreVdGrpJoinOnModel> coreVdGrpJoinOnList = coreVdGrpJoinOnServiceImpl.getVdGroupJoinOnbygroupInfoId(id);
		assertNotNull(coreVdGrpJoinOnList);
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		verify(coreVdGrpJoinOnDAO, atLeast(1)).findByCoreVdGroups(any());
	}
	
	@Test
	@DisplayName("getVdGroupJoinOnbygroupInfoIdExceptionTest method test for test exception")
	void getVdGroupJoinOnbygroupInfoIdExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinOnServiceImpl.getVdGroupJoinOnbygroupInfoId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdGroupJoinOnbygroupInfoIdListExceptionTest method test for test exception")
	void getVdGroupJoinOnbygroupInfoIdListExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		List<CoreVdGrpJoinOnModel> coreVdGrpJoinOnModelList = new ArrayList<>();
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinOnDAO.findByCoreVdGroups(coreVdGroupsModel)).thenReturn(coreVdGrpJoinOnModelList);
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinOnServiceImpl.getVdGroupJoinOnbygroupInfoId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		verify(coreVdGrpJoinOnDAO, atLeast(1)).findByCoreVdGroups(any());
	}
	
	@Test
	@DisplayName("deleteVdGroupJoinOnbyGrpJoinIdTest method test for deleting virtual dataset join on by GrpJoinId")
	void deleteVdGroupJoinOnbyGrpJoinIdTest() {
		UUID id = UUID.randomUUID();
		doNothing().when(coreVdGrpJoinOnDAO).deleteById(id);
		coreVdGrpJoinOnServiceImpl.deleteVdGroupJoinOnbyGrpJoinId(id);
		verify(coreVdGrpJoinOnDAO, atLeast(1)).deleteById(any());
	}
	
	@Test
	@DisplayName("deleteVdGroupJoinOnbygroupInfoIdTest method test for deleting virtual dataset join on by groupInfoId")
	void deleteVdGroupJoinOnbygroupInfoIdTest() {
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		doNothing().when(coreVdGrpJoinOnDAO).deleteByCoreVdGroups(coreVdGroupsModel);
		coreVdGrpJoinOnServiceImpl.deleteVdGroupJoinOnbygroupInfoId(id);
		verify(coreVdGrpJoinOnDAO, atLeast(1)).deleteByCoreVdGroups(any());
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("deleteVdGroupJoinOnbygroupInfoIdExceptionTest method test for test exception")
	void deleteVdGroupJoinOnbygroupInfoIdExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel= null;
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinOnServiceImpl.deleteVdGroupJoinOnbygroupInfoId(id));		
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("saveAndUpdateJoinOnTest method test for updating virtual dataset join on")
	void saveAndUpdateJoinOnTest() {
		VdGroupJoinOnRequestDTO groupJoinOnRequestDTO = new VdGroupJoinOnRequestDTO();
		groupJoinOnRequestDTO.setSourceField("SourceField");
		groupJoinOnRequestDTO.setSourceFieldId("Sourcetablefield");
		groupJoinOnRequestDTO.setTargetField("Targettablename");
		groupJoinOnRequestDTO.setTargetFieldId("Targettablefield");
		groupJoinOnRequestDTO.setCondition("Equals");
		
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		CoreVdGrpJoinOnModel coreVdGrpJoinOnModel = new CoreVdGrpJoinOnModel();
		copyProperties(groupJoinOnRequestDTO, coreVdGrpJoinOnModel);
		coreVdGrpJoinOnModel.setJoinOnId(any());
		coreVdGrpJoinOnModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdGrpJoinOnModel.setSourceOne(groupJoinOnRequestDTO.getSourceField());
		coreVdGrpJoinOnModel.setSourceOneFieldId(groupJoinOnRequestDTO.getSourceFieldId());
		coreVdGrpJoinOnModel.setSourceTwo(groupJoinOnRequestDTO.getTargetField());
		coreVdGrpJoinOnModel.setSourceTwoFieldId(groupJoinOnRequestDTO.getTargetFieldId());
		coreVdGrpJoinOnModel
				.setCompareOperator(CompareOperator.fromValue(groupJoinOnRequestDTO.getCondition().toUpperCase()));

		when(coreVdGrpJoinOnDAO.save(coreVdGrpJoinOnModel)).thenReturn(coreVdGrpJoinOnModel);
		coreVdGrpJoinOnServiceImpl.saveAndUpdateJoinOn(groupJoinOnRequestDTO, coreVdGroupsModel);
		verify(coreVdGrpJoinOnDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("saveAndUpdateJoinOnWithJoinIdNotNullTest method test for updating virtual dataset join on")
	void saveAndUpdateJoinOnWithJoinIdNotNullTest() {
		VdGroupJoinOnRequestDTO groupJoinOnRequestDTO = new VdGroupJoinOnRequestDTO();
		groupJoinOnRequestDTO.setSourceField("SourceField");
		groupJoinOnRequestDTO.setSourceFieldId("Sourcetablefield");
		groupJoinOnRequestDTO.setTargetField("Targettablename");
		groupJoinOnRequestDTO.setTargetFieldId("Targettablefield");
		groupJoinOnRequestDTO.setCondition("Equals");
		groupJoinOnRequestDTO.setJoinColumnId(UUID.randomUUID());
		
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		CoreVdGrpJoinOnModel coreVdGrpJoinOnModel = new CoreVdGrpJoinOnModel();
		copyProperties(groupJoinOnRequestDTO, coreVdGrpJoinOnModel);
		coreVdGrpJoinOnModel.setJoinOnId(groupJoinOnRequestDTO.getJoinColumnId());
		coreVdGrpJoinOnModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdGrpJoinOnModel.setSourceOne(groupJoinOnRequestDTO.getSourceField());
		coreVdGrpJoinOnModel.setSourceOneFieldId(groupJoinOnRequestDTO.getSourceFieldId());
		coreVdGrpJoinOnModel.setSourceTwo(groupJoinOnRequestDTO.getTargetField());
		coreVdGrpJoinOnModel.setSourceTwoFieldId(groupJoinOnRequestDTO.getTargetFieldId());
		coreVdGrpJoinOnModel
				.setCompareOperator(CompareOperator.fromValue(groupJoinOnRequestDTO.getCondition().toUpperCase()));

		when(coreVdGrpJoinOnDAO.save(coreVdGrpJoinOnModel)).thenReturn(coreVdGrpJoinOnModel);
		coreVdGrpJoinOnServiceImpl.saveAndUpdateJoinOn(groupJoinOnRequestDTO, coreVdGroupsModel);
		verify(coreVdGrpJoinOnDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("saveAndUpdateJoinOnWithCatchTest method test for updating virtual dataset join on")
	void saveAndUpdateJoinOnWithCatchTest() {
		VdGroupJoinOnRequestDTO groupJoinOnRequestDTO = new VdGroupJoinOnRequestDTO();
		groupJoinOnRequestDTO.setSourceField("SourceField");
		groupJoinOnRequestDTO.setSourceFieldId("Sourcetablefield");
		groupJoinOnRequestDTO.setTargetField("Targettablename");
		groupJoinOnRequestDTO.setTargetFieldId("Targettablefield");
		groupJoinOnRequestDTO.setCondition("Equals");
		groupJoinOnRequestDTO.setJoinColumnId(UUID.randomUUID());
		
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		CoreVdGrpJoinOnModel coreVdGrpJoinOnModel = new CoreVdGrpJoinOnModel();
		copyProperties(groupJoinOnRequestDTO, coreVdGrpJoinOnModel);
		coreVdGrpJoinOnModel.setJoinOnId(groupJoinOnRequestDTO.getJoinColumnId());
		coreVdGrpJoinOnModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdGrpJoinOnModel.setSourceOne(groupJoinOnRequestDTO.getSourceField());
		coreVdGrpJoinOnModel.setSourceOneFieldId(groupJoinOnRequestDTO.getSourceFieldId());
		coreVdGrpJoinOnModel.setSourceTwo(groupJoinOnRequestDTO.getTargetField());
		coreVdGrpJoinOnModel.setSourceTwoFieldId(groupJoinOnRequestDTO.getTargetFieldId());
		coreVdGrpJoinOnModel
				.setCompareOperator(CompareOperator.fromValue(groupJoinOnRequestDTO.getCondition().toUpperCase()));

		when(coreVdGrpJoinOnDAO.save(coreVdGrpJoinOnModel)).thenThrow(new RuntimeException());
		assertThrows(RuntimeException.class, ()->coreVdGrpJoinOnServiceImpl.saveAndUpdateJoinOn(groupJoinOnRequestDTO, coreVdGroupsModel));
	}
	
	@Test
	@DisplayName("saveAndUpdateJoinOnWithRequestDtoNullTest method test for updating virtual dataset join on")
	void saveAndUpdateJoinOnWithRequestDtoNullTest() {
		VdGroupJoinOnRequestDTO groupJoinOnRequestDTO = null;
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		assertThrows(NotFound404Exception.class, ()->coreVdGrpJoinOnServiceImpl.saveAndUpdateJoinOn(groupJoinOnRequestDTO, coreVdGroupsModel));
	}
	
	@Test
	@DisplayName("saveAndUpdateJoinOnWithRequestModelNullTest method test for updating virtual dataset join on")
	void saveAndUpdateJoinOnWithRequestModelNullTest() {
		VdGroupJoinOnRequestDTO groupJoinOnRequestDTO = new VdGroupJoinOnRequestDTO();
		CoreVdGroupsModel coreVdGroupsModel = null;
		assertThrows(NotFound404Exception.class, ()->coreVdGrpJoinOnServiceImpl.saveAndUpdateJoinOn(groupJoinOnRequestDTO, coreVdGroupsModel));
	}
	
	@Test
	@DisplayName("deleteVdGrpJoinOnTest method test for deleting virtual dataset groups")
	void deleteVdGrpJoinOnTest() {
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();			
		List<VdGroupJoinOnRequestDTO> vdGroupJoinOnRequestDTO = new ArrayList<VdGroupJoinOnRequestDTO>();
		VdGroupJoinOnRequestDTO groupJoinOnRequestDTO = new VdGroupJoinOnRequestDTO();
		groupJoinOnRequestDTO.setJoinColumnId(UUID.randomUUID());
		vdGroupJoinOnRequestDTO.add(groupJoinOnRequestDTO);
		List<CoreVdGrpJoinOnModel> coreVdGrpJoinOnModel = new ArrayList<CoreVdGrpJoinOnModel>();
		CoreVdGrpJoinOnModel vdGrpJoinOnModel= new CoreVdGrpJoinOnModel();
		vdGrpJoinOnModel.setJoinOnId(UUID.randomUUID());
		coreVdGrpJoinOnModel.add(vdGrpJoinOnModel);
		when(coreVdGroupsDAO.findById(any())).thenReturn(Optional.of(coreVdGroupsModel));
		when(coreVdGrpJoinOnDAO.findByCoreVdGroups(any())).thenReturn(coreVdGrpJoinOnModel);
		coreVdGrpJoinOnServiceImpl.deleteVdGrpJoinOn(vdGroupJoinOnRequestDTO,UUID.randomUUID() );
		verify(coreVdGrpJoinOnDAO, atLeast(1)).deleteByJoinOnIdIn(any());
	}
	
	@Test
	@DisplayName("deleteVdGrpJoinOnWithCatchTest method test for deleting virtual dataset groups")
	void deleteVdGrpJoinOnWithCatchTest() {		
		List<VdGroupJoinOnRequestDTO> vdGroupJoinOnRequestDTO = new ArrayList<VdGroupJoinOnRequestDTO>();
		assertThrows(Exception.class, ()->coreVdGrpJoinOnServiceImpl.deleteVdGrpJoinOn(vdGroupJoinOnRequestDTO,UUID.randomUUID()));
	}
}
