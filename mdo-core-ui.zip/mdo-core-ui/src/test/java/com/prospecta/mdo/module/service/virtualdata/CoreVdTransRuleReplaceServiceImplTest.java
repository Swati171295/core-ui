package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdTransFieldSettingDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdTransRuleReplaceDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdTransRuleReplaceRequestDTO;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransRuleReplaceModel;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class CoreVdTransRuleReplaceServiceImplTest {
	
	@InjectMocks
	private CoreVdTransRuleReplaceServiceImpl coreVdTransRuleReplaceServiceImpl;
	
	@Mock
	private CoreVdTransRuleReplaceDAO coreVdTransRuleReplaceDAO;
	
	@Mock
	private CoreVdTransFieldSettingDAO coreVdTransFieldSettingDAO;
	
	@BeforeAll
	void init() {
		coreVdTransRuleReplaceServiceImpl = new CoreVdTransRuleReplaceServiceImpl();
	}
	
	@Test
	@DisplayName("getVdTransRuleReplacebyreplaceIdTest method test for get rule replace")
	void getVdTransRuleReplacebyreplaceIdTest() {
		CoreVdTransRuleReplaceModel coreVdTransRuleReplaceModel = spy(CoreVdTransRuleReplaceModel.class);
		UUID id = UUID.randomUUID();
		when(coreVdTransRuleReplaceDAO.findById(id)).thenReturn(Optional.of(coreVdTransRuleReplaceModel));
		coreVdTransRuleReplaceModel = coreVdTransRuleReplaceServiceImpl.getVdTransRuleReplacebyreplaceId(id);
		verify(coreVdTransRuleReplaceDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdTransRuleReplacebyreplaceIdExceptionTest method test for test exception")
	void getVdTransRuleReplacebyreplaceIdExceptionTest() {
		CoreVdTransRuleReplaceModel coreVdTransRuleReplaceModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdTransRuleReplaceDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdTransRuleReplaceModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransRuleReplaceServiceImpl.getVdTransRuleReplacebyreplaceId(id));
		verify(coreVdTransRuleReplaceDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdTransRuleReplacebytransFieldIdTest method test for get rule replace by trans field id")
	void getVdTransRuleReplacebytransFieldIdTest() {
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = spy(CoreVdTransFieldSettingModel.class);
		CoreVdTransRuleReplaceModel coreVdTransRuleReplaceModel = spy(CoreVdTransRuleReplaceModel.class);
		coreVdTransRuleReplaceModel.setCoreVdTransFieldSetting(coreVdTransFieldSettingModel);
		List<CoreVdTransRuleReplaceModel> coreVdTransRuleReplaceModelList = new ArrayList<>();
		coreVdTransRuleReplaceModelList.add(coreVdTransRuleReplaceModel);
		UUID id = UUID.randomUUID();
		when(coreVdTransRuleReplaceDAO.findByCoreVdTransFieldSetting(coreVdTransFieldSettingModel)).thenReturn(coreVdTransRuleReplaceModelList);
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.of(coreVdTransFieldSettingModel));
		List<CoreVdTransRuleReplaceModel> coreVdTransRuleReplaceList = coreVdTransRuleReplaceServiceImpl.getVdTransRuleReplacebytransFieldId(id);
		assertNotNull(coreVdTransRuleReplaceList);
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
		verify(coreVdTransRuleReplaceDAO, atLeast(1)).findByCoreVdTransFieldSetting(any());
	}
	
	@Test
	@DisplayName("getVdTransRuleReplacebytransFieldIdExceptionTest method test for test exception")
	void getVdTransRuleReplacebytransFieldIdExceptionTest() {
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdTransFieldSettingModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransRuleReplaceServiceImpl.getVdTransRuleReplacebytransFieldId(id));
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdTransRuleReplacebytransFieldIdTest method test for test exception")
	void getVdTransRuleReplacebytransFieldIdListExceptionTest() {
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = spy(CoreVdTransFieldSettingModel.class);
		List<CoreVdTransRuleReplaceModel> coreVdTransRuleReplaceModelList = new ArrayList<>();
		UUID id = UUID.randomUUID();
		when(coreVdTransRuleReplaceDAO.findByCoreVdTransFieldSetting(coreVdTransFieldSettingModel)).thenReturn(coreVdTransRuleReplaceModelList);
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.of(coreVdTransFieldSettingModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransRuleReplaceServiceImpl.getVdTransRuleReplacebytransFieldId(id));
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
		verify(coreVdTransRuleReplaceDAO, atLeast(1)).findByCoreVdTransFieldSetting(any());
	}
	
	@Test
	@DisplayName("deleteVdTransRuleReplacebyreplaceIdTest method test for rule replace")
	void deleteVdTransRuleReplacebyreplaceIdTest() {
		UUID id = UUID.randomUUID();
		doNothing().when(coreVdTransRuleReplaceDAO).deleteById(id);
		coreVdTransRuleReplaceServiceImpl.deleteVdTransRuleReplacebyreplaceId(id);
		verify(coreVdTransRuleReplaceDAO, atLeast(1)).deleteById(any());
	}
	
	@Test
	@DisplayName("deleteVdTransRuleReplacebytransFieldIdTest method test for delete rule replace by field id")
	void deleteVdTransRuleReplacebytransFieldIdTest() {
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel= new CoreVdTransFieldSettingModel();
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.of(coreVdTransFieldSettingModel));
		doNothing().when(coreVdTransRuleReplaceDAO).deleteByCoreVdTransFieldSetting(coreVdTransFieldSettingModel);
		coreVdTransRuleReplaceServiceImpl.deleteVdTransRuleReplacebytransFieldId(id);
		verify(coreVdTransRuleReplaceDAO, atLeast(1)).deleteByCoreVdTransFieldSetting(any());
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("deleteVdTransRuleReplacebytransFieldIdExceptionTest method test for test exception")
	void deleteVdTransRuleReplacebytransFieldIdExceptionTest() {
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel= null;
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdTransFieldSettingModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransRuleReplaceServiceImpl.deleteVdTransRuleReplacebytransFieldId(id));
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("saveOrUpdateVdTransRuleReplaceTest method test for test save or update")
	void saveOrUpdateVdTransRuleReplaceTest() {
	
		CoreVdTransRuleReplaceModel coreVdTransRuleReplaceModel = new CoreVdTransRuleReplaceModel();
		coreVdTransRuleReplaceModel.setVdReplaceId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		VdTransRuleReplaceRequestDTO ruleReplaceRequestDTO = new VdTransRuleReplaceRequestDTO();
		ruleReplaceRequestDTO.setVdReplaceId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		CoreVdTransFieldSettingModel coreVdTransFieldSetting = new CoreVdTransFieldSettingModel();
		copyProperties(ruleReplaceRequestDTO, coreVdTransRuleReplaceModel);
		coreVdTransRuleReplaceModel.setCoreVdTransFieldSetting(coreVdTransFieldSetting);
		when(coreVdTransRuleReplaceDAO.save(coreVdTransRuleReplaceModel)).thenReturn(coreVdTransRuleReplaceModel);
		coreVdTransRuleReplaceServiceImpl.saveOrUpdateVdTransRuleReplace(ruleReplaceRequestDTO, coreVdTransFieldSetting);
		verify(coreVdTransRuleReplaceDAO, atLeast(1)).save(coreVdTransRuleReplaceModel);
	}
	
	@Test
	@DisplayName("saveOrUpdateVdTransRuleReplaceTest1 method test for test exception")
	void saveOrUpdateVdTransRuleReplaceTest1() {
	
		CoreVdTransRuleReplaceModel coreVdTransRuleReplaceModel = new CoreVdTransRuleReplaceModel();
		coreVdTransRuleReplaceModel.setVdReplaceId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		VdTransRuleReplaceRequestDTO ruleReplaceRequestDTO = new VdTransRuleReplaceRequestDTO();
		ruleReplaceRequestDTO.setVdReplaceId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		CoreVdTransFieldSettingModel coreVdTransFieldSetting = new CoreVdTransFieldSettingModel();
		copyProperties(ruleReplaceRequestDTO, coreVdTransRuleReplaceModel);
		coreVdTransRuleReplaceModel.setCoreVdTransFieldSetting(null);
		when(coreVdTransRuleReplaceDAO.save(coreVdTransRuleReplaceModel)).thenReturn(coreVdTransRuleReplaceModel);
		Assertions.assertThrows(Exception.class, () -> {
			coreVdTransRuleReplaceServiceImpl.saveOrUpdateVdTransRuleReplace(ruleReplaceRequestDTO, coreVdTransFieldSetting);
		});
	}
	
	@Test
	@DisplayName("saveOrUpdateVdTransRuleReplaceTest2 method test for test null")
	void saveOrUpdateVdTransRuleReplaceTest2() {
	
		CoreVdTransRuleReplaceModel coreVdTransRuleReplaceModel = new CoreVdTransRuleReplaceModel();
		coreVdTransRuleReplaceModel.setVdReplaceId(any());
		VdTransRuleReplaceRequestDTO ruleReplaceRequestDTO = new VdTransRuleReplaceRequestDTO();
		ruleReplaceRequestDTO.setVdReplaceId(null);
		CoreVdTransFieldSettingModel coreVdTransFieldSetting = new CoreVdTransFieldSettingModel();
		copyProperties(ruleReplaceRequestDTO, coreVdTransRuleReplaceModel);
		coreVdTransRuleReplaceModel.setCoreVdTransFieldSetting(coreVdTransFieldSetting);
		when(coreVdTransRuleReplaceDAO.save(coreVdTransRuleReplaceModel)).thenReturn(coreVdTransRuleReplaceModel);
		coreVdTransRuleReplaceServiceImpl.saveOrUpdateVdTransRuleReplace(ruleReplaceRequestDTO, coreVdTransFieldSetting);
		verify(coreVdTransRuleReplaceDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("saveOrUpdateVdTransRuleReplaceTest3 method test for null")
	void saveOrUpdateVdTransRuleReplaceTest3() {
		assertThrows(Exception.class,
				() -> coreVdTransRuleReplaceServiceImpl.saveOrUpdateVdTransRuleReplace(null, new CoreVdTransFieldSettingModel()));
	}

	@Test
	@DisplayName("saveOrUpdateVdTransRuleReplaceTest4 method test for null")
	void saveOrUpdateVdTransRuleReplaceTest4() {
		assertThrows(Exception.class,
				() -> coreVdTransRuleReplaceServiceImpl.saveOrUpdateVdTransRuleReplace(new VdTransRuleReplaceRequestDTO(), null));
	}
	
	@Test
	@DisplayName("deleteVdTransRuleReplaceTest method test for test delete the virtual dataset transformation information")
	void deleteVdTransRuleReplaceTest() {

		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = new CoreVdTransFieldSettingModel();
		List<VdTransRuleReplaceRequestDTO> vdTransRuleReplaceRequestDTO = new ArrayList<VdTransRuleReplaceRequestDTO>();
		VdTransRuleReplaceRequestDTO transRuleReplaceRequestDTO= new VdTransRuleReplaceRequestDTO();
		transRuleReplaceRequestDTO.setVdReplaceId(UUID.randomUUID());
		vdTransRuleReplaceRequestDTO.add(transRuleReplaceRequestDTO);
		List<CoreVdTransRuleReplaceModel> coreVdTransRuleReplaceModel = new ArrayList<CoreVdTransRuleReplaceModel>();
		CoreVdTransRuleReplaceModel vdTransRuleReplaceModel= new CoreVdTransRuleReplaceModel();
		vdTransRuleReplaceModel.setVdReplaceId(UUID.randomUUID());
		coreVdTransRuleReplaceModel.add(vdTransRuleReplaceModel);
		when(coreVdTransFieldSettingDAO.findById(any())).thenReturn(Optional.of(coreVdTransFieldSettingModel));
		when(coreVdTransRuleReplaceDAO.findByCoreVdTransFieldSetting(any())).thenReturn(coreVdTransRuleReplaceModel);
		doNothing().when(coreVdTransRuleReplaceDAO).deleteByVdReplaceIdIn(any());
		coreVdTransRuleReplaceServiceImpl.deleteVdTransRuleReplace(vdTransRuleReplaceRequestDTO, UUID.randomUUID());
		verify(coreVdTransRuleReplaceDAO, atLeast(1)).deleteByVdReplaceIdIn(any());
	}

	@Test
	@DisplayName("deleteVdTransRuleReplaceTest1 method test for any exception")
	void deleteVdTransRuleReplaceTest1() {
		Assertions.assertThrows(Exception.class, () -> {
			coreVdTransRuleReplaceServiceImpl.deleteVdTransRuleReplace(new ArrayList<VdTransRuleReplaceRequestDTO>(), null);
		});
	}

}
