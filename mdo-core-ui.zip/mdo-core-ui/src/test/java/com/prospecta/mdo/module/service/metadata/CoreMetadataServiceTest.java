/**
 * 
 */
package com.prospecta.mdo.module.service.metadata;

import com.prospecta.mdo.module.dao.metadata.CoreMetadataDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataLangDAO;
import com.prospecta.mdo.module.dao.metadata.referencerule.CoreMetadataReferenceRuleDAO;
import com.prospecta.mdo.module.dao.module.CoreModuleDAO;
import com.prospecta.mdo.module.dao.module.CoreModuleDescriptionDAO;
import com.prospecta.mdo.module.dao.module.CoreStructureDAO;
import com.prospecta.mdo.module.dto.metadata.CreateFieldRequestDTO;
import com.prospecta.mdo.module.dto.metadata.CreateFieldResponseDTO;
import com.prospecta.mdo.module.dto.metadata.FieldIdsRequestDTO;
import com.prospecta.mdo.module.dto.metadata.FieldWithDescriptionResponseDTO;
import com.prospecta.mdo.module.dto.metadata.ReferenceRuleRequestDTO;
import com.prospecta.mdo.module.dto.metadata.ReferenceRuleResponseDTO;
import com.prospecta.mdo.module.dto.module.*;
import com.prospecta.mdo.module.exception.AlreadyExistsException;
import com.prospecta.mdo.module.exception.GRPCException;
import com.prospecta.mdo.module.grpc.DynamicCrudGenerationImpl;
import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;
import com.prospecta.mdo.module.model.metadata.elastic.UserFieldMetadata;
import com.prospecta.mdo.module.model.metadata.referencerule.CoreMetadataReferenceRuleModel;
import com.prospecta.mdo.module.model.module.CoreModuleModel;
import com.prospecta.mdo.module.model.module.CoreStructureModel;
import com.prospecta.mdo.module.repository.metadata.UserFieldMetadataRepository;
import com.prospecta.mdo.module.service.layout.CoreLayoutHeaderService;
import com.prospecta.mdo.module.service.module.CoreModuleService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.beans.BeanUtils.copyProperties;

/**
 * @author savan
 *
 */
@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
public class CoreMetadataServiceTest {

	@InjectMocks
	private CoreMetadataServiceImpl coreMetadataServiceImpl;

	@Mock
	private DynamicCrudGenerationImpl generationImpl;
	
	@Mock
	private CoreModuleDAO coreModuleDAO;
	
	@Mock
	private CoreModuleService coreModuleServiceImpl;
	
	@Mock
	private CoreMetadataDAO coreMetadataDAO;
	
	@Mock
	private CoreMetadataLangDAO coreMetadataLangDAO;
	
	@Mock
	private CoreLayoutHeaderService coreLayoutHeaderService;
	
	@Mock
	private CoreModuleDescriptionDAO coreModuleDescriptionDAO;
	
	@Mock
	private CoreMetadataReferenceRuleDAO coreMetadataReferenceRuleDAO;
	
	@Mock
	private CoreStructureDAO coreStructureDAO;

	@Mock
	UserFieldMetadataRepository repository;
	
	@BeforeAll
	public void init() {
		coreMetadataServiceImpl = new CoreMetadataServiceImpl();
	}
	
	@Test
	@DisplayName("createFieldTest metod to test creating metadata fields.")
	public void createFieldTest() {
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		fieldDTO.setIsKeyField(true);
		fieldDTO.setIsDescription(false);
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setFieldId("field1");
		metadataModel.setIsKeyField(true);
		
		metadatalist.add(metadataModel);
		
		Iterable<CoreMetadataModel> iterablemetadatalist = metadatalist;
		
		List<Iterable<CoreMetadataModel>> list = new ArrayList<Iterable<CoreMetadataModel>>();
		list.add(iterablemetadatalist);
		List<String> responseData = Arrays.asList("");
		CoreMetadataModel model = null;
		Optional<CoreMetadataModel> optionalModel = Optional.ofNullable(model);
		
		CoreModuleModel coreModuleModel = new CoreModuleModel();
		ModuleDescriptionInformationRequestDTO moduleDescriptionRequestDTO = new ModuleDescriptionInformationRequestDTO();
		moduleDescriptionRequestDTO.setDescription("any");	
		coreModuleModel.setModuleDescriptionRequestDTO(moduleDescriptionRequestDTO);
		
		when(coreModuleDAO.findByModuleIdAndTenantId(any(), any())).thenReturn(coreModuleModel);
		when(coreModuleServiceImpl.saveModuleFields(any(), any(), any(), any())).thenReturn(list);
		when(coreMetadataDAO.findFirstByFieldIdInAndModuleIdAndTenantId(anyList(), anyLong(), anyString())).thenReturn(optionalModel);
		when(coreMetadataDAO.findByStructureIdInAndModuleIdAndTenantIdAndIsKeyField(anyList(),anyLong(),anyString(),anyBoolean())).thenReturn(Collections.singletonList(metadataModel));
        when(coreStructureDAO.findChildStructureByStructureIdAndModuleIdAndTenantId(List.of(Short.parseShort("2")),1L,"0")).thenReturn(List.of(Short.parseShort("3")));

		when(generationImpl.generateDynamicTables(1L, "0", dto)).thenReturn(true);
		when(generationImpl.createUpdateDynamicIndex(1L, "0", dto)).thenReturn(true);

		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.createField(dto, "0", "Admin", 1L);
		
		assertTrue(responseDTO.isAcknowledge());

		when(generationImpl.generateDynamicTables(any(),any(),any())).thenReturn(true);
		when(generationImpl.createUpdateDynamicIndex(any(), any(), any())).thenReturn(false);

		assertThrows(GRPCException.class ,() -> coreMetadataServiceImpl.createField(dto, "0", "Admin", 1L));

		when(generationImpl.generateDynamicTables(any(), any(), any())).thenReturn(false);

		assertThrows(GRPCException.class ,() -> coreMetadataServiceImpl.createField(dto, "0", "Admin", 1L));

	}
	
	@Test
	@DisplayName("createFieldTest metod to test creating metadata fields.")
	public void createFieldTest2() {
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		fieldDTO.setIsKeyField(true);
		fieldDTO.setIsDescription(true);
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setFieldId("field1");
		metadataModel.setIsKeyField(true);
		
		metadatalist.add(metadataModel);
		
		Iterable<CoreMetadataModel> iterablemetadatalist = metadatalist;
		
		List<Iterable<CoreMetadataModel>> list = new ArrayList<Iterable<CoreMetadataModel>>();
		list.add(iterablemetadatalist);
		List<String> responseData = Arrays.asList("");
		CoreMetadataModel model = null;
		Optional<CoreMetadataModel> optionalModel = Optional.ofNullable(model);
		
		List<CoreMetadataModel> listCoreMetamodel = new ArrayList<>();
		CoreMetadataModel coreMetaModel = new CoreMetadataModel();
		listCoreMetamodel.add(coreMetaModel);
		
		CoreModuleModel coreModuleModel = new CoreModuleModel();
		ModuleDescriptionInformationRequestDTO moduleDescriptionRequestDTO = new ModuleDescriptionInformationRequestDTO();
		moduleDescriptionRequestDTO.setDescription("any");	
		coreModuleModel.setModuleDescriptionRequestDTO(moduleDescriptionRequestDTO);
		
		when(coreModuleDAO.findByModuleIdAndTenantId(any(), any())).thenReturn(coreModuleModel);
        when(coreMetadataDAO.findByModuleIdAndTenantIdAndIsDescription(anyLong(), anyString(), anyBoolean())).thenReturn(listCoreMetamodel);

		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.createField(dto, "0", "Admin", 1L);
		
		assertFalse(responseDTO.isAcknowledge());

	}
	
	@Test
	@DisplayName("createFieldTest metod to test creating metadata fields.")
	public void createFieldTest3() {
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO1 = new FieldDTO();
		fieldDTO1.setFieldId("LANGUAGEGRID");
		fieldDTO1.setShortText(moduledescription);
		fieldDTO1.setLongtexts(longtext);
		fieldDTO1.setHelptexts(helptext);
		fieldDTO1.setDataType("GRID");
		fieldDTO1.setPickList("15");
		fieldDTO1.setMaxChar(200L);
		fieldDTO1.setIsGridColumn(false);
		fieldDTO1.setParentField("");
		fieldDTO1.setIsKeyField(true);
		fieldDTO1.setIsDescription(true);
		
		FieldDTO fieldDTO2 = new FieldDTO();
		fieldDTO2.setFieldId("LANGUAGEGRID");
		fieldDTO2.setShortText(moduledescription);
		fieldDTO2.setLongtexts(longtext);
		fieldDTO2.setHelptexts(helptext);
		fieldDTO2.setDataType("GRID");
		fieldDTO2.setPickList("15");
		fieldDTO2.setMaxChar(200L);
		fieldDTO2.setIsGridColumn(false);
		fieldDTO2.setParentField("");
		fieldDTO2.setIsKeyField(true);
		fieldDTO2.setIsDescription(true);
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO2.setChildfields(childList);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO1);
		fieldlist.add(fieldDTO2);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setFieldId("field1");
		metadataModel.setIsKeyField(true);
		
		metadatalist.add(metadataModel);
		
		Iterable<CoreMetadataModel> iterablemetadatalist = metadatalist;
		
		List<Iterable<CoreMetadataModel>> list = new ArrayList<Iterable<CoreMetadataModel>>();
		list.add(iterablemetadatalist);
		List<String> responseData = Arrays.asList("");
		CoreMetadataModel model = null;
		Optional<CoreMetadataModel> optionalModel = Optional.ofNullable(model);
		
		List<CoreMetadataModel> listCoreMetamodel = new ArrayList<>();
		CoreMetadataModel coreMetaModel = new CoreMetadataModel();
		listCoreMetamodel.add(coreMetaModel);
		
		CoreModuleModel coreModuleModel = new CoreModuleModel();
		ModuleDescriptionInformationRequestDTO moduleDescriptionRequestDTO = new ModuleDescriptionInformationRequestDTO();
		moduleDescriptionRequestDTO.setDescription("any");	
		coreModuleModel.setModuleDescriptionRequestDTO(moduleDescriptionRequestDTO);
		
		when(coreModuleDAO.findByModuleIdAndTenantId(any(), any())).thenReturn(coreModuleModel);

		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.createField(dto, "0", "Admin", 1L);
		
		assertFalse(responseDTO.isAcknowledge());

	}

	@Test
	@DisplayName("createFieldTest1 metod to test exception.")
	public void createFieldTest1() {
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setFieldId("field1");
		
		metadatalist.add(metadataModel);
		
		Iterable<CoreMetadataModel> iterablemetadatalist = metadatalist;
		
		List<Iterable<CoreMetadataModel>> list = new ArrayList<Iterable<CoreMetadataModel>>();
		list.add(iterablemetadatalist);
		
		when(coreModuleDAO.findByModuleIdAndTenantId(any(), any())).thenReturn(null);
		
		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.createField(dto, "0", "Admin", 1L);
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreModuleDAO).findByModuleIdAndTenantId(any(), any());
	}
	
	@Test
	@DisplayName("updateFieldTest metod to test update metadata fields.")
	public void updateFieldTest() {
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("fieldId");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		fieldDTO.setIsKeyField(true);
		fieldDTO.setExistingKey(true);


		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("fieldId");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("fieldId");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("fieldId");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("fieldId1");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();

		metadataModel.setFieldId("fieldId");

		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
        metadataModel1.setFieldId("fieldId1");

		CoreMetadataModel metadataModel2 = new CoreMetadataModel();
		metadataModel2.setFieldId("field");
		
		metadatalist.add(metadataModel);
		metadatalist.add(metadataModel1);
		metadatalist.add(metadataModel2);

		List<CoreMetadataLangModel> metadataLangModelList = new ArrayList<>();

		CoreMetadataLangModel langModel = new CoreMetadataLangModel();
		langModel.setFieldId("fieldId");
		langModel.setLanguage("en");
		
		CoreMetadataLangModel langModel1 = new CoreMetadataLangModel();
		langModel1.setFieldId("field");
		langModel.setLanguage("aa");
		
		metadataLangModelList.add(langModel);
		metadataLangModelList.add(langModel1);
		
		List<CoreMetadataLangModel> CoreMetadataLanglist = new ArrayList<>();
		Iterable<CoreMetadataLangModel> iterablCoreMetadataLanglist = CoreMetadataLanglist;
		
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId")).thenReturn(metadatalist);
		when(coreMetadataLangDAO.findByFieldIdAndTenantId("fieldId", "0")).thenReturn(metadataLangModelList);
		doNothing().when(coreModuleServiceImpl).constructShortText(any(), any(), any(), any());
		doNothing().when(coreModuleServiceImpl).constructHelpText(any(), any(), any(), any());
		doNothing().when(coreModuleServiceImpl).constructLongText(any(), any(), any(), any());
		when(coreMetadataLangDAO.saveAll(any())).thenReturn(iterablCoreMetadataLanglist);
		when(coreStructureDAO.findChildStructureByStructureIdAndModuleIdAndTenantId(List.of(Short.parseShort("2")),1L,"0")).thenReturn(List.of(Short.parseShort("3")));

		when(generationImpl.alterColumns(anyLong(), anyString(), any())).thenReturn(true);
		when(generationImpl.createUpdateDynamicIndex(anyLong(), anyString(), any())).thenReturn(true);
		
		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.updateField(dto, "0", "Admin", 1L, "fieldId");
		
		assertTrue(responseDTO.isAcknowledge());

		when(generationImpl.alterColumns(anyLong(), anyString(), any())).thenReturn(true);
		when(generationImpl.createUpdateDynamicIndex(anyLong(), anyString(), any())).thenReturn(false);

		assertThrows(GRPCException.class,()->coreMetadataServiceImpl.updateField(dto, "0", "Admin", 1L, "fieldId"));

		when(generationImpl.alterColumns(anyLong(), anyString(), any())).thenReturn(false);
		assertThrows(GRPCException.class,()->coreMetadataServiceImpl.updateField(dto, "0", "Admin", 1L, "fieldId"));

		verify(coreMetadataDAO,atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId");
		verify(coreMetadataLangDAO,atLeast(2)).findByFieldIdAndTenantId("fieldId", "0");
		verify(coreModuleServiceImpl,atLeast(1)).constructShortText(any(), any(), any(), any());
		verify(coreModuleServiceImpl,atLeast(1)).constructHelpText(any(), any(), any(), any());
		verify(coreModuleServiceImpl,atLeast(1)).constructLongText(any(), any(), any(), any());
		verify(coreMetadataLangDAO,atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("updateFieldTest1 metod to test if lang fields are null.")
	public void updateFieldTest1() {
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("fieldId");
		fieldDTO.setShortText(null);
		fieldDTO.setLongtexts(null);
		fieldDTO.setHelptexts(null);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(true);
		fieldDTO.setParentField("");
		fieldDTO.setIsKeyField(true);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setFieldId("field");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setFieldId("field");
		
		metadatalist.add(metadataModel);
		metadatalist.add(metadataModel1);

		List<CoreMetadataLangModel> metadataLangModelList = new ArrayList<>();

		CoreMetadataLangModel langModel = new CoreMetadataLangModel();
		langModel.setFieldId("fieldId");
		
		metadataLangModelList.add(langModel);
		
		List<CoreMetadataLangModel> CoreMetadataLanglist = new ArrayList<>();
		Iterable<CoreMetadataLangModel> iterablCoreMetadataLanglist = CoreMetadataLanglist;
		
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId")).thenReturn(metadatalist);
		when(coreMetadataLangDAO.findByFieldIdAndTenantId("fieldId", "0")).thenReturn(metadataLangModelList);
		when(coreMetadataLangDAO.saveAll(any())).thenReturn(iterablCoreMetadataLanglist);
		when(generationImpl.alterColumns(anyLong(), anyString(), any())).thenReturn(true);
		when(generationImpl.createUpdateDynamicIndex(anyLong(), anyString(), any())).thenReturn(true);

		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.updateField(dto, "0", "Admin", 1L, "fieldId");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId");
		verify(coreMetadataLangDAO,atLeast(1)).findByFieldIdAndTenantId("fieldId", "0");
		verify(coreMetadataLangDAO,atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("updateFieldTest2 metod to test if lang field are empty.")
	public void updateFieldTest2() {
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("fieldId");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(true);
		fieldDTO.setParentField("");
		fieldDTO.setIsKeyField(true);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setFieldId("field");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setFieldId("fieldId");
		
		metadatalist.add(metadataModel);
		metadatalist.add(metadataModel1);

		List<CoreMetadataLangModel> metadataLangModelList = new ArrayList<>();

		CoreMetadataLangModel langModel = new CoreMetadataLangModel();
		langModel.setFieldId("field");
		
		metadataLangModelList.add(langModel);
		
		List<CoreMetadataLangModel> CoreMetadataLanglist = new ArrayList<>();
		Iterable<CoreMetadataLangModel> iterablCoreMetadataLanglist = CoreMetadataLanglist;
		
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId")).thenReturn(metadatalist);
		when(coreMetadataLangDAO.findByFieldIdAndTenantId("fieldId", "0")).thenReturn(metadataLangModelList);
		when(coreMetadataLangDAO.saveAll(any())).thenReturn(iterablCoreMetadataLanglist);
		when(generationImpl.alterColumns(anyLong(), anyString(), any())).thenReturn(true);
		when(generationImpl.createUpdateDynamicIndex(anyLong(), anyString(), any())).thenReturn(true);

		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.updateField(dto, "0", "Admin", 1L, "fieldId");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId");
		verify(coreMetadataLangDAO,atLeast(1)).findByFieldIdAndTenantId("fieldId", "0");
		verify(coreMetadataLangDAO,atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("updateFieldTest3 metod to test internal server error.")
	public void updateFieldTest3() {
		
		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("fieldId");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(true);
		fieldDTO.setParentField("");
		fieldDTO.setIsKeyField(true);
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		
		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);
		
		fields.add(requestDTO);
		
		dto.setFields(fields);
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setFieldId("field");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setFieldId("fieldId");
		
		metadatalist.add(metadataModel);
		metadatalist.add(metadataModel1);

		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId")).thenReturn(null);
		
		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.updateField(dto, "0", "Admin", 1L, "fieldId");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId");
	}
	
	
	@Test
	@DisplayName("removeFieldTest method to test the remove the fields.")
	public void removeFieldTest() {
		
		List<CoreMetadataModel> metadataModelList =  new ArrayList<>();
		
		CoreMetadataModel model = new CoreMetadataModel();
		model.setFieldId("fieldId");
		model.setParentField("fieldId");
		model.setTenantId("0");
		model.setModuleId(1l);
		model.setIsKeyField(true);
		model.setStructureId(Short.parseShort("1"));
		metadataModelList.add(model);

		
		List<CoreMetadataLangModel> langList = new ArrayList<>();
		
		CoreMetadataLangModel langModel = new CoreMetadataLangModel();
		langModel.setLanguage("en");
		
		langList.add(langModel);
		
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId")).thenReturn(metadataModelList);
		when(coreMetadataLangDAO.findByFieldIdAndTenantId(anyString(), anyString())).thenReturn(langList);
		doNothing().when(coreMetadataLangDAO).deleteAll(langList);
		doNothing().when(coreMetadataDAO).deleteAll(metadataModelList);
		when(generationImpl.deleteColumn(anyList(), isA(List.class), anyLong(), isA(String.class),isA(String.class))).thenReturn(true);
		
		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.removeField("0", "Admin", 1L, "fieldId");
		
		assertTrue(responseDTO.isAcknowledge());

		when(generationImpl.deleteColumn(anyList(), isA(List.class), anyLong(), isA(String.class),isA(String.class))).thenReturn(false);

		assertThrows(GRPCException.class,()-> coreMetadataServiceImpl.removeField("0", "Admin", 1L, "fieldId"));

		verify(coreMetadataDAO,atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId");
		verify(coreMetadataLangDAO,atLeast(1)).findByFieldIdAndTenantId("fieldId", "0");
		verify(coreMetadataLangDAO,atLeast(1)).deleteAll(langList);
		verify(coreMetadataDAO,atLeast(1)).deleteAll(metadataModelList);
	}

	@Test
	@DisplayName("removeFieldTest method to test the remove the grid fields.")
	public void removeFieldGrid() {

		List<CoreMetadataModel> metadataModelList =  new ArrayList<>();

		CoreMetadataModel model = new CoreMetadataModel();
		model.setFieldId("fieldId");
		model.setParentField("fieldId");
		model.setTenantId("0");
		model.setModuleId(1l);
		model.setIsKeyField(true);
		model.setStructureId(Short.parseShort("1"));

		CoreMetadataModel childModel = new CoreMetadataModel();
		childModel.setFieldId("fieldId1");
		childModel.setParentField("fieldId");
		childModel.setTenantId("0");
		childModel.setModuleId(1l);
		childModel.setIsKeyField(true);

		childModel.setStructureId(Short.parseShort("1"));
		metadataModelList.add(model);
		metadataModelList.add(childModel);

		List<CoreMetadataLangModel> langList = new ArrayList<>();

		CoreMetadataLangModel langModel = new CoreMetadataLangModel();
		langModel.setLanguage("en");

		langList.add(langModel);

		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId")).thenReturn(metadataModelList);
		when(coreMetadataLangDAO.findByFieldIdAndTenantId(anyString(), anyString())).thenReturn(langList);
		doNothing().when(coreMetadataLangDAO).deleteAll(langList);
		doNothing().when(coreMetadataDAO).deleteAll(metadataModelList);
		when(generationImpl.deleteColumn(anyList(), isA(List.class), anyLong(), isA(String.class),isA(String.class))).thenReturn(true);

		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.removeField("0", "Admin", 1L, "fieldId");

		assertTrue(responseDTO.isAcknowledge());

		verify(coreMetadataDAO,atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId");
		verify(coreMetadataLangDAO,atLeast(1)).findByFieldIdAndTenantId("fieldId", "0");
		verify(coreMetadataLangDAO,atLeast(1)).deleteAll(langList);
		verify(coreMetadataDAO,atLeast(1)).deleteAll(metadataModelList);
	}


	@Test
	@DisplayName("removeFieldTest1 method to test the exception check.")
	public void removeFieldTest1() {
		
		List<CoreMetadataModel> metadataModelList =  new ArrayList<>();
		
		CoreMetadataModel model = new CoreMetadataModel();
		model.setFieldId("fieldId");


		metadataModelList.add(model);
		
		List<CoreMetadataLangModel> langList = new ArrayList<>();
		
		CoreMetadataLangModel langModel = new CoreMetadataLangModel();
		langModel.setLanguage("en");
		
		langList.add(langModel);
		
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId")).thenReturn(null);
		
		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.removeField("0", "Admin", 1L, "fieldId");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId");
	}
	
	@Test
	@DisplayName("removeFieldTest2 method to test the remove the fields.")
	public void removeFieldTest2() {
		
		List<CoreMetadataModel> metadataModelList =  new ArrayList<>();
		
		CoreMetadataModel model = new CoreMetadataModel();
		model.setFieldId("fieldId");
		model.setStructureId(Short.parseShort("1"));
		model.setIsKeyField(true);

		metadataModelList.add(model);
		
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId")).thenReturn(metadataModelList);
		when(coreMetadataLangDAO.findByFieldIdAndTenantId("fieldId", "0")).thenReturn(null);
		doNothing().when(coreMetadataDAO).deleteAll(metadataModelList);
		when(generationImpl.deleteColumn(anyList(), anyList(), anyLong(), anyString(),anyString())).thenReturn(true);
		
		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.removeField("0", "Admin", 1L, "fieldId");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "fieldId", "fieldId");
		verify(coreMetadataLangDAO,atLeast(1)).findByFieldIdAndTenantId("fieldId", "0");
		verify(coreMetadataDAO,atLeast(1)).deleteAll(metadataModelList);
	}
	
	@Test
	@DisplayName("getSearchablefieldswithdescriptionTest method to test Get Searchable fields with field description.")
	public void getSearchablefieldswithdescriptionTest() {
		
		Pageable pageable = PageRequest.of(0, 10);
		
		List<CoreMetadataLangModel> metadataLang = new ArrayList<>();
		
		CoreMetadataLangModel description = new CoreMetadataLangModel();
		description.setFieldId("fieldId");
		
		CoreMetadataLangModel description1 = new CoreMetadataLangModel();
		description1.setFieldId("fieldId1");
		
		metadataLang.add(description);
		metadataLang.add(description1);
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldid");
		metadataModel1.setParentField("fieldId");
		
		metadataFields.add(metadataModel);
		metadataFields.add(metadataModel1);
		
		List<CoreMetadataModel> metadataFields1 = new ArrayList<>();
		
		CoreMetadataModel metadataModel2 = new CoreMetadataModel();
		metadataModel2.setModuleId(1L);
		metadataModel2.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel3 = new CoreMetadataModel();
		metadataModel3.setModuleId(2L);
		metadataModel3.setFieldId("fieldid");
		metadataModel3.setParentField("fieldId");
		
		metadataFields1.add(metadataModel2);
		metadataFields1.add(metadataModel3);
		
		FieldDTO fieldDto = new FieldDTO();
		fieldDto.setModuleId(1L);
		fieldDto.setStructureId("1");
		fieldDto.setFieldId("fieldId");
		
		List<ChildFieldsDTO> childList = new ArrayList<>();
		
		ChildFieldsDTO chieldDTO = new ChildFieldsDTO();
		chieldDTO.setFieldId("fieldId");
		
		childList.add(chieldDTO);
		
		fieldDto.setChildfields(childList);
		
		FieldDTO fieldDto1 = new FieldDTO();
		fieldDto1.setModuleId(2L);
		fieldDto1.setStructureId("1");
		fieldDto1.setFieldId("fieldId");
		
		CoreModuleModel module = new CoreModuleModel();
		module.setModuleId(1L);
		
		List<CoreStructureModel> structures = new ArrayList<>();
		
		CoreStructureModel str1 = new CoreStructureModel();
		str1.setIsHeader(true);
		str1.setParentStrucId((short) 1);
		str1.setStructureId((short) 1);
		
		CoreStructureModel str = new CoreStructureModel();
		str.setIsHeader(true);
		str.setParentStrucId((short) 1);
		str.setStructureId((short) 2);
		
		CoreStructureModel str2 = new CoreStructureModel();
		str2.setIsHeader(false);
		str2.setParentStrucId((short) 1);
		
		structures.add(str1);
		structures.add(str);
		structures.add(str2);
		
		when(coreMetadataLangDAO.findByIsSearchableAndSearchTerm(1L,"en", "0", "De",pageable)).thenReturn(metadataLang);
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldId(1L,"0", "fieldId")).thenReturn(metadataFields.get(0));
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldId(1L,"0", "fieldId1")).thenReturn(metadataFields.get(1));
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDto);
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDto1);
		when(coreStructureDAO.findByModuleIdAndStructureIdInAndTenantId(any(),any(),any())).thenReturn(structures);
		
		Map<Object, Object> response = coreMetadataServiceImpl.getSearchablefieldswithdescription(1L,"en", "De","0","10", "0");
		
		assertNotNull(response);
		verify(coreMetadataLangDAO, atLeast(1)).findByIsSearchableAndSearchTerm(1L,"en", "0", "De",pageable);
		verify(coreMetadataDAO, atLeast(1)).findByModuleIdAndTenantIdAndFieldId(1L,"0", "fieldId");
		verify(coreLayoutHeaderService, atLeast(2)).generateMetadataField(any(), any(), any(), any());
		verify(coreStructureDAO, atLeast(1)).findByModuleIdAndStructureIdInAndTenantId(any(),any(),any());
	}
	
	@Test
	@DisplayName("getSearchablefieldswithdescriptionTest1 method to test Get Searchable fields with field description.")
	public void getSearchablefieldswithdescriptionTest1() {
		
		Pageable pageable = PageRequest.of(0, 10);
		
		List<CoreMetadataLangModel> metadataLang = new ArrayList<>();
		
		CoreMetadataLangModel description = new CoreMetadataLangModel();
		description.setFieldId("fieldId");
		
		CoreMetadataLangModel description1 = new CoreMetadataLangModel();
		description1.setFieldId("fieldId");
		
		metadataLang.add(description);
		metadataLang.add(description1);
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldid");
		metadataModel1.setParentField("");
		
		metadataFields.add(metadataModel);
		metadataFields.add(metadataModel1);
		
		List<CoreMetadataModel> metadataFields1 = new ArrayList<>();
		
		CoreMetadataModel metadataModel2 = new CoreMetadataModel();
		metadataModel2.setModuleId(1L);
		metadataModel2.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel3 = new CoreMetadataModel();
		metadataModel3.setModuleId(2L);
		metadataModel3.setFieldId("fieldid");
		metadataModel3.setParentField("");
		
		metadataFields1.add(metadataModel2);
		metadataFields1.add(metadataModel3);
		
		FieldDTO fieldDto = new FieldDTO();
		fieldDto.setModuleId(1L);
		fieldDto.setStructureId("1");
		fieldDto.setFieldId("fieldId");
		
		List<ChildFieldsDTO> childList = new ArrayList<>();
		
		ChildFieldsDTO chieldDTO = new ChildFieldsDTO();
		chieldDTO.setFieldId("fieldId");
		
		childList.add(chieldDTO);
		
		fieldDto.setChildfields(childList);
		
		FieldDTO fieldDto1 = new FieldDTO();
		fieldDto1.setModuleId(2L);
		fieldDto1.setStructureId("1");
		fieldDto1.setFieldId("fieldId");
		
		CoreModuleModel module = new CoreModuleModel();
		module.setModuleId(1L);
		
		List<CoreStructureModel> structures = new ArrayList<>();
		
		CoreStructureModel str1 = new CoreStructureModel();
		str1.setIsHeader(false);
		str1.setParentStrucId((short) 1);
		
		structures.add(str1);
		
		when(coreMetadataLangDAO.findByIsSearchableAndSearchTerm(1L,"en", "0", "De",pageable)).thenReturn(metadataLang);
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldId(1L,"0", "fieldId")).thenReturn(metadataFields.get(0));
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDto);
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDto1);
		when(coreStructureDAO.findByModuleIdAndStructureIdInAndTenantId(any(),any(),any())).thenReturn(structures);
		
		Map<Object, Object> response = coreMetadataServiceImpl.getSearchablefieldswithdescription(1L,"en", "De","0","10", "0");
		
		assertNotNull(response);
		
		verify(coreMetadataLangDAO, atLeast(1)).findByIsSearchableAndSearchTerm(1L,"en", "0", "De",pageable);
		verify(coreMetadataDAO, atLeast(1)).findByModuleIdAndTenantIdAndFieldId(1L,"0", "fieldId");
	}
	
	@Test
	@DisplayName("getSearchablefieldswithdescriptionTest2 method to test Get Searchable fields with field description.")
	public void getSearchablefieldswithdescriptionTest2() {
		
		Pageable pageable = PageRequest.of(0, 10);
		
		when(coreMetadataLangDAO.findByIsSearchableAndSearchTerm(1L,"en", "0", "De",pageable)).thenReturn(null);
		
		Map<Object, Object> response = coreMetadataServiceImpl.getSearchablefieldswithdescription(1L,"en", "De","0","10", "0");
		
		assertNotNull(response);
		
		verify(coreMetadataLangDAO, atLeast(1)).findByIsSearchableAndSearchTerm(1L,"en", "0", "De",pageable);
	}
	
	@Test
	@DisplayName("getSearchablefieldswithdescriptionTest3 method to test to check exception handaling.")
	public void getSearchablefieldswithdescriptionTest3() {
		
		Pageable pageable = PageRequest.of(0, 10);
		
		when(coreMetadataLangDAO.findByIsSearchableAndSearchTerm(1L,"en", "0", "De",pageable)).thenThrow(new NoSuchElementException());
		
		Map<Object, Object> response = coreMetadataServiceImpl.getSearchablefieldswithdescription(1L,"en", "De","0","10", "0");
		
		assertFalse(response.containsKey("key"));
		
		verify(coreMetadataLangDAO, atLeast(1)).findByIsSearchableAndSearchTerm(1L,"en", "0", "De",pageable);
	}
	
	@Test
	@DisplayName("getSearchablefieldswithdescriptionTest4 method to test Get Searchable fields with field description.")
	public void getSearchablefieldswithdescriptionTest4() {
		
		Pageable pageable = PageRequest.of(0, 10);
		
		List<CoreMetadataLangModel> metadataLang = new ArrayList<>();

		CoreMetadataLangModel description = new CoreMetadataLangModel();
		description.setFieldId("fieldId");
		description.setLongText("long");
		description.setShortText("short");
		description.setHelpText("help");
		CoreMetadataLangModel description1 = new CoreMetadataLangModel();
		description1.setFieldId("fieldId");
		
		metadataLang.add(description);
		metadataLang.add(description1);
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldid");
		
		metadataFields.add(metadataModel);
		metadataFields.add(metadataModel1);
		
		List<CoreMetadataModel> metadataFields1 = new ArrayList<>();
		
		CoreMetadataModel metadataModel2 = new CoreMetadataModel();
		metadataModel2.setModuleId(1L);
		metadataModel2.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel3 = new CoreMetadataModel();
		metadataModel3.setModuleId(2L);
		metadataModel3.setFieldId("fieldid");
		metadataModel3.setParentField("");
		
		metadataFields1.add(metadataModel2);
		metadataFields1.add(metadataModel3);
		
		FieldDTO fieldDto = new FieldDTO();
		fieldDto.setModuleId(1L);
		fieldDto.setStructureId("1");
		fieldDto.setFieldId("fieldId");
		
		List<ChildFieldsDTO> childList = new ArrayList<>();
		
		ChildFieldsDTO chieldDTO = new ChildFieldsDTO();
		chieldDTO.setFieldId("fieldId");
		
		childList.add(chieldDTO);
		
		fieldDto.setChildfields(childList);
		
		FieldDTO fieldDto1 = new FieldDTO();
		fieldDto1.setModuleId(2L);
		fieldDto1.setStructureId("1");
		fieldDto1.setFieldId("fieldId");
		
		CoreModuleModel module = new CoreModuleModel();
		module.setModuleId(1L);
		
		List<CoreStructureModel> structures = new ArrayList<>();
		
		CoreStructureModel str1 = new CoreStructureModel();
		str1.setIsHeader(false);
		str1.setParentStrucId((short) 1);
		
		structures.add(str1);
		
		when(coreMetadataLangDAO.findByIsSearchableAndSearchTerm(1L,"en", "0", "De",pageable)).thenReturn(metadataLang);
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldId(1L,"0", "fieldId")).thenReturn(metadataFields.get(0));
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDto);
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDto1);
		when(coreStructureDAO.findByModuleIdAndStructureIdInAndTenantId(any(),any(),any())).thenReturn(structures);
		
		Map<Object, Object> response = coreMetadataServiceImpl.getSearchablefieldswithdescription(1L,"en", "De","0","10", "0");
		
		assertNotNull(response);
		
		verify(coreMetadataLangDAO, atLeast(1)).findByIsSearchableAndSearchTerm(1L,"en", "0", "De",pageable);
		verify(coreMetadataDAO, atLeast(1)).findByModuleIdAndTenantIdAndFieldId(any(),any(), any());

	}
	
	@Test
	@DisplayName("getMetadataOfFieldsBasedOnFieldIdArrayListTest method is used to Get Metadata of fields based on field Id list.")
	public void getMetadataOfFieldsBasedOnFieldIdArrayListTest() {
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldid");
		metadataModel1.setParentField("fieldId");
		
		metadataFields.add(metadataModel);
		metadataFields.add(metadataModel1);
		
		List<CoreMetadataModel> metadataFields1 = new ArrayList<>();
		
		CoreMetadataModel metadataModel2 = new CoreMetadataModel();
		metadataModel2.setModuleId(1L);
		metadataModel2.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel3 = new CoreMetadataModel();
		metadataModel3.setModuleId(2L);
		metadataModel3.setFieldId("fieldid");
		metadataModel3.setParentField("fieldId");
		
		metadataFields1.add(metadataModel2);
		metadataFields1.add(metadataModel3);
		
		FieldDTO fieldDto = new FieldDTO();
		fieldDto.setModuleId(1L);
		fieldDto.setStructureId("1");
		fieldDto.setFieldId("fieldId");
		
		List<ChildFieldsDTO> childList = new ArrayList<>();
		
		ChildFieldsDTO chieldDTO = new ChildFieldsDTO();
		chieldDTO.setFieldId("fieldId");
		
		childList.add(chieldDTO);
		
		fieldDto.setChildfields(childList);
		
		FieldDTO fieldDto1 = new FieldDTO();
		fieldDto1.setModuleId(2L);
		fieldDto1.setStructureId("1");
		fieldDto1.setFieldId("fieldId");
		
		CoreModuleModel module = new CoreModuleModel();
		module.setModuleId(1L);
		
		List<CoreStructureModel> structures = new ArrayList<>();
		
		CoreStructureModel str1 = new CoreStructureModel();
		str1.setIsHeader(true);
		str1.setParentStrucId((short) 1);
		str1.setStructureId((short) 1);
		
		CoreStructureModel str = new CoreStructureModel();
		str.setIsHeader(true);
		str.setParentStrucId((short) 1);
		str.setStructureId((short) 2);
		
		CoreStructureModel str2 = new CoreStructureModel();
		str2.setIsHeader(true);
		str2.setParentStrucId((short) 1);
		
		structures.add(str1);
		structures.add(str);
		structures.add(str2);
		
		FieldIdsRequestDTO request = new FieldIdsRequestDTO();
		List<String> fieldIds = new ArrayList<>();
		fieldIds.add("fieldId");
		fieldIds.add("fieldId");
		request.setFieldIds(fieldIds);
		
		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenReturn(metadataFields);
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDto);
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDto1);
		
		List<FieldWithDescriptionResponseDTO> response = coreMetadataServiceImpl.getMetadataOfFieldsBasedOnFieldIdArrayList(request,"en", "0");
		
		assertNotNull(response);
		
		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId");
		verify(coreLayoutHeaderService, atLeast(2)).generateMetadataField(any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("getMetadataOfFieldsBasedOnFieldIdArrayListTest1 method to test if parent structure is empty")
	public void getMetadataOfFieldsBasedOnFieldIdArrayListTest1() {
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldid");
		metadataModel1.setParentField("");
		
		metadataFields.add(metadataModel);
		metadataFields.add(metadataModel1);
		
		List<CoreMetadataModel> metadataFields1 = new ArrayList<>();
		
		CoreMetadataModel metadataModel2 = new CoreMetadataModel();
		metadataModel2.setModuleId(1L);
		metadataModel2.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel3 = new CoreMetadataModel();
		metadataModel3.setModuleId(2L);
		metadataModel3.setFieldId("fieldid");
		metadataModel3.setParentField("");
		
		metadataFields1.add(metadataModel2);
		metadataFields1.add(metadataModel3);
		
		FieldDTO fieldDto = new FieldDTO();
		fieldDto.setModuleId(1L);
		fieldDto.setStructureId("1");
		fieldDto.setFieldId("fieldId");
		
		List<ChildFieldsDTO> childList = new ArrayList<>();
		
		ChildFieldsDTO chieldDTO = new ChildFieldsDTO();
		chieldDTO.setFieldId("fieldId");
		
		childList.add(chieldDTO);
		
		fieldDto.setChildfields(childList);
		
		FieldDTO fieldDto1 = new FieldDTO();
		fieldDto1.setModuleId(2L);
		fieldDto1.setStructureId("1");
		fieldDto1.setFieldId("fieldId");
		
		CoreModuleModel module = new CoreModuleModel();
		module.setModuleId(1L);
		
		List<CoreStructureModel> structures = new ArrayList<>();
		
		CoreStructureModel str1 = new CoreStructureModel();
		str1.setIsHeader(true);
		str1.setParentStrucId((short) 1);
		str1.setStructureId((short) 1);
		
		CoreStructureModel str = new CoreStructureModel();
		str.setIsHeader(true);
		str.setParentStrucId((short) 1);
		str.setStructureId((short) 2);
		
		CoreStructureModel str2 = new CoreStructureModel();
		str2.setIsHeader(true);
		str2.setParentStrucId((short) 1);
		
		structures.add(str1);
		structures.add(str);
		structures.add(str2);
		
		FieldIdsRequestDTO request = new FieldIdsRequestDTO();
		List<String> fieldIds = new ArrayList<>();
		fieldIds.add("fieldId");
		fieldIds.add("fieldId");
		request.setFieldIds(fieldIds);
		
		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenReturn(metadataFields);
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDto);
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDto1);
		
		List<FieldWithDescriptionResponseDTO> response = coreMetadataServiceImpl.getMetadataOfFieldsBasedOnFieldIdArrayList(request,"en", "0");
		
		assertNotNull(response);
		
		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId");
		verify(coreLayoutHeaderService, atLeast(2)).generateMetadataField(any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("getMetadataOfFieldsBasedOnFieldIdArrayListTest3 method to test exception handling")
	public void getMetadataOfFieldsBasedOnFieldIdArrayListTest3() {
		
		FieldIdsRequestDTO request = new FieldIdsRequestDTO();
		List<String> fieldIds = new ArrayList<>();
		fieldIds.add("fieldId");
		fieldIds.add("fieldId");
		request.setFieldIds(fieldIds);
		
		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenThrow(new NoSuchElementException());
		
		List<FieldWithDescriptionResponseDTO> response = coreMetadataServiceImpl.getMetadataOfFieldsBasedOnFieldIdArrayList(request,"en", "0");
		
		assertTrue(response.isEmpty());
		
		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId");
	}

	@Test
	@DisplayName("Test to check get field by array parent null check")
	public void getFieldbyArrayParentCheck() {

		FieldIdsRequestDTO request = new FieldIdsRequestDTO();
		List<String> fieldIds = new ArrayList<>();
		fieldIds.add("fieldid");
		request.setFieldIds(fieldIds);

		List<CoreMetadataModel> metadataFields = new ArrayList<>();

		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldid");
		metadataModel1.setParentField("test");
		metadataFields.add(metadataModel1);

		FieldDTO fieldDTO =new FieldDTO();
		fieldDTO.setFieldId("fieldid");
		fieldDTO.setParentField("test");
		fieldDTO.setStructureId("1");

		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldid", "fieldid")).thenReturn(metadataFields);
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDTO);

		List<FieldWithDescriptionResponseDTO> response = coreMetadataServiceImpl.getMetadataOfFieldsBasedOnFieldIdArrayList(request,"en", "0");

		assertFalse(response.isEmpty());

		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldid", "fieldid");
	}
	
	@Test
	@DisplayName("getFieldDetailsWithFieldIdTest method to generate the fields based on the field id")
	public void getFieldDetailsWithFieldIdTest() {
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldid");
		metadataModel1.setParentField("fieldid");
		
		metadataFields.add(metadataModel);
		metadataFields.add(metadataModel1);
		
		List<CoreMetadataLangModel> metadataLang = new ArrayList<>();
		
		CoreMetadataLangModel model = new CoreMetadataLangModel();
		model.setFieldId("fieldId");
		model.setLanguage("en");
		model.setShortText("short text");
		model.setHelpText("help text");
		model.setLongText("long text");
		
		CoreMetadataLangModel model1 = new CoreMetadataLangModel();
		model1.setFieldId("fieldId");
		model1.setLanguage("en");
		
		metadataLang.add(model);
		metadataLang.add(model1);
		
		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenReturn(metadataFields);
		when(coreMetadataLangDAO.findByFieldIdAndTenantIdAndModuleId("fieldId", "0", 1L)).thenReturn(metadataLang);
		when(repository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.empty());

		FieldDTO response = coreMetadataServiceImpl.getFieldDetailsWithFieldId(1L,"fieldId", "0","admin");
		
		assertNotNull(response);
		
		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId");
		verify(coreMetadataLangDAO, atLeast(1)).findByFieldIdAndTenantIdAndModuleId("fieldId", "0", 1L);
	}
	
	@Test
	@DisplayName("getFieldDetailsWithFieldIdTest1 method to generate the fields based on the field id")
	public void getFieldDetailsWithFieldIdTest1() {
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldid");
		metadataModel1.setParentField("fieldid");
		
		metadataFields.add(metadataModel);
		metadataFields.add(metadataModel1);
		
		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenReturn(metadataFields);
		when(coreMetadataLangDAO.findByFieldIdAndTenantIdAndModuleId("fieldId", "0", 1L)).thenReturn(null);
		when(repository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.empty());

		FieldDTO response = coreMetadataServiceImpl.getFieldDetailsWithFieldId(1L,"fieldId", "0","admin");
		
		assertNotNull(response);
		
		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId");
		verify(coreMetadataLangDAO, atLeast(1)).findByFieldIdAndTenantIdAndModuleId("fieldId", "0", 1L);
	}
	
	@Test
	@DisplayName("getFieldDetailsWithFieldIdTest2 method to test if field id is empty")
	public void getFieldDetailsWithFieldIdTest2() {
		when(repository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.empty());

		FieldDTO response = coreMetadataServiceImpl.getFieldDetailsWithFieldId(1L,"", "0","admin");
		
		assertNull(response);
	}
	
	@Test
	@DisplayName("getFieldDetailsWithFieldIdTest3 method to test if field id is null")
	public void getFieldDetailsWithFieldIdTest3() {
		when(repository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.empty());

		FieldDTO response = coreMetadataServiceImpl.getFieldDetailsWithFieldId(1L,null, "0","admin");
		
		assertNull(response);
	}
	
	@Test
	@DisplayName("getFieldDetailsWithFieldIdTest4 method to check if metadataFields are empty")
	public void getFieldDetailsWithFieldIdTest4() {
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenReturn(metadataFields);
		when(repository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.empty());

		FieldDTO response = coreMetadataServiceImpl.getFieldDetailsWithFieldId(1L,"fieldId", "0","admin");
		
		assertNull(response);
		
		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId");
	}
	
	@Test
	@DisplayName("getFieldDetailsWithFieldIdTest5 method to check if metadataFields are null")
	public void getFieldDetailsWithFieldIdTest5() {
		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenReturn(null);
		when(repository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.empty());

		FieldDTO response = coreMetadataServiceImpl.getFieldDetailsWithFieldId(1L,"fieldId", "0","admin");
		
		assertNull(response);
		
		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId");
	}
	
	@Test
	@DisplayName("getFieldDetailsWithFieldIdTest6 method to generate the fields based on the field id")
	public void getFieldDetailsWithFieldIdTest6() {
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldid");
		metadataModel1.setParentField("");
		
		metadataFields.add(metadataModel);
		metadataFields.add(metadataModel1);
		
		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenReturn(metadataFields);
		when(coreMetadataLangDAO.findByFieldIdAndTenantIdAndModuleId("fieldId", "0", 1L)).thenReturn(null);
		when(repository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.empty());

		FieldDTO response = coreMetadataServiceImpl.getFieldDetailsWithFieldId(1L,"fieldId", "0","admin");
		
		assertNotNull(response);
		
		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId");
		verify(coreMetadataLangDAO, atLeast(1)).findByFieldIdAndTenantIdAndModuleId("fieldId", "0", 1L);
	}

	@Test
	@DisplayName("getFieldDetailsWithFieldIdTest5 method to check if draft")
	void getFieldDetailsWithFieldIdDraft() {

		UserFieldMetadata metadata = new UserFieldMetadata();
		FieldDTO dto =new FieldDTO() ;
		dto.setFieldId("field");
		metadata.setFieldData(dto);

		when(repository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.of(metadata));

		FieldDTO response = coreMetadataServiceImpl.getFieldDetailsWithFieldId(1L,"fieldId", "0","admin");

		assertNotNull(response);

	}

	@Test
	@DisplayName("Test for Parent Null Case")
	public void getFieldDetailsWithFieldIdParentNullCheck() {

		List<CoreMetadataModel> metadataFields = new ArrayList<>();

		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldid");
		metadataModel1.setParentField("test");


		metadataFields.add(metadataModel1);

		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenReturn(metadataFields);
		when(coreMetadataLangDAO.findByFieldIdAndTenantIdAndModuleId("fieldid", "0", 2L)).thenReturn(null);
		when(repository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.empty());

		FieldDTO response = coreMetadataServiceImpl.getFieldDetailsWithFieldId(1L,"fieldId", "0","admin");
		assertNotNull(response);

	}

	@Test
	@DisplayName("createRandomFieldId test to test Random fieldId generation")
	public void checkRandomFieldIdTest() {

		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

		List<FieldsRequestDTO> fields = new ArrayList<>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription("Earth");
		Map<String, String>longText =createMap();
		Map<String, String> helpText =createMap();
		Map<String, ModuleDescriptionInformationRequestDTO> letterModuleDescription =createModuleDescription("1wer");

		FieldDTO fieldDTO = createFieldDto(moduleDescription,longText,helpText," LAND ");
        ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription,longText,helpText," ");
        ChildFieldsDTO secondChildDto =createChildFieldDTO(letterModuleDescription,longText,helpText," ");

		FieldDTO secondFieldDTO = createFieldDto(moduleDescription,longText,helpText," ");
		secondFieldDTO.setChildfields(new ArrayList<>());
		childDTO.setParentField(" LAND ");
		secondChildDto.setParentField("");
		FieldDTO thirdFieldDTO = createFieldDto(moduleDescription,longText,helpText," ");
		thirdFieldDTO.setChildfields(null);

		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(secondChildDto);

		fieldDTO.setChildfields(childList);

		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		fieldlist.add(secondFieldDTO);

		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);

		fields.add(requestDTO);

		dto.setFields(fields);

		ModuleRequestDTO moduleRequestDTO = new ModuleRequestDTO();
		moduleRequestDTO.setFields(dto.getFields());

		when(coreMetadataDAO.findFirstByFieldIdInAndModuleIdAndTenantId(any(), any(), any())).thenReturn(Optional.empty());

		List<String> dynamicFieldIds= coreMetadataServiceImpl.createDynamicFieldIds(moduleRequestDTO, 1L, "0",true);
		assertTrue(!fieldDTO.getFieldId().trim().isEmpty());
		assertTrue(!childDTO.getFieldId().trim().isEmpty());
		assertFalse(dynamicFieldIds.isEmpty());

	}

	@Test
	@DisplayName("createRandomFieldId test to test Random fieldId generation duplicate element exception")
	public void checkRandomFieldIdTestException() {

		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

		List<FieldsRequestDTO> fields = new ArrayList<>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription(" ");
		Map<String, String>longText =createMap();
		Map<String, String> helpText =createMap();
		Map<String, ModuleDescriptionInformationRequestDTO> letterModuleDescription =createModuleDescription("Wer");


		FieldDTO fieldDTO = createFieldDto(moduleDescription,longText,helpText," TEST ");
		ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription,longText,helpText," CHILD ");
		ChildFieldsDTO secondChildDto =createChildFieldDTO(letterModuleDescription,longText,helpText,"SECONDCHILD");
		childDTO.setParentField("TEST");
		secondChildDto.setParentField(null);
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(secondChildDto);

		fieldDTO.setChildfields(childList);

		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);

		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);

		fields.add(requestDTO);

		dto.setFields(fields);

		ModuleRequestDTO moduleRequestDTO = new ModuleRequestDTO();
		moduleRequestDTO.setFields(dto.getFields());
		CoreMetadataModel model=new CoreMetadataModel();
		model.setFieldId("Plant");
		when(coreMetadataDAO.findFirstByFieldIdInAndModuleIdAndTenantId(any(), any(), any())).thenReturn(Optional.of(model));

		assertThrows(AlreadyExistsException.class, () -> {
			coreMetadataServiceImpl.createDynamicFieldIds(moduleRequestDTO, 1L, "0",true);
		});
	}


	@Test
	@DisplayName("Test to check special characters as first element of description")
	public void checkSpecialCharacters() {

		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

		List<FieldsRequestDTO> fields = new ArrayList<>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription("@er");
		Map<String, String>longText =createMap();
		Map<String, String> helpText =createMap();
		Map<String, ModuleDescriptionInformationRequestDTO> letterModuleDescription =createModuleDescription("1wer");

		FieldDTO fieldDTO = createFieldDto(letterModuleDescription,longText,helpText," ");
		ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription,longText,helpText," land ");
        childDTO.setParentField(null);
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);

		fieldDTO.setChildfields(childList);
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);

		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);

		fields.add(requestDTO);

		dto.setFields(fields);

		ModuleRequestDTO moduleRequestDTO = new ModuleRequestDTO();
		moduleRequestDTO.setFields(dto.getFields());
		when(coreMetadataDAO.findFirstByFieldIdInAndModuleIdAndTenantId(any(), any(), any())).thenReturn(Optional.empty());

		coreMetadataServiceImpl.createDynamicFieldIds(moduleRequestDTO, 1L, "0",true);

		assertFalse(fieldDTO.getFieldId().contains("@"));
		assertEquals(childDTO.getFieldId(),"land");

	}

	@Test
	@DisplayName("Test to check whitespace in of description")
	public void checkDescriptionWhiteSpace() {

		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

		List<FieldsRequestDTO> fields = new ArrayList<>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription(null);
		Map<String, String>longText =createMap();
		Map<String, String> helpText =createMap();
		Map<String, ModuleDescriptionInformationRequestDTO> letterModuleDescription =createModuleDescription(" ");

		FieldDTO fieldDTO = createFieldDto(letterModuleDescription,longText,helpText," ");
		ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription,longText,helpText," land ");
		childDTO.setParentField(" ");
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);

		fieldDTO.setChildfields(childList);
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);

		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);

		fields.add(requestDTO);

		dto.setFields(fields);

		ModuleRequestDTO moduleRequestDTO = new ModuleRequestDTO();
		moduleRequestDTO.setFields(dto.getFields());
		when(coreMetadataDAO.findFirstByFieldIdInAndModuleIdAndTenantId(any(), any(), any())).thenReturn(Optional.empty());

		coreMetadataServiceImpl.createDynamicFieldIds(moduleRequestDTO, 1L, "0",true);

		assertFalse(fieldDTO.getFieldId().isEmpty());

	}

	@Test
	@DisplayName("Test to check dynamic field when fieldId is null")
	public void checkFieldId() {

		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

		List<FieldsRequestDTO> fields = new ArrayList<>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription("testDescription");
		Map<String, String>longText =createMap();
		Map<String, String> helpText =createMap();
		Map<String, ModuleDescriptionInformationRequestDTO> letterModuleDescription =createModuleDescription("123");

		FieldDTO fieldDTO = createFieldDto(letterModuleDescription,longText,helpText,null);
		ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription,longText,helpText,"");
        childDTO.setParentField(null);
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);

		fieldDTO.setChildfields(childList);
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);

		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);

		fields.add(requestDTO);

		dto.setFields(fields);

		ModuleRequestDTO moduleRequestDTO = new ModuleRequestDTO();
		moduleRequestDTO.setFields(dto.getFields());
		when(coreMetadataDAO.findFirstByFieldIdInAndModuleIdAndTenantId(any(), any(), any())).thenReturn(Optional.empty());

		coreMetadataServiceImpl.createDynamicFieldIds(moduleRequestDTO, 1L, "0",true);

		assertFalse(fieldDTO.getFieldId().isEmpty());
		assertFalse(childDTO.getFieldId().isEmpty());
	}

	@Test
	@DisplayName("Fetch Fields Count")
	void fetchFieldsCount() {

		when(coreMetadataDAO.countByModuleIdAndTenantId(1L, "0")).thenReturn(1L);

		Map<String,Long> count = coreMetadataServiceImpl.fieldCount(1L,"0");

		assertEquals(1L,count.get("count"));

		verify(coreMetadataDAO,atLeast(1)).countByModuleIdAndTenantId(1L, "0");

	}

	@Test
	@DisplayName("searchFieldsWithDescriptionTest method to Search fields with field description.")
	void searchFieldsWithDescriptionTest() {

		Pageable pageable = PageRequest.of(0, 10);

		List<CoreMetadataLangModel> metadataLang = new ArrayList<>();

		CoreMetadataLangModel description = new CoreMetadataLangModel();
		description.setFieldId("fieldId");
		metadataLang.add(description);

		List<CoreMetadataModel> metadataFields = new ArrayList<>();

		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");

		metadataFields.add(metadataModel);

		FieldDTO fieldDto = new FieldDTO();
		fieldDto.setModuleId(1L);
		fieldDto.setStructureId("1");
		fieldDto.setFieldId("fieldId");


		CoreModuleModel module = new CoreModuleModel();
		module.setModuleId(1L);

		when(coreMetadataLangDAO.findBySearchTerm(1L,"en", "0", "De",pageable)).thenReturn(metadataLang);
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldId(1L,"0", "fieldId")).thenReturn(metadataFields.get(0));
		when(coreLayoutHeaderService.generateMetadataField(any(), any(), any(), any())).thenReturn(fieldDto);

		List<FieldWithDescriptionResponseDTO> response = coreMetadataServiceImpl.searchByDesc(1L,"0", "De",0,10, "en");

		assertNotNull(response);
		verify(coreMetadataLangDAO, atLeast(1)).findBySearchTerm(1L,"en", "0", "De",pageable);
		verify(coreMetadataDAO, atLeast(1)).findByModuleIdAndTenantIdAndFieldId(1L,"0", "fieldId");
		verify(coreLayoutHeaderService, atLeast(1)).generateMetadataField(any(), any(), any(), any());
	}

	@Test
	@DisplayName("Set Grid Key Field Test")
	void setGridFieldTest() {

		CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

		List<FieldsRequestDTO> fields = new ArrayList<>();

		Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription("Earth");
		Map<String, String>longText =createMap();
		Map<String, String> helpText =createMap();
		Map<String, ModuleDescriptionInformationRequestDTO> letterModuleDescription =createModuleDescription("1wer");

		FieldDTO fieldDTO = createFieldDto(moduleDescription,longText,helpText,"LAND");
		fieldDTO.setIsKeyField(true);
		FieldDTO gridField = createFieldDto(moduleDescription,longText,helpText,"GRID");

		ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription,longText,helpText,"child");

		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);

		gridField.setChildfields(childList);

		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		fieldlist.add(fieldDTO);
		fieldlist.add(gridField);

		FieldsRequestDTO requestDTO = new FieldsRequestDTO();
		requestDTO.setStructureid("2");
		requestDTO.setFieldlist(fieldlist);

		fields.add(requestDTO);

		dto.setFields(fields);

		CoreMetadataModel model = new CoreMetadataModel();
		copyProperties(gridField,model);
        model.setFieldId("New");
        model.setStructureId(Short.parseShort("2"));
		List<CoreMetadataModel> list = new ArrayList<>(){{add(model);}};

		ModuleRequestDTO moduleRequestDTO = new ModuleRequestDTO();
		moduleRequestDTO.setFields(dto.getFields());

		when(coreModuleDAO.findByModuleIdAndTenantId(any(), any())).thenReturn(new CoreModuleModel());
		when(coreMetadataDAO.findByPickListAndModuleIdAndTenantIdAndIsSubGridAndStructureIdIn(anyString(),anyLong(),anyString(),anyBoolean(),anyList())).thenReturn(list);
		//when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", "GRID", "GRID")).thenReturn(list);
		when(coreStructureDAO.findChildStructureByStructureIdAndModuleIdAndTenantId(List.of(Short.parseShort("2")),1L,"0")).thenReturn(List.of(Short.parseShort("3")));

		when(generationImpl.generateDynamicTables(anyLong(), anyString(), any())).thenReturn(true);
		when(generationImpl.createUpdateDynamicIndex(anyLong(), anyString(), any())).thenReturn(true);

		CreateFieldResponseDTO responseDTO = coreMetadataServiceImpl.createField(dto,"0","Admin",1L);
		assertTrue(responseDTO.isAcknowledge());

	}

	@Test
	@DisplayName("get key fields test")
	void getKeyField() {

		CoreMetadataModel model = new CoreMetadataModel();
		model.setFieldId("rt");

		List<CoreMetadataModel> modelList = Collections.singletonList(model);

		when(coreStructureDAO.findParentStructureByStructureIdAndModuleIdAndTenantId(any(),anyLong(),anyString(),anyBoolean())).thenReturn(null);

		when(coreMetadataDAO.findKeyFieldByStructureList(anyString(),anyList(),anyLong(),anyString(),anyBoolean(),eq(PageRequest.of(1,1)))).thenReturn(modelList);

		List<FieldDTO> fieldDTOList = coreMetadataServiceImpl.getkeyFields(Short.parseShort("3"),"0","admin",1L,"",1,1);

		assertNotNull(fieldDTOList);
	}

	private FieldDTO createFieldDto(Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription,Map<String, String> longText,
									Map<String, String> helpText,String fieldId){

		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId(fieldId);
		fieldDTO.setShortText(moduleDescription);
		fieldDTO.setLongtexts(longText);
		fieldDTO.setHelptexts(helpText);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
	    return fieldDTO;
	}

	private ChildFieldsDTO createChildFieldDTO(Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription,Map<String, String> longText,
											   Map<String, String> helpText,String fieldId){

		ChildFieldsDTO childDTO = new ChildFieldsDTO();
		childDTO.setFieldId(fieldId);
		childDTO.setShortText(moduleDescription);
		childDTO.setLongtexts(longText);
		childDTO.setHelptexts(helpText);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		return childDTO;
	}

	private Map<String, ModuleDescriptionInformationRequestDTO> createModuleDescription(String description) {

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription(description);
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);
		return  moduledescription;
	}

	private Map<String,String> createMap() {
		Map<String, String> text = new HashMap<>();
		text.put("en", "Material");
		text.put("fr", "matériel");
		text.put("sp", "tipo de material");
		text.put("gj", "tipo de material");
		return text;
	}
	
	@Test
	@DisplayName("createReferenceRuleTest method to test creating metadata reference rules.")
	public void createReferenceRuleTest() {
		
		ReferenceRuleRequestDTO dto = new ReferenceRuleRequestDTO();
		
		dto.setFieldId("any");
		dto.setModuleId(1L);	
		Short orderData = 1;
		dto.setOrderData(orderData);
		dto.setReferencedFieldId("any");
		dto.setReferencedModuleId(1L);
		
		CoreMetadataReferenceRuleModel modelData = new CoreMetadataReferenceRuleModel();
		
		modelData.setFieldId("any");
		modelData.setModuleId(1L);	
		Short order_Data = 1;
		modelData.setOrderData(order_Data);	
		modelData.setReferencedFieldId("any");
		modelData.setReferencedModuleId(1L);
		modelData.setReferenceUuid(UUID.randomUUID());
		
		ReferenceRuleResponseDTO responseDTO = coreMetadataServiceImpl.createReferenceRule(dto, "any");
		
		assertTrue(responseDTO.isAcknowledge());
	}
	
	@Test
	@DisplayName("createReferenceRuleTest method to test creating metadata reference rules.")
	public void createReferenceRuleTest1() {
		
		ReferenceRuleRequestDTO dto = new ReferenceRuleRequestDTO();
		
		dto.setFieldId("any");
		dto.setModuleId(1L);	
		Short orderData = 1;
		dto.setOrderData(orderData);
		dto.setReferencedFieldId("any");
		dto.setReferencedModuleId(1L);	
		
		when(coreMetadataReferenceRuleDAO.save(new CoreMetadataReferenceRuleModel())).thenThrow(new IllegalArgumentException());
		ReferenceRuleResponseDTO responseDTO = coreMetadataServiceImpl.createReferenceRule(dto, "any");
		
		assertFalse(responseDTO.isAcknowledge());
	}
	
	@Test
	@DisplayName("updateReferenceRuleTest method to test updating metadata reference rules.")
	public void updateReferenceRuleTest() {
		
		ReferenceRuleRequestDTO dto = new ReferenceRuleRequestDTO();
		
		dto.setFieldId("any");
		dto.setModuleId(1L);	
		Short order_Data = 1;
		dto.setOrderData(order_Data);	
		dto.setReferencedFieldId("any");
		dto.setReferencedModuleId(1L);	
		
		CoreMetadataReferenceRuleModel modelData = new CoreMetadataReferenceRuleModel();
		
		modelData.setFieldId("any");
		modelData.setModuleId(1L);	
		Short orderData = 1;
		modelData.setOrderData(orderData);	
		modelData.setReferencedFieldId("any");
		modelData.setReferencedModuleId(1L);
		modelData.setReferenceUuid(UUID.randomUUID());
		
		Optional<CoreMetadataReferenceRuleModel> model = Optional.of(modelData);
		when(coreMetadataReferenceRuleDAO.findById("any")).thenReturn(model);
		ReferenceRuleResponseDTO responseDTO = coreMetadataServiceImpl.updateReferenceRule(dto, "any");
		
		assertTrue(responseDTO.isAcknowledge());
	}
	
	@Test
	@DisplayName("updateReferenceRuleTest method to test updating metadata reference rules.")
	public void updateReferenceRuleTest1() {
		
		ReferenceRuleRequestDTO dto = new ReferenceRuleRequestDTO();
		
		dto.setFieldId("any");
		dto.setModuleId(1L);	
		Short orderData = 1;
		dto.setOrderData(orderData);
		dto.setReferencedFieldId("any");
		dto.setReferencedModuleId(1L);	
		
		when(coreMetadataReferenceRuleDAO.findById("any")).thenThrow(new NoSuchElementException());
		ReferenceRuleResponseDTO responseDTO = coreMetadataServiceImpl.updateReferenceRule(dto, "any");
		
		assertFalse(responseDTO.isAcknowledge());
	}
}
