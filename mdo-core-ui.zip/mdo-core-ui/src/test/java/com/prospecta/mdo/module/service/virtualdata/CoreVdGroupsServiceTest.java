package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdHeaderDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupsRequestDTO;
import com.prospecta.mdo.module.enums.GroupType;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class CoreVdGroupsServiceTest {

	@InjectMocks
	private CoreVdGroupsServiceImpl coreVdGroupsServiceImpl;

	@Mock
	private CoreVdGroupsDAO coreVdGroupsDAO;

	@Mock
	private CoreVdHeaderDAO coreVdHeaderDAO;

	@BeforeAll
	void init() {
		coreVdGroupsServiceImpl = new CoreVdGroupsServiceImpl();
	}

	@Test
	@DisplayName("getVdGroupsbyvdIdTest method test for getting virtual dataset groups by vdId")
	void getVdGroupsbyvdIdTest() {
		CoreVdHeaderModel coreVdHeaderModel = spy(CoreVdHeaderModel.class);
		coreVdHeaderModel.setVdName("sample virual dataset name");
		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		List<CoreVdGroupsModel> coreVdGroupsModelList = new ArrayList<>();
		coreVdGroupsModelList.add(coreVdGroupsModel);
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findByCoreVdHeader(coreVdHeaderModel)).thenReturn(coreVdGroupsModelList);
		when(coreVdHeaderDAO.findById(id)).thenReturn(Optional.of(coreVdHeaderModel));

		List<CoreVdGroupsModel> coreVdGroupsList = coreVdGroupsServiceImpl.getVdGroupsbyvdId(id);
		assertNotNull(coreVdGroupsList);
		verify(coreVdHeaderDAO, atLeast(1)).findById(any());
		verify(coreVdGroupsDAO, atLeast(1)).findByCoreVdHeader(any());
	}
	
	@Test
	@DisplayName("getVdGroupsbyvdIdExceptionTest method test for test exception")
	void getVdGroupsbyvdIdExceptionTest() {
		CoreVdHeaderModel coreVdHeader = null;
		UUID id = UUID.randomUUID();
		when(coreVdHeaderDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdHeader));
		assertThrows(NotFound404Exception.class,()->coreVdGroupsServiceImpl.getVdGroupsbyvdId(id));
		verify(coreVdHeaderDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdGroupsbyGroupIdTest method test for getting virtual dataset groups by GroupId")
	void getVdGroupsbyGroupIdTest() {

		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		coreVdGroupsModel = coreVdGroupsServiceImpl.getVdGroupsbyGroupId(id);
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());

	}
	
	@Test
	@DisplayName("getVdGroupsbyGroupIdExceptionTest method test for test exception")
	void getVdGroupsbyGroupIdExceptionTest() {

		CoreVdGroupsModel coreVdGroupsModel =null;
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class,()->coreVdGroupsServiceImpl.getVdGroupsbyGroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());

	}
	
	@Test
	@DisplayName("deleteVdGroupsbyvdIdTest method test for deleting virtual dataset groups by vdId")
	void deleteVdGroupsbyvdIdTest() {
		CoreVdHeaderModel coreVdHeaderModel= new CoreVdHeaderModel();
		UUID id = UUID.randomUUID();
		when(coreVdHeaderDAO.findById(id)).thenReturn(Optional.of(coreVdHeaderModel));
		doNothing().when(coreVdGroupsDAO).deleteByCoreVdHeader(coreVdHeaderModel);
		coreVdGroupsServiceImpl.deleteVdGroupsbyvdId(id);
		verify(coreVdGroupsDAO, atLeast(1)).deleteByCoreVdHeader(any());
		verify(coreVdHeaderDAO, atLeast(1)).findById(any());

	}
	
	@Test
	@DisplayName("deleteVdGroupsbyvdIdExceptionTest method test for test exception")
	void deleteVdGroupsbyvdIdExceptionTest() {
		CoreVdHeaderModel coreVdHeader = null;
		UUID id = UUID.randomUUID();
		when(coreVdHeaderDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdHeader));
		assertThrows(NotFound404Exception.class,()->coreVdGroupsServiceImpl.deleteVdGroupsbyvdId(id));
		verify(coreVdHeaderDAO, atLeast(1)).findById(any());

	}

	@Test
	@DisplayName("deleteVdGroupsbyGroupIdTest method test for deleting virtual dataset groups by GroupId")
	void deleteVdGroupsbyGroupIdTest() {
		UUID id = UUID.randomUUID();
		doNothing().when(coreVdGroupsDAO).deleteById(id);
		coreVdGroupsServiceImpl.deleteVdGroupsbyGroupId(id);
		verify(coreVdGroupsDAO, atLeast(1)).deleteById(any());
	}
	
	@Test
	@DisplayName("saveOrUpdateVdGroupsTest method test for test save or update")
	void saveOrUpdateVdGroupsTest() {
		VdGroupsRequestDTO groupsRequestDTO = new VdGroupsRequestDTO();
		groupsRequestDTO.setGroupId(UUID.randomUUID());
		groupsRequestDTO.setGroupName("sample group name");
		groupsRequestDTO.setGroupType("JOIN");
		groupsRequestDTO.setTenantId("M0001");
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Sample vdName");
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		copyProperties(groupsRequestDTO, coreVdGroupsModel);
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		coreVdGroupsModel.setGroupType(GroupType.fromValue(groupsRequestDTO.getGroupType()));
		when(coreVdGroupsDAO.save(coreVdGroupsModel)).thenReturn(coreVdGroupsModel);
		coreVdGroupsServiceImpl.saveOrUpdateVdGroups(groupsRequestDTO, coreVdHeaderModel,"M0001");
		verify(coreVdGroupsDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("saveOrUpdateVdGroupsWithGroupIdNullTest method test for test save or update")
	void saveOrUpdateVdGroupsWithGroupIdNullTest() {

		VdGroupsRequestDTO groupsRequestDTO = new VdGroupsRequestDTO();
		groupsRequestDTO.setGroupId(null);
		groupsRequestDTO.setGroupName("sample group name");
		groupsRequestDTO.setGroupType("JOIN");
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Sample vdName");
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		copyProperties(groupsRequestDTO, coreVdGroupsModel);
		coreVdGroupsModel.setGroupId(any());
		
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		coreVdGroupsModel.setGroupType(GroupType.fromValue(groupsRequestDTO.getGroupType()));
		when(coreVdGroupsDAO.save(coreVdGroupsModel)).thenReturn(coreVdGroupsModel);
		coreVdGroupsServiceImpl.saveOrUpdateVdGroups(groupsRequestDTO, coreVdHeaderModel,"M0001");
		verify(coreVdGroupsDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("saveOrUpdateWithNullDTOTest method test for test save or update")
	void saveOrUpdateWithNullDTOTest() {
		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Sample vdName");
		assertThrows(NotFound404Exception.class, ()-> coreVdGroupsServiceImpl.saveOrUpdateVdGroups(null, coreVdHeaderModel,"M0001"));
	}
	
	@Test
	@DisplayName("saveOrUpdateWithNullModelTest method test for test save or update")
	void saveOrUpdateWithNullModelTest() {
		
		VdGroupsRequestDTO groupsRequestDTO = new VdGroupsRequestDTO();
		groupsRequestDTO.setGroupId(UUID.randomUUID());
		groupsRequestDTO.setGroupName("sample group name");
		groupsRequestDTO.setGroupType("JOIN");
		assertThrows(NotFound404Exception.class, ()-> coreVdGroupsServiceImpl.saveOrUpdateVdGroups(groupsRequestDTO, null,"M0001"));
	}
	
	@Test
	@DisplayName("saveOrUpdateVdGroupsCatchTest method test for test save or update")
	void saveOrUpdateVdGroupsCatchTest() {
		VdGroupsRequestDTO groupsRequestDTO = new VdGroupsRequestDTO();
		groupsRequestDTO.setGroupId(UUID.randomUUID());
		groupsRequestDTO.setGroupName("sample group name");
		groupsRequestDTO.setGroupType("JOIN");
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Sample vdName");
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		copyProperties(groupsRequestDTO, coreVdGroupsModel);
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		coreVdGroupsModel.setGroupType(GroupType.fromValue(groupsRequestDTO.getGroupType()));
		when(coreVdGroupsDAO.save(coreVdGroupsModel)).thenThrow(new RuntimeException());
		assertThrows(RuntimeException.class, ()-> coreVdGroupsServiceImpl.saveOrUpdateVdGroups(groupsRequestDTO, coreVdHeaderModel,"M0001"));
	}
	
	@Test
	@DisplayName("deleteCoreVdGroupTest method test for deleting virtual dataset groups by vdId")
	void deleteCoreVdGroupTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		List<VdGroupsRequestDTO> groupsRequestDTOs = new ArrayList<VdGroupsRequestDTO>();
		VdGroupsRequestDTO groupsRequestDTO= new VdGroupsRequestDTO();
		groupsRequestDTO.setGroupId(UUID.randomUUID());
		groupsRequestDTOs.add(groupsRequestDTO);
		List<CoreVdGroupsModel> coreVdGroupsModel = new ArrayList<CoreVdGroupsModel>();		
		CoreVdGroupsModel vdGroupsModel =new CoreVdGroupsModel();
		vdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.add(vdGroupsModel);
		when(coreVdHeaderDAO.findById(any())).thenReturn(Optional.of(coreVdHeaderModel));
		when(coreVdGroupsDAO.findByCoreVdHeader(any())).thenReturn(coreVdGroupsModel);
		doNothing().when(coreVdGroupsDAO).deleteByGroupIdIn(any());	
		coreVdGroupsServiceImpl.deleteCoreVdGroup(groupsRequestDTOs,UUID.randomUUID());
		verify(coreVdGroupsDAO, atLeast(1)).deleteByGroupIdIn(any());
	}
	
	@Test
	@DisplayName("deleteCoreVdGroupCatchTest method test for deleting virtual dataset groups by vdId")
	void deleteCoreVdGroupCatchTest() {			
		List<VdGroupsRequestDTO> groupsRequestDTOs = new ArrayList<VdGroupsRequestDTO>();
		assertThrows(Exception.class, ()-> coreVdGroupsServiceImpl.deleteCoreVdGroup(groupsRequestDTOs, any()));
	}
	
	@Test
	@DisplayName("saveOrUpdateVdGroupsWithNullTest method test for check null")
	void saveOrUpdateVdGroupsWithNullTest() {
		VdGroupsRequestDTO groupsRequestDTO = new VdGroupsRequestDTO();
		groupsRequestDTO.setGroupId(UUID.randomUUID());
		groupsRequestDTO.setGroupName("sample group name");
		groupsRequestDTO.setGroupType("JOIN");
		groupsRequestDTO.setTenantId(null);
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Sample vdName");
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		copyProperties(groupsRequestDTO, coreVdGroupsModel);
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		coreVdGroupsModel.setGroupType(GroupType.fromValue(groupsRequestDTO.getGroupType()));
		assertThrows(RuntimeException.class,()->coreVdGroupsServiceImpl.saveOrUpdateVdGroups(groupsRequestDTO, coreVdHeaderModel,null));
	}
	
	
}
