package com.prospecta.mdo.module.dao.virtualdata;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransRuleReplaceModel;

@ActiveProfiles("test")
@DataJpaTest
class CoreVdTransRuleReplaceDaoTest {
	
	@Autowired
    private TestEntityManager entityManager;
	
	@Autowired
    private CoreVdTransRuleReplaceDAO coreVdTransRuleReplaceDAO;

	@DisplayName("findByCoreVdTransFieldSettingTest -> find trans rule replace by field setting")
	@Test
	void findByCoreVdTransFieldSettingTest() {		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		coreVdGrpTransInfoModel.setUuid(UUID.randomUUID());
		coreVdGrpTransInfoModel.setCoreVdGroups(coreVdGroupsModel);
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = new CoreVdTransFieldSettingModel();
		coreVdTransFieldSettingModel.setTransId(UUID.randomUUID());
		coreVdTransFieldSettingModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdTransFieldSettingModel.setCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		coreVdTransFieldSettingModel.setFieldName("Test field name");
		CoreVdTransRuleReplaceModel coreVdTransRuleReplaceModel = new CoreVdTransRuleReplaceModel();
		coreVdTransRuleReplaceModel.setVdReplaceId(UUID.randomUUID());
		coreVdTransRuleReplaceModel.setCoreVdTransFieldSetting(coreVdTransFieldSettingModel);
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.persist(coreVdGrpTransInfoModel);
		entityManager.persist(coreVdTransFieldSettingModel);
		entityManager.persist(coreVdTransRuleReplaceModel);
		entityManager.flush();
		List<CoreVdTransRuleReplaceModel> actualList = coreVdTransRuleReplaceDAO.findByCoreVdTransFieldSetting(coreVdTransFieldSettingModel);
		assertEquals(actualList.get(0).getCoreVdTransFieldSetting().getFieldName(),coreVdTransFieldSettingModel.getFieldName(), "Trans rule replace found is different than expected");
	}
	
	@DisplayName("deleteByCoreVdTransFieldSettingTest -> delete trans rule replace by field setting")
	@Test
	void deleteByCoreVdTransFieldSettingTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		coreVdGrpTransInfoModel.setUuid(UUID.randomUUID());
		coreVdGrpTransInfoModel.setCoreVdGroups(coreVdGroupsModel);
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = new CoreVdTransFieldSettingModel();
		coreVdTransFieldSettingModel.setTransId(UUID.randomUUID());
		coreVdTransFieldSettingModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdTransFieldSettingModel.setCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		coreVdTransFieldSettingModel.setFieldName("Test field name");
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.persist(coreVdGrpTransInfoModel);
		entityManager.persist(coreVdTransFieldSettingModel);
		entityManager.flush();
		coreVdTransRuleReplaceDAO.deleteByCoreVdTransFieldSetting(coreVdTransFieldSettingModel);
		List<CoreVdTransRuleReplaceModel> actualList = coreVdTransRuleReplaceDAO.findByCoreVdTransFieldSetting(coreVdTransFieldSettingModel);
		assertTrue(actualList.isEmpty(),"Trans rule replace is deleted.");
	}
}
