/**
 * 
 */
package com.prospecta.mdo.module.rest.layout;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.prospecta.mdo.module.component.JWTTokenProvider;
import com.prospecta.mdo.module.dto.elastic.MDORecordES;
import com.prospecta.mdo.module.dto.layout.*;
import com.prospecta.mdo.module.enums.FieldType;
import com.prospecta.mdo.module.service.layout.CoreLayoutHeaderService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * @author savan
 *
 */
@SpringBootTest
@ActiveProfiles("Test")
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
public class LayoutRestControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private JWTTokenProvider jWTTokenProvider;
	
	@MockBean
	private CoreLayoutHeaderService coreLayoutHeaderService;
	
	private static final String PAYLOAD = "{\"username\":\"Admin\",\"roles\":[],\"tenantCode\":\"0\"}";
	
	@Test
	@DisplayName("Test case for createLayoutTest controller method to Create Layout.")
	@WithMockUser
	public void createLayoutTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		LayoutRequestDTO dto = new LayoutRequestDTO();
		dto.setDescription("Test Layout Name");
		dto.setType("0");

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);

		LayoutResponseDTO responseDTO = new LayoutResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreLayoutHeaderService.createLayout(any(), any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc.perform(post("/layout/{MODULEID}/create", 1L).header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isCreated());

		verify(coreLayoutHeaderService).createLayout(any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for createLayoutTest1 controller method to test validation")
	@WithMockUser
	public void createLayoutTest1() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		LayoutRequestDTO dto = new LayoutRequestDTO();
		dto.setDescription("Test Layout Name");
		dto.setType("0");

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);

			LayoutResponseDTO responseDTO = new LayoutResponseDTO();
		responseDTO.setAcknowledge(false);

		when(coreLayoutHeaderService.createLayout(any(), any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc.perform(post("/layout/{MODULEID}/create", 1L).header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());

		verify(coreLayoutHeaderService).createLayout(any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for updateLayoutTest controller method to Update Layout.")
	@WithMockUser
	public void updateLayoutTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		LayoutRequestDTO dto = new LayoutRequestDTO();
		dto.setDescription("Test Layout Name-update");
		dto.setType("0");

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);

		LayoutResponseDTO responseDTO = new LayoutResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreLayoutHeaderService.updateLayout(any(), any(), any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc.perform(put("/layout/{MODULEID}/{LAYOUTID}/update", 1L,"1444a553-1d90-4ee1-9b83-eaa68a28f17a").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());

		verify(coreLayoutHeaderService).updateLayout(any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for updateLayoutTest1 controller method to test internal server error.")
	@WithMockUser
	public void updateLayoutTest1() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		LayoutRequestDTO dto = new LayoutRequestDTO();
		dto.setDescription("Test Layout Name-update");
		dto.setType("0");

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);

		LayoutResponseDTO responseDTO = new LayoutResponseDTO();
		responseDTO.setAcknowledge(false);

		when(coreLayoutHeaderService.updateLayout(any(), any(), any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc.perform(put("/layout/{MODULEID}/{LAYOUTID}/update", 1L,"1444a553-1d90-4ee1-9b83-eaa68a28f17a").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());

		verify(coreLayoutHeaderService).updateLayout(any(), any(), any(), any(), any());
	}
	

	@Test
	@DisplayName("getLayoutTest method to test to fetch Layout")
	@WithMockUser
	public void getLayoutTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		List<FetchedLayoutDTO> response = new ArrayList<>();

		FetchedLayoutDTO fetchDTO = new FetchedLayoutDTO();
		fetchDTO.setTabText("tab text");
		
		response.add(fetchDTO);
		
		when(coreLayoutHeaderService.getLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0")).thenReturn(response);
		
		this.mockMvc.perform(
				get("/layout/layoutdetails/{MODULEID}/{LAYOUTID}/{LANGUAGE}", 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "en")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());
		
		verify(coreLayoutHeaderService, atLeast(1)).getLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");
	}
	
	@Test
	@DisplayName("getLayoutTest1 method to test to fetch Layout")
	@WithMockUser
	public void getLayoutTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		when(coreLayoutHeaderService.getLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0")).thenReturn(null);
		
		this.mockMvc.perform(
				get("/layout/layoutdetails/{MODULEID}/{LAYOUTID}/{LANGUAGE}", 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "en")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isInternalServerError());
		
		verify(coreLayoutHeaderService, atLeast(1)).getLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");
	}
	
	@Test
	@DisplayName("getLayoutTest2 method to test to fetch Layout")
	@WithMockUser
	public void getLayoutTest2() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		List<FetchedLayoutDTO> response = new ArrayList<>();

		when(coreLayoutHeaderService.getLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0")).thenReturn(response);
		
		this.mockMvc.perform(
				get("/layout/layoutdetails/{MODULEID}/{LAYOUTID}/{LANGUAGE}", 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "en")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isInternalServerError());
		
		verify(coreLayoutHeaderService, atLeast(1)).getLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");
	}
	
	@Test
	@DisplayName("createUpdateLayoutTabTest method to test creation and updation of layout tab")
	@WithMockUser
	public void createUpdateLayoutTabTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		LayoutTabDTO requestDTO = new LayoutTabDTO();
		requestDTO.setIsTabReadOnly(true);
		requestDTO.setTabOrder((short)1);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(requestDTO);
		
		LayoutTabResponseDTO responseDTO = new LayoutTabResponseDTO();
		responseDTO.setAcknowledge(true);
		
		when(coreLayoutHeaderService.createUpdateLayoutTab(requestDTO, 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "0"))
				.thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/layout/{MODULEID}/assignTab/{LAYOUTID}", 1L,"1444a553-1d90-4ee1-9b83-eaa68a28f17a").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isCreated());
		
		verify(coreLayoutHeaderService, atLeast(1)).createUpdateLayoutTab(requestDTO, 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "0");
	}
	
	@Test
	@DisplayName("createUpdateLayoutTabTest1 method to test Internal server error")
	@WithMockUser
	public void createUpdateLayoutTabTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		LayoutTabDTO requestDTO = new LayoutTabDTO();
		requestDTO.setIsTabReadOnly(true);
		requestDTO.setTabOrder((short)1);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(requestDTO);
		
		LayoutTabResponseDTO responseDTO = new LayoutTabResponseDTO();
		responseDTO.setAcknowledge(false);
		
		when(coreLayoutHeaderService.createUpdateLayoutTab(requestDTO, 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "0"))
				.thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/layout/{MODULEID}/assignTab/{LAYOUTID}", 1L,"1444a553-1d90-4ee1-9b83-eaa68a28f17a").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());
		
		verify(coreLayoutHeaderService, atLeast(1)).createUpdateLayoutTab(requestDTO, 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "0");
	}
	
	@Test
	@DisplayName("prepareMDOESRecordTest method to test to Prepare and return MDOESRecord JSON based on layout and Fields")
	@WithMockUser
	public void prepareMDOESRecordTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		MDORecordES response = new MDORecordES();

		when(coreLayoutHeaderService.prepareMDOESRecord("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0")).thenReturn(response);
		
		this.mockMvc.perform(
				get("/layout/prepare-mdoesrecord/{MODULEID}/{LAYOUTID}/{LANGUAGE}", 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "en")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());
		
		verify(coreLayoutHeaderService, atLeast(1)).prepareMDOESRecord("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");
	}
	
	@Test
	@DisplayName("prepareMDOESRecordTest1 method to test to check if response is null")
	@WithMockUser
	public void prepareMDOESRecordTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		when(coreLayoutHeaderService.prepareMDOESRecord("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0")).thenReturn(null);
		
		this.mockMvc.perform(
				get("/layout/prepare-mdoesrecord/{MODULEID}/{LAYOUTID}/{LANGUAGE}", 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "en")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isInternalServerError());
		
		verify(coreLayoutHeaderService, atLeast(1)).prepareMDOESRecord("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");
	}

	@Test
	@DisplayName("Delete Layout Method Test")
	@WithMockUser
	void deleteLayoutTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		LayoutResponseDTO responseDTO=new LayoutResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreLayoutHeaderService.deleteLayout("1444a553-1d90-4ee1-9b83-eaa68a28f1","0")).thenReturn(responseDTO);

		this.mockMvc.perform(
				delete("/layout/delete").param("layoutId","1444a553-1d90-4ee1-9b83-eaa68a28f1")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());

		verify(coreLayoutHeaderService, atLeast(1)).deleteLayout("1444a553-1d90-4ee1-9b83-eaa68a28f1","0");
	}
	@Test
	@DisplayName("Fetch Layout Test")
	@WithMockUser
	void listLayoutTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		LayoutDetailsResponseDTO dto = new LayoutDetailsResponseDTO();
		dto.setLabels("test");
		List<LayoutDetailsResponseDTO> responseDTO=new ArrayList<>();
		responseDTO.add(dto);

		LayoutListRequestDTO listRequestDTO = new LayoutListRequestDTO();
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(listRequestDTO);
		when(coreLayoutHeaderService.listLayouts(any(),any(),any(),any(),any(),any(),any(),any())).thenReturn(responseDTO);

		this.mockMvc.perform(
				post("/layout/1/list")
						.param("fetchCount","0")
						.param("fetchSize","1")
						.param("searchTerm","")
						.param("dateCreated","")
						.param("dateModified","")
						.contentType(MediaType.APPLICATION_JSON)
						.content(requestJson)
						.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());

		verify(coreLayoutHeaderService, atLeast(1)).listLayouts(any(),any(),any(),any(),any(),any(),any(),any());
	}

	@Test
	@DisplayName("get Layout Test")
	@WithMockUser
	void getLayoutDtoTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		LayoutDetailsResponseDTO dto = new LayoutDetailsResponseDTO();
		dto.setLabels("test");

		when(coreLayoutHeaderService.getLayout(any(),any(),any())).thenReturn(dto);

		this.mockMvc.perform(
				get("/layout/1/get-layout")
						.param("layoutId","509415c9-92f8-473a-a898-9fb3d657a165")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());

		verify(coreLayoutHeaderService, atLeast(1)).getLayout(any(),any(),any());
	}
	@Test
	@DisplayName("Count Layout Test")
	@WithMockUser
	void countLayoutTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		Map<String,Long> map = new HashMap<>(){{put("count",1L);}};

		when(coreLayoutHeaderService.layoutCount(any(),any())).thenReturn(map);

		this.mockMvc.perform(
				get("/layout/1/count")
				.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());

		verify(coreLayoutHeaderService, atLeast(1)).layoutCount(any(),any());
	}

	@Test
	@DisplayName("Save Layout Details Test")
	@WithMockUser
	void saveLayoutDetailsTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		FetchedLayoutDTO dto = new FetchedLayoutDTO();
		dto.setIsTabHidden(false);

		FetchedLayoutDTO dtoUpdate = new FetchedLayoutDTO();
		dtoUpdate.setIsTabHidden(false);
		dtoUpdate.setTcode(UUID.randomUUID());

		LayoutFieldsDTO fieldsDTO = new LayoutFieldsDTO();
		fieldsDTO.setFieldType(FieldType.FIELD);
		fieldsDTO.setFieldId("Field");

		LayoutFieldsDTO fieldsDTOUpdate = new LayoutFieldsDTO();
		fieldsDTO.setFieldType(FieldType.FIELD);
		fieldsDTO.setFieldId("Field");
		fieldsDTO.setTabFieldUuid(UUID.randomUUID());


		dto.setFields(List.of(fieldsDTO));
		dtoUpdate.setFields(List.of(fieldsDTOUpdate));


		List<FetchedLayoutDTO> dtoList = List.of(dtoUpdate,dto);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dtoList);

		when(coreLayoutHeaderService.saveLayoutDetails(any(),any(),any(),any(),any(),any())).thenReturn(dtoList);

		this.mockMvc.perform(
				post("/layout/{moduleId}/save-layout-details/{layoutId}/{language}",1L,"509415c9-92f8-473a-a898-9fb3d657a165","en")
						.contentType(MediaType.APPLICATION_JSON)
						.content(requestJson)
						.header("authorization", "Bearer " + token))
				.andExpect(status().isCreated());

		verify(coreLayoutHeaderService, atLeast(1)).saveLayoutDetails(any(),any(),any(),any(),any(),any());
	}
	
	@Test
	@DisplayName("Test case for createLayoutTest controller method to Create or update rule mapping.")
	@WithMockUser
	public void createRuleMappingTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		RuleMappingRequestDTO ruleMappingRequestDTO = new RuleMappingRequestDTO();
		List<UUID> ruleMappingIds = new ArrayList<>();
		ruleMappingIds.add(UUID.randomUUID());
		ruleMappingIds.add(UUID.randomUUID());
		ruleMappingRequestDTO.setRuleMappingIds(ruleMappingIds);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(ruleMappingRequestDTO);

		RuleMappingResponseDTO responseDTO =new RuleMappingResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreLayoutHeaderService.createOrUpdateRuleMapping(any(), any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc.perform(put("/layout/{moduleId}/save-rule-mapping/{layoutId}", 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f1").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isCreated());

		verify(coreLayoutHeaderService).createOrUpdateRuleMapping(any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Delete Layout rule mapping Method Test")
	@WithMockUser
	void deleteRuleMappingTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		RuleMappingResponseDTO responseDTO=new RuleMappingResponseDTO();
		responseDTO.setAcknowledge(true);
		
		RuleMappingRequestDTO ruleMappingRequestDTO = new RuleMappingRequestDTO();
		List<UUID> ruleMappingIds = new ArrayList<>();
		ruleMappingIds.add(UUID.randomUUID());
		ruleMappingIds.add(UUID.randomUUID());
		ruleMappingRequestDTO.setRuleMappingIds(ruleMappingIds);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(ruleMappingRequestDTO);

		when(coreLayoutHeaderService.deleteRuleMapping(ruleMappingRequestDTO, 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f1", "0")).thenReturn(responseDTO);

		this.mockMvc.perform(
				delete("/layout/{moduleId}/delete-rule-mapping/{layoutId}",1L,"1444a553-1d90-4ee1-9b83-eaa68a28f1")
						.header("authorization", "Bearer " + token).contentType(MediaType.APPLICATION_JSON).content(requestJson))
				.andExpect(status().isOk());

		verify(coreLayoutHeaderService, atLeast(1)).deleteRuleMapping(ruleMappingRequestDTO, 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f1", "0");
	}
	
}
