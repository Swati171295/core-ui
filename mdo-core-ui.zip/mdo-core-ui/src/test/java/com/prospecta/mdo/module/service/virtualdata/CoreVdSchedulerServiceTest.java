package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.beans.BeanUtils.copyProperties;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Splitter;
import com.nimbusds.jose.JOSEException;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdHeaderDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdSchedulerDAO;
import com.prospecta.mdo.module.dto.virtualdata.CommonResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.CoreVdSchedulerRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.HeaderResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.ResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.RestJobRequestDTO;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdSchedulerModel;

/**
 * @author komal
 *
 */

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
public class CoreVdSchedulerServiceTest {

	@InjectMocks
	private CoreVdSchedulerServiceImpl coreVdSchedulerServiceImpl;
	
	@Mock
	private CommonService commonService;
	
	@Mock
	private WebClientImpl webClientImpl;
	
	@Mock
	private CoreVdSchedulerDAO coreVdSchedulerDAO;
	
	@Mock
	private CoreVdHeaderDAO coreVdHeaderDAO;
	
	@BeforeAll
	void init() {
		coreVdSchedulerServiceImpl = new CoreVdSchedulerServiceImpl();
		ReflectionTestUtils.setField(coreVdSchedulerServiceImpl, "serverUrl", "https://dev.masterdataonline.com/core");
	}
	
	@Test
	@DisplayName("scheduleJobTest1 method test for schedule the job")
	void scheduleJobTest1() throws JOSEException, JsonProcessingException {
		
		CoreVdSchedulerRequestDTO coreVdSchedulerRequestDTO = new CoreVdSchedulerRequestDTO();
		coreVdSchedulerRequestDTO.setVdId(UUID.randomUUID());
		coreVdSchedulerRequestDTO.setRestMethod("post");
		coreVdSchedulerRequestDTO.setRestEndpoint("sample rest endpoint");
		Map<String, String> map = new HashMap<>();
		map.put("value1", "value2");
		coreVdSchedulerRequestDTO.setRestParams(map);
		coreVdSchedulerRequestDTO.setRestBody("sample rest body");
		coreVdSchedulerRequestDTO.setTenantId("M00001");
		coreVdSchedulerRequestDTO.setStartTime(Timestamp.valueOf("2021-10-13 10:45:44"));
		coreVdSchedulerRequestDTO.setEndTime(Timestamp.valueOf("2021-10-14 10:45:44"));
		coreVdSchedulerRequestDTO.setCron("0 0 * * 0");

		HeaderResponseDTO headerResponseDTO=new HeaderResponseDTO();
		headerResponseDTO.setVdId(UUID.randomUUID());
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		ObjectMapper mapper = new ObjectMapper();
		CoreVdSchedulerModel coreVdSchedulerModel = new CoreVdSchedulerModel();
		copyProperties(coreVdSchedulerRequestDTO,coreVdSchedulerModel);
		coreVdSchedulerModel.setSchedulerId(UUID.randomUUID());
		coreVdSchedulerModel.setVdId(coreVdHeaderModel);
		coreVdSchedulerModel.setRestParams(mapper.writeValueAsString(coreVdSchedulerRequestDTO.getRestParams()));
		coreVdSchedulerModel.setVdObject(mapper.writeValueAsString(headerResponseDTO));
		coreVdSchedulerModel.setTenantId(coreVdSchedulerRequestDTO.getTenantId());
		
		RestJobRequestDTO restJobRequestDTO = new RestJobRequestDTO();
		copyProperties(coreVdSchedulerModel, restJobRequestDTO);
		restJobRequestDTO.setJobId(coreVdSchedulerModel.getSchedulerId());
		restJobRequestDTO.setVdId(coreVdSchedulerModel.getVdId().getVdId());
		restJobRequestDTO.setMs("CORE");
		restJobRequestDTO.setStartTime(Timestamp.valueOf("2021-10-13 10:45:44").getTime());
		restJobRequestDTO.setEndTime(Timestamp.valueOf("2021-10-14 10:45:44").getTime());
		restJobRequestDTO.setFqdn("https://dev.masterdataonline.com");
		restJobRequestDTO.setRestParams(Splitter.on(",").withKeyValueSeparator(":").split(coreVdSchedulerModel.getRestParams().replace("{", "").replace("}", "")));
		
		Long timeDiff = coreVdSchedulerRequestDTO.getEndTime().getTime() - coreVdSchedulerRequestDTO.getStartTime().getTime();
		assertNotEquals(timeDiff, 864000023);
		when(commonService.getVirtualDataset(any(),any())).thenReturn(new ResponseDTO());	
		when(coreVdHeaderDAO.findById(any())).thenReturn(Optional.of(coreVdHeaderModel));
		when(coreVdSchedulerDAO.save(any())).thenReturn(coreVdSchedulerModel);	
		assertTrue(scheduleJobForRest(coreVdSchedulerModel,""));
		doNothing().when(webClientImpl).saveScheduleJob(restJobRequestDTO,"");	
		coreVdSchedulerServiceImpl.scheduleJob(coreVdSchedulerRequestDTO, "");
		verify(webClientImpl, atLeast(1)).saveScheduleJob(any(),any());
	}
	
	private boolean scheduleJobForRest(CoreVdSchedulerModel coreVdSchedulerModel, String string) {
		return true;
	}
	
	@Test
	@DisplayName("scheduleJobTest method test for schedule the job")
	void scheduleJobTest() throws JOSEException, JsonProcessingException {
		
		CoreVdSchedulerRequestDTO coreVdSchedulerRequestDTO = new CoreVdSchedulerRequestDTO();
		coreVdSchedulerRequestDTO.setVdId(UUID.randomUUID());
		coreVdSchedulerRequestDTO.setRestMethod("ooo");
		coreVdSchedulerRequestDTO.setRestEndpoint("sample rest endpoint");
		Map<String, String> map = new HashMap<>();
		map.put("value1", "value2");
		coreVdSchedulerRequestDTO.setRestParams(map);
		coreVdSchedulerRequestDTO.setRestBody("sample rest body");
		coreVdSchedulerRequestDTO.setTenantId("M00001");
		coreVdSchedulerRequestDTO.setStartTime(Timestamp.valueOf("2021-10-13 10:45:44"));
		coreVdSchedulerRequestDTO.setEndTime(Timestamp.valueOf("2021-10-13 10:45:44"));
		coreVdSchedulerRequestDTO.setCron("0 0 * * 0");
		assertThrows(CommonVirtualDatasetException.class, ()-> coreVdSchedulerServiceImpl.scheduleJob(coreVdSchedulerRequestDTO, ""));
	}
	
	@Test
	@DisplayName("scheduleJobCatchTest method test for schedule the job")
	void scheduleJobCatchTest() throws JOSEException, JsonProcessingException {
		assertThrows(CommonVirtualDatasetException.class, ()-> coreVdSchedulerServiceImpl.scheduleJob(null, ""));
	}
	
	@Test
	@DisplayName("scheduleJobTest2 method test for schedule the job")
	void scheduleJobTest2() throws JOSEException, JsonProcessingException {
		
		CoreVdSchedulerRequestDTO coreVdSchedulerRequestDTO = new CoreVdSchedulerRequestDTO();
		coreVdSchedulerRequestDTO.setVdId(UUID.randomUUID());
		coreVdSchedulerRequestDTO.setRestMethod("post");
		coreVdSchedulerRequestDTO.setRestEndpoint("sample rest endpoint");
		Map<String, String> map = new HashMap<>();
		map.put("value1", "value2");
		coreVdSchedulerRequestDTO.setRestParams(map);
		coreVdSchedulerRequestDTO.setRestBody("sample rest body");
		coreVdSchedulerRequestDTO.setTenantId("M00001");
		coreVdSchedulerRequestDTO.setStartTime(Timestamp.valueOf("2021-10-13 10:45:44"));
		coreVdSchedulerRequestDTO.setEndTime(Timestamp.valueOf("2021-10-14 10:45:44"));
		coreVdSchedulerRequestDTO.setCron("0 0 * * 0");

		HeaderResponseDTO headerResponseDTO=new HeaderResponseDTO();
		headerResponseDTO.setVdId(UUID.randomUUID());
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		ObjectMapper mapper = new ObjectMapper();
		CoreVdSchedulerModel coreVdSchedulerModel = new CoreVdSchedulerModel();
		copyProperties(coreVdSchedulerRequestDTO,coreVdSchedulerModel);
		coreVdSchedulerModel.setSchedulerId(UUID.randomUUID());
		coreVdSchedulerModel.setRestParams(mapper.writeValueAsString(coreVdSchedulerRequestDTO.getRestParams()));
		coreVdSchedulerModel.setVdObject(mapper.writeValueAsString(headerResponseDTO));
		coreVdSchedulerModel.setTenantId(coreVdSchedulerRequestDTO.getTenantId());
		
		RestJobRequestDTO restJobRequestDTO = new RestJobRequestDTO();
		copyProperties(coreVdSchedulerModel, restJobRequestDTO);
		restJobRequestDTO.setJobId(coreVdSchedulerModel.getSchedulerId());
		restJobRequestDTO.setMs("CORE");
		restJobRequestDTO.setRestParams(Splitter.on(",").withKeyValueSeparator(":").split(coreVdSchedulerModel.getRestParams().replace("{", "").replace("}", "")));
		Long timeDiff = coreVdSchedulerRequestDTO.getEndTime().getTime() - coreVdSchedulerRequestDTO.getStartTime().getTime();
		assertNotEquals(timeDiff, 864000023);
		when(commonService.getVirtualDataset(any(),any())).thenReturn(new ResponseDTO());	
		when(coreVdHeaderDAO.findById(any())).thenReturn(Optional.of(coreVdHeaderModel));
		when(coreVdSchedulerDAO.save(any())).thenReturn(coreVdSchedulerModel);	
		assertTrue(scheduleJobForRest(coreVdSchedulerModel,""));
		assertThrows(CommonVirtualDatasetException.class, ()-> coreVdSchedulerServiceImpl.scheduleJob(coreVdSchedulerRequestDTO, ""));

	}
	@Test
	@DisplayName("scheduleJobExceptionTest method test for schedule the job")
	void scheduleJobExceptionTest() throws JOSEException, JsonProcessingException {
		
		CoreVdSchedulerRequestDTO coreVdSchedulerRequestDTO = new CoreVdSchedulerRequestDTO();
		coreVdSchedulerRequestDTO.setVdId(UUID.randomUUID());
		coreVdSchedulerRequestDTO.setRestMethod("ooo");
		coreVdSchedulerRequestDTO.setRestEndpoint("sample rest endpoint");
		Map<String, String> map = new HashMap<>();
		map.put("value1", "value2");
		coreVdSchedulerRequestDTO.setRestParams(map);
		coreVdSchedulerRequestDTO.setRestBody("sample rest body");
		coreVdSchedulerRequestDTO.setTenantId("M00001");
		coreVdSchedulerRequestDTO.setStartTime(Timestamp.valueOf("2021-10-13 10:45:44"));
		coreVdSchedulerRequestDTO.setEndTime(Timestamp.valueOf("2021-10-14 10:45:44"));
		coreVdSchedulerRequestDTO.setCron("0 0 * * 0");
		when(commonService.getVirtualDataset(any(),any())).thenReturn(new ResponseDTO());	
		assertThrows(CommonVirtualDatasetException.class, ()-> coreVdSchedulerServiceImpl.scheduleJob(coreVdSchedulerRequestDTO, ""));
	}
	
	@Test
	@DisplayName("sendToSparkJobVdIdNullTest method test for send data to spark exception handling")
	void sendToSparkJobVdIdNullTest() throws JOSEException, JsonProcessingException {
		assertThrows(CommonVirtualDatasetException.class, ()-> coreVdSchedulerServiceImpl.sendToSparkJob(null, ""));
	}
	
	@Test
	@DisplayName("sendToSparkJobVdNotFoundTest method test for send data to spark exception handling")
	void sendToSparkJobVdNotFoundTest() throws JOSEException, JsonProcessingException {
		when(coreVdHeaderDAO.findById(any())).thenReturn(Optional.empty());
		assertThrows(CommonVirtualDatasetException.class, ()-> coreVdSchedulerServiceImpl.sendToSparkJob(UUID.randomUUID(), ""));
	}
	
	@Test
	@DisplayName("sendToSparkJobSchedulerIdNullTest method test for send data to spark exception handling")
	void sendToSparkJobSchedulerIdNullTest() throws JOSEException, JsonProcessingException {
		when(coreVdHeaderDAO.findById(any())).thenReturn(Optional.of(new CoreVdHeaderModel()));
		when(coreVdSchedulerDAO.findByVdId(any())).thenReturn(Optional.empty());
		assertThrows(CommonVirtualDatasetException.class, ()-> coreVdSchedulerServiceImpl.sendToSparkJob(UUID.randomUUID(), ""));
	}
	
	@Test
	@DisplayName("sendToSparkJobTest method test for send data to spark")
	void sendToSparkJobTest() throws JOSEException, JsonProcessingException {
		when(coreVdHeaderDAO.findById(any())).thenReturn(Optional.of(new CoreVdHeaderModel()));
		CoreVdSchedulerModel coreVdSchedulerModel = new CoreVdSchedulerModel();
		coreVdSchedulerModel.setSchedulerId(UUID.randomUUID());
		when(coreVdSchedulerDAO.findByVdId(any())).thenReturn(Optional.of(coreVdSchedulerModel));
		when(webClientImpl.sendToSpark(any(),any())).thenReturn(any());
		CommonResponseDTO commonResponseDTO=coreVdSchedulerServiceImpl.sendToSparkJob(UUID.randomUUID(), "");
		assertEquals(true, commonResponseDTO.isSuccess());
	}

	@DisplayName("scheduleJobWithVdIdExistsTest method test for schedule the job")
	void scheduleJobWithVdIdExistsTest() throws JOSEException, JsonProcessingException {
		
		CoreVdSchedulerRequestDTO coreVdSchedulerRequestDTO = new CoreVdSchedulerRequestDTO();
		coreVdSchedulerRequestDTO.setVdId(UUID.randomUUID());
		coreVdSchedulerRequestDTO.setRestMethod("post");
		coreVdSchedulerRequestDTO.setRestEndpoint("sample rest endpoint");
		Map<String, String> map = new HashMap<>();
		map.put("value1", "value2");
		coreVdSchedulerRequestDTO.setRestParams(map);
		coreVdSchedulerRequestDTO.setRestBody("sample rest body");
		coreVdSchedulerRequestDTO.setTenantId("M00001");
		coreVdSchedulerRequestDTO.setStartTime(Timestamp.valueOf("2021-10-13 10:45:44"));
		coreVdSchedulerRequestDTO.setEndTime(Timestamp.valueOf("2021-10-14 10:45:44"));
		coreVdSchedulerRequestDTO.setCron("0 0 * * 0");

		HeaderResponseDTO headerResponseDTO=new HeaderResponseDTO();
		headerResponseDTO.setVdId(UUID.randomUUID());
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		ObjectMapper mapper = new ObjectMapper();
		CoreVdSchedulerModel coreVdSchedulerModel = new CoreVdSchedulerModel();
		copyProperties(coreVdSchedulerRequestDTO,coreVdSchedulerModel);
		coreVdSchedulerModel.setSchedulerId(UUID.randomUUID());
		coreVdSchedulerModel.setVdId(coreVdHeaderModel);
		coreVdSchedulerModel.setRestParams(mapper.writeValueAsString(coreVdSchedulerRequestDTO.getRestParams()));
		coreVdSchedulerModel.setVdObject(mapper.writeValueAsString(headerResponseDTO));
		coreVdSchedulerModel.setTenantId(coreVdSchedulerRequestDTO.getTenantId());
		
		RestJobRequestDTO restJobRequestDTO = new RestJobRequestDTO();
		copyProperties(coreVdSchedulerModel, restJobRequestDTO);
		restJobRequestDTO.setJobId(coreVdSchedulerModel.getSchedulerId());
		restJobRequestDTO.setVdId(coreVdSchedulerModel.getVdId().getVdId());
		restJobRequestDTO.setMs("CORE");
		restJobRequestDTO.setStartTime(Timestamp.valueOf("2021-10-13 10:45:44").getTime());
		restJobRequestDTO.setEndTime(Timestamp.valueOf("2021-10-14 10:45:44").getTime());
		restJobRequestDTO.setFqdn("https://dev.masterdataonline.com");
		restJobRequestDTO.setRestParams(Splitter.on(",").withKeyValueSeparator(":").split(coreVdSchedulerModel.getRestParams().replace("{", "").replace("}", "")));
		
		Long timeDiff = coreVdSchedulerRequestDTO.getEndTime().getTime() - coreVdSchedulerRequestDTO.getStartTime().getTime();
		assertNotEquals(timeDiff, 864000023);
		when(commonService.getVirtualDataset(any(),any())).thenReturn(new ResponseDTO());	
		when(coreVdHeaderDAO.findById(any())).thenReturn(Optional.of(coreVdHeaderModel));
		when(coreVdSchedulerDAO.findByVdId(any())).thenReturn(Optional.of(coreVdSchedulerModel));	
		when(coreVdSchedulerDAO.save(any())).thenReturn(coreVdSchedulerModel);	
		assertTrue(scheduleJobForRest(coreVdSchedulerModel,""));
		doNothing().when(webClientImpl).saveScheduleJob(restJobRequestDTO,"");	
		assertThrows(CommonVirtualDatasetException.class, ()-> coreVdSchedulerServiceImpl.scheduleJob(coreVdSchedulerRequestDTO, ""));
	}

}
