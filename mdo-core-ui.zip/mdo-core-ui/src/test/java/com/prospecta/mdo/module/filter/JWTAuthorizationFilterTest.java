package com.prospecta.mdo.module.filter;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;

import com.prospecta.mdo.module.component.JWTTokenProvider;
import com.prospecta.mdo.module.exception.JWTExpiredException;


@DisplayName("Test all methods of JWTAuthenticationFilterTest")
@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
@AutoConfigureMockMvc
class JWTAuthorizationFilterTest {
	
	private JWTTokenProvider jwtTokenProvider;
	
	private JWTAuthorizationFilter filter;

	private static final String token = "ZXlKMGVYQWlPaUpLVjFRaUxDSmhiR2NpT2lKSVV6STFOaUo5LmV5SnBjM01pT2lKUWNtOXpjR1ZqZEdFaUxDSnBZWFFpT2pFMk1UTXpOekU0T0RBc0ltVjRjQ0k2TVRnNU56TTJPRFk0TUN3aVlYVmtJam9pZDNkM0xuQnliM053WldOMFlTNWpiMjBpTENKemRXSWlPaUoxYzJWeVFIQnliM053WldOMFlTNWpiMjBpTENKMGIydGxibFZ6WlhKdVlXMWxJam9pVUhKdmFtVmpkQ0JCWkcxcGJtbHpkSEpoZEc5eUlpd2laWGh3YVhKNVJHRjBaU0k2SWpFNE9UTTBOVFl3TURBd01EQWlmUS5KLXdTNldYMmQ1YU1KQU05dVRGa3pUZnd0VWRPSFRXNFJGRTVfeDB5MXRB";
	
	@BeforeEach
	public void setUp() {
		this.jwtTokenProvider = mock(JWTTokenProvider.class);
		this.filter = new JWTAuthorizationFilter(this.jwtTokenProvider);
	}
	
	@DisplayName(value = "doFilter, normal flow of refresh token")
	@Test
	void doFilterTest1() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "Bearer " + token);
		request.setServletPath("/signUp");
		request.setMethod("POST");
		
		JSONObject payload = new JSONObject();
		payload.put("username", "user");
		
		when(jwtTokenProvider.resolveToken(any(HttpServletRequest.class))).thenReturn(token);
		when(jwtTokenProvider.getPayload(token)).thenReturn(payload.toString());
		
		FilterChain chain = mock(FilterChain.class);
		this.filter.doFilter(request, new MockHttpServletResponse(), chain);
		
		verify(jwtTokenProvider, atLeast(1)).resolveToken(any(HttpServletRequest.class));
		verify(jwtTokenProvider, atLeast(1)).getPayload(token);
		
	}
	
	@DisplayName(value = "doFilter, test first catch block")
	@Test
	void doFilterTest2() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "Bearer " + token);
		request.setServletPath("/signUp");
		request.setMethod("POST");
		
		JSONObject payload = new JSONObject();
		payload.put("username", "user");
		
		when(jwtTokenProvider.resolveToken(any(HttpServletRequest.class))).thenReturn(token);
		when(jwtTokenProvider.getPayload(token)).thenThrow(new ParseException("test exception successful", 0)).thenThrow(new JWTExpiredException("test exception successful"));
		
		FilterChain chain = mock(FilterChain.class);

		this.filter.doFilter(request, new MockHttpServletResponse(), chain);
		this.filter.doFilter(request, new MockHttpServletResponse(), chain);
		
		verify(jwtTokenProvider, atLeast(1)).resolveToken(any(HttpServletRequest.class));
		verify(jwtTokenProvider, atLeast(2)).getPayload(token);
		
	}

	@DisplayName(value = "doFilter, if token is null")
	@Test
	void doFilterTest3() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "Bearer " + token);
		request.setServletPath("/signUp");
		request.setMethod("POST");
		assertNotNull(request);
		
		FilterChain chain = mock(FilterChain.class);
		this.filter.doFilter(request, new MockHttpServletResponse(), chain);
	}

	@DisplayName(value = "doFilter, if request url does not match then do nothing")
	@Test
	void doFilterTest4() throws Exception {
		MockHttpServletResponse response = new MockHttpServletResponse();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "Bearer " + token);
		request.setServletPath("/signin");
		request.setMethod("POST");
		assertNotNull(request);
		
		FilterChain chain = mock(FilterChain.class);
		this.filter.doFilter(request, response, chain);
		
	}

}












