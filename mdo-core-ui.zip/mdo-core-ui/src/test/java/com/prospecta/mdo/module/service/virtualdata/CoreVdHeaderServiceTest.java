package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.nimbusds.jose.JOSEException;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdHeaderDAO;
import com.prospecta.mdo.module.dto.virtualdata.CommonResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.ResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdHeaderRequestDTO;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.exception.TenanatIdNotFoundException;
import com.prospecta.mdo.module.exception.VDNameExistsException;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

/**
 * @author komal
 *
 */
@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class CoreVdHeaderServiceTest {
	
	@InjectMocks
	private CoreVdHeaderServiceImpl coreVdHeaderServiceImpl;
	
	@Mock
	private CoreVdHeaderDAO coreVdHeaderDAO;
	
	
	@BeforeAll
	void init() {
		coreVdHeaderServiceImpl = new CoreVdHeaderServiceImpl();
	}
	
	@Test
	@DisplayName("createVirtualDatasetTest method test for create virtual dataset")
	void createVirtualDatasetTest() throws JOSEException {
		
		VdHeaderRequestDTO requestDTO = new VdHeaderRequestDTO("Sample Dataset", "Sample Description"); 
						
		CoreVdHeaderModel model = new CoreVdHeaderModel();
		model.setVdId(UUID.randomUUID());
		model.setVdName("Sample Dataset");
		model.setVdDescription("Sample Description");
		
		when(coreVdHeaderDAO.findByVdNameAndTenantId(any(), any())).thenReturn(null);	
		when(coreVdHeaderDAO.save(any())).thenReturn(model);	
				
		CommonResponseDTO actual = coreVdHeaderServiceImpl.createVirtualDataset(requestDTO, "0");
		assertNotNull(actual.toString());
		
		verify(coreVdHeaderDAO, atLeast(1)).findByVdNameAndTenantId(any(), any());
		verify(coreVdHeaderDAO, atLeast(1)).save(any());
		
	}
	
	@Test
	@DisplayName("createVirtualDatasetTestTenantIdMissing method test for internal server error if tenantId Missing")
	void createVirtualDatasetTestTenantIdMissing() throws JOSEException {
		
		assertThrows(TenanatIdNotFoundException.class, ()-> coreVdHeaderServiceImpl.createVirtualDataset(new VdHeaderRequestDTO(null, null), null));
			
	}
	
	@Test
	@DisplayName("createVirtualDatasetTestVdNameExists method test for internal server error if vdName is already exists")
	void createVirtualDatasetTestVdNameExists() throws JOSEException {
		
		VdHeaderRequestDTO requestDTO = new VdHeaderRequestDTO("Sample Dataset", "Sample Description");
						
		CoreVdHeaderModel model = new CoreVdHeaderModel();
		model.setVdId(UUID.randomUUID());
		model.setVdName("Sample Dataset");
		model.setVdDescription("Sample Description");
		
		when(coreVdHeaderDAO.findByVdNameAndTenantId(any(), any())).thenReturn(model);	
		
		assertThrows(VDNameExistsException.class, ()-> coreVdHeaderServiceImpl.createVirtualDataset(requestDTO, "0"));
	
	 	verify(coreVdHeaderDAO, atLeast(1)).findByVdNameAndTenantId(any(), any());
		
	}
	
	@Test
	@DisplayName("getVirtualDatasetListWithTenantIdTest method test for get list of virtual dataset")
	void getVirtualDatasetListWithTenantIdTest() throws JOSEException {
								
		List<CoreVdHeaderModel> vdHeaderModels =  new ArrayList<>();
		
		CoreVdHeaderModel obj1 = new CoreVdHeaderModel();
		obj1.setVdId(UUID.randomUUID());
		obj1.setVdName("Sample VdName");
		obj1.setTenantId("M00001");
		CoreVdHeaderModel obj2 = new CoreVdHeaderModel();
		obj2.setVdId(UUID.randomUUID());
		obj2.setVdName("Sample VdName");
		obj2.setTenantId("M00001");
		
		vdHeaderModels.add(obj1);
		vdHeaderModels.add(obj2);
		
		Pageable paging = PageRequest.of(0, 1);

	 	when(coreVdHeaderDAO.searchAllByTenantIdAndSearchString(any(), any(), any())).thenReturn(vdHeaderModels);	
				
		ResponseDTO actual = coreVdHeaderServiceImpl.getVirtualDatasetList(new ArrayList<>(List.of("M00001")), paging, "searchString");
		assertNotNull(actual.toString());
		
		verify(coreVdHeaderDAO, atLeast(1)).searchAllByTenantIdAndSearchString(any(), any(), any());
		
	}
	
	@Test
	@DisplayName("getVirtualDatasetListWithoutTenantIdTest method test for get list of virtual dataset")
	void getVirtualDatasetListWithoutTenantIdTest() throws JOSEException {
			
		List<CoreVdHeaderModel> vdHeaderModels =  new ArrayList<>();

		Pageable paging = PageRequest.of(0, 1);
		
		when(coreVdHeaderDAO.searchAllBySearchString(any(), any())).thenReturn(vdHeaderModels);	
		
		assertThrows(RuntimeException.class, ()-> coreVdHeaderServiceImpl.getVirtualDatasetList(new ArrayList<>(), paging, "searchString"));
		
		verify(coreVdHeaderDAO, atLeast(1)).searchAllBySearchString(any(), any());

	}
	
	@Test
	@DisplayName("getVirtualDatasetListWithoutSearchStringWithTenantIdTest method test for get list of virtual dataset")
	void getVirtualDatasetListWithoutSearchStringTest() throws JOSEException {
					
		List<CoreVdHeaderModel> vdHeaderModels =  new ArrayList<>();
		
		Pageable paging = PageRequest.of(0, 10);

		when(coreVdHeaderDAO.findByTenantIdOrderByVdNameAsc(any(), any())).thenReturn(vdHeaderModels);	
				
		coreVdHeaderServiceImpl.getVirtualDatasetList(new ArrayList<>(List.of("M00001")), paging, null);
	
		verify(coreVdHeaderDAO, atLeast(1)).findByTenantIdOrderByVdNameAsc(any(), any());

	}
	
	@Test
	@DisplayName("getVirtualDatasetListWithoutTenantIdAndSearchStringTest method test for get list of virtual dataset")
	void getVirtualDatasetListWithoutTenantIdAndSearchStringTest() throws JOSEException {
					
		List<CoreVdHeaderModel> vdHeaderModels =  new ArrayList<>();
		
		Pageable paging = PageRequest.of(0, 10);

		when(coreVdHeaderDAO.findByOrderByVdNameAsc(any())).thenReturn(vdHeaderModels);	
				
		coreVdHeaderServiceImpl.getVirtualDatasetList(new ArrayList<>(), paging, null);
	
		verify(coreVdHeaderDAO, atLeast(1)).findByOrderByVdNameAsc(any());
	}
	
	@Test
	@DisplayName("getVirtualDatasetWithTenantIdListNoMatchFoundTest method test for internal server error if match not found")
	void getVirtualDatasetWithTenantIdListNoMatchFoundTest() throws JOSEException {
								
		List<CoreVdHeaderModel> vdHeaderModels =  new ArrayList<>();
		
		Pageable paging = PageRequest.of(0, 10);

		when(coreVdHeaderDAO.searchAllByTenantIdAndSearchString(anyString(), any(), any())).thenReturn(vdHeaderModels);	
				
		assertThrows(RuntimeException.class, ()-> coreVdHeaderServiceImpl.getVirtualDatasetList(new ArrayList<>(List.of("M00001")), paging, "searchString"));
	
		verify(coreVdHeaderDAO, atLeast(1)).searchAllByTenantIdAndSearchString(anyString(), any(), any());

		
	}
	
	@Test
	@DisplayName("getVirtualDatasetTest method test for get virtual dataset")
	void getVirtualDatasetTest() {
		UUID id = UUID.randomUUID();
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(id);
		when(coreVdHeaderDAO.findById(any())).thenReturn(Optional.of(coreVdHeaderModel));
		coreVdHeaderServiceImpl.getVirtualDataset(id);
		verify(coreVdHeaderDAO, atLeast(1)).findById(any());
		
	}
	
	@Test
	@DisplayName("getVirtualDatasetExceptionTest method test for test exception")
	void getVirtualDatasetExceptionTest() {
		UUID id = UUID.randomUUID();
		CoreVdHeaderModel coreVdHeaderModel = null;
		when(coreVdHeaderDAO.findById(any())).thenReturn(Optional.ofNullable(coreVdHeaderModel));
		assertThrows(CommonVirtualDatasetException.class,()->coreVdHeaderServiceImpl.getVirtualDataset(id));
		//assertThrows(RuntimeException.class,()->coreVdHeaderServiceImpl.getVirtualDataset(id));
		verify(coreVdHeaderDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVirtualDatasetVdIdExceptionTest method test for test exception")
	void getVirtualDatasetVdIdExceptionTest() {
		assertThrows(CommonVirtualDatasetException.class,()->coreVdHeaderServiceImpl.getVirtualDataset(null));
		verify(coreVdHeaderDAO, atLeast(0)).findById(any());
	}
	
	
	@Test
	@DisplayName("deleteVirtualDatasetTest method test for delete virtual dataset")
	void deleteVirtualDatasetTest() {
		UUID id = UUID.randomUUID();
		doNothing().when(coreVdHeaderDAO).deleteById(id);
		coreVdHeaderServiceImpl.deleteVirtualDataset(id);
		verify(coreVdHeaderDAO, atLeast(1)).deleteById(any());
	}
	
	@Test
	@DisplayName("deleteVirtualDatasetExceptionTest method test for test exception handling")
	void deleteVirtualDatasetExceptionTest() {
		UUID id = UUID.randomUUID();
		doNothing().when(coreVdHeaderDAO).deleteById(id);
		assertThrows(RuntimeException.class, ()-> coreVdHeaderServiceImpl.deleteVirtualDataset(any()));		
		verify(coreVdHeaderDAO, atLeast(0)).deleteById(any());
	}
	
	@Test
	@DisplayName("updateVirtualDatasetTest method test for update virtual dataset")
	void updateVirtualDatasetTest() {
		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(any());
		coreVdHeaderModel.setVdName("Sample vdName");
		VdHeaderRequestDTO requestDTO = new VdHeaderRequestDTO();
		requestDTO.setVdId(UUID.randomUUID());
		requestDTO.setVdName("Sample vdName");
		when(coreVdHeaderDAO.save(coreVdHeaderModel)).thenReturn(coreVdHeaderModel);
		coreVdHeaderServiceImpl.updateVirtualDataset(requestDTO, "0");
		verify(coreVdHeaderDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("updateVirtualDatasetCatchTest method test for update virtual dataset")
	void updateVirtualDatasetCatchTest() {
		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(any());
		coreVdHeaderModel.setVdName("Sample vdName");
		VdHeaderRequestDTO requestDTO = new VdHeaderRequestDTO();
		requestDTO.setVdId(UUID.randomUUID());
		requestDTO.setVdName("Sample vdName");
		when(coreVdHeaderDAO.save(coreVdHeaderModel)).thenThrow(new RuntimeException());
		assertThrows(RuntimeException.class,()->coreVdHeaderServiceImpl.updateVirtualDataset(requestDTO, "0"));
	}
	
	@Test
	@DisplayName("updateVirtualDatasetWithNullRequest method test for update virtual dataset")
	void updateVirtualDatasetWithNullRequest() throws JOSEException{		
		assertThrows(RuntimeException.class,()->coreVdHeaderServiceImpl.updateVirtualDataset(null, "M0001"));
	}
	
	@Test
	@DisplayName("updateVirtualDatasetWithNullTest method test for check null")
	void updateVirtualDatasetWithNullTest() {
		
		VdHeaderRequestDTO requestDTO = new VdHeaderRequestDTO();
		requestDTO.setVdId(UUID.randomUUID());
		requestDTO.setVdName("Sample vdName");
		requestDTO.setTenantId(null);
		assertThrows(RuntimeException.class,()->coreVdHeaderServiceImpl.updateVirtualDataset(requestDTO, null));
	}
	
}
