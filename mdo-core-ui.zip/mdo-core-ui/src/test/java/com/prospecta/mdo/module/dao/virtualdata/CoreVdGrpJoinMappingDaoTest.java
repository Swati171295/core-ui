package com.prospecta.mdo.module.dao.virtualdata;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import com.prospecta.mdo.module.enums.JoinOperator;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinMappingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

@ActiveProfiles("test")
@DataJpaTest
class CoreVdGrpJoinMappingDaoTest {

	@Autowired
    private TestEntityManager entityManager;
	
	@Autowired
    private CoreVdGrpJoinMappingDAO coreVdGrpJoinMappingDAO;
	
	@DisplayName("findByCoreVdGrpJoinInfoTest -> find group join mapping by join information")
	@Test
	void findByCoreVdGrpJoinInfoTest() {		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel= new CoreVdGrpJoinInfoModel();
		coreVdGrpJoinInfoModel.setUuid(UUID.randomUUID());
		coreVdGrpJoinInfoModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdGrpJoinInfoModel.setJoinOperator(JoinOperator.OR);
		CoreVdGrpJoinMappingModel coreVdGrpJoinMappingModel = new CoreVdGrpJoinMappingModel();
		coreVdGrpJoinMappingModel.setUuid(UUID.randomUUID());
		coreVdGrpJoinMappingModel.setCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel);
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.persist(coreVdGrpJoinInfoModel);
		entityManager.persist(coreVdGrpJoinMappingModel);
		entityManager.flush();
		List<CoreVdGrpJoinMappingModel> actualList = coreVdGrpJoinMappingDAO.findByCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel);
		assertEquals(actualList.get(0).getCoreVdGrpJoinInfo().getJoinOperator(),coreVdGrpJoinInfoModel.getJoinOperator(), "group join mapping found is different than expected");
	}
	
	@DisplayName("deleteByCoreVdGrpJoinInfoTest -> delete group join mapping by join information")
	@Test
	void deleteByCoreVdGrpJoinInfoTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel= new CoreVdGrpJoinInfoModel();
		coreVdGrpJoinInfoModel.setUuid(UUID.randomUUID());
		coreVdGrpJoinInfoModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdGrpJoinInfoModel.setJoinOperator(JoinOperator.OR);		
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.persist(coreVdGrpJoinInfoModel);
		entityManager.flush();
		coreVdGrpJoinMappingDAO.deleteByCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel);
		List<CoreVdGrpJoinMappingModel> actualList = coreVdGrpJoinMappingDAO.findByCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel);
		assertTrue(actualList.isEmpty(),"core group mapping is deleted.");
	}
}
