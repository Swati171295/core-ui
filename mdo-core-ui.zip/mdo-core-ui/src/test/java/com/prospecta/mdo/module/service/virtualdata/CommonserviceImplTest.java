
package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpJoinInfoDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpTransInfoDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdHeaderDAO;
import com.prospecta.mdo.module.dto.virtualdata.DeleteUdrResponse;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinInfoRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinMappingRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinOnRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupResultsRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupTransInfoRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupsRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdHeaderRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdTransFieldSettingRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdTransRuleConcatRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdTransRuleReplaceRequestDTO;
import com.prospecta.mdo.module.enums.CompareOperator;
import com.prospecta.mdo.module.enums.ConcatFieldType;
import com.prospecta.mdo.module.enums.GroupType;
import com.prospecta.mdo.module.enums.JoinOperator;
import com.prospecta.mdo.module.enums.JoinType;
import com.prospecta.mdo.module.enums.SourceScope;
import com.prospecta.mdo.module.enums.SourceType;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinMappingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinOnModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpResultsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransRuleConcatModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransRuleReplaceModel;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class CommonserviceImplTest {
	
	@InjectMocks
	private CommonserviceImpl commonserviceImpl;
	
	@Mock
	private CoreVdGroupsService coreVdGroupsService;

	@Mock
	private CoreVdHeaderService coreVdHeaderService;

	@Mock
	private CoreVdGrpJoinInfoService coreVdGrpJoinInfoService;

	@Mock
	private CoreVdGrpJoinOnService coreVdGrpJoinOnService;

	@Mock
	private CoreVdGrpResultsService coreVdGrpResultsService;

	@Mock
	private CoreVdTransInfoService coreVdTransInfoService;

	@Mock
	private CoreVdGrpJoinMappingService coreVdGrpJoinMappingService;

	@Mock
	private CoreVdTransRuleConcatService coreVdTransRuleConcatService;

	@Mock
	private CoreVdTransRuleReplaceService coreVdTransRuleReplaceService;

	@Mock
	private CoreVdTransFieldSettingService coreVdTransFieldSettingService;

	@Mock
	private CoreVdHeaderDAO coreVdHeaderDAO;
	
	@Mock
	private CoreVdGrpJoinInfoDAO coreVdGrpJoinInfoDAO;
	
	@Mock
	private CoreVdGrpTransInfoDAO coreVdGrpTransInfoDAO;
	
	@Mock
	private WebClientImpl webClientImpl;	
	
	@Test
	@DisplayName("updateVirtualDatasetTest method test for Update virtual dataset")
	void updateVirtualDatasetTest() {
		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		List<VdGroupsRequestDTO> vdGroupsRequestDTOList = new ArrayList<VdGroupsRequestDTO>();
		VdGroupsRequestDTO vdGroupsRequestDTO = new VdGroupsRequestDTO();
		vdGroupsRequestDTO.setGroupId(UUID.randomUUID());
		vdGroupsRequestDTOList.add(vdGroupsRequestDTO);
		vdHeaderRequestDTO.setGroupDetails(vdGroupsRequestDTOList);
		when(coreVdHeaderService.updateVirtualDataset(any(), anyString())).thenReturn(coreVdHeaderModel);
		doNothing().when(coreVdGroupsService).deleteCoreVdGroup(any(),any());
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		when(coreVdGroupsService.saveOrUpdateVdGroups(any(),any(),anyString())).thenReturn(coreVdGroupsModel);
		doNothing().when(coreVdGrpJoinInfoService).deleteVdGroupInfo(any(),any());
		
		List<VdGroupJoinInfoRequestDTO> vdGroupJoinInfoRequestDTOList = new ArrayList<VdGroupJoinInfoRequestDTO>();
		VdGroupJoinInfoRequestDTO vdGroupJoinInfoRequestDTO = new VdGroupJoinInfoRequestDTO();
		vdGroupJoinInfoRequestDTOList.add(vdGroupJoinInfoRequestDTO);
		vdGroupsRequestDTO.setGroupJoinDetail(vdGroupJoinInfoRequestDTOList);
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();
		when(coreVdGrpJoinInfoService.saveAndUpdateGrpJoinInfo(any(),any())).thenReturn(coreVdGrpJoinInfoModel);
		doNothing().when(coreVdGrpJoinMappingService).deleteVdGrpJoinMapping(any(),any());
		
		List<VdGroupJoinMappingRequestDTO> vdGroupJoinMappingRequestDTOList = new ArrayList<VdGroupJoinMappingRequestDTO>();
		vdGroupJoinInfoRequestDTO.setJoinMapping(vdGroupJoinMappingRequestDTOList);
		VdGroupJoinMappingRequestDTO vdGroupJoinMappingRequestDTO = new VdGroupJoinMappingRequestDTO();
		vdGroupJoinMappingRequestDTOList.add(vdGroupJoinMappingRequestDTO);
		CoreVdGrpJoinMappingModel coreVdGrpJoinMappingModel = new CoreVdGrpJoinMappingModel();
		when(coreVdGrpJoinMappingService.saveAndUpdateJoinMapping(any(),any())).thenReturn(coreVdGrpJoinMappingModel);
		
		List<VdGroupJoinOnRequestDTO> vdGroupJoinOnRequestDTOList = new ArrayList<VdGroupJoinOnRequestDTO>();
		VdGroupJoinOnRequestDTO vdGroupJoinOnRequestDTO = new VdGroupJoinOnRequestDTO();
		vdGroupJoinOnRequestDTOList.add(vdGroupJoinOnRequestDTO);
		vdGroupsRequestDTO.setJoinColumns(vdGroupJoinOnRequestDTOList);
		CoreVdGrpJoinOnModel coreVdGrpJoinOnModel = new CoreVdGrpJoinOnModel();
		when(coreVdGrpJoinOnService.saveAndUpdateJoinOn(any(),any())).thenReturn(coreVdGrpJoinOnModel);
		doNothing().when(coreVdTransInfoService).deleteVdTransInfo(any(),any());
		
		List<VdGroupTransInfoRequestDTO> VdGroupTransInfoRequestDTOList = new ArrayList<VdGroupTransInfoRequestDTO>();
		VdGroupTransInfoRequestDTO vdGroupTransInfoRequestDTO = new VdGroupTransInfoRequestDTO();
		VdGroupTransInfoRequestDTOList.add(vdGroupTransInfoRequestDTO);
		vdGroupsRequestDTO.setGroupTransDetail(VdGroupTransInfoRequestDTOList);
		when(coreVdTransInfoService.saveOrUpdateVdTransInfo(any(),any())).thenReturn(new CoreVdGrpTransInfoModel());
		doNothing().when(coreVdTransFieldSettingService).deleteVdTransFieldSetting(any(),any());
		
		List<VdTransFieldSettingRequestDTO> vdTransFieldSettingRequestDTOList = new ArrayList<VdTransFieldSettingRequestDTO>();
		VdTransFieldSettingRequestDTO vdTransFieldSettingRequestDTO = new VdTransFieldSettingRequestDTO();
		vdTransFieldSettingRequestDTOList.add(vdTransFieldSettingRequestDTO);
		vdGroupTransInfoRequestDTO.setGroupTransFieldSetting(vdTransFieldSettingRequestDTOList);
		when(coreVdTransFieldSettingService.saveAndUpdateTransFieldSetting(any(),any())).thenReturn(new CoreVdTransFieldSettingModel());
		doNothing().when(coreVdTransRuleConcatService).deleteVdTransRuleConcat(any(),any());
		
		List<VdTransRuleConcatRequestDTO> vdTransRuleConcatRequestDTOList = new ArrayList<VdTransRuleConcatRequestDTO>();
		VdTransRuleConcatRequestDTO vdTransRuleConcatRequestDTO = new VdTransRuleConcatRequestDTO();
		vdTransRuleConcatRequestDTOList.add(vdTransRuleConcatRequestDTO);
		vdTransFieldSettingRequestDTO.setTransConcatDetail(vdTransRuleConcatRequestDTOList);
		when(coreVdTransRuleConcatService.saveAndUpdateRuleConcat(any(),any())).thenReturn(new CoreVdTransRuleConcatModel());
		doNothing().when(coreVdTransRuleReplaceService).deleteVdTransRuleReplace(any(),any());
		
		List<VdTransRuleReplaceRequestDTO> vdTransRuleReplaceRequestDTOList = new ArrayList<VdTransRuleReplaceRequestDTO>();
		VdTransRuleReplaceRequestDTO vdTransRuleReplaceRequestDTO = new VdTransRuleReplaceRequestDTO();
		vdTransRuleReplaceRequestDTOList.add(vdTransRuleReplaceRequestDTO);
		vdTransFieldSettingRequestDTO.setTransReplaceDetail(vdTransRuleReplaceRequestDTOList);
		when(coreVdTransRuleReplaceService.saveOrUpdateVdTransRuleReplace(any(),any())).thenReturn(new CoreVdTransRuleReplaceModel());
		doNothing().when(coreVdGrpResultsService).deleteVdGroupResults(any(),any());
		
		List<VdGroupResultsRequestDTO> vdGroupResultsRequestDTOList = new ArrayList<VdGroupResultsRequestDTO>();
		VdGroupResultsRequestDTO vdGroupResultsRequestDTO = new VdGroupResultsRequestDTO();
		vdGroupResultsRequestDTOList.add(vdGroupResultsRequestDTO);
		vdHeaderRequestDTO.setGroupResult(vdGroupResultsRequestDTOList);
		when(coreVdGrpResultsService.saveOrUpdateVdGroupResults(any(),any(),any())).thenReturn(new CoreVdGrpResultsModel());
		
		assertNotNull(commonserviceImpl.updateVirtualDataset(vdHeaderRequestDTO, "test"));
		//commonserviceImpl.updateVirtualDataset(vdHeaderRequestDTO, "test");
	}
	
	@Test
	@DisplayName("updateVirtualDatasetTest method test for null")
	void updateVirtualDatasetTest1() {
		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		List<VdGroupsRequestDTO> vdGroupsRequestDTOList = new ArrayList<VdGroupsRequestDTO>();
		VdGroupsRequestDTO vdGroupsRequestDTO = new VdGroupsRequestDTO();
		vdGroupsRequestDTO.setGroupId(UUID.randomUUID());
		vdGroupsRequestDTOList.add(vdGroupsRequestDTO);
		vdHeaderRequestDTO.setGroupDetails(vdGroupsRequestDTOList);
		when(coreVdHeaderService.updateVirtualDataset(any(), anyString())).thenReturn(null);
		
		Assertions.assertThrows(Exception.class, () -> {
			commonserviceImpl.updateVirtualDataset(vdHeaderRequestDTO, "test");
		});
	}
	
	
	@Test
	@DisplayName("getVirtualDatasetTest method test for get virtual dataset data")
	void getVirtualDatasetTest() {
		
		List<CoreVdTransRuleReplaceModel> coreVdTransRuleReplace = new ArrayList<>();
		CoreVdTransRuleReplaceModel vdTransRuleReplaceModel = new CoreVdTransRuleReplaceModel();
		vdTransRuleReplaceModel.setVdReplaceId(UUID.randomUUID());
		coreVdTransRuleReplace.add(vdTransRuleReplaceModel);
		
		List<CoreVdTransRuleConcatModel> coreVdTransRuleConcat = new ArrayList<>(); 
		CoreVdTransRuleConcatModel vdTransRuleConcatModel = new CoreVdTransRuleConcatModel();
		vdTransRuleConcatModel.setVdConcatId(UUID.randomUUID());
		vdTransRuleConcatModel.setFieldType(ConcatFieldType.TABLECOLUMN);
		coreVdTransRuleConcat.add(vdTransRuleConcatModel);
		
		List<CoreVdTransFieldSettingModel> coreVdTransFieldSetting = new ArrayList<>();
		CoreVdTransFieldSettingModel vdTransFieldSettingModel = new CoreVdTransFieldSettingModel();
		vdTransFieldSettingModel.setCoreVdTransRuleReplace(coreVdTransRuleReplace);
		vdTransFieldSettingModel.setCoreVdTransRuleConcat(coreVdTransRuleConcat);
		coreVdTransFieldSetting.add(vdTransFieldSettingModel);
		
		List<CoreVdGrpJoinMappingModel> coreVdGrpJoinMapping = new ArrayList<>();
		CoreVdGrpJoinMappingModel vdGrpJoinMappingModel = new CoreVdGrpJoinMappingModel();
		vdGrpJoinMappingModel.setUuid(UUID.randomUUID());
		vdGrpJoinMappingModel.setCompareOperator(CompareOperator.EQUALS);
		coreVdGrpJoinMapping.add(vdGrpJoinMappingModel);
		
		List<CoreVdGrpJoinInfoModel> coreVdGrpJoinInfo = new ArrayList<>();
		CoreVdGrpJoinInfoModel vdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();
		vdGrpJoinInfoModel.setCoreVdGrpJoinMapping(coreVdGrpJoinMapping);
		vdGrpJoinInfoModel.setSourceOneType(SourceType.MODULE);
		vdGrpJoinInfoModel.setSourceTwoType(SourceType.SYSTABLE);
		vdGrpJoinInfoModel.setJoinOperator(JoinOperator.AND);
		vdGrpJoinInfoModel.setJoinType(JoinType.INNER);
		vdGrpJoinInfoModel.setResultScopeUdrId("1234");
		vdGrpJoinInfoModel.setSourceOneScopeUdrId("1234");
		vdGrpJoinInfoModel.setSourceTwoScopeUdrId("1234");
		coreVdGrpJoinInfo.add(vdGrpJoinInfoModel);
		
		List<CoreVdGrpJoinOnModel> coreVdGrpJoinOn = new ArrayList<>();
		CoreVdGrpJoinOnModel vdGrpJoinOnModel = new CoreVdGrpJoinOnModel();
		vdGrpJoinOnModel.setJoinOnId(UUID.randomUUID());
		vdGrpJoinOnModel.setCompareOperator(CompareOperator.EQUALS);
		coreVdGrpJoinOn.add(vdGrpJoinOnModel);
		
		List<CoreVdGrpTransInfoModel> coreVdGrpTransInfo = new ArrayList<>();
		CoreVdGrpTransInfoModel vdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		vdGrpTransInfoModel.setCoreVdTransFieldSetting(coreVdTransFieldSetting);
		vdGrpTransInfoModel.setSourceScope(SourceScope.ALL);
		vdGrpTransInfoModel.setSourceType(SourceType.SYSTABLE);
		vdGrpTransInfoModel.setResultScopeUdrId("1234");
		vdGrpTransInfoModel.setSourceScopeUdrId("1234");
		coreVdGrpTransInfo.add(vdGrpTransInfoModel);
		
		List<CoreVdGrpResultsModel> coreVdGrpResults = new ArrayList<>();
		CoreVdGrpResultsModel vdGrpResultsModel = new CoreVdGrpResultsModel();
		vdGrpResultsModel.setFieldId("1235");
		vdGrpResultsModel.setUuid(UUID.randomUUID());
		coreVdGrpResults.add(vdGrpResultsModel);
		
		List<CoreVdGroupsModel> coreVdGroups = new ArrayList<>();
		CoreVdGroupsModel vdGroupsModel = new CoreVdGroupsModel();
		vdGroupsModel.setCoreVdGrpJoinInfo(coreVdGrpJoinInfo);
		vdGroupsModel.setCoreVdGrpJoinOn(coreVdGrpJoinOn);
		vdGroupsModel.setCoreVdGrpTransInfo(coreVdGrpTransInfo);
		vdGroupsModel.setGroupType(GroupType.JOIN);
		coreVdGroups.add(vdGroupsModel);
		
		CoreVdHeaderModel coreVdHeaderModel= new CoreVdHeaderModel();
		coreVdHeaderModel.setCoreVdGroups(coreVdGroups);
		coreVdHeaderModel.setCoreVdGrpResults(coreVdGrpResults);
		
		when(coreVdHeaderService.getVirtualDataset(any())).thenReturn(coreVdHeaderModel);
		when(webClientImpl.getVirtualDataUdrId(any(),any())).thenReturn(any());
		commonserviceImpl.getVirtualDataset(UUID.randomUUID(),"");		
		verify(coreVdHeaderService, atLeast(1)).getVirtualDataset(any());
		
	}
	
	@Test
	@DisplayName("getVirtualDatasetVdIdNullTest method test for testing exception")
	void getVirtualDatasetVdIdNullTest() {
		
		Assertions.assertThrows(CommonVirtualDatasetException.class, () -> {commonserviceImpl.getVirtualDataset(null,"");});
		verify(coreVdHeaderService, atLeast(0)).getVirtualDataset(any());
		
	}
	
	@Test
	@DisplayName("getVirtualDatasetExceptionTest method test the exception handling")
	void getVirtualDatasetExceptionTest() {		
		
		List<CoreVdGroupsModel> coreVdGroups = new ArrayList<>();
		CoreVdGroupsModel vdGroupsModel = new CoreVdGroupsModel();
		coreVdGroups.add(vdGroupsModel);
		
		CoreVdHeaderModel coreVdHeaderModel= new CoreVdHeaderModel();
		coreVdHeaderModel.setCoreVdGroups(coreVdGroups);
		
		when(coreVdHeaderService.getVirtualDataset(any())).thenReturn(coreVdHeaderModel);
		Assertions.assertThrows(CommonVirtualDatasetException.class, () -> {commonserviceImpl.getVirtualDataset(UUID.randomUUID(),"");});
		verify(coreVdHeaderService, atLeast(1)).getVirtualDataset(any());
	}

	@Test
	@DisplayName("deleteVirtualDatasetTest method test for delete virtual dataset")
	void deleteVirtualDatasetTest() {
		
		List<CoreVdGroupsModel> groupIdList = new ArrayList<CoreVdGroupsModel>();
		when(coreVdHeaderDAO.existsById(any())).thenReturn(true);
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		groupIdList.add(coreVdGroupsModel);
		when(coreVdGroupsService.getVdGroupsbyvdId(any())).thenReturn(groupIdList);
		
		List<CoreVdGrpJoinInfoModel> coreVdGrpJoinInfoModelList= new ArrayList<>();
		when(coreVdGrpJoinInfoDAO.findByCoreVdGroups(any())).thenReturn(coreVdGrpJoinInfoModelList);
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();
		coreVdGrpJoinInfoModelList.add(coreVdGrpJoinInfoModel);
		
		List<CoreVdGrpTransInfoModel> coreVdGrpTransInfoModelList = new ArrayList<CoreVdGrpTransInfoModel>();
		when(coreVdGrpTransInfoDAO.findByCoreVdGroups(any())).thenReturn(coreVdGrpTransInfoModelList);
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		coreVdGrpTransInfoModelList.add(coreVdGrpTransInfoModel);
		
		doNothing().when(coreVdHeaderService).deleteVirtualDataset(any());
		
		DeleteUdrResponse response = new DeleteUdrResponse();
		when(webClientImpl.deleteUdrId(any(), any())).thenReturn(response);
		commonserviceImpl.deleteVirtualDataset(UUID.randomUUID(), "test");
		assertNotNull(commonserviceImpl.deleteVirtualDataset(UUID.randomUUID(), "test"));
		verify(coreVdGrpTransInfoDAO, atLeast(1)).findByCoreVdGroups(any());
	}
	
	@Test
	@DisplayName("deleteVirtualDatasetTest1 method test for exception")
	void deleteVirtualDatasetTest1() {
		
		List<CoreVdGroupsModel> groupIdList = new ArrayList<CoreVdGroupsModel>();
		when(coreVdHeaderDAO.existsById(any())).thenReturn(false);
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		groupIdList.add(coreVdGroupsModel);
		
		Assertions.assertThrows(Exception.class, () -> {
			commonserviceImpl.deleteVirtualDataset(UUID.randomUUID(), "test");
		});
	}
	
	@Test
	@DisplayName("deleteVirtualDatasetExceptionTest method test for exception")
	void deleteVirtualDatasetExceptionTest() {
		
		Assertions.assertThrows(CommonVirtualDatasetException.class, () -> {
			commonserviceImpl.deleteVirtualDataset(null, "test");
		});
	}
	
	@Test
	@DisplayName("deleteVirtualDatasetCatchExceptionTest method test for exception")
	void deleteVirtualDatasetCatchExceptionTest() {
		
		List<CoreVdGroupsModel> groupIdList =null;
		when(coreVdHeaderDAO.existsById(any())).thenReturn(true);
		when(coreVdGroupsService.getVdGroupsbyvdId(any())).thenReturn(groupIdList);
		
		Assertions.assertThrows(CommonVirtualDatasetException.class, () -> {
			commonserviceImpl.deleteVirtualDataset(UUID.randomUUID(), "test");
		});
		
		verify(coreVdHeaderService, atLeast(0)).deleteVirtualDataset(any());
		
		
	}
}

