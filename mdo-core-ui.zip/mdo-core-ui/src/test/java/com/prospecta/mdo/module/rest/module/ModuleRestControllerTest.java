/**
 * 
 */
package com.prospecta.mdo.module.rest.module;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.prospecta.mdo.module.component.JWTTokenProvider;
import com.prospecta.mdo.module.dto.module.*;
import com.prospecta.mdo.module.model.module.CoreModuleModel;
import com.prospecta.mdo.module.service.module.CoreModuleService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * @author savan
 *
 */
@SpringBootTest
@ActiveProfiles("Test")
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
public class ModuleRestControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private JWTTokenProvider jWTTokenProvider;
	
	@MockBean
	private CoreModuleService coreModuleService;
	
	private static final String PAYLOAD = "{\"username\":\"Admin\",\"roles\":[],\"tenantCode\":\"0\"}";
	
	@DisplayName("Test case for saveModule controller method for saving a module")
	@Test
	@WithMockUser
	public void saveModuleTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setSystemType("xyz");
		requestDTO.setIndustry("abc");
		requestDTO.setDisplayCriteria("view");
		requestDTO.setModuledescription(moduledescription);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");
		List<Long> parentModuleIds = new ArrayList<>();
		parentModuleIds.add(1l);
		requestDTO.setParentModuleIds(parentModuleIds);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(requestDTO);
		
		ModuleResponseDTO responseDTO = new ModuleResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreModuleService.saveModel(any(),any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/module/save").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isCreated()).andReturn();

		verify(coreModuleService,atLeast(1)).saveModel(any(), any());
	}
	
	@DisplayName("Test case for saveModule controller method for internal server error")
	@Test
	@WithMockUser
	public void saveModuleTest1() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setSystemType("xyz");
		requestDTO.setIndustry("abc");
		requestDTO.setDisplayCriteria("view");
		requestDTO.setModuledescription(moduledescription);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(requestDTO);
		
		ModuleResponseDTO responseDTO = new ModuleResponseDTO();
		responseDTO.setAcknowledge(false);

		when(coreModuleService.saveModel(any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/module/save").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());

		verify(coreModuleService,atLeast(1)).saveModel(any(), any());
	}
	
	@DisplayName("Test case for saveField controller method saving the field")
	@Test
	@WithMockUser
	public void saveField() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(fieldDTO);
		
		FieldResponseDTO responseDTO = new FieldResponseDTO();
		responseDTO.setAcknowledge(true);
		
		when(coreModuleService.saveField(any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/module/fields/{MODULEID}/save",4L).header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());
		
		verify(coreModuleService,atLeast(1)).saveField(any(), any(), any());
	}
	
	@DisplayName("Test case for saveField1 controller method to test exception")
	@Test
	@WithMockUser
	public void saveField1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(fieldDTO);
		
		FieldResponseDTO responseDTO = new FieldResponseDTO();
		responseDTO.setAcknowledge(false);
		
		when(coreModuleService.saveField(any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/module/fields/{MODULEID}/save",4L).header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());
		
		verify(coreModuleService,atLeast(1)).saveField(any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for getFieldIdsWithStructureTest controller method to get all available fields related to structureid")
	@WithMockUser
	public void getFieldIdsWithStructureTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		FieldIdsWithStructureRequestDTO dto = new FieldIdsWithStructureRequestDTO();
		dto.setStructureId("1");
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		FieldIdsWithStructureResponseDTO responseDTO = new FieldIdsWithStructureResponseDTO();
		responseDTO.setAcknowledge(true);
		
		when(coreModuleService.getFieldsWithStructure(any(),any(),any(),any(),any(),any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/module/fields/{MODULEID}/{lang}/listFieldIdByStructure", 1L, "en")
				.header("authorization", "Bearer " + token).param("fetchcount", "0").param("fetchsize", "10")
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());
		
		verify(coreModuleService).getFieldsWithStructure(any(),any(),any(),any(),any(),any());
	}
	
	@Test
	@DisplayName("Test case for getFieldIdsWithStructureTest1 controller method to check for internal server error")
	@WithMockUser
	public void getFieldIdsWithStructureTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		FieldIdsWithStructureRequestDTO dto = new FieldIdsWithStructureRequestDTO();
		dto.setStructureId("1");
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		FieldIdsWithStructureResponseDTO responseDTO = new FieldIdsWithStructureResponseDTO();
		responseDTO.setAcknowledge(false);
		
		when(coreModuleService.getFieldsWithStructure(any(),any(),any(),any(),any(),any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/module/fields/{MODULEID}/{lang}/listFieldIdByStructure", 1L, "en")
				.header("authorization", "Bearer " + token).param("fetchcount", "0").param("fetchsize", "10")
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());
		
		verify(coreModuleService).getFieldsWithStructure(any(),any(),any(),any(),any(),any());
	}
	
	@Test
	@DisplayName("Test case for getAllPicklistFieldsTest controller method to get all available fields related to picklist and serch description")
	@WithMockUser
	public void getAllPicklistFieldsTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		PicklistFieldsRequestDTO dto = new PicklistFieldsRequestDTO();
		dto.setDescription("Ma");
		dto.setPickList("1");
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		PickListFieldsResponseDTO responseDTO = new PickListFieldsResponseDTO();
		responseDTO.setAcknowledge(true);
		
		when(coreModuleService.getAllPicklistFields(any(), any(), any(),any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/module/fields/{MODULEID}/{lang}/listByPicklist", 1L, "en")
				.header("authorization", "Bearer " + token).param("fetchcount", "0").param("fetchsize", "10")
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());
		
		verify(coreModuleService).getAllPicklistFields(any(), any(), any(),any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for getAllPicklistFieldsTest1 controller method to test internal server error")
	@WithMockUser
	public void getAllPicklistFieldsTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		PicklistFieldsRequestDTO dto = new PicklistFieldsRequestDTO();
		dto.setDescription("Ma");
		dto.setPickList("1");
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		PickListFieldsResponseDTO responseDTO = new PickListFieldsResponseDTO();
		responseDTO.setAcknowledge(false);
		
		when(coreModuleService.getAllPicklistFields(any(), any(), any(),any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/module/fields/{MODULEID}/{lang}/listByPicklist", 1L, "en")
				.header("authorization", "Bearer " + token).param("fetchcount", "0").param("fetchsize", "10")
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());
		
		verify(coreModuleService).getAllPicklistFields(any(), any(), any(),any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for getAllDataTypefieldsTest controller method to get all available fields related to datatpe and serch description")
	@WithMockUser
	public void getAllDataTypefieldsTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		DataTypeFieldsRequestDTO dto = new DataTypeFieldsRequestDTO();
		dto.setDescription("Ma");
		dto.setDatatype("CHAR");
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		DataTypeFieldsResponseDTO responseDTO = new DataTypeFieldsResponseDTO();
		responseDTO.setAcknowledge(true);
		
		when(coreModuleService.getAllDataTypefields(any(), any(), any(),any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/module/fields/{MODULEID}/{lang}/listByDataType", 1L, "en")
				.header("authorization", "Bearer " + token).param("fetchcount", "0").param("fetchsize", "10")
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());
		
		verify(coreModuleService).getAllDataTypefields(any(), any(), any(),any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for getAllDataTypefieldsTest1 controller method to test internal server error")
	@WithMockUser
	public void getAllDataTypefieldsTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		DataTypeFieldsRequestDTO dto = new DataTypeFieldsRequestDTO();
		dto.setDescription("Ma");
		dto.setDatatype("CHAR");
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);
		
		DataTypeFieldsResponseDTO responseDTO = new DataTypeFieldsResponseDTO();
		responseDTO.setAcknowledge(false);
		
		when(coreModuleService.getAllDataTypefields(any(), any(), any(),any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(post("/module/fields/{MODULEID}/{lang}/listByDataType", 1L, "en")
				.header("authorization", "Bearer " + token).param("fetchcount", "0").param("fetchsize", "10")
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());
		
		verify(coreModuleService).getAllDataTypefields(any(), any(), any(),any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for updateModuleDescriptionTest controller method to update existin module description")
	@WithMockUser
	public void updateModuleDescriptionTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(moduledescription);
		
		ModuleResponseDTO responseDTO = new ModuleResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreModuleService.updateModuleDescription(any(), any(), any())).thenReturn(responseDTO);
		
		this.mockMvc.perform(put("/module/{MODULEID}/update/description", 1L)
				.header("authorization", "Bearer " + token)
 				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());
		verify(coreModuleService,atLeast(1)).updateModuleDescription(any(),any(), any());
	}
	
	@Test
	@DisplayName("Test case for updateModuleDescriptionTest1 controller method to test internal server error")
	@WithMockUser
	public void updateModuleDescriptionTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);


		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(moduledescription);
		
		ModuleResponseDTO responseDTO = new ModuleResponseDTO();
		responseDTO.setAcknowledge(false);
		
		when(coreModuleService.updateModuleDescription(moduledescription, "0", 1L)).thenReturn(responseDTO);
		
		this.mockMvc.perform(put("/module/{MODULEID}/update/description", 1L)
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());

		verify(coreModuleService,atLeast(1)).updateModuleDescription(any(),any(), any());
	}

	@Test
	@DisplayName("Test case for updateModuleDescriptionTestException controller method to test internal server error")
	@WithMockUser
	void updateModuleDescriptionTestException() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);


		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(moduledescription);

		ModuleResponseDTO responseDTO = new ModuleResponseDTO();
		responseDTO.setAcknowledge(false);

		when(coreModuleService.updateModuleDescription(moduledescription, "0", 1L)).thenReturn(null);

		this.mockMvc.perform(put("/module/{MODULEID}/update/description", 1L)
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());

		verify(coreModuleService,atLeast(1)).updateModuleDescription(any(),any(), any());
	}

	@Test
	@DisplayName("Test case for updateModuleDescriptionTestExceptionNull controller method to test internal server error")
	@WithMockUser
	void updateModuleDescriptionTestExceptionNull() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		this.mockMvc.perform(put("/module/{MODULEID}/update/description", 1L)
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content("{}")).andExpect(status().isInternalServerError());

	}

	@Test
	@DisplayName("Test case for getAllFieldsByStructureTest controller method to Get All fields by Structure")
	@WithMockUser
	public void getAllFieldsByStructureTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		 List<FieldDTO> response = new ArrayList<FieldDTO>();
		 
		 FieldDTO field = new FieldDTO();
		 field.setDataType("DEC");
		 
		 response.add(field);
		
		when(coreModuleService.getAllFieldsByStructure(1L, "en", "1", "0", "10", "0")).thenReturn(response);
		
		this.mockMvc.perform(get("/module/fields/{MODULEID}/{lang}/listFieldIdyStructure/{STRUCTUREID}", 1L, "en","1")
				.header("authorization", "Bearer " + token).param("fetchcount", "0").param("fetchsize", "10")).andExpect(status().isOk());
		
		verify(coreModuleService).getAllFieldsByStructure(1L, "en", "1", "0", "10", "0");
	}
	
	@Test
	@DisplayName("Test case for getAllFieldsByStructureTest1 controller method to check if response is empty")
	@WithMockUser
	public void getAllFieldsByStructureTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		 List<FieldDTO> response = new ArrayList<FieldDTO>();
		 
		when(coreModuleService.getAllFieldsByStructure(1L, "en", "1", "0", "10", "0")).thenReturn(response);
		
		this.mockMvc.perform(get("/module/fields/{MODULEID}/{lang}/listFieldIdyStructure/{STRUCTUREID}", 1L, "en","1")
				.header("authorization", "Bearer " + token).param("fetchcount", "0").param("fetchsize", "10")).andExpect(status().isInternalServerError());
		
		verify(coreModuleService).getAllFieldsByStructure(1L, "en", "1", "0", "10", "0");
	}
	
	@Test
	@DisplayName("Test case for getAllFieldsByStructureTest2 controller method to check if response is null")
	@WithMockUser
	public void getAllFieldsByStructureTest2() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		when(coreModuleService.getAllFieldsByStructure(1L, "en", "1", "0", "10", "0")).thenReturn(null);
		
		this.mockMvc.perform(get("/module/fields/{MODULEID}/{lang}/listFieldIdyStructure/{STRUCTUREID}", 1L, "en","1")
				.header("authorization", "Bearer " + token).param("fetchcount", "0").param("fetchsize", "10")).andExpect(status().isInternalServerError());
		
		verify(coreModuleService).getAllFieldsByStructure(1L, "en", "1", "0", "10", "0");
	}
	
	@Test
	@DisplayName("Test case for getAllModulesTest controller method to List of all Modules")
	@WithMockUser
	public void getAllModulesTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		 List<CoreModuleModel> response = new ArrayList<CoreModuleModel>();
		 
		 CoreModuleModel module = new CoreModuleModel();
		 module.setModuleId(1L);
		 
		 response.add(module);
		
		when(coreModuleService.getAllModules("en", "0", "10", "0")).thenReturn(response);
		
		this.mockMvc.perform(get("/module/get-all-modules")
				.header("authorization", "Bearer " + token).param("language","en").param("fetchcount", "0").param("fetchsize", "10")).andExpect(status().isOk());
		
		verify(coreModuleService).getAllModules("en", "0", "10", "0");
	}
	
	@Test
	@DisplayName("Test case for getAllModulesTest1 controller method to test if no moduleList is empty")
	@WithMockUser
	public void getAllModulesTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		 List<CoreModuleModel> response = new ArrayList<CoreModuleModel>();
		 
		when(coreModuleService.getAllModules("en", "0", "10", "0")).thenReturn(response);
		
		this.mockMvc.perform(get("/module/get-all-modules")
				.header("authorization", "Bearer " + token).param("language","en").param("fetchcount", "0").param("fetchsize", "10")).andExpect(status().isInternalServerError());
		
		verify(coreModuleService).getAllModules("en", "0", "10", "0");
	}
	
	@Test
	@DisplayName("Test case for getAllModulesTest2 controller method to test if no modulelist id null")
	@WithMockUser
	public void getAllModulesTest2() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		 List<CoreModuleModel> response = new ArrayList<CoreModuleModel>();
		 
		when(coreModuleService.getAllModules("en", "0", "10", "0")).thenReturn(null);
		
		this.mockMvc.perform(get("/module/get-all-modules")
				.header("authorization", "Bearer " + token).param("language","en").param("fetchcount", "0").param("fetchsize", "10")).andExpect(status().isInternalServerError());
		
		verify(coreModuleService).getAllModules("en", "0", "10", "0");
	}
	
	@Test
	@DisplayName("Test case for getObjectAndFieldsByDescription controller method to test Get Object and Fields by description.")
	@WithMockUser
	public void getObjectAndFieldsByDescriptionTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		List<ModuleTreeDTO> response = new ArrayList<>();
		
		ModuleTreeDTO treeDto = new ModuleTreeDTO();
		treeDto.setModuleId(1L);
		
		response.add(treeDto);
		 
		when(coreModuleService.getModuleTree("en", "De", "0")).thenReturn(response);
		
		this.mockMvc.perform(get("/module/getbydescription/{lang}/{description}", "en","De")
				.header("authorization", "Bearer " + token).param("fetchcount", "0").param("fetchsize", "10")).andExpect(status().isOk());
		
		verify(coreModuleService).getModuleTree("en", "De", "0");
	}
	
	@Test
	@DisplayName("Test case for getObjectAndFieldsByDescription1 controller method to test if response is null.")
	@WithMockUser
	public void getObjectAndFieldsByDescriptionTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		when(coreModuleService.getModuleTree("en", "De", "0")).thenReturn(null);
		
		this.mockMvc.perform(get("/module/getbydescription/{lang}/{description}", "en","De")
				.header("authorization", "Bearer " + token).param("fetchcount", "0").param("fetchsize", "10")).andExpect(status().isInternalServerError());
		
		verify(coreModuleService).getModuleTree("en", "De", "0");
	}
	
	@Test
	@DisplayName("Test case for getModuleDescriptionBasedOnModuleidTest controller method to test if no moduleList is empty")
	@WithMockUser
	public void getModuleDescriptionBasedOnModuleidTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		ModuleDescriptionDTO response = new ModuleDescriptionDTO();
		response.setModuleid(1L);
		 
		when(coreModuleService.getModuleDescriptionBasedOnModuleid(1L,"en", "0")).thenReturn(response);
		
		this.mockMvc.perform(get("/module/get-module-desc/{MODULEID}/{LANG}", 1L,"en")
				.header("authorization", "Bearer " + token)).andExpect(status().isOk());
		
		verify(coreModuleService).getModuleDescriptionBasedOnModuleid(1L,"en", "0");
	}
	
	@Test
	@DisplayName("Test case for getModuleDescriptionBasedOnModuleidTest1 controller method to internal server error")
	@WithMockUser
	public void getModuleDescriptionBasedOnModuleidTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		when(coreModuleService.getModuleDescriptionBasedOnModuleid(1L,"en", "0")).thenReturn(null);
		
		this.mockMvc.perform(get("/module/get-module-desc/{MODULEID}/{LANG}", 1L,"en")
				.header("authorization", "Bearer " + token)).andExpect(status().isInternalServerError());
		
		verify(coreModuleService).getModuleDescriptionBasedOnModuleid(1L,"en", "0");
	}
	
	@Test
	@DisplayName("Test case for getAllModulesBasedOnSearchDetailsTest controller method to get all modules based on the serch details")
	@WithMockUser
	public void getAllModulesBasedOnSearchDetailsTest() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		List<CoreModuleModel> response = new ArrayList<>();
		CoreModuleModel modue = new CoreModuleModel();
		modue.setModuleId(1L);
		response.add(modue);
		 
		when(coreModuleService.getAllModulesBasedOnSearchDetails("en","Ma", "0")).thenReturn(response);
		
		this.mockMvc.perform(get("/module/{lang}/get-modules", "en")
				.header("authorization", "Bearer " + token).param("description", "Ma")).andExpect(status().isOk());
		
		verify(coreModuleService).getAllModulesBasedOnSearchDetails("en","Ma", "0");
	}
	
	@Test
	@DisplayName("Test case for getAllModulesBasedOnSearchDetailsTest1 controller method to test if response is null")
	@WithMockUser
	public void getAllModulesBasedOnSearchDetailsTest1() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		when(coreModuleService.getAllModulesBasedOnSearchDetails("en","Ma", "0")).thenReturn(null);
		
		this.mockMvc.perform(get("/module/{lang}/get-modules", "en")
				.header("authorization", "Bearer " + token).param("description", "Ma")).andExpect(status().isInternalServerError());
		
		verify(coreModuleService).getAllModulesBasedOnSearchDetails("en","Ma", "0");
	}
	
	@Test
	@DisplayName("Test case for getAllModulesBasedOnSearchDetailsTest2 controller method to test if response is empty")
	@WithMockUser
	public void getAllModulesBasedOnSearchDetailsTest2() throws Exception {
		
		String token = jWTTokenProvider.createToken(PAYLOAD);
		
		List<CoreModuleModel> response = new ArrayList<>();
		
		when(coreModuleService.getAllModulesBasedOnSearchDetails("en","Ma", "0")).thenReturn(response);
		
		this.mockMvc.perform(get("/module/{lang}/get-modules", "en")
				.header("authorization", "Bearer " + token).param("description", "Ma")).andExpect(status().isInternalServerError());
		
		verify(coreModuleService).getAllModulesBasedOnSearchDetails("en","Ma", "0");
	}

	@Test
	@DisplayName("Test case for getAllModulesBasedOnSearchDetailsTest controller method to get all modules based on the serch details")
	@WithMockUser
	public void getDetailsTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<CoreModuleModel> response = new ArrayList<>();
		CoreModuleModel modue = new CoreModuleModel();
		modue.setModuleId(1L);
		response.add(modue);

		when(coreModuleService.getDetailsByModuleId("0",1l)).thenReturn(null);

		this.mockMvc.perform(get("/module/{moduleId}/getDetails", 1l)
				.header("authorization", "Bearer " + token).param("moduleId","1")).andExpect(status().isInternalServerError());

		verify(coreModuleService).getDetailsByModuleId("0",1l);
	}

	@Test
	@DisplayName("Test case for getDetails controller method to test if response is null")
	@WithMockUser
	public void getDetailsTest1() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		when(coreModuleService.getDetailsByModuleId("0",1l)).thenReturn(null);

		this.mockMvc.perform(get("/module/{moduleId}/getDetails", 1l)
				.header("authorization", "Bearer " + token).param("moduleId","1")).andExpect(status().isInternalServerError());

		verify(coreModuleService).getDetailsByModuleId("0",1l);
	}

	@Test
	@DisplayName("Test case for getAllModulesBasedOnSearchDetailsTest2 controller method to test if response is empty")
	@WithMockUser
	public void getDetailsTest2() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<CoreModuleModel> response = new ArrayList<>();

		when(coreModuleService.getDetailsByModuleId("0",1l)).thenReturn(null);

		this.mockMvc.perform(get("/module/{moduleId}/getDetails", 1l)
				.header("authorization", "Bearer " + token).param("moduleId","1")).andExpect(status().isInternalServerError());

		verify(coreModuleService).getDetailsByModuleId("0",1l);
	}

	@DisplayName("Test case for save/update structure controller method for saving/updating structure")
	@Test
	@WithMockUser
	public void saveAndUpdateStructureTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);
		ModuleStructureDTO moduleStructureDTO = new ModuleStructureDTO();
		moduleStructureDTO.setLanguage("en");
		moduleStructureDTO.setIsHeader(true);
		moduleStructureDTO.setModuleId(0l);
		moduleStructureDTO.setParentStrucId(Short.parseShort("0"));
		moduleStructureDTO.setStrucDesc("Structure description");
		moduleStructureDTO.setTenantId("0");
		moduleStructureDTO.setParentStrucId(Short.parseShort("1"));
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(moduleStructureDTO);
		ModuleResponseDTO responseDTO = new ModuleResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreModuleService.saveModel(any(),any())).thenReturn(responseDTO);

		this.mockMvc.perform(post("/module/saveAndUpdateStructure").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk()).andReturn();

		verify(coreModuleService,atLeast(1)).saveAndUpdateStructure(any(), any());
	}
	
	@DisplayName("Test case for updateModule controller method for update a module")
	@Test
	@WithMockUser
	public void updateModule() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setSystemType("xyz");
		requestDTO.setIndustry("abc");
		requestDTO.setDisplayCriteria("view");
		requestDTO.setModuledescription(moduledescription);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");
		List<Long> parentModuleIds = new ArrayList<>();
		parentModuleIds.add(1l);
		requestDTO.setParentModuleIds(parentModuleIds);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(requestDTO);

		ModuleResponseDTO responseDTO = new ModuleResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreModuleService.updateModule(any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc
				.perform(put("/module/update/{MODULEID}", 1l).header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(requestJson))
				.andExpect(status().isOk()).andReturn();

		verify(coreModuleService, atLeast(1)).updateModule(any(), any(), any());
	}
	
	@DisplayName("Test case for updateModule controller method for update a module")
	@Test
	@WithMockUser
	public void updateModule1() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setSystemType("xyz");
		requestDTO.setIndustry("abc");
		requestDTO.setDisplayCriteria("view");
		requestDTO.setModuledescription(null);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");
		requestDTO.setParentModuleIds(null);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(requestDTO);

		ModuleResponseDTO responseDTO = new ModuleResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreModuleService.updateModule(any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc
				.perform(put("/module/update/{MODULEID}", 1l).header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(requestJson))
				.andExpect(status().isOk()).andReturn();

		verify(coreModuleService, atLeast(1)).updateModule(any(), any(), any());
	}

	@Test
	@DisplayName("Test case for Delete Module")
	@WithMockUser
	void deleteModule() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		ModuleResponseDTO responseDTO=new ModuleResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreModuleService.deleteModule(1L,"0")).thenReturn(responseDTO);

		this.mockMvc.perform(delete("/module/delete").param("moduleId","1")
				.header("authorization", "Bearer " + token)).andExpect(status().isOk());

		verify(coreModuleService,atLeast(1)).deleteModule(1L,"0");
	}

	@Test
	@DisplayName("Delete Structure Test")
	@WithMockUser
	void deleteStructureTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		ModuleResponseDTO responseDTO = new ModuleResponseDTO();
		when(coreModuleService.deleteStructure(1L,Short.parseShort("1"), "0")).thenReturn(responseDTO);

		this.mockMvc.perform(delete("/module/{moduleId}/delete-structure/{structId}", 1L,"1")
				.header("authorization", "Bearer " + token)).andExpect(status().isOk());

		verify(coreModuleService).deleteStructure(1L,Short.parseShort("1"), "0");
	}

	@Test
	@DisplayName("Get Structures Test")
	@WithMockUser
	void getAllStructures() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);


		when(coreModuleService.getAllStructures(1L,"0", "","en",1,1)).thenReturn(new ArrayList<>());

		this.mockMvc.perform(get("/module/{moduleId}/get-all-structures/{language}", 1L,"en")
				.param("searchTerm","")
				.param("fetchCount","1")
				.param("fetchSize","1")
				.header("authorization", "Bearer " + token)).andExpect(status().isOk());

		verify(coreModuleService).getAllStructures(1L,"0", "","en",1,1);
	}
}
