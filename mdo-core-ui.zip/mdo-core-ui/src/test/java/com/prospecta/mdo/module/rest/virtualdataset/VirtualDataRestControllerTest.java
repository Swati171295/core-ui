package com.prospecta.mdo.module.rest.virtualdataset;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.prospecta.mdo.module.component.JWTTokenProvider;
import com.prospecta.mdo.module.dto.JWTToken;
import com.prospecta.mdo.module.dto.virtualdata.CommonResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.CoreVdSchedulerRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.ResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinInfoRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupTransInfoRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupsRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdHeaderRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdHeaderResponseDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdTransFieldSettingRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdTransRuleConcatRequestDTO;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;
import com.prospecta.mdo.module.service.virtualdata.CommonService;
import com.prospecta.mdo.module.service.virtualdata.CoreVdHeaderService;
import com.prospecta.mdo.module.service.virtualdata.CoreVdSchedulerService;

/**
 * @author komal
 *
 */
@SpringBootTest
@ActiveProfiles("Test")
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
class VirtualDataRestControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private JWTTokenProvider jWTTokenProvider;

	private static final String PAYLOAD = "{\"username\":\"Admin\",\"roles\":[],\"tenantCode\":\"0\"}";

	@MockBean
	private CommonService commonService;

	@MockBean
	private CoreVdHeaderService coreVdHeaderService;

	@MockBean
	private CoreVdSchedulerService coreVdSchedulerService;

	@Test
	@WithMockUser
	@DisplayName("updateVirtualDatasetTest method to test update virtual dataset information")
	void updateVirtualDatasetTest() throws Exception {
		String token = jWTTokenProvider.createToken(PAYLOAD);

		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdId(UUID.randomUUID());
		vdHeaderRequestDTO.setVdName("test");
		vdHeaderRequestDTO.setVdDescription("test");
		vdHeaderRequestDTO.setTenantId("M00001");
		VdHeaderResponseDTO vdHeaderResponseDTO = new VdHeaderResponseDTO();
		vdHeaderResponseDTO.setVdId(UUID.randomUUID());
		vdHeaderResponseDTO.setVdName("test");

		CommonResponseDTO commonResponse = new CommonResponseDTO();
		commonResponse.setData(vdHeaderResponseDTO);
		commonResponse.setSuccess(true);
		commonResponse.setStatus(200);

		when(commonService.updateVirtualDataset(vdHeaderRequestDTO, "0")).thenReturn(commonResponse);

		this.mockMvc
				.perform(post("/virtualdataset/save-update").header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(convertToJson(vdHeaderRequestDTO)))
				.andExpect(status().isOk());

		verify(commonService, atLeast(1)).updateVirtualDataset(any(), anyString());

	}

	@Test
	@WithMockUser
	@DisplayName("updateVirtualDatasetTest1 method to test the exception handaling part")
	void updateVirtualDatasetTest1() throws Exception {
		String token = jWTTokenProvider.createToken(PAYLOAD);

		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdId(UUID.randomUUID());
		vdHeaderRequestDTO.setVdName("test");
		vdHeaderRequestDTO.setVdDescription("test");
		vdHeaderRequestDTO.setTenantId("M00001");
		when(commonService.updateVirtualDataset(any(), anyString())).thenThrow(new RuntimeException());

		this.mockMvc
				.perform(post("/virtualdataset/save-update").header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(convertToJson(vdHeaderRequestDTO)))
				.andExpect(status().isInternalServerError());

		verify(commonService, atLeast(1)).updateVirtualDataset(any(), anyString());

	}

	@Test
	@WithMockUser
	@DisplayName("updateVirtualDatasetTestSourceOneException method to test the exception handaling part")
	void updateVirtualDatasetTestSourceOneException() throws Exception {
		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<VdGroupJoinInfoRequestDTO> groupJoinInfoRequestDTO = new ArrayList<>();
		VdGroupJoinInfoRequestDTO vdGroupJoinInfoRequestDTO = new VdGroupJoinInfoRequestDTO();
		vdGroupJoinInfoRequestDTO.setSourceOne("customer");
		vdGroupJoinInfoRequestDTO.setSourceOneType("MODULE");
		vdGroupJoinInfoRequestDTO.setSourceTwo("country");
		vdGroupJoinInfoRequestDTO.setSourceTwoType("SYSTABLE");
		vdGroupJoinInfoRequestDTO.setSourceOneModule(null);
		vdGroupJoinInfoRequestDTO.setSourceTwoModule(null);
		vdGroupJoinInfoRequestDTO.setJoinType("INNER");
		vdGroupJoinInfoRequestDTO.setJoinOperator("AND");
		groupJoinInfoRequestDTO.add(vdGroupJoinInfoRequestDTO);
		List<VdGroupsRequestDTO> groupsRequestDTO = new ArrayList<>();
		VdGroupsRequestDTO vdGroupsRequestDTO = new VdGroupsRequestDTO();
		vdGroupsRequestDTO.setGroupType("join");
		vdGroupsRequestDTO.setGroupName("join 1");
		vdGroupsRequestDTO.setGroupJoinDetail(groupJoinInfoRequestDTO);
		groupsRequestDTO.add(vdGroupsRequestDTO);
		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdId(UUID.randomUUID());
		vdHeaderRequestDTO.setVdName("test");
		vdHeaderRequestDTO.setVdDescription("test");
		vdHeaderRequestDTO.setTenantId("M00001");
		vdHeaderRequestDTO.setGroupDetails(groupsRequestDTO);
		when(commonService.updateVirtualDataset(any(), anyString())).thenThrow(new RuntimeException());

		this.mockMvc
				.perform(post("/virtualdataset/save-update").header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(convertToJson(vdHeaderRequestDTO)))
				.andExpect(status().is(400));

		verify(commonService, atLeast(0)).updateVirtualDataset(any(), anyString());

	}

	@Test
	@WithMockUser
	@DisplayName("updateVirtualDatasetTestSourceTwoModuleException method to test the exception handaling part")
	void updateVirtualDatasetTestSourceTwoModuleException() throws Exception {
		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<VdGroupJoinInfoRequestDTO> groupJoinInfoRequestDTO = new ArrayList<>();
		VdGroupJoinInfoRequestDTO vdGroupJoinInfoRequestDTO = new VdGroupJoinInfoRequestDTO();
		vdGroupJoinInfoRequestDTO.setSourceOne("customer");
		vdGroupJoinInfoRequestDTO.setSourceOneType("MODULE");
		vdGroupJoinInfoRequestDTO.setSourceTwo("country");
		vdGroupJoinInfoRequestDTO.setSourceTwoType("Module");
		vdGroupJoinInfoRequestDTO.setSourceOneModule(113L);
		vdGroupJoinInfoRequestDTO.setSourceTwoModule(123L);
		vdGroupJoinInfoRequestDTO.setJoinType("INNER");
		vdGroupJoinInfoRequestDTO.setJoinOperator("AND");
		vdGroupJoinInfoRequestDTO.setSourceOneScopeUdr("1234");
		vdGroupJoinInfoRequestDTO.setSourceTwoScopeUdr("1234");
		vdGroupJoinInfoRequestDTO.setResultScopeUdr("1234");
		groupJoinInfoRequestDTO.add(vdGroupJoinInfoRequestDTO);
		List<VdGroupsRequestDTO> groupsRequestDTO = new ArrayList<>();
		VdGroupsRequestDTO vdGroupsRequestDTO = new VdGroupsRequestDTO();
		vdGroupsRequestDTO.setGroupType("join");
		vdGroupsRequestDTO.setGroupName("join 1");
		vdGroupsRequestDTO.setGroupJoinDetail(groupJoinInfoRequestDTO);
		groupsRequestDTO.add(vdGroupsRequestDTO);
		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdId(UUID.randomUUID());
		vdHeaderRequestDTO.setVdName("test");
		vdHeaderRequestDTO.setVdDescription("test");
		vdHeaderRequestDTO.setTenantId("M00001");
		vdHeaderRequestDTO.setGroupDetails(groupsRequestDTO);
		VdHeaderResponseDTO vdHeaderResponseDTO = new VdHeaderResponseDTO();
		vdHeaderResponseDTO.setVdId(UUID.randomUUID());
		vdHeaderResponseDTO.setVdName("test");
		CommonResponseDTO commonResponse = new CommonResponseDTO();
		commonResponse.setData(vdHeaderResponseDTO);
		commonResponse.setSuccess(true);
		commonResponse.setStatus(200);

		when(commonService.updateVirtualDataset(vdHeaderRequestDTO, "0")).thenReturn(commonResponse);

		this.mockMvc
				.perform(post("/virtualdataset/save-update").header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(convertToJson(vdHeaderRequestDTO)))
				.andExpect(status().isOk());

		verify(commonService, atLeast(1)).updateVirtualDataset(any(), anyString());

	}

	@Test
	@WithMockUser
	@DisplayName("updateVirtualDatasetTestSourceTwoException method to test the exception handaling part")
	void updateVirtualDatasetTestSourceTwoException() throws Exception {
		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<VdGroupJoinInfoRequestDTO> groupJoinInfoRequestDTO = new ArrayList<>();
		VdGroupJoinInfoRequestDTO vdGroupJoinInfoRequestDTO = new VdGroupJoinInfoRequestDTO();
		vdGroupJoinInfoRequestDTO.setSourceOne("customer");
		vdGroupJoinInfoRequestDTO.setSourceOneType("SYSTABLE");
		vdGroupJoinInfoRequestDTO.setSourceTwo("country");
		vdGroupJoinInfoRequestDTO.setSourceTwoType("Module");
		vdGroupJoinInfoRequestDTO.setSourceOneModule(null);
		vdGroupJoinInfoRequestDTO.setSourceTwoModule(null);
		vdGroupJoinInfoRequestDTO.setJoinType("INNER");
		vdGroupJoinInfoRequestDTO.setJoinOperator("AND");
		groupJoinInfoRequestDTO.add(vdGroupJoinInfoRequestDTO);
		List<VdGroupsRequestDTO> groupsRequestDTO = new ArrayList<>();
		VdGroupsRequestDTO vdGroupsRequestDTO = new VdGroupsRequestDTO();
		vdGroupsRequestDTO.setGroupType("join");
		vdGroupsRequestDTO.setGroupName("join 1");
		vdGroupsRequestDTO.setGroupJoinDetail(groupJoinInfoRequestDTO);
		groupsRequestDTO.add(vdGroupsRequestDTO);
		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdId(UUID.randomUUID());
		vdHeaderRequestDTO.setVdName("test");
		vdHeaderRequestDTO.setVdDescription("test");
		vdHeaderRequestDTO.setTenantId("M00001");
		vdHeaderRequestDTO.setGroupDetails(groupsRequestDTO);
		when(commonService.updateVirtualDataset(any(), anyString())).thenThrow(new RuntimeException());

		this.mockMvc
				.perform(post("/virtualdataset/save-update").header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(convertToJson(vdHeaderRequestDTO)))
				.andExpect(status().is(400));

		verify(commonService, atLeast(0)).updateVirtualDataset(any(), anyString());

	}

	@Test
	@WithMockUser
	@DisplayName("updateVirtualDatasetTestTransInfoSourceException method to test the exception handaling part")
	void updateVirtualDatasetTestTransInfoSourceException() throws Exception {
		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<VdGroupTransInfoRequestDTO> groupTransInfoRequestDTO = new ArrayList<>();
		VdGroupTransInfoRequestDTO vdGroupTransInfoRequestDTO = new VdGroupTransInfoRequestDTO();
		vdGroupTransInfoRequestDTO.setSource("user");
		vdGroupTransInfoRequestDTO.setSourceType("Module");
		vdGroupTransInfoRequestDTO.setSourceModule(null);
		groupTransInfoRequestDTO.add(vdGroupTransInfoRequestDTO);
		List<VdGroupsRequestDTO> groupsRequestDTO = new ArrayList<>();
		VdGroupsRequestDTO vdGroupsRequestDTO = new VdGroupsRequestDTO();
		vdGroupsRequestDTO.setGroupType("join");
		vdGroupsRequestDTO.setGroupName("join 1");
		vdGroupsRequestDTO.setGroupTransDetail(groupTransInfoRequestDTO);
		groupsRequestDTO.add(vdGroupsRequestDTO);
		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdId(UUID.randomUUID());
		vdHeaderRequestDTO.setVdName("test");
		vdHeaderRequestDTO.setVdDescription("test");
		vdHeaderRequestDTO.setTenantId("M00001");
		vdHeaderRequestDTO.setGroupDetails(groupsRequestDTO);
		when(commonService.updateVirtualDataset(any(), anyString())).thenThrow(new RuntimeException());

		this.mockMvc
				.perform(post("/virtualdataset/save-update").header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(convertToJson(vdHeaderRequestDTO)))
				.andExpect(status().is(400));

		verify(commonService, atLeast(0)).updateVirtualDataset(any(), anyString());

	}

	@Test
	@WithMockUser
	@DisplayName("updateVirtualDatasetTestUserInputException method to test the exception handaling part")
	void updateVirtualDatasetTestUserInputException() throws Exception {
		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<VdTransRuleConcatRequestDTO> transRuleConcatRequestDTO = new ArrayList<>();
		VdTransRuleConcatRequestDTO vdTransRuleConcatRequestDTO = new VdTransRuleConcatRequestDTO();
		vdTransRuleConcatRequestDTO.setFieldName("test");
		vdTransRuleConcatRequestDTO.setFieldType("USERINPUT");
		vdTransRuleConcatRequestDTO.setFieldValue("abc@");
		transRuleConcatRequestDTO.add(vdTransRuleConcatRequestDTO);
		List<VdTransFieldSettingRequestDTO> transFieldSettingRequestDTO = new ArrayList<>();
		VdTransFieldSettingRequestDTO vdTransFieldSettingRequestDTO = new VdTransFieldSettingRequestDTO();
		vdTransFieldSettingRequestDTO.setFieldName("userId");
		vdTransFieldSettingRequestDTO.setTransRuleType("CONCAT");
		vdTransFieldSettingRequestDTO.setTransConcatDetail(transRuleConcatRequestDTO);
		transFieldSettingRequestDTO.add(vdTransFieldSettingRequestDTO);
		List<VdGroupTransInfoRequestDTO> groupTransInfoRequestDTO = new ArrayList<>();
		VdGroupTransInfoRequestDTO vdGroupTransInfoRequestDTO = new VdGroupTransInfoRequestDTO();
		vdGroupTransInfoRequestDTO.setSource("user");
		vdGroupTransInfoRequestDTO.setSourceType("Module");
		vdGroupTransInfoRequestDTO.setSourceModule(123L);
		vdGroupTransInfoRequestDTO.setGroupTransFieldSetting(transFieldSettingRequestDTO);
		groupTransInfoRequestDTO.add(vdGroupTransInfoRequestDTO);
		List<VdGroupsRequestDTO> groupsRequestDTO = new ArrayList<>();
		VdGroupsRequestDTO vdGroupsRequestDTO = new VdGroupsRequestDTO();
		vdGroupsRequestDTO.setGroupType("join");
		vdGroupsRequestDTO.setGroupName("join 1");
		vdGroupsRequestDTO.setGroupTransDetail(groupTransInfoRequestDTO);
		groupsRequestDTO.add(vdGroupsRequestDTO);
		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdId(UUID.randomUUID());
		vdHeaderRequestDTO.setVdName("test");
		vdHeaderRequestDTO.setVdDescription("test");
		vdHeaderRequestDTO.setTenantId("M00001");
		vdHeaderRequestDTO.setGroupDetails(groupsRequestDTO);
		when(commonService.updateVirtualDataset(any(), anyString())).thenThrow(new RuntimeException());

		this.mockMvc
				.perform(post("/virtualdataset/save-update").header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(convertToJson(vdHeaderRequestDTO)))
				.andExpect(status().is(400));

		verify(commonService, atLeast(0)).updateVirtualDataset(any(), anyString());

	}

	@Test
	@WithMockUser
	@DisplayName("updateVirtualDatasetTestUserInputValidateException method to test the exception handaling part")
	void updateVirtualDatasetTestUserInputValidateException() throws Exception {
		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<VdTransRuleConcatRequestDTO> transRuleConcatRequestDTO = new ArrayList<>();
		VdTransRuleConcatRequestDTO vdTransRuleConcatRequestDTO = new VdTransRuleConcatRequestDTO();
		vdTransRuleConcatRequestDTO.setFieldName("test");
		vdTransRuleConcatRequestDTO.setFieldType("USERINPUT");
		vdTransRuleConcatRequestDTO.setFieldValue("field value");
		transRuleConcatRequestDTO.add(vdTransRuleConcatRequestDTO);
		List<VdTransFieldSettingRequestDTO> transFieldSettingRequestDTO = new ArrayList<>();
		VdTransFieldSettingRequestDTO vdTransFieldSettingRequestDTO = new VdTransFieldSettingRequestDTO();
		vdTransFieldSettingRequestDTO.setFieldName("userId");
		vdTransFieldSettingRequestDTO.setTransRuleType("CONCAT");
		vdTransFieldSettingRequestDTO.setTransConcatDetail(transRuleConcatRequestDTO);
		transFieldSettingRequestDTO.add(vdTransFieldSettingRequestDTO);
		List<VdGroupTransInfoRequestDTO> groupTransInfoRequestDTO = new ArrayList<>();
		VdGroupTransInfoRequestDTO vdGroupTransInfoRequestDTO = new VdGroupTransInfoRequestDTO();
		vdGroupTransInfoRequestDTO.setSource("user");
		vdGroupTransInfoRequestDTO.setSourceType("Module");
		vdGroupTransInfoRequestDTO.setSourceModule(123L);
		vdGroupTransInfoRequestDTO.setGroupTransFieldSetting(transFieldSettingRequestDTO);
		groupTransInfoRequestDTO.add(vdGroupTransInfoRequestDTO);
		List<VdGroupsRequestDTO> groupsRequestDTO = new ArrayList<>();
		VdGroupsRequestDTO vdGroupsRequestDTO = new VdGroupsRequestDTO();
		vdGroupsRequestDTO.setGroupType("join");
		vdGroupsRequestDTO.setGroupName("join 1");
		vdGroupsRequestDTO.setGroupTransDetail(groupTransInfoRequestDTO);
		groupsRequestDTO.add(vdGroupsRequestDTO);
		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdId(UUID.randomUUID());
		vdHeaderRequestDTO.setVdName("test");
		vdHeaderRequestDTO.setVdDescription("test");
		vdHeaderRequestDTO.setTenantId("M00001");
		vdHeaderRequestDTO.setGroupDetails(groupsRequestDTO);
		when(commonService.updateVirtualDataset(any(), anyString())).thenThrow(new RuntimeException());

		this.mockMvc
				.perform(post("/virtualdataset/save-update").header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(convertToJson(vdHeaderRequestDTO)))
				.andExpect(status().is(400));

		verify(commonService, atLeast(0)).updateVirtualDataset(any(), anyString());

	}

	@Test
	@WithMockUser
	@DisplayName("updateVirtualDatasetTestUserInputNullException method to test the exception handaling part")
	void updateVirtualDatasetTestUserInputNullException() throws Exception {
		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<VdTransRuleConcatRequestDTO> transRuleConcatRequestDTO = new ArrayList<>();
		VdTransRuleConcatRequestDTO vdTransRuleConcatRequestDTO = new VdTransRuleConcatRequestDTO();
		vdTransRuleConcatRequestDTO.setFieldName("test");
		vdTransRuleConcatRequestDTO.setFieldType("USERINPUT");
		vdTransRuleConcatRequestDTO.setFieldValue(null);
		transRuleConcatRequestDTO.add(vdTransRuleConcatRequestDTO);
		List<VdTransFieldSettingRequestDTO> transFieldSettingRequestDTO = new ArrayList<>();
		VdTransFieldSettingRequestDTO vdTransFieldSettingRequestDTO = new VdTransFieldSettingRequestDTO();
		vdTransFieldSettingRequestDTO.setFieldName("userId");
		vdTransFieldSettingRequestDTO.setTransRuleType("CONCAT");
		vdTransFieldSettingRequestDTO.setTransConcatDetail(transRuleConcatRequestDTO);
		transFieldSettingRequestDTO.add(vdTransFieldSettingRequestDTO);
		List<VdGroupTransInfoRequestDTO> groupTransInfoRequestDTO = new ArrayList<>();
		VdGroupTransInfoRequestDTO vdGroupTransInfoRequestDTO = new VdGroupTransInfoRequestDTO();
		vdGroupTransInfoRequestDTO.setSource("user");
		vdGroupTransInfoRequestDTO.setSourceType("Module");
		vdGroupTransInfoRequestDTO.setSourceModule(123L);
		vdGroupTransInfoRequestDTO.setGroupTransFieldSetting(transFieldSettingRequestDTO);
		groupTransInfoRequestDTO.add(vdGroupTransInfoRequestDTO);
		List<VdGroupsRequestDTO> groupsRequestDTO = new ArrayList<>();
		VdGroupsRequestDTO vdGroupsRequestDTO = new VdGroupsRequestDTO();
		vdGroupsRequestDTO.setGroupType("join");
		vdGroupsRequestDTO.setGroupName("join 1");
		vdGroupsRequestDTO.setGroupTransDetail(groupTransInfoRequestDTO);
		groupsRequestDTO.add(vdGroupsRequestDTO);
		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdId(UUID.randomUUID());
		vdHeaderRequestDTO.setVdName("test");
		vdHeaderRequestDTO.setVdDescription("test");
		vdHeaderRequestDTO.setTenantId("M00001");
		vdHeaderRequestDTO.setGroupDetails(groupsRequestDTO);
		when(commonService.updateVirtualDataset(any(), anyString())).thenThrow(new RuntimeException());

		this.mockMvc
				.perform(post("/virtualdataset/save-update").header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(convertToJson(vdHeaderRequestDTO)))
				.andExpect(status().is(400));

		verify(commonService, atLeast(0)).updateVirtualDataset(any(), anyString());

	}

	static <T> String convertToJson(T object) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		ObjectWriter writer = mapper.writer().withDefaultPrettyPrinter();

		return writer.writeValueAsString(object);
	}

	@Test
	@DisplayName("Test case for createVirtualDatasetTest controller method to test everything working properly.")
	@WithMockUser
	void createVirtualDatasetTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdName("Sample Dataset");
		vdHeaderRequestDTO.setVdDescription("Sample Description");

		Gson gson = new Gson();
		String json = gson.toJson(vdHeaderRequestDTO);

		when(coreVdHeaderService.createVirtualDataset(vdHeaderRequestDTO, "M00001"))
				.thenReturn(new CommonResponseDTO(200, true, "Your dataset has been created successfully.",
						"{'virtualDatasetId':0,'virtualDatasetName':'test'}"));

		this.mockMvc.perform(post("/virtualdataset/create-dataset").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(json)).andExpect(status().isOk());

		verify(coreVdHeaderService).createVirtualDataset(any(), anyString());
	}

	@Test
	@DisplayName("Test case for createVirtualDatasetVdNameNotPresentTest controller method to test internal server error for vdName is not present.")
	@WithMockUser
	void createVirtualDatasetVdNameNotPresentTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdName(null);
		vdHeaderRequestDTO.setVdDescription("Sample Description");

		Gson gson = new Gson();
		String json = gson.toJson(vdHeaderRequestDTO);

		this.mockMvc.perform(post("/virtualdataset/create-dataset").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(json)).andExpect(status().isBadRequest());
	}

	@Test
	@DisplayName("Test case for createVirtualDatasetVdDescriptionNotPresentTest controller method to test create virtual dataset without vdDescription.")
	@WithMockUser
	void createVirtualDatasetVdDescriptionNotPresentTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdName("Sample Dataset");

		Gson gson = new Gson();
		String json = gson.toJson(vdHeaderRequestDTO);

		when(coreVdHeaderService.createVirtualDataset(vdHeaderRequestDTO, "0"))
				.thenReturn(new CommonResponseDTO(200, true, "Your dataset has been created successfully.",
						"{'virtualDatasetId':0,'virtualDatasetName':'test'}"));

		this.mockMvc.perform(post("/virtualdataset/create-dataset").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(json)).andExpect(status().isOk());

		verify(coreVdHeaderService, atLeast(1)).createVirtualDataset(any(), anyString());
	}

	@Test
	@DisplayName("Test case for createVirtualDatasetSpecialCharTest controller method to test create virtual dataset with special characters.")
	@WithMockUser
	void createVirtualDatasetSpecialCharTest() throws Exception {

	String token = jWTTokenProvider.createToken(PAYLOAD);
		
 		VdHeaderRequestDTO vdHeaderRequestDTO = new VdHeaderRequestDTO();
		vdHeaderRequestDTO.setVdName("Sample@#$%");
		vdHeaderRequestDTO.setVdDescription("Sample Description");

	    Gson gson = new Gson();
	    String json = gson.toJson(vdHeaderRequestDTO);
		
		when(coreVdHeaderService.createVirtualDataset(vdHeaderRequestDTO, "M00001"))
		.thenReturn(new CommonResponseDTO(200, true, "Your dataset has been created successfully.","{'virtualDatasetId':0,'virtualDatasetName':'Sample@#$%'}"));		
		
		this.mockMvc.perform(post("/virtualdataset/create-dataset")
				.header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON)
	            .content(json))
				.andExpect(status().isOk());
		
		verify(coreVdHeaderService).createVirtualDataset(any(), anyString());	
	}

	@Test
	@DisplayName("Test case for listVirtualDatasetWithTenantIdTest controller method to test everything working properly.")
	@WithMockUser
	void listVirtualDatasetWithTenantIdTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		Pageable paging = PageRequest.of(0, 1);

		when(coreVdHeaderService.getVirtualDatasetList(new ArrayList<>(List.of("M00001")), paging, "a")).thenReturn(
				new ResponseDTO("Success.", "{'virtualDatasetId':0,'virtualDatasetName':'test','tenantId':'M00001'}"));

		this.mockMvc
				.perform(get("/virtualdataset/get-dataset-list", 1L, "en").header("authorization", "Bearer " + token)
						.param("searchstring", "a").param("page", "0").param("size", "10"))
				.andExpect(status().isOk());

		verify(coreVdHeaderService, atLeast(1)).getVirtualDatasetList(any(), any(), anyString());
	}

	@Test
	@DisplayName("Test case for listVirtualDatasetWithoutTenantIdTest controller method to test everything working properly.")
	@WithMockUser
	void listVirtualDatasetWithoutTenantIdTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		Pageable paging = PageRequest.of(0, 1);

		when(coreVdHeaderService.getVirtualDatasetList(null, paging, "a")).thenReturn(
				new ResponseDTO("Success.", "{'virtualDatasetId':0,'virtualDatasetName':'test','tenantId':'null'}"));

		this.mockMvc
				.perform(get("/virtualdataset/get-dataset-list", 1L, "en").header("authorization", "Bearer " + token)
						.param("searchstring", "a").param("page", "0").param("size", "1"))
				.andExpect(status().isOk());

		verify(coreVdHeaderService, atLeast(1)).getVirtualDatasetList(any(), any(), anyString());
	}

	@Test
	@DisplayName("Test case for listVirtualDatasetWithSpecialCharacterTest controller method to test searchString as special character.")
	@WithMockUser
	void listVirtualDatasetWithSpecialCharacterTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		Pageable paging = PageRequest.of(0, 1);

		JWTToken jwtToken = new JWTToken();
		jwtToken.setTenantCode("M00001");

		when(coreVdHeaderService.getVirtualDatasetList(new ArrayList<>(List.of(jwtToken.getTenantCode())), paging, "@"))
				.thenReturn(new ResponseDTO("Success.",
						"{'virtualDatasetId':0,'virtualDatasetName':'test','tenantId':'M00001'}"));

		when(coreVdHeaderService.getVirtualDatasetList(new ArrayList<>(List.of("M00001")), paging, "@")).thenReturn(
				new ResponseDTO("Success.", "{'virtualDatasetId':0,'virtualDatasetName':'test','tenantId':'M00001'}"));

		this.mockMvc
				.perform(get("/virtualdataset/get-dataset-list", 1L, "en").header("authorization", "Bearer " + token)
						.param("searchstring", "a").param("page", "0").param("size", "10"))
				.andExpect(status().isOk());

		verify(coreVdHeaderService, atLeast(1)).getVirtualDatasetList(any(), any(), anyString());
	}

	@Test
	@DisplayName("Test case for listVirtualDatasetWithPaginationAndSortingTest controller method to test searchString as special character.")
	@WithMockUser
	void listVirtualDatasetWithPaginationAndSortingTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		Pageable paging = PageRequest.of(0, 2);

		when(coreVdHeaderService.getVirtualDatasetList(new ArrayList<>(List.of("M00001")), paging, ""))
				.thenReturn(new ResponseDTO("Success.",
						"{'virtualDatasetId':0,'virtualDatasetName':'abc','tenantId':'M00001'},{'virtualDatasetId':0,'virtualDatasetName':'def','tenantId':'M00001'}"));

		this.mockMvc
				.perform(get("/virtualdataset/get-dataset-list", 1L, "en").header("authorization", "Bearer " + token)
						.param("tenantId", "M000001").param("searchstring", "a").param("page", "0").param("size", "10"))
				.andExpect(status().isOk());

		verify(coreVdHeaderService, atLeast(1)).getVirtualDatasetList(any(), any(), anyString());
	}

	@Test
	@DisplayName("Test case for deleteVirtualDatasetTest controller method to test delete virtual dataset.")
	@WithMockUser
	void deleteVirtualDatasetTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		when(commonService.deleteVirtualDataset(any(), any())).thenReturn(new CommonResponseDTO());

		this.mockMvc.perform(delete("/virtualdataset/delete-dataset", 1L, "en")
				.header("authorization", "Bearer " + token).param("vdId", "084f4bca-effd-49d5-b3f8-3497ba0f8cc9"))
				.andExpect(status().isOk());

		verify(commonService, atLeast(1)).deleteVirtualDataset(any(), any());
	}

	@Test
	@DisplayName("Test case for deleteVirtualDatasetVdIdNullTest controller method to test delete virtual dataset exception.")
	@WithMockUser
	void deleteVirtualDatasetVdIdNullTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		when(commonService.deleteVirtualDataset(any(), any())).thenReturn(new CommonResponseDTO());

		this.mockMvc
				.perform(delete("/virtualdataset/delete-dataset", 1L, "en").header("authorization", "Bearer " + token))
				.andExpect(status().isBadRequest());

		verify(commonService, atLeast(0)).deleteVirtualDataset(any(), any());
	}

	@Test
	@DisplayName("Test case for deleteVirtualDatasetExceptionTest controller method to test delete virtual dataset exception.")
	@WithMockUser
	void deleteVirtualDatasetExceptionTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		when(commonService.deleteVirtualDataset(any(), any())).thenThrow(new RuntimeException());

		this.mockMvc.perform(delete("/virtualdataset/delete-dataset", 1L, "en")
				.header("authorization", "Bearer " + token).param("vdId", "084f4bca-effd-49d5-b3f8-3497ba0f8cc9"))
				.andExpect(status().is(500));

		verify(commonService, atLeast(0)).deleteVirtualDataset(any(), any());
	}

	@Test
	@DisplayName("Test case for getVirtualDatasetTest controller method to test get virtual dataset.")
	@WithMockUser
	void getVirtualDatasetTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		when(commonService.getVirtualDataset(any(), any())).thenReturn(
				new ResponseDTO("Success.", "{'virtualDatasetId':0,'virtualDatasetName':'abc','tenantId':'M00001'}"));

		this.mockMvc.perform(get("/virtualdataset/get-dataset", 1L, "en").header("authorization", "Bearer " + token)
				.param("vdId", "084f4bca-effd-49d5-b3f8-3497ba0f8cc9")).andExpect(status().isOk());

		verify(commonService, atLeast(1)).getVirtualDataset(any(), any());
	}

	@Test
	@DisplayName("Test case for getVirtualDatasetWithNullVdIdTest controller method to test get virtual dataset.")
	@WithMockUser
	void getVirtualDatasetWithNullVdIdTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		when(commonService.getVirtualDataset(any(), any())).thenReturn(new ResponseDTO());

		this.mockMvc.perform(get("/virtualdataset/get-dataset", 1L, "en").header("authorization", "Bearer " + token))
				.andExpect(status().isBadRequest());
	}

	@Test
	@DisplayName("Test case for getVirtualDatasetWithExceptionTest controller method for test exception.")
	@WithMockUser
	void getVirtualDatasetWithExceptionTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		when(commonService.getVirtualDataset(any(), any())).thenThrow(new RuntimeException());

		this.mockMvc.perform(get("/virtualdataset/get-dataset", 1L, "en").header("authorization", "Bearer " + token)
				.param("vdId", "084f4bca-effd-49d5-b3f8-3497ba0f8cc9")).andExpect(status().is(500));
	}

	@Test
	@DisplayName("Test case for createSchedulerTest controller method to create Scheduler.")
	@WithMockUser
	void createSchedulerTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		CoreVdSchedulerRequestDTO requestDTO = new CoreVdSchedulerRequestDTO();
		requestDTO.setVdId(UUID.randomUUID());
		requestDTO.setRestEndpoint("sample rest endpoint");
		Map<String, String> map = new HashMap<>();
		map.put("value1", "value2");
		requestDTO.setRestParams(map);
		requestDTO.setRestBody("sample rest body");
		requestDTO.setRestMethod("sample rest method");
		requestDTO.setTenantId("M0001");
		requestDTO.setStartTime(Timestamp.valueOf("2021-10-13 10:45:44"));
		requestDTO.setEndTime(Timestamp.valueOf("2021-10-13 10:45:44"));
		requestDTO.setCron("0 0 * * 0");
		when(coreVdSchedulerService.scheduleJob(any(), any())).thenReturn(new CommonResponseDTO("Success.",
				"{'virtualDatasetId':0,'virtualDatasetName':'abc','tenantId':'M00001'}"));

		this.mockMvc
				.perform(post("/virtualdataset/create-scheduler", 1L, "en").header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(convertToJson(requestDTO)))
				.andExpect(status().isOk());
		verify(coreVdSchedulerService, atLeast(1)).scheduleJob(any(), any());
	}

	@Test
	@DisplayName("Test case for createSchedulerCatchTest controller method to create Scheduler.")
	@WithMockUser
	void createSchedulerCatchTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		CoreVdSchedulerRequestDTO requestDTO = new CoreVdSchedulerRequestDTO();
		requestDTO.setVdId(UUID.randomUUID());
		requestDTO.setRestEndpoint("sample rest endpoint");
		Map<String, String> map = new HashMap<>();
		map.put("value1", "value2");
		requestDTO.setRestParams(map);
		requestDTO.setRestBody("sample rest body");
		requestDTO.setRestMethod("sample rest method");
		requestDTO.setTenantId("M0001");
		requestDTO.setStartTime(Timestamp.valueOf("2021-10-13 10:45:44"));
		requestDTO.setEndTime(Timestamp.valueOf("2021-10-13 10:45:44"));
		requestDTO.setCron("0 0 * * 0");
		when(coreVdSchedulerService.scheduleJob(any(), any())).thenThrow(new RuntimeException());

		this.mockMvc
				.perform(post("/virtualdataset/create-scheduler", 1L, "en").header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(convertToJson(requestDTO)))
				.andExpect(status().isInternalServerError());
	}

	@Test
	@DisplayName("Test case for sparkJobTest controller method to test everything working properly.")
	@WithMockUser
	void sparkJobTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		when(coreVdSchedulerService.sendToSparkJob(UUID.randomUUID(), "a"))
				.thenReturn(new CommonResponseDTO("Success.", "{'vdId':0}"));

		this.mockMvc.perform(post("/virtualdataset/send-to-spark", 1L, "en").header("authorization", "Bearer " + token)
				.param("vdId", "084f4bca-effd-49d5-b3f8-3497ba0f8cc9")).andExpect(status().isOk());

		verify(coreVdSchedulerService, atLeast(1)).sendToSparkJob(any(), anyString());
	}

	@Test
	@DisplayName("Test case for sparkJobCatchTest controller method to test catch block.")
	@WithMockUser
	void sparkJobCatchTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		when(coreVdSchedulerService.sendToSparkJob(any(), anyString())).thenThrow(new RuntimeException());

		this.mockMvc
				.perform(post("/virtualdataset/send-to-spark", 1L, "en").header("authorization", "Bearer " + token)
						.param("vdId", "084f4bca-effd-49d5-b3f8-3497ba0f8cc9"))
				.andExpect(status().isInternalServerError());
	}
}
