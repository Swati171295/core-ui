/**
 *
 */
package com.prospecta.mdo.module.service.tab;

import com.prospecta.mdo.module.dao.layout.CoreLayoutTabDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataLangDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabFieldsDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabLabelsDAO;
import com.prospecta.mdo.module.dto.layout.LayoutTabDTO;
import com.prospecta.mdo.module.dto.tab.*;
import com.prospecta.mdo.module.enums.FieldType;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.layout.CoreLayoutTabModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;
import com.prospecta.mdo.module.model.tab.CoreTabFieldsModel;
import com.prospecta.mdo.module.model.tab.CoreTabLabelsModel;
import com.prospecta.mdo.module.model.tab.CoreTabModel;
import com.prospecta.mdo.module.service.metadata.CoreMetadataService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * @author savan
 *
 */
@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
public class CoreTabModelServiceTest {

	@InjectMocks
	private CoreTabModelServiceImpl coreTabModelServiceImpl;
	
	@Mock
	private CoreTabDAO coreTabModelDAO;
	
	@Mock
	private CoreTabLabelsDAO coreTabLabelsModelDAO;
	
	@Mock
	private CoreTabFieldsDAO coreTabFieldsDAO;

	@Mock
	private CoreMetadataLangDAO coreMetadataLangDAO;

	@Mock
	private CoreMetadataDAO coreMetadataDAO;

	@Mock
	private CoreLayoutTabDAO coreLayoutTabDAO;

	@Mock
	private CoreMetadataService coreMetadataService;

	@BeforeAll
	public void init() {
		coreTabModelServiceImpl = new CoreTabModelServiceImpl();
	}
	
	@Test
	@DisplayName("createTabTest method test for create layout")
	public void createTabTest() {
		
		TabRequestDTO dto = new TabRequestDTO();
		dto.setModuleid("1");

		Map<String, String> description = new HashMap<String, String>();
		description.put("en", "Label English");
		description.put("sp", "Label English");
		
		Map<String, String> information = new HashMap<String, String>();
		information.put("en", "Information text of English for Tab Level");
		
		dto.setDescription(description);
		dto.setInformation(information);
		
		List<CoreTabLabelsModel> labelList = new ArrayList<>();
		Iterable<CoreTabLabelsModel> iterablemetadatalist = labelList;
		
		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.randomUUID());
		
		when(coreTabModelDAO.save(any())).thenReturn(tabModel);
		when(coreTabLabelsModelDAO.saveAll(any())).thenReturn(iterablemetadatalist);
		
		TabResponseDTO responseDTO = coreTabModelServiceImpl.createTab(dto, UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"), "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "Admin");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreTabModelDAO, atLeast(1)).save(any());
		verify(coreTabLabelsModelDAO, atLeast(1)).saveAll(any());
	}

	@Test
	@DisplayName("createTabTest1 method test for constructTabInformation")
	public void createTabTest1() {
		
		TabRequestDTO dto = new TabRequestDTO();
		dto.setModuleid("1");

		Map<String, String> description = new HashMap<String, String>();
		description.put("en", "Label English");
		
		Map<String, String> information = new HashMap<String, String>();
		information.put("en", "Information text of English for Tab Level");
		information.put("fr", "Information text of English for Tab Level");
		
		dto.setDescription(description);
		dto.setInformation(information);
		
		List<CoreTabLabelsModel> labelList = new ArrayList<>();
		Iterable<CoreTabLabelsModel> iterablemetadatalist = labelList;
		
		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.randomUUID());
		
		when(coreTabModelDAO.save(any())).thenReturn(tabModel);
		when(coreTabLabelsModelDAO.saveAll(any())).thenReturn(iterablemetadatalist);
		
		TabResponseDTO responseDTO = coreTabModelServiceImpl.createTab(dto, UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"), "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "Admin");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreTabModelDAO, atLeast(1)).save(any());
		verify(coreTabLabelsModelDAO, atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("createTabTest2 method test for constructTabInformation")
	public void createTabTest2() {
		
		TabRequestDTO dto = new TabRequestDTO();
		dto.setModuleid("1");

		Map<String, String> description = new HashMap<String, String>();
		description.put("en", "Label English");
		
		Map<String, String> information = new HashMap<String, String>();
		
		dto.setDescription(description);
		dto.setInformation(information);
		
		List<CoreTabLabelsModel> labelList = new ArrayList<>();
		Iterable<CoreTabLabelsModel> iterablemetadatalist = labelList;
		
		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.randomUUID());
		
		when(coreTabModelDAO.save(any())).thenReturn(tabModel);
		when(coreTabLabelsModelDAO.saveAll(any())).thenReturn(iterablemetadatalist);
		
		TabResponseDTO responseDTO = coreTabModelServiceImpl.createTab(dto, UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"), "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "Admin");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreTabModelDAO, atLeast(1)).save(any());
		verify(coreTabLabelsModelDAO, atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("createTabTest3 method test for constructTabInformation")
	public void createTabTest3() {
		
		TabRequestDTO dto = new TabRequestDTO();
		dto.setModuleid("1");

		Map<String, String> description = new HashMap<String, String>();
		description.put("en", "Label English");
		
		dto.setDescription(description);
		
		List<CoreTabLabelsModel> labelList = new ArrayList<>();
		Iterable<CoreTabLabelsModel> iterablemetadatalist = labelList;
		
		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.randomUUID());
		
		when(coreTabModelDAO.save(any())).thenReturn(tabModel);
		when(coreTabLabelsModelDAO.saveAll(any())).thenReturn(iterablemetadatalist);
		
		TabResponseDTO responseDTO = coreTabModelServiceImpl.createTab(dto, UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"), "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "Admin");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreTabModelDAO, atLeast(1)).save(any());
		verify(coreTabLabelsModelDAO, atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("createTabTest4 method test for create layout")
	public void createTabTest4() {
		
		TabRequestDTO dto = new TabRequestDTO();
		dto.setModuleid("1");

		Map<String, String> description = new HashMap<String, String>();
		description.put("en", "Label English");
		description.put("sp", "Label English");
		
		Map<String, String> information = new HashMap<String, String>();
		information.put("en", "Information text of English for Tab Level");
		
		dto.setDescription(description);
		dto.setInformation(information);
		
		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.randomUUID());
		
		when(coreTabModelDAO.save(any())).thenThrow(new RuntimeException());
		
		TabResponseDTO responseDTO = coreTabModelServiceImpl.createTab(dto, UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"), "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "Admin");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreTabModelDAO, atLeast(1)).save(any());
	}

	@Test
	@DisplayName("get Layout Tab method test")
	void getLayoutTab() {

		CoreLayoutTabModel model = new CoreLayoutTabModel();
		model.setTabOrder(Short.parseShort("1"));


		when(coreLayoutTabDAO.findByTcodeAndLayoutIdAndTenantId(any(),any(),any())).thenReturn(model);

		LayoutTabDTO responseDTO = coreTabModelServiceImpl.getLayoutTab(UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"), UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "Admin");

		assertNotNull(responseDTO.getTabOrder());

		verify(coreLayoutTabDAO, atLeast(1)).findByTcodeAndLayoutIdAndTenantId(any(),any(),any());
	}

	@Test
	@DisplayName("get Layout Tab method test Exception")
	void getLayoutTabException() {

		CoreLayoutTabModel model = new CoreLayoutTabModel();
		model.setTabOrder(Short.parseShort("1"));


		when(coreLayoutTabDAO.findByTcodeAndLayoutIdAndTenantId(any(),any(),any())).thenReturn(null);

		assertThrows(NotFound404Exception.class,()->
				coreTabModelServiceImpl.getLayoutTab(UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"),
						UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "Admin")
		);


		verify(coreLayoutTabDAO, atLeast(1)).findByTcodeAndLayoutIdAndTenantId(any(),any(),any());
	}

	@Test
	@DisplayName("updateTabTest method test for create layout")
	public void updateTabTest() {
		
		TabRequestDTO dto = new TabRequestDTO();
		dto.setModuleid("1");

		Map<String, String> description = new HashMap<String, String>();
		description.put("en", "Label English");
		description.put("sp", "Label English");
		
		Map<String, String> information = new HashMap<String, String>();
		information.put("en", "Information text of English for Tab Level");
		
		dto.setDescription(description);
		dto.setInformation(information);
		
		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.randomUUID());
		
		List<CoreTabLabelsModel> labelList = new ArrayList<>();
		Iterable<CoreTabLabelsModel> iterablemetadatalist = labelList;
		
		when(coreTabModelDAO.findByTcodeAndLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"),1L, "0")).thenReturn(tabModel);
		when(coreTabModelDAO.save(any())).thenReturn(tabModel);
		doNothing().when(coreTabLabelsModelDAO).deleteByTcode(any());
		when(coreTabLabelsModelDAO.saveAll(any())).thenReturn(iterablemetadatalist);
		
		TabResponseDTO responseDTO = coreTabModelServiceImpl.updateTab(dto, UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"), UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0", "Admin");
	
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreTabModelDAO, atLeast(1)).findByTcodeAndLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"),1L, "0");
		verify(coreTabModelDAO, atLeast(1)).save(any());
		verify(coreTabLabelsModelDAO, atLeast(1)).deleteByTcode(any());
		verify(coreTabLabelsModelDAO, atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("updateTabTest1 method test for Runtime exception")
	public void updateTabTest1() {
		
		TabRequestDTO dto = new TabRequestDTO();
		dto.setModuleid("1");

		Map<String, String> description = new HashMap<String, String>();
		description.put("en", "Label English");
		description.put("sp", "Label English");
		
		Map<String, String> information = new HashMap<String, String>();
		information.put("en", "Information text of English for Tab Level");
		
		dto.setDescription(description);
		dto.setInformation(information);
		
		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.randomUUID());
		
		when(coreTabModelDAO.findByTcodeAndLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"),1L, "0")).thenReturn(null);
		
		TabResponseDTO responseDTO = coreTabModelServiceImpl.updateTab(dto, UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"), UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0", "Admin");
	
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreTabModelDAO, atLeast(1)).findByTcodeAndLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"),1L, "0");
	}
	
	@Test
	@DisplayName("assignFieldToTabTest method test for Assign Field To Tab")
	public void assignFieldToTabTest() {
		
		List<TabFieldDTO> requestDTO = new ArrayList<>();
		
		TabFieldDTO fieldDTO = new TabFieldDTO();
		fieldDTO.setFieldId("FieldId1");
		
		TabFieldDTO fieldDTO1 = new TabFieldDTO();
		fieldDTO1.setFieldId("FieldId2");

		requestDTO.add(fieldDTO);
		requestDTO.add(fieldDTO1);
		
		List<CoreTabFieldsModel> labelList = new ArrayList<>();
		
		CoreTabFieldsModel fieldModel = new CoreTabFieldsModel();
		fieldModel.setFieldId("Field1");
		
		labelList.add(fieldModel);
		
		Iterable<CoreTabFieldsModel> iterablemetadatalist = labelList;
		
		when(coreTabFieldsDAO.saveAll(any())).thenReturn(iterablemetadatalist);

		List<TabFieldDTO> responseDTO = coreTabModelServiceImpl.assignFieldToTab(requestDTO, UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0");
		
		assertNotNull(responseDTO);
		
		verify(coreTabFieldsDAO).saveAll(any());
	}

	@Test
	@DisplayName("assignField ToTabTest method test for Assign Field To Tab")
	public void assignFieldToTab() {

		List<TabFieldDTO> requestDTO = new ArrayList<>();

		TabFieldDTO fieldDTO = new TabFieldDTO();
		fieldDTO.setDescription("test");

		TabFieldDTO fieldDTO1 = new TabFieldDTO();
		fieldDTO1.setUrl("test");

		requestDTO.add(fieldDTO);
		requestDTO.add(fieldDTO1);

		List<CoreTabFieldsModel> labelList = new ArrayList<>();

		CoreTabFieldsModel fieldModel = new CoreTabFieldsModel();
		fieldModel.setFieldId("Field1");

		labelList.add(fieldModel);

		Iterable<CoreTabFieldsModel> iterablemetadatalist = labelList;

		when(coreTabFieldsDAO.saveAll(any())).thenReturn(iterablemetadatalist);

		List<TabFieldDTO> responseDTO = coreTabModelServiceImpl.assignFieldToTab(requestDTO, UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0");

		assertNotNull(responseDTO);

		verify(coreTabFieldsDAO).saveAll(any());
	}

	@Test
	@DisplayName("UpdateassignFieldToTabTest method test for Assign Field To Tab")
	void updateAssignFieldToTabTest() {

		List<TabFieldDTO> requestDTO = new ArrayList<>();

		TabFieldDTO fieldDTO = new TabFieldDTO();
		fieldDTO.setFieldId("FieldId1");
        fieldDTO.setTabFieldUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));


		requestDTO.add(fieldDTO);

		List<CoreTabFieldsModel> labelList = new ArrayList<>();

		CoreTabFieldsModel fieldModel = new CoreTabFieldsModel();
		fieldModel.setFieldId("Field1");
		fieldModel.setUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));

		labelList.add(fieldModel);

		when(coreTabFieldsDAO.findByTcodeAndUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"))).thenReturn(Optional.of(fieldModel));

		TabFieldResponseDTO responseDTO = coreTabModelServiceImpl.assignFieldToTabUpdate(requestDTO, UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0");

		assertTrue(responseDTO.isAcknowledge());

		verify(coreTabFieldsDAO,atLeast(1)).findByTcodeAndUuid(any(),any());
	}

	@Test
	@DisplayName("UpdateassignField ToTabTest method test for Assign Field To Tab")
	void updateAssignFieldToTab() {

		List<TabFieldDTO> requestDTO = new ArrayList<>();

		TabFieldDTO fieldDTO = new TabFieldDTO();
		fieldDTO.setDescription("FieldId1");
		fieldDTO.setTabFieldUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		fieldDTO.setFieldType(FieldType.TEXT);

		TabFieldDTO fieldUrl = new TabFieldDTO();
		fieldUrl.setUrl("FieldId1");
		fieldUrl.setFieldType(FieldType.IMAGE);
		fieldUrl.setTabFieldUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17b"));


		requestDTO.add(fieldDTO);
		requestDTO.add(fieldUrl);

		List<CoreTabFieldsModel> labelList = new ArrayList<>();

		CoreTabFieldsModel fieldModel = new CoreTabFieldsModel();
		fieldModel.setDescription("Field1");
		fieldModel.setFieldType(FieldType.IMAGE);
		fieldModel.setUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));

		CoreTabFieldsModel fieldModelUrl = new CoreTabFieldsModel();
		fieldModelUrl.setUrl("fd");
		fieldModel.setFieldType(FieldType.IMAGE);
		fieldModel.setUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17b"));

		labelList.add(fieldModel);

		when(coreTabFieldsDAO.findByTcodeAndUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"))).thenReturn(Optional.of(fieldModel));
		when(coreTabFieldsDAO.findByTcodeAndUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17b"))).thenReturn(Optional.of(fieldModelUrl));


		TabFieldResponseDTO responseDTO = coreTabModelServiceImpl.assignFieldToTabUpdate(requestDTO, UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0");

		assertTrue(responseDTO.isAcknowledge());

		verify(coreTabFieldsDAO,atLeast(1)).findByTcodeAndUuid(any(),any());
	}

	@Test
	@DisplayName("UpdateassignField To Test Null for Assign Field To Tab")
	void updateAssignFieldToTabNullCheck() {

		List<TabFieldDTO> requestDTO = new ArrayList<>();

		TabFieldDTO fieldDTO = new TabFieldDTO();
		fieldDTO.setDescription("FieldId1");
		fieldDTO.setTabFieldUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		fieldDTO.setFieldType(FieldType.TEXT);

		TabFieldDTO fieldUrl = new TabFieldDTO();
		fieldUrl.setUrl("FieldId1");
		fieldUrl.setFieldType(FieldType.IMAGE);
		fieldUrl.setTabFieldUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17b"));


		requestDTO.add(fieldDTO);
		requestDTO.add(fieldUrl);

		List<CoreTabFieldsModel> labelList = new ArrayList<>();

		CoreTabFieldsModel fieldModel = new CoreTabFieldsModel();
		fieldModel.setFieldType(FieldType.IMAGE);
		fieldModel.setUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));

		CoreTabFieldsModel fieldModelUrl = new CoreTabFieldsModel();
		fieldModel.setFieldType(FieldType.IMAGE);
		fieldModel.setUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17b"));

		labelList.add(fieldModel);

		when(coreTabFieldsDAO.findByTcodeAndUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"))).thenReturn(Optional.of(fieldModel));
		when(coreTabFieldsDAO.findByTcodeAndUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17b"))).thenReturn(Optional.of(fieldModelUrl));


		TabFieldResponseDTO responseDTO = coreTabModelServiceImpl.assignFieldToTabUpdate(requestDTO, UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0");

		assertTrue(responseDTO.isAcknowledge());

		verify(coreTabFieldsDAO,atLeast(1)).findByTcodeAndUuid(any(),any());
	}

	@Test
	@DisplayName("UpdateassignField To Test Field Type for Assign Field To Tab")
	void updateAssignFieldToTabCheckField() {

		List<TabFieldDTO> requestDTO = new ArrayList<>();

		TabFieldDTO fieldDTO = new TabFieldDTO();
		fieldDTO.setDescription("FieldId1");
		fieldDTO.setTabFieldUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		fieldDTO.setFieldType(FieldType.TEXT);

		TabFieldDTO fieldUrl = new TabFieldDTO();
		fieldUrl.setUrl("FieldId1");
		fieldUrl.setFieldType(FieldType.IMAGE);
		fieldUrl.setTabFieldUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17b"));


		requestDTO.add(fieldDTO);
		requestDTO.add(fieldUrl);

		List<CoreTabFieldsModel> labelList = new ArrayList<>();

		CoreTabFieldsModel fieldModel = new CoreTabFieldsModel();
		fieldModel.setDescription("Field1");
		fieldModel.setFieldType(FieldType.FIELD);
		fieldModel.setUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));

		CoreTabFieldsModel fieldModelUrl = new CoreTabFieldsModel();
		fieldModelUrl.setUrl("fd");
		fieldModel.setFieldType(FieldType.FIELD);
		fieldModel.setUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17b"));

		labelList.add(fieldModel);

		when(coreTabFieldsDAO.findByTcodeAndUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"))).thenReturn(Optional.of(fieldModel));
		when(coreTabFieldsDAO.findByTcodeAndUuid(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17b"))).thenReturn(Optional.of(fieldModelUrl));


		TabFieldResponseDTO responseDTO = coreTabModelServiceImpl.assignFieldToTabUpdate(requestDTO, UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0");

		assertTrue(responseDTO.isAcknowledge());

		verify(coreTabFieldsDAO,atLeast(1)).findByTcodeAndUuid(any(),any());
	}

	@Test
	@DisplayName("Test for Delete Tab Field when list is empty")
	void deleteTabField() {

		CoreTabFieldsModel fieldModel = new CoreTabFieldsModel();
		fieldModel.setFieldId("Field1");

		List<String> list = new ArrayList<>();
		UUIDRequestListDTO dto =new UUIDRequestListDTO();
		dto.setUuidList(list);

		when(coreTabFieldsDAO.findByTcodeAndTenantId(any(),any())).thenReturn(Optional.empty());

		TabFieldResponseDTO responseDTO = coreTabModelServiceImpl.deleteTabField(UUID.fromString("444a553-1d90-4ee1-9b83-eaa68a28f17a"),
				dto, "0");

		assertTrue(responseDTO.isAcknowledge());

		verify((coreTabFieldsDAO),atLeast(1)).findByTcodeAndTenantId(any(),any());
	}

	@Test
	@DisplayName("Test Delete when list is not empty")
	void deleteTabFieldList() {

		List<String> list = new ArrayList<>(){{add("444a553-1d90-4ee1-9b83-eaa68a28f17a");}};
		UUIDRequestListDTO dto =new UUIDRequestListDTO();
		dto.setUuidList(list);

		when(coreTabFieldsDAO.findByUuidIn(any())).thenReturn(new ArrayList<>());

		TabFieldResponseDTO	response = coreTabModelServiceImpl.deleteTabField(UUID.fromString("444a553-1d90-4ee1-9b83-eaa68a28f17a"),
					dto, "0");
		assertTrue(response.isAcknowledge());

		verify((coreTabFieldsDAO),atLeast(1)).findByUuidIn(any());
	}

	@Test
	@DisplayName("Search Tab Fields")
	void searchTabField() {

		TabFieldDetailsDTO dto = new TabFieldDetailsDTO();
		dto.setFieldId("fieldId");
		dto.setFieldDescription("desc");
		dto.setDescription("tab");
		dto.setTabUuid(UUID.fromString("3acd60df-574d-4ce7-b8ba-e3e2629d3333"));
		dto.setType(FieldType.FIELD);

		CoreMetadataModel model = new CoreMetadataModel();
		model.setPickList("1");
		model.setDataType("CHAR");
		model.setFieldId("fieldId");

		List<TabFieldDetailsDTO> listDto=Collections.singletonList(dto);
		when(coreTabFieldsDAO.searchTabFieldsByDesc("","en",
				UUID.fromString("3acd60df-574d-4ce7-b8ba-e3e2629d3333"), PageRequest.of(0,1))).thenReturn(listDto);

		when (coreMetadataDAO.findByFieldIdInAndModuleIdAndTenantId(anyList(),any(),any())).thenReturn(new ArrayList<>(){{add(model);}});

		List<TabSearchDTO> response = coreTabModelServiceImpl.searchByDesc(1L,"",0,1,"0","en",UUID.fromString("3acd60df-574d-4ce7-b8ba-e3e2629d3333"));

		assertNotNull(response);

		verify((coreTabFieldsDAO),atLeast(1)).searchTabFieldsByDesc("","en",
				UUID.fromString("3acd60df-574d-4ce7-b8ba-e3e2629d3333"), PageRequest.of(0,1));
	}

	@Test
	@DisplayName("Search unassigned Tab Fields")
	void searchUnassignedTabField() {

		CoreTabFieldsModel dto = new CoreTabFieldsModel();
		dto.setFieldId("fieldId");

		CoreMetadataLangModel model = new CoreMetadataLangModel();
		model.setFieldId("fieldId");

		List<CoreMetadataLangModel> list= Collections.singletonList(model);

		List<String> fields = new ArrayList<>(){{add("fieldId");}};
		List<CoreTabFieldsModel> listDto=Collections.singletonList(dto);
		when(coreTabFieldsDAO.findBytCodeandLayoutId(UUID.fromString("3acd60df-574d-4ce7-b8ba-e3e2629d3333"))).thenReturn(listDto);
		when(coreMetadataLangDAO.searchByFieldidNotIn(fields,"","en",1L,"0",PageRequest.of(0,1))).thenReturn(list);

		when(coreMetadataService.getHierachyFieldMap(anyLong(), anyString(), anyList(), anyString())).thenReturn(new HashMap<>());

		Map<Object, Object> response = coreTabModelServiceImpl.searchUnassignedTabFields(1L,"",0,1,"0","en",UUID.fromString("3acd60df-574d-4ce7-b8ba-e3e2629d3333"));

		assertNotNull(response);

		verify((coreTabFieldsDAO),atLeast(1)).findBytCodeandLayoutId(UUID.fromString("3acd60df-574d-4ce7-b8ba-e3e2629d3333"));
		verify((coreMetadataLangDAO),atLeast(1)).searchByFieldidNotIn(fields,"","en",1L,"0",PageRequest.of(0,1));

	}

	@Test
	@DisplayName("Get Layout Tab list")
	void getLayoutTabList() {

		UUID layoutId = UUID.randomUUID();
		LayoutTabDTO model = new LayoutTabDTO();
		model.setTabid(layoutId.toString());

		when(coreLayoutTabDAO.findByLayoutId(any(),any(),any(),any(),eq(PageRequest.of(1,1)))).thenReturn(Collections.singletonList(model));

		List<LayoutTabDTO> list = coreTabModelServiceImpl.getLayoutTabList(layoutId,"","en",1,1,"0");
		assertEquals(1,list.size());

		verify(coreLayoutTabDAO,atLeast(1)).findByLayoutId(layoutId,"0","","en",PageRequest.of(1,1));

	}

	@Test
	@DisplayName("Get Tab Fields")
	void getTabFields() {

		UUID tCode = UUID.randomUUID();
		CoreTabFieldsModel model = new CoreTabFieldsModel();
		model.setTcode(tCode);

		when(coreTabFieldsDAO.findByTcodeAndTenantIdAndModuleId(any(),any(),any(),eq(PageRequest.of(1,1)))).thenReturn(Collections.singletonList(model));
		when(coreTabFieldsDAO.findByTcodeAndTenantIdAndModuleIdAndStructureId(any(),any(),any(),any(),eq(PageRequest.of(1,1)))).thenReturn(Collections.singletonList(model));

		List<TabFieldDTO> list = coreTabModelServiceImpl.getTabFields(1L,tCode,1,1,"0",Short.parseShort("0"));
		List<TabFieldDTO> dtoList = coreTabModelServiceImpl.getTabFields(1L,tCode,1,1,"0",null);

		assertEquals(1,list.size());
		assertEquals(1,dtoList.size());

		verify(coreTabFieldsDAO,atLeast(1)).findByTcodeAndTenantIdAndModuleId(any(),any(),any(),eq(PageRequest.of(1,1)));
		verify(coreTabFieldsDAO,atLeast(1)).findByTcodeAndTenantIdAndModuleIdAndStructureId(any(),any(),any(),any(),eq(PageRequest.of(1,1)));

	}
}
