/**
 * 
 */
package com.prospecta.mdo.module.rest.tab;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.prospecta.mdo.module.component.JWTTokenProvider;
import com.prospecta.mdo.module.dto.layout.LayoutTabDTO;
import com.prospecta.mdo.module.dto.tab.*;
import com.prospecta.mdo.module.service.tab.CoreTabModelService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * @author savan
 *
 */
@SpringBootTest
@ActiveProfiles("Test")
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
public class TabRestControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private JWTTokenProvider jWTTokenProvider;
	
	@MockBean
	private CoreTabModelService coreTabModelService;
	
	private static final String PAYLOAD = "{\"username\":\"Admin\",\"roles\":[],\"tenantCode\":\"0\"}";
	
	@Test
	@DisplayName("Test case for createTabTest controller method to Create tab.")
	@WithMockUser
	public void createTabTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		TabRequestDTO dto = new TabRequestDTO();
		dto.setModuleid("1");

		Map<String, String> description = new HashMap<String, String>();
		description.put("en", "Label English");
		
		Map<String, String> information = new HashMap<String, String>();
		information.put("en", "Information text of English for Tab Level");
		
		dto.setDescription(description);
		dto.setInformation(information);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);

		TabResponseDTO responseDTO = new TabResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreTabModelService.createTab(any(), any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc.perform(post("/tab/{LAYOUTID}/create", "02ece30a-8d01-46dd-beee-d22a5ad40707").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isCreated());

		verify(coreTabModelService).createTab(any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for createTabTest1 controller method to check internal server error.")
	@WithMockUser
	public void createTabTest1() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		TabRequestDTO dto = new TabRequestDTO();
		dto.setModuleid("1");

		Map<String, String> description = new HashMap<String, String>();
		description.put("en", "Label English");
		
		Map<String, String> information = new HashMap<String, String>();
		information.put("en", "Information text of English for Tab Level");
		
		dto.setDescription(description);
		dto.setInformation(information);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);

		TabResponseDTO responseDTO = new TabResponseDTO();
		responseDTO.setAcknowledge(false);

		when(coreTabModelService.createTab(any(), any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc.perform(post("/tab/{LAYOUTID}/create", "02ece30a-8d01-46dd-beee-d22a5ad40707").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());

		verify(coreTabModelService).createTab(any(), any(), any(), any());
	}

	@Test
	@DisplayName("Test case for get layout tab")
	@WithMockUser
	void GetLayoutTabTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		LayoutTabDTO responseDTO = new LayoutTabDTO();

		when(coreTabModelService.getLayoutTab(any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc.perform(get("/tab/{layoutId}/get-layout-tab", "02ece30a-8d01-46dd-beee-d22a5ad40707")
				.param("tCode","02ece30a-8d01-46dd-beee-d22a5ad40707")
				.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());

		verify(coreTabModelService).getLayoutTab(any(), any(), any());
	}

	@Test
	@DisplayName("Test case for updateTabTest controller method to Update tab.")
	@WithMockUser
	public void updateTabTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		TabRequestDTO dto = new TabRequestDTO();
		dto.setModuleid("1");

		Map<String, String> description = new HashMap<String, String>();
		description.put("en", "Label English");
		
		Map<String, String> information = new HashMap<String, String>();
		information.put("en", "Information text of English for Tab Level");
		
		dto.setDescription(description);
		dto.setInformation(information);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);

		TabResponseDTO responseDTO = new TabResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreTabModelService.updateTab(any(), any(), any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc.perform(put("/tab/{LAYOUTID}/update/{TCODE}", "02ece30a-8d01-46dd-beee-d22a5ad40707","1444a553-1d90-4ee1-9b83-eaa68a28f17a").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());

		verify(coreTabModelService).updateTab(any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("Test case for updateTabTest1 controller method to intertnal server error.")
	@WithMockUser
	public void updateTabTest1() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		TabRequestDTO dto = new TabRequestDTO();
		dto.setModuleid("1");

		Map<String, String> description = new HashMap<String, String>();
		description.put("en", "Label English");
		
		Map<String, String> information = new HashMap<String, String>();
		information.put("en", "Information text of English for Tab Level");
		
		dto.setDescription(description);
		dto.setInformation(information);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);

		TabResponseDTO responseDTO = new TabResponseDTO();
		responseDTO.setAcknowledge(false);

		when(coreTabModelService.updateTab(any(), any(), any(), any(), any())).thenReturn(responseDTO);

		this.mockMvc.perform(put("/tab/{LAYOUTID}/update/{TCODE}", "02ece30a-8d01-46dd-beee-d22a5ad40707","1444a553-1d90-4ee1-9b83-eaa68a28f17a").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());

		verify(coreTabModelService).updateTab(any(), any(), any(), any(), any());
	}
	
	
	@Test
	@DisplayName("Test case for assignFieldToTabTest controller method to Assign Field To Tab.")
	@WithMockUser
	public void assignFieldToTabTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<TabFieldDTO> requestDTO = new ArrayList<>();
		
		TabFieldDTO fieldDTO = new TabFieldDTO();

		requestDTO.add(fieldDTO);
		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(requestDTO);

		List<TabFieldDTO> responseDTO = new ArrayList<>();

		when(coreTabModelService.assignFieldToTab(any(),any(),any())).thenReturn(responseDTO);

		this.mockMvc.perform(post("/tab/{TCODE}/assignfield", "02ece30a-8d01-46dd-beee-d22a5ad40707").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());

		verify(coreTabModelService).assignFieldToTab(any(),any(),any());
	}

	@Test
	@DisplayName("Test case for UpdateassignFieldToTabTest controller method to Assign Field To Tab.")
	@WithMockUser
	void updateAssignFieldToTabTest() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<TabFieldDTO> requestDTO = new ArrayList<>();

		TabFieldDTO fieldDTO = new TabFieldDTO();
		fieldDTO.setTabFieldUuid(UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"));

		requestDTO.add(fieldDTO);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(requestDTO);

		TabFieldResponseDTO responseDTO = new TabFieldResponseDTO();
		responseDTO.setAcknowledge(true);

		when(coreTabModelService.assignFieldToTabUpdate(any(),any(),any())).thenReturn(responseDTO);

		this.mockMvc.perform(post("/tab/{TCODE}/field/update", "02ece30a-8d01-46dd-beee-d22a5ad40707").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());

		verify(coreTabModelService).assignFieldToTabUpdate(any(),any(),any());
	}

	@Test
	@DisplayName("Test case for UpdateassignFieldToTabTest controller method to Assign Field To Tab Exception.")
	@WithMockUser
	void updateAssignFieldToTabTestException() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		List<TabFieldDTO> requestDTO = new ArrayList<>();

		TabFieldDTO fieldDTO = new TabFieldDTO();
		fieldDTO.setTabFieldUuid(UUID.fromString("02ece30a-8d01-46dd-beee-d22a5ad40707"));

		requestDTO.add(fieldDTO);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(requestDTO);

		TabFieldResponseDTO responseDTO = new TabFieldResponseDTO();
		responseDTO.setAcknowledge(false);

		when(coreTabModelService.assignFieldToTabUpdate(any(),any(),any())).thenReturn(responseDTO);

		this.mockMvc.perform(post("/tab/{TCODE}/field/update", "02ece30a-8d01-46dd-beee-d22a5ad40707").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isInternalServerError());

		verify(coreTabModelService).assignFieldToTabUpdate(any(),any(),any());
	}


	@Test
	@DisplayName("Test case for delete Tab Field Controller Method")
	@WithMockUser
	void deleteTabField() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		TabFieldResponseDTO responseDTO=new TabFieldResponseDTO();
		responseDTO.setAcknowledge(true);

		List<String> list = new ArrayList<>(){{add("444a553-1d90-4ee1-9b83-eaa68a28f17a");}};
		UUIDRequestListDTO dto =new UUIDRequestListDTO();
		dto.setUuidList(list);
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

		ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		String requestJson = ow.writeValueAsString(dto);


		when(coreTabModelService.deleteTabField(UUID.fromString("444a553-1d90-4ee1-9b83-eaa68a28f17a"),
				dto,"0")).thenReturn(responseDTO);

		this.mockMvc.perform(
				delete("/tab/delete/{tCode}",  "444a553-1d90-4ee1-9b83-eaa68a28f17a")
						.contentType(MediaType.APPLICATION_JSON)
						.content(requestJson)
						.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());

		verify((coreTabModelService),atLeast(1)).deleteTabField(UUID.fromString("444a553-1d90-4ee1-9b83-eaa68a28f17a"),
				dto,"0");
	}

	@Test
	@DisplayName("Test case for search Tab Field Controller Method")
	@WithMockUser
	void searchTabField() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		TabSearchDTO responseDTO=new TabSearchDTO();
		responseDTO.setTabUuid(UUID.randomUUID());

		List<TabSearchDTO> list = Collections.singletonList(responseDTO);

		when(coreTabModelService.searchByDesc(1L,"",0,1,"0","en",
				UUID.fromString("444a553-1d90-4ee1-9b83-eaa68a28f17a"))).thenReturn(list);

		this.mockMvc.perform(
				get("/tab/fields/1/search-by-description/{language}/{layoutId}",  "en","444a553-1d90-4ee1-9b83-eaa68a28f17a")
						.param("searchTerm","")
						.param("fetchCount","0")
						.param("fetchSize","1")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());

		verify((coreTabModelService),atLeast(1)).searchByDesc(1L,"",0,1,"0","en",
				UUID.fromString("444a553-1d90-4ee1-9b83-eaa68a28f17a"));
	}

	@Test
	@DisplayName("Test case for search unassigned Tab Field Controller Method")
	@WithMockUser
	void searchUnassignedTabField() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		Map<Object, Object> map = new HashMap<>();

		when(coreTabModelService.searchUnassignedTabFields(1L,"",0,1,"0","en",
				UUID.fromString("444a553-1d90-4ee1-9b83-eaa68a28f17a"))).thenReturn(map);

		this.mockMvc.perform(
				get("/tab/1/fields/search-unassigned-fields/{language}/{layoutId}",  "en","444a553-1d90-4ee1-9b83-eaa68a28f17a")
						.param("searchTerm","")
						.param("fetchCount","0")
						.param("fetchSize","1")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());

		verify((coreTabModelService),atLeast(1)).searchUnassignedTabFields(1L,"",0,1,"0","en",
				UUID.fromString("444a553-1d90-4ee1-9b83-eaa68a28f17a"));
	}

	@Test
	@DisplayName("Test case for Layout Tab List")
	@WithMockUser
	void getLayoutTabList() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

        UUID layoutId =UUID.randomUUID();

        when(coreTabModelService.getLayoutTabList(layoutId,"","en",1,1,"0")).thenReturn(new ArrayList<>());

		this.mockMvc.perform(
				get("/tab/{layoutId}/get-layout-tab-list/{language}",  layoutId,"en")
						.param("searchTerm","")
						.param("fetchCount","1")
						.param("fetchSize","1")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());

		verify((coreTabModelService),atLeast(1)).getLayoutTabList(layoutId,"","en",1,1,"0");
	}

	@Test
	@DisplayName("Test case for Tab Fields List")
	@WithMockUser
	void getTabFields() throws Exception {

		String token = jWTTokenProvider.createToken(PAYLOAD);

		UUID tCode =UUID.randomUUID();

		when(coreTabModelService.getTabFields(1L,tCode,1,1,"0",Short.parseShort("0"))).thenReturn(new ArrayList<>());

		this.mockMvc.perform(
				get("/tab/fields/{moduleId}/get-tab-fields/{tCode}",  1L,tCode)
						.param("fetchCount","1")
						.param("fetchSize","1")
						.param("structureId","0")
						.header("authorization", "Bearer " + token))
				.andExpect(status().isOk());

		verify((coreTabModelService),atLeast(1)).getTabFields(1L,tCode,1,1,"0",Short.parseShort("0"));
	}
}
