package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpResultsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdHeaderDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupResultsRequestDTO;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpResultsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class CoreVdGrpResultsServiceTest {

	@InjectMocks
	private CoreVdGrpResultsServiceImpl coreVdGrpResultsServiceImpl;

	@Mock
	private CoreVdGrpResultsDAO coreVdGrpResultsDAO;

	@Mock
	private CoreVdHeaderDAO coreVdHeaderDAO;

	@Mock
	private CoreVdGroupsDAO coreVdGroupsDAO;

	@BeforeAll
	void init() {
		coreVdGrpResultsServiceImpl = new CoreVdGrpResultsServiceImpl();
	}

	@Test
	@DisplayName("getVdResultbyvdIdTest method test for get virtual dataset result by vdId")
	void getVdResultbyvdIdTest() {
		CoreVdHeaderModel coreVdHeaderModel = spy(CoreVdHeaderModel.class);
		CoreVdGrpResultsModel coreVdGrpResultsModel = spy(CoreVdGrpResultsModel.class);
		coreVdGrpResultsModel.setCoreVdHeader(coreVdHeaderModel);
		List<CoreVdGrpResultsModel> coreVdGrpResultsModelList = new ArrayList<>();
		coreVdGrpResultsModelList.add(coreVdGrpResultsModel);
		UUID id = UUID.randomUUID();
		when(coreVdGrpResultsDAO.findByCoreVdHeader(coreVdHeaderModel)).thenReturn(coreVdGrpResultsModelList);
		when(coreVdHeaderDAO.findById(id)).thenReturn(Optional.of(coreVdHeaderModel));
		List<CoreVdGrpResultsModel> coreVdGrpResultsList = coreVdGrpResultsServiceImpl.getVdResultbyvdId(id);
		assertNotNull(coreVdGrpResultsList);
		verify(coreVdHeaderDAO, atLeast(1)).findById(any());
		verify(coreVdGrpResultsDAO, atLeast(1)).findByCoreVdHeader(any());
	}

	@Test
	@DisplayName("getVdResultbyvdIdExceptionTest method test for test exception")
	void getVdResultbyvdIdExceptionTest() {
		CoreVdHeaderModel coreVdHeaderModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdHeaderDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdHeaderModel));
		assertThrows(NotFound404Exception.class, () -> coreVdGrpResultsServiceImpl.getVdResultbyvdId(id));
		verify(coreVdHeaderDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("getVdResultbyvdIdListExceptionTest method test for test exception")
	void getVdResultbyvdIdListExceptionTest() {
		CoreVdHeaderModel coreVdHeaderModel = spy(CoreVdHeaderModel.class);
		List<CoreVdGrpResultsModel> coreVdGrpResultsModelList = new ArrayList<>();
		UUID id = UUID.randomUUID();
		when(coreVdGrpResultsDAO.findByCoreVdHeader(coreVdHeaderModel)).thenReturn(coreVdGrpResultsModelList);
		when(coreVdHeaderDAO.findById(id)).thenReturn(Optional.of(coreVdHeaderModel));
		assertThrows(NotFound404Exception.class, () -> coreVdGrpResultsServiceImpl.getVdResultbyvdId(id));
		verify(coreVdHeaderDAO, atLeast(1)).findById(any());
		verify(coreVdGrpResultsDAO, atLeast(1)).findByCoreVdHeader(any());
	}

	@Test
	@DisplayName("getVdResultbygroupIdTest method test for get virtual dataset result by group id")
	void getVdResultbygroupIdTest() {
		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		CoreVdGrpResultsModel coreVdGrpResultsModel = spy(CoreVdGrpResultsModel.class);
		coreVdGrpResultsModel.setCoreVdGroups(coreVdGroupsModel);
		List<CoreVdGrpResultsModel> coreVdGrpResultsModelList = new ArrayList<>();
		coreVdGrpResultsModelList.add(coreVdGrpResultsModel);
		UUID id = UUID.randomUUID();
		when(coreVdGrpResultsDAO.findByCoreVdGroups(coreVdGroupsModel)).thenReturn(coreVdGrpResultsModelList);
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		List<CoreVdGrpResultsModel> coreVdGrpResultsList = coreVdGrpResultsServiceImpl.getVdResultbygroupId(id);
		assertNotNull(coreVdGrpResultsList);
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		verify(coreVdGrpResultsDAO, atLeast(1)).findByCoreVdGroups(any());
	}

	@Test
	@DisplayName("getVdResultbygroupIdExceptionTest method test for test exception")
	void getVdResultbygroupIdExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class, () -> coreVdGrpResultsServiceImpl.getVdResultbygroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("getVdResultbygroupIdTest method test for test exception")
	void getVdResultbygroupIdListExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		List<CoreVdGrpResultsModel> coreVdGrpResultsModelList = new ArrayList<>();
		UUID id = UUID.randomUUID();
		when(coreVdGrpResultsDAO.findByCoreVdGroups(coreVdGroupsModel)).thenReturn(coreVdGrpResultsModelList);
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class, () -> coreVdGrpResultsServiceImpl.getVdResultbygroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		verify(coreVdGrpResultsDAO, atLeast(1)).findByCoreVdGroups(any());
	}

	@Test
	@DisplayName("getVdResultbyresultIdTest method test for get virtual dataset result by result id")
	void getVdResultbyresultIdTest() {
		CoreVdGrpResultsModel coreVdGrpResultsModel = spy(CoreVdGrpResultsModel.class);
		UUID id = UUID.randomUUID();
		when(coreVdGrpResultsDAO.findById(id)).thenReturn(Optional.of(coreVdGrpResultsModel));
		coreVdGrpResultsModel = coreVdGrpResultsServiceImpl.getVdResultbyresultId(id);
		verify(coreVdGrpResultsDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("getVdResultbyresultIdExceptionTest method test for test exception")
	void getVdResultbyresultIdExceptionTest() {
		CoreVdGrpResultsModel coreVdGrpResultsModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGrpResultsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGrpResultsModel));
		assertThrows(NotFound404Exception.class, () -> coreVdGrpResultsServiceImpl.getVdResultbyresultId(id));
		verify(coreVdGrpResultsDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("deleteVdResultbyvdIdTest method test for delete virtual dataset result by vdId")
	void deleteVdResultbyvdIdTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		UUID id = UUID.randomUUID();
		when(coreVdHeaderDAO.findById(id)).thenReturn(Optional.of(coreVdHeaderModel));
		doNothing().when(coreVdGrpResultsDAO).deleteByCoreVdHeader(coreVdHeaderModel);
		coreVdGrpResultsServiceImpl.deleteVdResultbyvdId(id);
		verify(coreVdGrpResultsDAO, atLeast(1)).deleteByCoreVdHeader(any());
		verify(coreVdHeaderDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("deleteVdResultbyvdIdExceptionTest method test for test exception")
	void deleteVdResultbyvdIdExceptionTest() {
		CoreVdHeaderModel coreVdHeaderModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdHeaderDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdHeaderModel));
		assertThrows(NotFound404Exception.class, () -> coreVdGrpResultsServiceImpl.deleteVdResultbyvdId(id));
		verify(coreVdHeaderDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("deleteVdResultbygroupIdTest method test for delete virtual dataset result by groupId")
	void deleteVdResultbygroupIdTest() {
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		doNothing().when(coreVdGrpResultsDAO).deleteByCoreVdGroups(coreVdGroupsModel);
		coreVdGrpResultsServiceImpl.deleteVdResultbygroupId(id);
		verify(coreVdGrpResultsDAO, atLeast(1)).deleteByCoreVdGroups(any());
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("deleteVdResultbygroupIdExceptionTest method test for test exception")
	void deleteVdResultbygroupIdExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class, () -> coreVdGrpResultsServiceImpl.deleteVdResultbygroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("deleteVdResultbyresultIdTest method test for delete virtual dataset result by result id")
	void deleteVdResultbyresultIdTest() {
		UUID id = UUID.randomUUID();
		doNothing().when(coreVdGrpResultsDAO).deleteById(id);
		coreVdGrpResultsServiceImpl.deleteVdResultbyresultId(id);
		verify(coreVdGrpResultsDAO, atLeast(1)).deleteById(any());
	}

	@Test
	@DisplayName("coreVdGrpResultsModelTest method test for test save or update")
	void coreVdGrpResultsModelTest() {
		CoreVdGrpResultsModel coreVdGrpResultsModel = new CoreVdGrpResultsModel();
		coreVdGrpResultsModel.setUuid(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		VdGroupResultsRequestDTO groupResultsRequestDTO = new VdGroupResultsRequestDTO();
		groupResultsRequestDTO.setResultId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		CoreVdGroupsModel coreVdGroups = new CoreVdGroupsModel();
		CoreVdHeaderModel coreVdHeader = new CoreVdHeaderModel();

		copyProperties(groupResultsRequestDTO, coreVdGrpResultsModel);
		coreVdGrpResultsModel.setCoreVdGroups(coreVdGroups);
		coreVdGrpResultsModel.setCoreVdHeader(coreVdHeader);
		when(coreVdGrpResultsDAO.save(coreVdGrpResultsModel)).thenReturn(coreVdGrpResultsModel);
		coreVdGrpResultsServiceImpl.saveOrUpdateVdGroupResults(groupResultsRequestDTO, coreVdGroups, coreVdHeader);
		verify(coreVdGrpResultsDAO, atLeast(1)).save(coreVdGrpResultsModel);
	}

	@Test
	@DisplayName("coreVdGrpResultsModelTest1 method test any exception")
	void coreVdGrpResultsModelTest1() {
		CoreVdGrpResultsModel coreVdGrpResultsModel = new CoreVdGrpResultsModel();
		coreVdGrpResultsModel.setUuid(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		VdGroupResultsRequestDTO groupResultsRequestDTO = new VdGroupResultsRequestDTO();
		groupResultsRequestDTO.setResultId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		CoreVdGroupsModel coreVdGroups = new CoreVdGroupsModel();
		CoreVdHeaderModel coreVdHeader = new CoreVdHeaderModel();

		copyProperties(groupResultsRequestDTO, coreVdGrpResultsModel);
		coreVdGrpResultsModel.setCoreVdGroups(coreVdGroups);
		coreVdGrpResultsModel.setCoreVdHeader(null);
		when(coreVdGrpResultsDAO.save(coreVdGrpResultsModel)).thenReturn(coreVdGrpResultsModel);
		Assertions.assertThrows(Exception.class, () -> {
			coreVdGrpResultsServiceImpl.saveOrUpdateVdGroupResults(groupResultsRequestDTO, coreVdGroups, coreVdHeader);
		});
	}

	@Test
	@DisplayName("coreVdGrpResultsModelTest2 method test for tnull")
	void coreVdGrpResultsModelTest2() {
		CoreVdGrpResultsModel coreVdGrpResultsModel = new CoreVdGrpResultsModel();
		coreVdGrpResultsModel.setUuid(any());
		VdGroupResultsRequestDTO groupResultsRequestDTO = new VdGroupResultsRequestDTO();
		groupResultsRequestDTO.setResultId(null);
		CoreVdGroupsModel coreVdGroups = new CoreVdGroupsModel();
		CoreVdHeaderModel coreVdHeader = new CoreVdHeaderModel();

		copyProperties(groupResultsRequestDTO, coreVdGrpResultsModel);
		coreVdGrpResultsModel.setCoreVdGroups(coreVdGroups);
		coreVdGrpResultsModel.setCoreVdHeader(coreVdHeader);
		when(coreVdGrpResultsDAO.save(coreVdGrpResultsModel)).thenReturn(coreVdGrpResultsModel);
		coreVdGrpResultsServiceImpl.saveOrUpdateVdGroupResults(groupResultsRequestDTO, coreVdGroups, coreVdHeader);
		verify(coreVdGrpResultsDAO, atLeast(1)).save(any());
	}

	@Test
	@DisplayName("coreVdGrpResultsModelTest3 method test for null")
	void coreVdGrpResultsModelTest3() {
		assertThrows(Exception.class, () -> coreVdGrpResultsServiceImpl.saveOrUpdateVdGroupResults(null,
				new CoreVdGroupsModel(), new CoreVdHeaderModel()));
	}

	@Test
	@DisplayName("coreVdGrpResultsModelTest4 method test for null")
	void coreVdGrpResultsModelTest4() {
		assertThrows(Exception.class, () -> coreVdGrpResultsServiceImpl
				.saveOrUpdateVdGroupResults(new VdGroupResultsRequestDTO(), null, new CoreVdHeaderModel()));
	}
	
	@Test
	@DisplayName("coreVdGrpResultsModelTest5 method test for null")
	void coreVdGrpResultsModelTest5() {
		assertThrows(Exception.class, () -> coreVdGrpResultsServiceImpl
				.saveOrUpdateVdGroupResults(new VdGroupResultsRequestDTO(), new CoreVdGroupsModel(), null));
	}
	
	@Test
	@DisplayName("deleteVdGroupResultsTest method test for test delete the virtual dataset transformation information")
	void deleteVdGroupResultsTest() {

		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		List<VdGroupResultsRequestDTO> vdGroupResultsRequestDTO = new ArrayList<VdGroupResultsRequestDTO>();
		VdGroupResultsRequestDTO groupResultsRequestDTO = new VdGroupResultsRequestDTO();
		groupResultsRequestDTO.setResultId(UUID.randomUUID());
		vdGroupResultsRequestDTO.add(groupResultsRequestDTO);
		List<CoreVdGrpResultsModel> coreVdGrpResultsModel = new ArrayList<CoreVdGrpResultsModel>();
		CoreVdGrpResultsModel vdGrpResultsModel = new CoreVdGrpResultsModel();
		vdGrpResultsModel.setUuid(UUID.randomUUID());
		coreVdGrpResultsModel.add(vdGrpResultsModel);
		when(coreVdHeaderDAO.findById(any())).thenReturn(Optional.of(coreVdHeaderModel));
		when(coreVdGrpResultsDAO.findByCoreVdHeader(any())).thenReturn(coreVdGrpResultsModel);
		doNothing().when(coreVdGrpResultsDAO).deleteByUuidIn(any());
		coreVdGrpResultsServiceImpl.deleteVdGroupResults(vdGroupResultsRequestDTO, UUID.randomUUID());
		verify(coreVdGrpResultsDAO, atLeast(1)).deleteByUuidIn(any());
	}

	@Test
	@DisplayName("deleteVdGroupResultsTest1 method test for any exception")
	void deleteVdGroupResultsTest1() {
		Assertions.assertThrows(Exception.class, () -> {
			coreVdGrpResultsServiceImpl.deleteVdGroupResults(new ArrayList<VdGroupResultsRequestDTO>(), null);
		});
	}
}
