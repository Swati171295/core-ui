package com.prospecta.mdo.module.service.grid;

import com.prospecta.mdo.module.dao.grid.CoreGridDAO;
import com.prospecta.mdo.module.dao.grid.CoreGridSequenceDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataDAO;
import com.prospecta.mdo.module.dto.grid.GridResponseDTO;
import com.prospecta.mdo.module.dto.grid.GridSettingRequestDTO;
import com.prospecta.mdo.module.dto.grid.GridSettingResponseDTO;
import com.prospecta.mdo.module.dto.grid.SequenceSettingRequestDTO;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.grid.CompositeSequenceSettingId;
import com.prospecta.mdo.module.model.grid.CoreGridSequenceSetting;
import com.prospecta.mdo.module.model.grid.CoreGridSettingModel;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class CoreGridServiceImplTest {

    @InjectMocks
    CoreGridServiceImpl gridSettingService;

    @Mock
    CoreMetadataDAO coreMetadataDAO;

    @Mock
    CoreGridDAO coreGridDAO;

    @Mock
    CoreGridSequenceDAO coreGridSequenceDAO;

    @BeforeAll
    public void init() {
        gridSettingService = new CoreGridServiceImpl();
    }

    @Test
    @DisplayName("Test case for Save Grid Test method to Save/Update Grid Settings")
    void saveUpdateGridSetting() {

        GridSettingRequestDTO requestDTO = new GridSettingRequestDTO();
        requestDTO.setFieldId("FLD_123");

        List<GridSettingRequestDTO> requestDTOList = Collections.singletonList(requestDTO);

        List<String> fieldIds = Collections.singletonList("FLD_123");

        when(coreMetadataDAO.findFieldIdByFieldIdInAndModuleIdAndTenantId(fieldIds, 1L, "0")).thenReturn(fieldIds);
        when(coreGridDAO.findByGridFieldIdAndFieldIdAndModuleIdAndTenantId("FLD_125","FLD_123", 1L, "0")).thenReturn(Optional.empty());

        GridResponseDTO responseDTO = gridSettingService.saveUpdateGridSetting(requestDTOList, 1L, "FLD_125", "0");

        assertTrue(responseDTO.isAcknowledge());
        assertEquals("FLD_125", responseDTO.getGridFieldId());

        verify((coreMetadataDAO), atLeast(1)).findFieldIdByFieldIdInAndModuleIdAndTenantId(any(), any(), any());
        verify((coreGridDAO), atLeast(1)).findByGridFieldIdAndFieldIdAndModuleIdAndTenantId("FLD_125","FLD_123", 1L, "0");
    }

    @Test
    @DisplayName("Test case for Save Grid Settings to check absent field exception")
    void saveUpdateGridSettingException() {

        GridSettingRequestDTO requestDTO = new GridSettingRequestDTO();
        requestDTO.setFieldId("FLD_123");
        GridSettingRequestDTO secondRequestDTO = new GridSettingRequestDTO();
        requestDTO.setFieldId("FLD_124");

        List<GridSettingRequestDTO> requestDTOList = new ArrayList<>() {{
            add(requestDTO);
            add(secondRequestDTO);
        }};

        List<String> fieldIds = Collections.singletonList("FLD_124");

        when(coreMetadataDAO.findFieldIdByFieldIdInAndModuleIdAndTenantId(any(), any(), any())).thenReturn(fieldIds);

        assertThrows(NotFound404Exception.class,
                () -> gridSettingService.saveUpdateGridSetting(requestDTOList, 1L, "FLD_125", "0"));

        verify((coreMetadataDAO), atLeast(1)).findFieldIdByFieldIdInAndModuleIdAndTenantId(any(), any(), any());
    }

    @Test
    @DisplayName("Test case for get Grid Test method to get Grid Settings")
    void getGridSetting() {

        CoreGridSettingModel model = new CoreGridSettingModel();
        model.setFieldId("test");
        model.setGridFieldId("FLD_125");
        List<CoreGridSettingModel> modelList = Collections.singletonList(model);

        when(coreGridDAO.findByGridFieldIdAndModuleIdAndTenantId("FLD_125", 1L, "0")).thenReturn(Optional.of(modelList));

        List<GridSettingResponseDTO> responseDTO = gridSettingService.getGridSetting(1L, "FLD_125", "0");

        assertFalse(responseDTO.isEmpty());
        assertEquals("FLD_125", responseDTO.get(0).getGridFieldId());

        verify((coreGridDAO), atLeast(1)).findByGridFieldIdAndModuleIdAndTenantId("FLD_125", 1L, "0");
    }

    @Test
    @DisplayName("Test case for get Grid Test method to get Grid Settings Exception")
    void getGridSettingException() {

        when(coreGridDAO.findByGridFieldIdAndModuleIdAndTenantId("FLD_125", 1L, "0")).thenReturn(Optional.empty());

        assertThrows(NotFound404Exception.class, () -> gridSettingService.getGridSetting(1L, "FLD_125", "0"));

        verify((coreGridDAO), atLeast(1)).findByGridFieldIdAndModuleIdAndTenantId("FLD_125", 1L, "0");
    }

    @Test
    @DisplayName("Test case for get Sortable Grid Fields")
    void getSortableFields() {

        CoreGridSettingModel responseDTO = new CoreGridSettingModel();
        responseDTO.setGridFieldId("field");
        responseDTO.setIsSort(true);

        when(coreGridDAO.findSortableFields(anyString(),anyString(),anyLong(),anyString(),anyString(),anyBoolean(),eq(PageRequest.of(1,1)))).thenReturn(new ArrayList<>(){{add(responseDTO);}});

        List<GridSettingResponseDTO> dto =gridSettingService.getSortableGridFields(1L,"field","",1,1,"en","0");

        assertEquals(1,dto.size());

        verify((coreGridDAO), atLeast(1)).findSortableFields(anyString(),anyString(),anyLong(),anyString(),anyString(),anyBoolean(),eq(PageRequest.of(1,1)));
    }

    @Test
    @DisplayName("Test case for get Sequence Grid fields")
    void getSequenceFields() {

        CoreGridSettingModel responseDTO = new CoreGridSettingModel();
        responseDTO.setGridFieldId("field");
        responseDTO.setIsSort(true);

        when(coreGridDAO.findSequenceFields(anyString(),anyString(),anyLong(),anyString(),anyString(),anyBoolean(),eq(PageRequest.of(1,1)))).thenReturn(new ArrayList<>(){{add(responseDTO);}});

        List<GridSettingResponseDTO> dto =gridSettingService.getSequenceGridFields(1L,"field","",1,1,"en","0");

        assertEquals(1,dto.size());

        verify((coreGridDAO), atLeast(1)).findSequenceFields(anyString(),anyString(),anyLong(),anyString(),anyString(),anyBoolean(),eq(PageRequest.of(1,1)));
    }

    @Test
    @DisplayName("Test case for Save update Sequence Setting")
    void saveUpdateSequenceSetting() {

        SequenceSettingRequestDTO firstDTO = new SequenceSettingRequestDTO();
        SequenceSettingRequestDTO secondDTO = new SequenceSettingRequestDTO();

        UUID uuid= UUID.randomUUID();

        CoreGridSequenceSetting responseDTO = new CoreGridSequenceSetting();
        responseDTO.setGridSettingUuid(uuid);
        responseDTO.setModuleId(1L);
        responseDTO.setTenantId("0");

        firstDTO.setGridSettingUuid(uuid);

        secondDTO.setGridSettingUuid(UUID.randomUUID());

        List<SequenceSettingRequestDTO> list = new ArrayList<>();
        list.add(firstDTO);
        list.add(secondDTO);

        CompositeSequenceSettingId id = new CompositeSequenceSettingId(1L,"0",uuid);
        when(coreGridSequenceDAO.findById(id)).thenReturn(Optional.of(responseDTO));

        GridResponseDTO dto =gridSettingService.saveUpdateSequenceSetting(list,1L,"0");

        assertTrue(dto.isAcknowledge());
    }
}