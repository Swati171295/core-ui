package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdTransFieldSettingDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdTransRuleConcatDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupTransInfoRequestDTO;
import com.prospecta.mdo.module.dto.virtualdata.VdTransRuleConcatRequestDTO;
import com.prospecta.mdo.module.enums.ConcatFieldType;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransRuleConcatModel;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class CoreVdTransRuleConcatServiceImplTest {

	@InjectMocks
	private CoreVdTransRuleConcatServiceImpl coreVdTransRuleConcatServiceImpl;
	
	@Mock
	private CoreVdTransRuleConcatDAO coreVdTransRuleConcatDAO;
	
	@Mock
	private CoreVdTransFieldSettingDAO coreVdTransFieldSettingDAO;
	
	@BeforeAll
	void init() {
		coreVdTransRuleConcatServiceImpl = new CoreVdTransRuleConcatServiceImpl();
	}
	
	@Test
	@DisplayName("getVdTransRuleConcatbyConcatIdTest method test for get rule concat")
	void getVdTransRuleConcatbyConcatIdTest() {
		CoreVdTransRuleConcatModel coreVdTransRuleConcatModel = spy(CoreVdTransRuleConcatModel.class);
		UUID id = UUID.randomUUID();
		when(coreVdTransRuleConcatDAO.findById(id)).thenReturn(Optional.of(coreVdTransRuleConcatModel));
		coreVdTransRuleConcatModel = coreVdTransRuleConcatServiceImpl.getVdTransRuleConcatbyConcatId(id);
		verify(coreVdTransRuleConcatDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdTransRuleConcatbyConcatIdExceptionTest method test for test Exception")
	void getVdTransRuleConcatbyConcatIdExceptionTest() {
		CoreVdTransRuleConcatModel coreVdTransRuleConcatModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdTransRuleConcatDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdTransRuleConcatModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransRuleConcatServiceImpl.getVdTransRuleConcatbyConcatId(id));
		verify(coreVdTransRuleConcatDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdTransRuleConcatbytransFieldIdTest method test for get rule concat by trans field id")
	void getVdTransRuleConcatbytransFieldIdTest() {
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = spy(CoreVdTransFieldSettingModel.class);
		CoreVdTransRuleConcatModel coreVdTransRuleConcatModel = spy(CoreVdTransRuleConcatModel.class);
		coreVdTransRuleConcatModel.setCoreVdTransFieldSetting(coreVdTransFieldSettingModel);
		List<CoreVdTransRuleConcatModel> coreVdTransRuleConcatModelList = new ArrayList<>();
		coreVdTransRuleConcatModelList.add(coreVdTransRuleConcatModel);
		UUID id = UUID.randomUUID();
		when(coreVdTransRuleConcatDAO.findByCoreVdTransFieldSetting(coreVdTransFieldSettingModel)).thenReturn(coreVdTransRuleConcatModelList);
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.of(coreVdTransFieldSettingModel));
		List<CoreVdTransRuleConcatModel> coreVdTransRuleConcatList = coreVdTransRuleConcatServiceImpl.getVdTransRuleConcatbytransFieldId(id);
		assertNotNull(coreVdTransRuleConcatList);
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
		verify(coreVdTransRuleConcatDAO, atLeast(1)).findByCoreVdTransFieldSetting(any());
	}
	
	@Test
	@DisplayName("getVdTransRuleConcatbytransFieldIdExceptionTest method test for test exception")
	void getVdTransRuleConcatbytransFieldIdExceptionTest() {
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdTransFieldSettingModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransRuleConcatServiceImpl.getVdTransRuleConcatbytransFieldId(id));
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdTransRuleConcatbytransFieldIdListExceptionTest method test for test exception")
	void getVdTransRuleConcatbytransFieldIdListExceptionTest() {
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = spy(CoreVdTransFieldSettingModel.class);
		List<CoreVdTransRuleConcatModel> coreVdTransRuleConcatModelList = new ArrayList<>();
		UUID id = UUID.randomUUID();
		when(coreVdTransRuleConcatDAO.findByCoreVdTransFieldSetting(coreVdTransFieldSettingModel)).thenReturn(coreVdTransRuleConcatModelList);
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.of(coreVdTransFieldSettingModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransRuleConcatServiceImpl.getVdTransRuleConcatbytransFieldId(id));
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
		verify(coreVdTransRuleConcatDAO, atLeast(1)).findByCoreVdTransFieldSetting(any());
	}
	
	@Test
	@DisplayName("deleteVdTransRuleConcatbyConcatIdTest method test for rule concat")
	void deleteVdTransRuleConcatbyConcatIdTest() {
		UUID id = UUID.randomUUID();
		doNothing().when(coreVdTransRuleConcatDAO).deleteById(id);
		coreVdTransRuleConcatServiceImpl.deleteVdTransRuleConcatbyConcatId(id);
		verify(coreVdTransRuleConcatDAO, atLeast(1)).deleteById(any());
	}
	
	@Test
	@DisplayName("deleteVdTransRuleConcatbytransFieldIdTest method test for delete rule concat by field id")
	void deleteVdTransRuleConcatbytransFieldIdTest() {
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel= new CoreVdTransFieldSettingModel();
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.of(coreVdTransFieldSettingModel));
		doNothing().when(coreVdTransRuleConcatDAO).deleteByCoreVdTransFieldSetting(coreVdTransFieldSettingModel);
		coreVdTransRuleConcatServiceImpl.deleteVdTransRuleConcatbytransFieldId(id);
		verify(coreVdTransRuleConcatDAO, atLeast(1)).deleteByCoreVdTransFieldSetting(any());
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("deleteVdTransRuleConcatbytransFieldIdExceptionTest method test for test exception")
	void deleteVdTransRuleConcatbytransFieldIdExceptionTest() {
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel= null;
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdTransFieldSettingModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransRuleConcatServiceImpl.deleteVdTransRuleConcatbytransFieldId(id));
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("saveAndUpdateRuleConcatTest method test for test save or update")
	void saveAndUpdateRuleConcatTest() {
		CoreVdTransRuleConcatModel coreVdTransRuleConcatModel = new CoreVdTransRuleConcatModel();
		VdTransRuleConcatRequestDTO transRuleConcatRequestDTO = new VdTransRuleConcatRequestDTO();
		transRuleConcatRequestDTO.setVdConcatId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		transRuleConcatRequestDTO.setFieldType("USERINPUT");
		copyProperties(transRuleConcatRequestDTO, coreVdTransRuleConcatModel);
		CoreVdTransFieldSettingModel coreVdTransFieldSetting = new CoreVdTransFieldSettingModel();
		coreVdTransRuleConcatModel.setCoreVdTransFieldSetting(coreVdTransFieldSetting);
		coreVdTransRuleConcatModel.setFieldType(
				ConcatFieldType.fromValue(transRuleConcatRequestDTO.getFieldType().toUpperCase()));
		when(coreVdTransRuleConcatDAO.save(coreVdTransRuleConcatModel)).thenReturn(coreVdTransRuleConcatModel);
		coreVdTransRuleConcatServiceImpl.saveAndUpdateRuleConcat(transRuleConcatRequestDTO, coreVdTransFieldSetting);
		verify(coreVdTransRuleConcatDAO, atLeast(1)).save(coreVdTransRuleConcatModel);
	}
	
	@Test
	@DisplayName("saveAndUpdateRuleConcatWithExceptionTest method test for exception")
	void saveAndUpdateRuleConcatWithExceptionTest() {
		CoreVdTransRuleConcatModel coreVdTransRuleConcatModel = new CoreVdTransRuleConcatModel();
		VdTransRuleConcatRequestDTO transRuleConcatRequestDTO = new VdTransRuleConcatRequestDTO();
		transRuleConcatRequestDTO.setVdConcatId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		transRuleConcatRequestDTO.setFieldType("USERINPUT");
		copyProperties(transRuleConcatRequestDTO, coreVdTransRuleConcatModel);
		CoreVdTransFieldSettingModel coreVdTransFieldSetting = new CoreVdTransFieldSettingModel();
		coreVdTransRuleConcatModel.setCoreVdTransFieldSetting(coreVdTransFieldSetting);
		coreVdTransRuleConcatModel.setFieldType(null);
		when(coreVdTransRuleConcatDAO.save(coreVdTransRuleConcatModel)).thenReturn(coreVdTransRuleConcatModel);
		Assertions.assertThrows(Exception.class, () -> {
			coreVdTransRuleConcatServiceImpl.saveAndUpdateRuleConcat(transRuleConcatRequestDTO, coreVdTransFieldSetting);
		});
	}
	
	@Test
	@DisplayName("saveAndUpdateRuleConcatWithVdConcatIdNullTest method test for null")
	void saveAndUpdateRuleConcatWithVdConcatIdNullTest() {
		CoreVdTransRuleConcatModel coreVdTransRuleConcatModel = new CoreVdTransRuleConcatModel();
		VdTransRuleConcatRequestDTO transRuleConcatRequestDTO = new VdTransRuleConcatRequestDTO();
		transRuleConcatRequestDTO.setVdConcatId(any());
		transRuleConcatRequestDTO.setFieldType("USERINPUT");
		copyProperties(transRuleConcatRequestDTO, coreVdTransRuleConcatModel);
		CoreVdTransFieldSettingModel coreVdTransFieldSetting = new CoreVdTransFieldSettingModel();
		coreVdTransRuleConcatModel.setCoreVdTransFieldSetting(coreVdTransFieldSetting);
		coreVdTransRuleConcatModel.setFieldType(
				ConcatFieldType.fromValue(transRuleConcatRequestDTO.getFieldType().toUpperCase()));
		when(coreVdTransRuleConcatDAO.save(coreVdTransRuleConcatModel)).thenReturn(coreVdTransRuleConcatModel);
		coreVdTransRuleConcatServiceImpl.saveAndUpdateRuleConcat(transRuleConcatRequestDTO, coreVdTransFieldSetting);
		verify(coreVdTransRuleConcatDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("saveAndUpdateRuleConcatWithNullDTOTest method test for null")
	void saveAndUpdateRuleConcatWithNullDTOTest() {

//		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
//		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		assertThrows(Exception.class,
				() -> coreVdTransRuleConcatServiceImpl.saveAndUpdateRuleConcat(null, new CoreVdTransFieldSettingModel()));
	}

	@Test
	@DisplayName("saveAndUpdateRuleConcatWithNullModelTest method test for null")
	void saveAndUpdateRuleConcatWithNullModelTest() {

		VdGroupTransInfoRequestDTO vdGroupTransInfoRequestDTO = new VdGroupTransInfoRequestDTO();
		assertThrows(Exception.class,
				() -> coreVdTransRuleConcatServiceImpl.saveAndUpdateRuleConcat(new VdTransRuleConcatRequestDTO(), null));
	}
	
	@Test
	@DisplayName("deleteVdTransRuleConcatTest method test for test delete the virtual dataset transformation information")
	void deleteVdTransRuleConcatTest() {

		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = new CoreVdTransFieldSettingModel();
		List<VdTransRuleConcatRequestDTO> vdTransRuleConcatRequestDTO = new ArrayList<VdTransRuleConcatRequestDTO>();
		VdTransRuleConcatRequestDTO transRuleConcatRequestDTO=new VdTransRuleConcatRequestDTO();
		transRuleConcatRequestDTO.setVdConcatId(UUID.randomUUID());
		vdTransRuleConcatRequestDTO.add(transRuleConcatRequestDTO);
		List<CoreVdTransRuleConcatModel> coreVdTransRuleConcatModel = new ArrayList<CoreVdTransRuleConcatModel>();
		CoreVdTransRuleConcatModel vdTransRuleConcatModel= new CoreVdTransRuleConcatModel();
		vdTransRuleConcatModel.setVdConcatId(UUID.randomUUID());
		coreVdTransRuleConcatModel.add(vdTransRuleConcatModel);
		when(coreVdTransFieldSettingDAO.findById(any())).thenReturn(Optional.of(coreVdTransFieldSettingModel));
		when(coreVdTransRuleConcatDAO.findByCoreVdTransFieldSetting(any())).thenReturn(coreVdTransRuleConcatModel);
		doNothing().when(coreVdTransRuleConcatDAO).deleteByVdConcatIdIn(any());
		coreVdTransRuleConcatServiceImpl.deleteVdTransRuleConcat(vdTransRuleConcatRequestDTO, UUID.randomUUID());
		verify(coreVdTransRuleConcatDAO, atLeast(1)).deleteByVdConcatIdIn(any());
	}

	@Test
	@DisplayName("deleteCoreVdGroupWithExceptionTest method test for any exception")
	void deleteCoreVdGroupWithExceptionTest() {
		List<VdTransRuleConcatRequestDTO> vdTransRuleConcatRequestDTO = new ArrayList<VdTransRuleConcatRequestDTO>();
		Assertions.assertThrows(RuntimeException.class, () -> {
			coreVdTransRuleConcatServiceImpl.deleteVdTransRuleConcat(vdTransRuleConcatRequestDTO, null);
		});
	}

}
