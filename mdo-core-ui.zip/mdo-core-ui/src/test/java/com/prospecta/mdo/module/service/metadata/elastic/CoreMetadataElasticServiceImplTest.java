package com.prospecta.mdo.module.service.metadata.elastic;

import com.prospecta.mdo.module.dto.metadata.BulkDeleteDTO;
import com.prospecta.mdo.module.dto.metadata.CreateFieldRequestDTO;
import com.prospecta.mdo.module.dto.metadata.FieldIdsRequestDTO;
import com.prospecta.mdo.module.dto.module.ChildFieldsDTO;
import com.prospecta.mdo.module.dto.module.FieldDTO;
import com.prospecta.mdo.module.dto.module.FieldsRequestDTO;
import com.prospecta.mdo.module.dto.module.ModuleDescriptionInformationRequestDTO;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.metadata.elastic.UserFieldMetadata;
import com.prospecta.mdo.module.repository.metadata.UserFieldMetadataRepository;
import com.prospecta.mdo.module.service.metadata.CoreMetadataService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessResourceFailureException;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class CoreMetadataElasticServiceImplTest {

    @InjectMocks
    private static CoreMetadataElasticServiceImpl coreMetadataElasticServiceImpl;

    @Mock
    UserFieldMetadataRepository userFieldMetadataRepository;

    @Mock
    CoreMetadataService coreMetadataService;

    @BeforeAll
    static void init() {
        coreMetadataElasticServiceImpl = new CoreMetadataElasticServiceImpl();
    }

    @Test
    @DisplayName("Test case for Draft Field Creation")
    void draftField() {

        CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

        List<FieldsRequestDTO> fields = new ArrayList<>();

        Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription("Test Draft");

        FieldDTO fieldDTO = createFieldDto(moduleDescription,"TestingField");
        ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription,"land");


        fieldDTO.setChildfields(new ArrayList<>(){{add(childDTO);}});

        FieldsRequestDTO requestDTO = new FieldsRequestDTO();
        requestDTO.setStructureid("2");
        requestDTO.setFieldlist(new ArrayList<>(){{add(fieldDTO);}});
        UserFieldMetadata userFieldMetadata=new UserFieldMetadata(fieldDTO.getFieldId(),"0",1L,"admin");
        userFieldMetadata.setFieldData(fieldDTO);
        userFieldMetadata.setSearchString("");

        fields.add(requestDTO);
        dto.setFields(fields);
        when(userFieldMetadataRepository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.of(userFieldMetadata));
        when(coreMetadataService.createDynamicFieldIds(any(),any(),any(),eq(false))).thenReturn(new ArrayList<>());
        assertTrue(coreMetadataElasticServiceImpl.createDraftField(dto,"0","admin",1L).isAcknowledge());
    }

    @Test
    @DisplayName("Test case for Draft Field Exception Catching")
    void draftFieldException() {

        CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

        List<FieldsRequestDTO> fields = new ArrayList<>();

        Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription("Test Draft");

        FieldDTO fieldDTO = createFieldDto(moduleDescription,"TestingField");
        ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription,"land");


        fieldDTO.setChildfields(new ArrayList<>(){{add(childDTO);}});

        FieldsRequestDTO requestDTO = new FieldsRequestDTO();
        requestDTO.setStructureid("2");
        requestDTO.setFieldlist(new ArrayList<>(){{add(fieldDTO);}});
        UserFieldMetadata userFieldMetadata=new UserFieldMetadata(fieldDTO.getFieldId(),"0",1L,"admin");
        userFieldMetadata.setFieldData(fieldDTO);
        userFieldMetadata.setSearchString("");

        fields.add(requestDTO);
        dto.setFields(fields);
        when(userFieldMetadataRepository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.of(userFieldMetadata));
        when(coreMetadataService.createDynamicFieldIds(any(),any(),any(),eq(false))).thenReturn(new ArrayList<>());
        when(userFieldMetadataRepository.saveAll(any())).thenThrow(DataAccessResourceFailureException.class);

        assertThrows(DataAccessResourceFailureException.class,()->
                coreMetadataElasticServiceImpl.createDraftField(dto,"0","admin",1L));
    }

    @Test
    @DisplayName("Test case for get Draft Field")
    void getDraftField() {

        CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

        List<FieldsRequestDTO> fields = new ArrayList<>();

        Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription("Test Draft");

        FieldDTO fieldDTO = createFieldDto(moduleDescription,"TestingField");
        ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription,"land");


        fieldDTO.setChildfields(new ArrayList<>(){{add(childDTO);}});

        FieldsRequestDTO requestDTO = new FieldsRequestDTO();
        requestDTO.setStructureid("2");
        requestDTO.setFieldlist(new ArrayList<>(){{add(fieldDTO);}});
        UserFieldMetadata userFieldMetadata=new UserFieldMetadata(fieldDTO.getFieldId(),"0",1L,"admin");
        userFieldMetadata.setFieldData(fieldDTO);
        userFieldMetadata.setSearchString("");

        fields.add(requestDTO);
        dto.setFields(fields);
        when(userFieldMetadataRepository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.of(userFieldMetadata));
        assertEquals(coreMetadataElasticServiceImpl.getDraftField("Testing","0","admin",1L),fieldDTO);
    }

    @Test
    @DisplayName("Test case for get Draft Field Not Found Exception")
    void getDraftFieldException() {

        CreateFieldRequestDTO dto = new CreateFieldRequestDTO();

        List<FieldsRequestDTO> fields = new ArrayList<>();

        Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription("Test Draft");

        FieldDTO fieldDTO = createFieldDto(moduleDescription,"TestingField");
        ChildFieldsDTO childDTO=createChildFieldDTO(moduleDescription,"land");


        fieldDTO.setChildfields(new ArrayList<>(){{add(childDTO);}});

        FieldsRequestDTO requestDTO = new FieldsRequestDTO();
        requestDTO.setStructureid("2");
        requestDTO.setFieldlist(new ArrayList<>(){{add(fieldDTO);}});

        fields.add(requestDTO);
        dto.setFields(fields);
        when(userFieldMetadataRepository.findByFieldIdAndModuleIdAndTenantIdAndUserId(any(),any(),any(),any())).thenReturn(Optional.empty());

        assertThrows(NotFound404Exception.class,()->
                coreMetadataElasticServiceImpl.getDraftField("Testing","0","admin",1L));
    }

    @Test
    @DisplayName("Test case for delete Draft Field")
    void deleteDraftField() {

        FieldIdsRequestDTO requestDTO = new FieldIdsRequestDTO();
        requestDTO.setFieldIds(new ArrayList<>(){{add("field");}});

        assertTrue(coreMetadataElasticServiceImpl.deleteDraftField("Testing","0","admin",1L).isAcknowledge());
        BulkDeleteDTO dto = coreMetadataElasticServiceImpl.deleteBulkDraftField(requestDTO,"0","admin",1L);
        assertNotNull(dto.getDeletedFields());
    }


    private FieldDTO createFieldDto(Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription, String fieldId){

        FieldDTO fieldDTO = new FieldDTO();
        Map<String, String>longText =createMap();
        Map<String, String> helpText =createMap();
        fieldDTO.setFieldId(fieldId);
        fieldDTO.setShortText(moduleDescription);
        fieldDTO.setLongtexts(longText);
        fieldDTO.setHelptexts(helpText);
        fieldDTO.setDataType("GRID");
        fieldDTO.setPickList("15");
        fieldDTO.setMaxChar(200L);
        fieldDTO.setIsGridColumn(false);
        fieldDTO.setParentField("");
        return fieldDTO;
    }

    private ChildFieldsDTO createChildFieldDTO(Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription,String fieldId){

        ChildFieldsDTO childDTO = new ChildFieldsDTO();
        Map<String, String>longText =createMap();
        Map<String, String> helpText =createMap();
        childDTO.setFieldId(fieldId);
        childDTO.setShortText(moduleDescription);
        childDTO.setLongtexts(longText);
        childDTO.setHelptexts(helpText);
        childDTO.setDataType("GRID");
        childDTO.setPickList("15");
        childDTO.setMaxChar(200L);
        childDTO.setIsGridColumn(true);
        childDTO.setParentField("LANGUAGEGRID");
        return childDTO;
    }

    private Map<String, ModuleDescriptionInformationRequestDTO> createModuleDescription(String description) {

        Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
        ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
        enData.setDescription(description);
        enData.setInformation("English info");
        ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
        frData.setDescription("FRENCH");
        frData.setInformation("FRENCH info");
        ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
        arData.setDescription("ARABIC");
        arData.setInformation("ARABIC info");
        ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
        jrData.setDescription("JAPANI");
        jrData.setInformation("JAPANI info");
        moduledescription.put("en", enData);
        moduledescription.put("fr", frData);
        moduledescription.put("ar", arData);
        moduledescription.put("jr", jrData);
        return  moduledescription;
    }

    private Map<String,String> createMap() {
        Map<String, String> text = new HashMap<>();
        text.put("en", "Material");
        text.put("fr", "matériel");
        text.put("sp", "tipo de material");
        text.put("gj", "tipo de material");
        return text;
    }
}