package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpJoinInfoDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpJoinMappingDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinMappingRequestDTO;
import com.prospecta.mdo.module.enums.CompareOperator;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinMappingModel;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class CoreVdGrpJoinMappingServiceTest {
	
	@InjectMocks
	private CoreVdGrpJoinMappingServiceImpl coreVdGrpJoinMappingServiceImpl;
	
	@Mock
	private CoreVdGrpJoinMappingDAO coreVdGrpJoinMappingDAO;
	
	@Mock
	private CoreVdGrpJoinInfoDAO coreVdGrpJoinInfoDAO;
	
	@BeforeAll
	void init() {
		coreVdGrpJoinMappingServiceImpl = new CoreVdGrpJoinMappingServiceImpl();
	}
	
	@Test
	@DisplayName("getVdGroupJoinMappingbyMappingIdest method test for getting virtual dataset join mapping by MappingId")
	void getVdGroupJoinMappingbyMappingIdTest() {
		CoreVdGrpJoinMappingModel coreVdGrpJoinMappingModel = spy(CoreVdGrpJoinMappingModel.class);
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinMappingDAO.findById(id)).thenReturn(Optional.of(coreVdGrpJoinMappingModel));
		coreVdGrpJoinMappingModel = coreVdGrpJoinMappingServiceImpl.getVdGroupJoinMappingbyMappingId(id);
		verify(coreVdGrpJoinMappingDAO, atLeast(1)).findById(any());
		
	}
	
	@Test
	@DisplayName("getVdGroupJoinMappingbyMappingIdExceptionTest method test for exception")
	void getVdGroupJoinMappingbyMappingIdExceptionTest() {
		CoreVdGrpJoinMappingModel coreVdGrpJoinMappingModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinMappingDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGrpJoinMappingModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinMappingServiceImpl.getVdGroupJoinMappingbyMappingId(id));
		verify(coreVdGrpJoinMappingDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdGroupJoinMappingbygroupInfoIdTest method test for getting virtual dataset join mapping by groupInfoId")
	void getVdGroupJoinMappingbygroupInfoIdTest() {
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = spy(CoreVdGrpJoinInfoModel.class);
		CoreVdGrpJoinMappingModel coreVdGrpJoinMappingModel = spy(CoreVdGrpJoinMappingModel.class);
		coreVdGrpJoinMappingModel.setCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel);
		List<CoreVdGrpJoinMappingModel> coreVdGrpJoinMappingModelList = new ArrayList<>();
		coreVdGrpJoinMappingModelList.add(coreVdGrpJoinMappingModel);
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinMappingDAO.findByCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel)).thenReturn(coreVdGrpJoinMappingModelList);
		when(coreVdGrpJoinInfoDAO.findById(id)).thenReturn(Optional.of(coreVdGrpJoinInfoModel));
		List<CoreVdGrpJoinMappingModel> coreVdGrpJoinMappingList = coreVdGrpJoinMappingServiceImpl.getVdGroupJoinMappingbygroupInfoId(id);
		assertNotNull(coreVdGrpJoinMappingList);
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).findById(any());
		verify(coreVdGrpJoinMappingDAO, atLeast(1)).findByCoreVdGrpJoinInfo(any());
	}
	
	@Test
	@DisplayName("getVdGroupJoinMappingbygroupInfoIdExceptionTest method test for exception")
	void getVdGroupJoinMappingbygroupInfoIdExceptionTest() {
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinInfoDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGrpJoinInfoModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinMappingServiceImpl.getVdGroupJoinMappingbygroupInfoId(id));
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdGroupJoinMappingbygroupInfoIdListExceptionTest method test for exception")
	void getVdGroupJoinMappingbygroupInfoIdListExceptionTest() {
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = spy(CoreVdGrpJoinInfoModel.class);
		List<CoreVdGrpJoinMappingModel> coreVdGrpJoinMappingModelList = new ArrayList<>();
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinMappingDAO.findByCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel)).thenReturn(coreVdGrpJoinMappingModelList);
		when(coreVdGrpJoinInfoDAO.findById(id)).thenReturn(Optional.of(coreVdGrpJoinInfoModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinMappingServiceImpl.getVdGroupJoinMappingbygroupInfoId(id));
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).findById(any());
		verify(coreVdGrpJoinMappingDAO, atLeast(1)).findByCoreVdGrpJoinInfo(any());
	}
	
	@Test
	@DisplayName("deleteVdGroupJoinMappingbyMappingIdTest method test for deleting virtual dataset join mapping by MappingId")
	void deleteVdGroupJoinMappingbyMappingIdTest() {
		UUID id = UUID.randomUUID();
		doNothing().when(coreVdGrpJoinMappingDAO).deleteById(id);
		coreVdGrpJoinMappingServiceImpl.deleteVdGroupJoinMappingbyMappingId(id);
		verify(coreVdGrpJoinMappingDAO, atLeast(1)).deleteById(any());
	}
	
	@Test
	@DisplayName("deleteVdGroupJoinMappingbygroupInfoIdTest method test for deleting virtual dataset join mapping by groupInfoId")
	void deleteVdGroupJoinMappingbygroupInfoIdTest() {
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel= new CoreVdGrpJoinInfoModel();
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinInfoDAO.findById(id)).thenReturn(Optional.of(coreVdGrpJoinInfoModel));
		doNothing().when(coreVdGrpJoinMappingDAO).deleteByCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel);
		coreVdGrpJoinMappingServiceImpl.deleteVdGroupJoinMappingbygroupInfoId(id);
		verify(coreVdGrpJoinMappingDAO, atLeast(1)).deleteByCoreVdGrpJoinInfo(any());
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("deleteVdGroupJoinMappingbygroupInfoIdExceptionTest method test for test exception")
	void deleteVdGroupJoinMappingbygroupInfoIdExceptionTest() {
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel= null;
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinInfoDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGrpJoinInfoModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinMappingServiceImpl.deleteVdGroupJoinMappingbygroupInfoId(id));
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).findById(any());
	}

	@Test
	@DisplayName("updateVdGroupJoinMappingTest method test for updating virtual dataset join mapping")
	void updateVdGroupJoinMappingTest() {
		VdGroupJoinMappingRequestDTO groupJoinMappingRequestDTO = new VdGroupJoinMappingRequestDTO();
		groupJoinMappingRequestDTO.setJoinMappingId(UUID.randomUUID());
		groupJoinMappingRequestDTO.setSourceOneField("oneField");
		groupJoinMappingRequestDTO.setSourceTwoField("twoField");
		groupJoinMappingRequestDTO.setOrderBy((short) 1);
		groupJoinMappingRequestDTO.setOperator("EQUALS");
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();
		CoreVdGrpJoinMappingModel coreVdGrpJoinMappingModel = new CoreVdGrpJoinMappingModel();
		copyProperties(groupJoinMappingRequestDTO, coreVdGrpJoinMappingModel);
		coreVdGrpJoinMappingModel.setUuid(groupJoinMappingRequestDTO.getJoinMappingId());
		coreVdGrpJoinMappingModel.setCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel);
		coreVdGrpJoinMappingModel.setSourceOneFieldId(groupJoinMappingRequestDTO.getSourceOneField());
		coreVdGrpJoinMappingModel.setSourceTwoFieldId(groupJoinMappingRequestDTO.getSourceTwoField());
		coreVdGrpJoinMappingModel.setOrder(groupJoinMappingRequestDTO.getOrderBy());
		coreVdGrpJoinMappingModel
				.setCompareOperator(CompareOperator.fromValue(groupJoinMappingRequestDTO.getOperator()));
		when(coreVdGrpJoinMappingDAO.save(coreVdGrpJoinMappingModel)).thenReturn(coreVdGrpJoinMappingModel);
		coreVdGrpJoinMappingServiceImpl.saveAndUpdateJoinMapping(groupJoinMappingRequestDTO, coreVdGrpJoinInfoModel);
		verify(coreVdGrpJoinMappingDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("updateVdGroupJoinMappingWithJoinMappingIdNullTest method test for updating virtual dataset join mapping")
	void updateVdGroupJoinMappingWithJoinMappingIdNullTest() {
		VdGroupJoinMappingRequestDTO groupJoinMappingRequestDTO = new VdGroupJoinMappingRequestDTO();
		groupJoinMappingRequestDTO.setSourceOneField("oneField");
		groupJoinMappingRequestDTO.setSourceTwoField("twoField");
		groupJoinMappingRequestDTO.setOrderBy((short) 1);
		groupJoinMappingRequestDTO.setOperator("EQUALS");
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();	
		CoreVdGrpJoinMappingModel coreVdGrpJoinMappingModel = new CoreVdGrpJoinMappingModel();
		coreVdGrpJoinMappingModel.setUuid(any());
		copyProperties(groupJoinMappingRequestDTO, coreVdGrpJoinMappingModel);
		coreVdGrpJoinMappingModel.setCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel);
		coreVdGrpJoinMappingModel.setSourceOneFieldId(groupJoinMappingRequestDTO.getSourceOneField());
		coreVdGrpJoinMappingModel.setSourceTwoFieldId(groupJoinMappingRequestDTO.getSourceTwoField());
		coreVdGrpJoinMappingModel.setOrder(groupJoinMappingRequestDTO.getOrderBy());
		coreVdGrpJoinMappingModel
				.setCompareOperator(CompareOperator.fromValue(groupJoinMappingRequestDTO.getOperator()));
		when(coreVdGrpJoinMappingDAO.save(coreVdGrpJoinMappingModel)).thenReturn(coreVdGrpJoinMappingModel);
		coreVdGrpJoinMappingServiceImpl.saveAndUpdateJoinMapping(groupJoinMappingRequestDTO, coreVdGrpJoinInfoModel);
		verify(coreVdGrpJoinMappingDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("updateVdGroupJoinMappingwithCatchTest method test for updating virtual dataset join mapping")
	void updateVdGroupJoinMappingwithCatchTest() {
		VdGroupJoinMappingRequestDTO groupJoinMappingRequestDTO = new VdGroupJoinMappingRequestDTO();
		groupJoinMappingRequestDTO.setJoinMappingId(UUID.randomUUID());
		groupJoinMappingRequestDTO.setSourceOneField("oneField");
		groupJoinMappingRequestDTO.setSourceTwoField("twoField");
		groupJoinMappingRequestDTO.setOrderBy((short) 1);
		groupJoinMappingRequestDTO.setOperator("EQUALS");
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();
		CoreVdGrpJoinMappingModel coreVdGrpJoinMappingModel = new CoreVdGrpJoinMappingModel();
		copyProperties(groupJoinMappingRequestDTO, coreVdGrpJoinMappingModel);
		coreVdGrpJoinMappingModel.setUuid(groupJoinMappingRequestDTO.getJoinMappingId());
		coreVdGrpJoinMappingModel.setCoreVdGrpJoinInfo(coreVdGrpJoinInfoModel);
		coreVdGrpJoinMappingModel.setSourceOneFieldId(groupJoinMappingRequestDTO.getSourceOneField());
		coreVdGrpJoinMappingModel.setSourceTwoFieldId(groupJoinMappingRequestDTO.getSourceTwoField());
		coreVdGrpJoinMappingModel.setOrder(groupJoinMappingRequestDTO.getOrderBy());
		coreVdGrpJoinMappingModel
				.setCompareOperator(CompareOperator.fromValue(groupJoinMappingRequestDTO.getOperator()));
		when(coreVdGrpJoinMappingDAO.save(coreVdGrpJoinMappingModel)).thenThrow(new RuntimeException());
		assertThrows(RuntimeException.class, ()->coreVdGrpJoinMappingServiceImpl.saveAndUpdateJoinMapping(groupJoinMappingRequestDTO, coreVdGrpJoinInfoModel));
	}
	
	@Test
	@DisplayName("updateVdGroupJoinMappingwithRequestDtoNullTest method test for updating virtual dataset join mapping")
	void updateVdGroupJoinMappingwithRequestDtoNullTest() {
		VdGroupJoinMappingRequestDTO groupJoinMappingRequestDTO = null;
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();
		assertThrows(NotFound404Exception.class, ()->coreVdGrpJoinMappingServiceImpl.saveAndUpdateJoinMapping(groupJoinMappingRequestDTO, coreVdGrpJoinInfoModel));
	}
	
	@Test
	@DisplayName("updateVdGroupJoinMappingwithRequestModelNullTest method test for updating virtual dataset join mapping")
	void updateVdGroupJoinMappingwithRequestModelNullTest() {
		VdGroupJoinMappingRequestDTO groupJoinMappingRequestDTO = new VdGroupJoinMappingRequestDTO();
		groupJoinMappingRequestDTO.setJoinMappingId(UUID.randomUUID());
		groupJoinMappingRequestDTO.setSourceOneField("oneField");
		groupJoinMappingRequestDTO.setSourceTwoField("twoField");
		groupJoinMappingRequestDTO.setOrderBy((short) 1);
		groupJoinMappingRequestDTO.setOperator("EQUALS");
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = null;
		assertThrows(NotFound404Exception.class, ()->coreVdGrpJoinMappingServiceImpl.saveAndUpdateJoinMapping(groupJoinMappingRequestDTO, coreVdGrpJoinInfoModel));
	}
	
	@Test
	@DisplayName("deleteVdGrpJoinMappingTest method test for deleting ")
	void deleteVdGrpJoinMappingTest() {
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();			
		List<VdGroupJoinMappingRequestDTO> vdGroupJoinMappingRequestDTO = new ArrayList<VdGroupJoinMappingRequestDTO>();
		VdGroupJoinMappingRequestDTO groupJoinMappingRequestDTO= new VdGroupJoinMappingRequestDTO();
		groupJoinMappingRequestDTO.setJoinMappingId(UUID.randomUUID());
		vdGroupJoinMappingRequestDTO.add(groupJoinMappingRequestDTO);
		List<CoreVdGrpJoinMappingModel> coreVdGrpJoinMappingModel = new ArrayList<CoreVdGrpJoinMappingModel>();
		CoreVdGrpJoinMappingModel vdGrpJoinMappingModel=new CoreVdGrpJoinMappingModel();
		vdGrpJoinMappingModel.setUuid(UUID.randomUUID());
		coreVdGrpJoinMappingModel.add(vdGrpJoinMappingModel);
		when(coreVdGrpJoinInfoDAO.findById(any())).thenReturn(Optional.of(coreVdGrpJoinInfoModel));
		when(coreVdGrpJoinMappingDAO.findByCoreVdGrpJoinInfo(any())).thenReturn(coreVdGrpJoinMappingModel);
		coreVdGrpJoinMappingServiceImpl.deleteVdGrpJoinMapping(vdGroupJoinMappingRequestDTO,UUID.randomUUID() );
		verify(coreVdGrpJoinMappingDAO, atLeast(1)).deleteByUuidIn(any());		
	}
	
	@Test
	@DisplayName("deleteVdGrpJoinMappingwithCatchTest method test for deleting ")
	void deleteVdGrpJoinMappingwithCatchTest() {		
		List<VdGroupJoinMappingRequestDTO> vdGroupJoinMappingRequestDTO = new ArrayList<VdGroupJoinMappingRequestDTO>();
		assertThrows(Exception.class, ()-> coreVdGrpJoinMappingServiceImpl.deleteVdGrpJoinMapping(vdGroupJoinMappingRequestDTO,UUID.randomUUID()));
	}
}