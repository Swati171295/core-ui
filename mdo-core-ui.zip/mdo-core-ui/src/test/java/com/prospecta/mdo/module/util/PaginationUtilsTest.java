package com.prospecta.mdo.module.util;

import static org.junit.jupiter.api.Assertions.assertNotNull;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;

import com.nimbusds.jose.JOSEException;


@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class PaginationUtilsTest {
	
	@InjectMocks
	PaginationUtils paginationUtils;
	
	
	@Test
	@DisplayName("getValidPageTest method test for get valid pages")
	void getValidPageTest() throws JOSEException{
		
		Pageable pageable = PaginationUtils.getValidPage(null, 2);
		assertNotNull(pageable.toString());
		
		pageable = PaginationUtils.getValidPage(0, 0);
		assertNotNull(pageable.toString());
		
		pageable = PaginationUtils.getValidPage(2, 1);
		assertNotNull(pageable.toString());
		
		pageable = PaginationUtils.getValidPage(2, null);
		assertNotNull(pageable.toString());
	}
}
