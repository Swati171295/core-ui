package com.prospecta.mdo.module.dao.virtualdata;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

@ActiveProfiles("test")
@DataJpaTest
class CoreVdGroupsDaoTest {
	
	@Autowired
    private TestEntityManager entityManager;
	
	@Autowired
    private CoreVdGroupsDAO coreVdGroupsDAO;
	
	
	@DisplayName("findByCoreVdHeaderTest -> find group by vdHeader")
	@Test
	void findByCoreVdHeaderTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.flush();		
		List<CoreVdGroupsModel> actualList= coreVdGroupsDAO.findByCoreVdHeader(coreVdHeaderModel);		
		assertEquals(actualList.get(0).getCoreVdHeader().getTenantId(),coreVdHeaderModel.getTenantId(), "groupinfo found is different than expected");
	}
	
	@DisplayName("deleteByCoreVdHeaderTest -> delete group by vdHeader")
	@Test
	void deleteByCoreVdHeaderTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		entityManager.persist(coreVdHeaderModel);
		entityManager.flush();
		coreVdGroupsDAO.deleteByCoreVdHeader(coreVdHeaderModel);
		List<CoreVdGroupsModel> actualList= coreVdGroupsDAO.findByCoreVdHeader(coreVdHeaderModel);
		assertTrue(actualList.isEmpty(),"vdHeader is deleted.");
	}

}
