package com.prospecta.mdo.module.rest.grid;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.prospecta.mdo.module.component.JWTTokenProvider;
import com.prospecta.mdo.module.dto.grid.GridResponseDTO;
import com.prospecta.mdo.module.dto.grid.GridSettingRequestDTO;
import com.prospecta.mdo.module.dto.grid.GridSettingResponseDTO;
import com.prospecta.mdo.module.dto.grid.SequenceSettingRequestDTO;
import com.prospecta.mdo.module.service.grid.CoreGridService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@ActiveProfiles("Test")
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
class GridRestControllerTest {

    private static final String PAYLOAD = "{\"username\":\"Admin\",\"roles\":[],\"tenantCode\":\"0\"}";
    @MockBean
    CoreGridService coreGridService;
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private JWTTokenProvider jWTTokenProvider;

    @Test
    @DisplayName("Test case for Save Grid Test controller method to Save/Update Grid Settings")
    @WithMockUser
    void createGridSetting() throws Exception{

        String token = jWTTokenProvider.createToken(PAYLOAD);

        GridSettingRequestDTO requestDTO =new GridSettingRequestDTO();
        requestDTO.setFieldId("FLD_122");
        requestDTO.setIsDisplayOnly(true);
        requestDTO.setIsHide(true);
        requestDTO.setOrder(Byte.parseByte("1"));
        List<GridSettingRequestDTO> list=new ArrayList<>(){{add(requestDTO);}};

        GridResponseDTO responseDTO=new GridResponseDTO();
        responseDTO.setAcknowledge(true);

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String json=ow.writeValueAsString(list);

        when(coreGridService.saveUpdateGridSetting(any(),any(),any(),any())).thenReturn(responseDTO);

        this.mockMvc.perform(put("/grid/gridfield/{moduleId}/save-or-update-grid-setting", 1L)
                .param("fieldId","FLD_123")
                .header("authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON).content(json)).andExpect(status().isCreated());
    }

    @Test
    @DisplayName("Test case for Get Grid Test controller method to Get Grid Settings")
    @WithMockUser
    void getGrid() throws Exception{

        String token = jWTTokenProvider.createToken(PAYLOAD);

        GridSettingResponseDTO responseDTO = new GridSettingResponseDTO();
        responseDTO.setGridFieldId("FLD_125");
        List<GridSettingResponseDTO> list = Collections.singletonList(responseDTO);

        when(coreGridService.getGridSetting(1L, "FLD_125", "0")).thenReturn(list);

        this.mockMvc.perform(get("/grid/{moduleId}/get-grid-setting", 1L)
                .param("fieldId", "FLD_125")
                .header("authorization", "Bearer " + token)).andExpect(status().isOk());
    }

    @Test
    @DisplayName("Test case for Get Sortable Grid fields")
    @WithMockUser
    void getSortableGrid() throws Exception{

        String token = jWTTokenProvider.createToken(PAYLOAD);

        when(coreGridService.getSortableGridFields(1L, "FLD_125", "",1,1,"en","0")).thenReturn(new ArrayList<>());

        this.mockMvc.perform(get("/grid/{moduleId}/get-sort-grid-fields/{language}", 1L,"en")
                .param("gridFieldId", "FLD_125")
                .param("searchTerm","")
                .param("fetchCount","1")
                .param("fetchSize","1")
                .header("authorization", "Bearer " + token)).andExpect(status().isOk());


    }

    @Test
    @DisplayName("Test case for Get sequence fields")
    @WithMockUser
    void getSequenceGrid() throws Exception{

        String token = jWTTokenProvider.createToken(PAYLOAD);

        when(coreGridService.getSequenceGridFields(1L, "FLD_125", "",1,1,"en","0")).thenReturn(new ArrayList<>());

        this.mockMvc.perform(get("/grid/{moduleId}/get-sequence-grid-fields/{language}", 1L,"en")
                .param("gridFieldId", "FLD_125")
                .param("searchTerm","")
                .param("fetchCount","1")
                .param("fetchSize","1")
                .header("authorization", "Bearer " + token)).andExpect(status().isOk());


    }

    @Test
    @DisplayName("Test case for Save update Sequence Setting")
    @WithMockUser
    void saveSequenceSetting() throws Exception{

        String token = jWTTokenProvider.createToken(PAYLOAD);

        List<SequenceSettingRequestDTO> dtoList = new ArrayList<>();

        SequenceSettingRequestDTO dto = new SequenceSettingRequestDTO();

        dtoList.add(dto);

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);

        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String json=ow.writeValueAsString(dtoList);

        when(coreGridService.saveUpdateSequenceSetting(dtoList, 1L,"0")).thenReturn(new GridResponseDTO());

        this.mockMvc.perform(put("/grid/{moduleId}/save-update-sequence-setting", 1L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .header("authorization", "Bearer " + token)).andExpect(status().isCreated());


    }
}
