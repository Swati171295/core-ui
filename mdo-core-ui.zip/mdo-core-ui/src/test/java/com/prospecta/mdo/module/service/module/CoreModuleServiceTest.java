/**
 * 
 */
package com.prospecta.mdo.module.service.module;

import com.prospecta.mdo.module.dao.metadata.CoreMetadataDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataLangDAO;
import com.prospecta.mdo.module.dao.module.CoreModuleDAO;
import com.prospecta.mdo.module.dao.module.CoreModuleDescriptionDAO;
import com.prospecta.mdo.module.dao.module.CoreStructureDAO;
import com.prospecta.mdo.module.dao.module.CoreSubModuleDao;
import com.prospecta.mdo.module.dto.module.*;
import com.prospecta.mdo.module.exception.GRPCException;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.grpc.DynamicCrudGenerationImpl;
import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;
import com.prospecta.mdo.module.model.module.CoreModuleDescriptionModel;
import com.prospecta.mdo.module.model.module.CoreModuleModel;
import com.prospecta.mdo.module.model.module.CoreStructureModel;
import com.prospecta.mdo.module.model.module.CoreSubModuleModel;
import com.prospecta.mdo.module.service.layout.CoreLayoutHeaderService;
import com.prospecta.mdo.module.service.metadata.CoreMetadataService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * @author savan
 *
 */
@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
public class CoreModuleServiceTest {

	@InjectMocks
	private CoreModuleServiceImpl coreModuleServiceImpl;
	
	@Mock
	private CoreModuleDAO coreModuleDAO;
	
	@Mock
	private CoreModuleDescriptionDAO coreModuleDescriptionDAO;
	
	@Mock
	private CoreMetadataLangDAO coreMetadataLangDAO;
	
	@Mock
	private CoreMetadataDAO coreMetadataDAO;
	
	@Mock
	private CoreStructureDAO coreStructureDAO;
	
	@Mock
	private CoreLayoutHeaderService coreLayoutHeaderService;

	@Mock
	private CoreSubModuleDao coreSubModuleDao;

	@Mock
	private DynamicCrudGenerationImpl generationImpl;

	@Mock
	private CoreMetadataService service;
	
	@BeforeAll
	public void init() {
		coreModuleServiceImpl = new CoreModuleServiceImpl();
	}
	
	@Test
	@DisplayName("saveModelTest method to test the creation of the module")
	public void saveModelTest() {
		
		String tenantCode = "0";
		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);
		
		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");
		
		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");

		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setModuledescription(moduledescription);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();
		
		FieldsRequestDTO fieldsRequestDTO = new FieldsRequestDTO();
		fieldsRequestDTO.setStructureid("1");
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("1");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("1");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		fieldlist.add(fieldDTO);
		
		fieldsRequestDTO.setFieldlist(fieldlist);
		
		fields.add(fieldsRequestDTO);
		
		requestDTO.setFields(fields);
		
		CoreModuleModel coreModule = new CoreModuleModel();
		coreModule.setModuleId(1L);
		
		List<CoreModuleDescriptionModel> list = new ArrayList<>();
		Iterable<CoreModuleDescriptionModel> iterableList = list;
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		Iterable<CoreMetadataModel> iterablemetadatalist = metadatalist;
		
		List<CoreMetadataLangModel> CoreMetadataLanglist = new ArrayList<>();
		Iterable<CoreMetadataLangModel> iterablCoreMetadataLanglist = CoreMetadataLanglist;
		List<Long> parentModuleIds = new ArrayList<>();
		parentModuleIds.add(1l);
		parentModuleIds.add(2l);
		parentModuleIds.stream().forEach(id -> {
			CoreSubModuleModel coreSubModuleModel = new CoreSubModuleModel();
			coreSubModuleModel.setModuleId(1l);
			coreSubModuleModel.setUuid(UUID.randomUUID());
			coreSubModuleModel.setParentModuleId(id);
		});
		when(coreModuleDAO.save(any())).thenReturn(coreModule);
		when(coreModuleDescriptionDAO.saveAll(any())).thenReturn(iterableList);
		when(coreStructureDAO.save(any())).thenReturn(new CoreStructureModel());
		when(coreMetadataDAO.saveAll(any())).thenReturn(iterablemetadatalist);
		when(coreMetadataLangDAO.saveAll(any())).thenReturn(iterablCoreMetadataLanglist);
		
		
		ModuleResponseDTO responseDTO = coreModuleServiceImpl.saveModel(requestDTO, tenantCode);
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreModuleDAO,atLeast(1)).save(any());
		verify(coreModuleDescriptionDAO,atLeast(1)).saveAll(any());
		verify(coreStructureDAO,atLeast(1)).save(any());
		verify(coreMetadataLangDAO,atLeast(1)).saveAll(any());
		verify(coreMetadataDAO,atLeast(2)).saveAll(any());
	}
	
	@Test
	@DisplayName("saveModelTest1 method to test if structure id is null")
	public void saveModelTest1() {
		
		String tenantCode = "0";

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");

		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");


		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");

		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setModuledescription(moduledescription);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();
		
		FieldsRequestDTO fieldsRequestDTO = new FieldsRequestDTO();
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("1");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("1");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		fieldlist.add(fieldDTO);
		
		fieldsRequestDTO.setFieldlist(fieldlist);
		
		fields.add(fieldsRequestDTO);
		
		requestDTO.setFields(fields);
		
		CoreModuleModel coreModule = new CoreModuleModel();
		coreModule.setModuleId(1L);
		
		List<CoreModuleDescriptionModel> list = new ArrayList<>();
		Iterable<CoreModuleDescriptionModel> iterableList = list;
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		Iterable<CoreMetadataModel> iterablemetadatalist = metadatalist;
		
		List<CoreMetadataLangModel> CoreMetadataLanglist = new ArrayList<>();
		Iterable<CoreMetadataLangModel> iterablCoreMetadataLanglist = CoreMetadataLanglist;
		
		when(coreModuleDAO.save(any())).thenReturn(coreModule);
		when(coreModuleDescriptionDAO.saveAll(any())).thenReturn(iterableList);
		when(coreStructureDAO.save(any())).thenReturn(new CoreStructureModel());
		when(coreMetadataDAO.saveAll(any())).thenReturn(iterablemetadatalist);
		when(coreMetadataLangDAO.saveAll(any())).thenReturn(iterablCoreMetadataLanglist);
		
		
		ModuleResponseDTO responseDTO = coreModuleServiceImpl.saveModel(requestDTO, tenantCode);
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreModuleDAO,atLeast(1)).save(any());
		verify(coreModuleDescriptionDAO,atLeast(1)).saveAll(any());
		verify(coreStructureDAO,atLeast(1)).save(any());
		verify(coreMetadataLangDAO,atLeast(1)).saveAll(any());
		verify(coreMetadataDAO,atLeast(2)).saveAll(any());
	}
	
	@Test
	@DisplayName("saveModelTest2 method to test if structure id is empty")
	public void saveModelTest2() {
		
		String tenantCode = "0";

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");

		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setModuledescription(moduledescription);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();
		
		FieldsRequestDTO fieldsRequestDTO = new FieldsRequestDTO();
		fieldsRequestDTO.setStructureid("");
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("1");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("1");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		fieldlist.add(fieldDTO);
		
		fieldsRequestDTO.setFieldlist(fieldlist);
		
		fields.add(fieldsRequestDTO);
		
		requestDTO.setFields(fields);
		
		CoreModuleModel coreModule = new CoreModuleModel();
		coreModule.setModuleId(1L);
		
		List<CoreModuleDescriptionModel> list = new ArrayList<>();
		Iterable<CoreModuleDescriptionModel> iterableList = list;
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		Iterable<CoreMetadataModel> iterablemetadatalist = metadatalist;
		
		List<CoreMetadataLangModel> CoreMetadataLanglist = new ArrayList<>();
		Iterable<CoreMetadataLangModel> iterablCoreMetadataLanglist = CoreMetadataLanglist;
		
		when(coreModuleDAO.save(any())).thenReturn(coreModule);
		when(coreModuleDescriptionDAO.saveAll(any())).thenReturn(iterableList);
		when(coreStructureDAO.save(any())).thenReturn(new CoreStructureModel());
		when(coreMetadataDAO.saveAll(any())).thenReturn(iterablemetadatalist);
		when(coreMetadataLangDAO.saveAll(any())).thenReturn(iterablCoreMetadataLanglist);
		
		
		ModuleResponseDTO responseDTO = coreModuleServiceImpl.saveModel(requestDTO, tenantCode);
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreModuleDAO,atLeast(1)).save(any());
		verify(coreModuleDescriptionDAO,atLeast(1)).saveAll(any());
		verify(coreStructureDAO,atLeast(1)).save(any());
		verify(coreMetadataLangDAO,atLeast(1)).saveAll(any());
		verify(coreMetadataDAO,atLeast(2)).saveAll(any());
	}
	
	@Test
	@DisplayName("saveModelTest3 method to test Exception handaling")
	public void saveModelTest3() {
		
		String tenantCode = "0";

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");

		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setModuledescription(moduledescription);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();
		
		FieldsRequestDTO fieldsRequestDTO = new FieldsRequestDTO();
		fieldsRequestDTO.setStructureid("1");
		
		List<FieldDTO> fieldlist = new ArrayList<FieldDTO>();
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		fieldlist.add(fieldDTO);
		
		fieldsRequestDTO.setFieldlist(fieldlist);
		
		fields.add(fieldsRequestDTO);
		
		requestDTO.setFields(fields);
		
		CoreModuleModel coreModule = new CoreModuleModel();
		coreModule.setModuleId(1L);
		
		when(coreModuleDAO.save(any())).thenThrow(new RuntimeException());
		
		ModuleResponseDTO responseDTO = coreModuleServiceImpl.saveModel(requestDTO, tenantCode);
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreModuleDAO,atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("constructLangDataTest method to test if help text is null")
	public void constructLangDataTest() {
		
		String tenantCode = "0";

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		
		List<CoreMetadataLangModel> CoreMetadataLanglist = new ArrayList<>();
		Iterable<CoreMetadataLangModel> iterablCoreMetadataLanglist = CoreMetadataLanglist;
		
		when(coreMetadataLangDAO.saveAll(any())).thenReturn(iterablCoreMetadataLanglist);
		
		coreModuleServiceImpl.constructLangData(tenantCode, fieldDTO,1L);
		
		verify(coreMetadataLangDAO,atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("constructLangDataTest1 method to test if help text is empty")
	public void constructLangDataTest1() {
		
		String tenantCode = "0";

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		
		List<CoreMetadataLangModel> CoreMetadataLanglist = new ArrayList<>();
		Iterable<CoreMetadataLangModel> iterablCoreMetadataLanglist = CoreMetadataLanglist;
		
		when(coreMetadataLangDAO.saveAll(any())).thenReturn(iterablCoreMetadataLanglist);
		
		coreModuleServiceImpl.constructLangData(tenantCode, fieldDTO,1L);
		
		verify(coreMetadataLangDAO,atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("constructLangDataTest2 method to test if long text is null")
	public void constructLangDataTest2() {
		
		String tenantCode = "0";

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");


		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		
		List<CoreMetadataLangModel> CoreMetadataLanglist = new ArrayList<>();
		Iterable<CoreMetadataLangModel> iterablCoreMetadataLanglist = CoreMetadataLanglist;
		
		when(coreMetadataLangDAO.saveAll(any())).thenReturn(iterablCoreMetadataLanglist);
		
		coreModuleServiceImpl.constructLangData(tenantCode, fieldDTO,1L);
		
		verify(coreMetadataLangDAO,atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("constructLangDataTest3 method to test if long text is empty")
	public void constructLangDataTest3() {
		
		String tenantCode = "0";

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		
		List<CoreMetadataLangModel> CoreMetadataLanglist = new ArrayList<>();
		Iterable<CoreMetadataLangModel> iterablCoreMetadataLanglist = CoreMetadataLanglist;
		
		when(coreMetadataLangDAO.saveAll(any())).thenReturn(iterablCoreMetadataLanglist);
		
		coreModuleServiceImpl.constructLangData(tenantCode, fieldDTO,1L);
		
		verify(coreMetadataLangDAO,atLeast(1)).saveAll(any());
	}
	
	
	@Test
	@DisplayName("saveModuleFieldsTest method to validate field list size")
	public void saveModuleFieldsTest() {
		
		String tenantCode = "0";
		
		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");
		
		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setModuledescription(moduledescription);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");
		
		List<FieldsRequestDTO> fields = new ArrayList<FieldsRequestDTO>();
		
		FieldsRequestDTO fieldsRequestDTO = new FieldsRequestDTO();
		fieldsRequestDTO.setStructureid("1");
		
		List<FieldDTO> fieldlist = mock(List.class);
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		fieldlist.add(fieldDTO);
		
		fieldsRequestDTO.setFieldlist(fieldlist);
		
		fields.add(fieldsRequestDTO);
		
		requestDTO.setFields(fields);
		
		CoreModuleModel coreModule = new CoreModuleModel();
		coreModule.setModuleId(1L);
		
		when(fieldlist.size()).thenReturn(101);
		assertThrows(RuntimeException.class, ()-> coreModuleServiceImpl.saveModuleFields(requestDTO, coreModule.getModuleId(), tenantCode, tenantCode));
	}
	
	@Test
	@DisplayName("saveFieldTest method to test save the field for the module")
	public void saveFieldTest() {

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("1");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRI");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("1");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		CoreStructureModel structure = new CoreStructureModel();
		structure.setStructureId((short) 1);
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		Iterable<CoreMetadataModel> iterablemetadatalist = metadatalist;
		
		when(coreStructureDAO.findTopByModuleIdOrderByStructureIdDesc(any())).thenReturn(structure);
		when(coreMetadataDAO.countByModuleId(any())).thenReturn(501L);
		when(coreMetadataDAO.save(any())).thenReturn(new CoreMetadataModel());
		when(coreMetadataDAO.saveAll(any())).thenReturn(iterablemetadatalist);
		
		FieldResponseDTO responseDTO = coreModuleServiceImpl.saveField(fieldDTO, String.valueOf(0), 1L);
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreStructureDAO,atLeast(1)).findTopByModuleIdOrderByStructureIdDesc(any());
		verify(coreMetadataDAO,atLeast(1)).countByModuleId(any());
		verify(coreMetadataDAO,atLeast(1)).save(any());
		verify(coreMetadataDAO,atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("saveFieldTest1 method to test if structure is not available for the moduleId")
	public void saveFieldTest1() {

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("15");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("15");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		
		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		when(coreStructureDAO.findTopByModuleIdOrderByStructureIdDesc(any())).thenReturn(null);

		FieldResponseDTO responseDTO = coreModuleServiceImpl.saveField(fieldDTO, String.valueOf(0), 1L);
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreStructureDAO,atLeast(1)).findTopByModuleIdOrderByStructureIdDesc(any());
	}
	
	@Test
	@DisplayName("saveFieldTest2 method to test save the field for the module into same structure")
	public void saveFieldTest2() {

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		Map<String, String> longtext = new HashMap<>();
		longtext.put("en", "Material");
		longtext.put("fr", "matériel");
		longtext.put("cz", "Typ materiálu");
		longtext.put("sp", "tipo de material");

		Map<String, String> helptext = new HashMap<>();
		helptext.put("en", "Material");
		helptext.put("fr", "matériel");
		helptext.put("sp", "tipo de material");
		helptext.put("gj", "tipo de material");
		
		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId("LANGUAGEGRID");
		fieldDTO.setShortText(moduledescription);
		fieldDTO.setLongtexts(longtext);
		fieldDTO.setHelptexts(helptext);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		fieldDTO.setExistingKey(false);
		fieldDTO.setIsKeyField(false);

		
		ChildFieldsDTO childDTO = new ChildFieldsDTO(); 
		childDTO.setFieldId("LANGUAGE");
		childDTO.setShortText(moduledescription);
		childDTO.setLongtexts(longtext);
		childDTO.setHelptexts(helptext);
		childDTO.setDataType("GRID");
		childDTO.setPickList("1");
		childDTO.setMaxChar(200L);
		childDTO.setIsGridColumn(true);
		childDTO.setParentField("LANGUAGEGRID");
		childDTO.setIsSubGrid(false);
		
		ChildFieldsDTO childDTO1 = new ChildFieldsDTO(); 
		childDTO1.setFieldId("DESCRIPTION");
		childDTO1.setShortText(moduledescription);
		childDTO1.setLongtexts(longtext);
		childDTO1.setHelptexts(helptext);
		childDTO1.setDataType("GRID");
		childDTO1.setPickList("1");
		childDTO1.setMaxChar(200L);
		childDTO1.setIsGridColumn(true);
		childDTO1.setParentField("LANGUAGEGRID");
		childDTO1.setIsSubGrid(false);


		List<ChildFieldsDTO> childList = new ArrayList<ChildFieldsDTO>();
		childList.add(childDTO);
		childList.add(childDTO1);
		
		fieldDTO.setChildfields(childList);
		
		CoreStructureModel structure = new CoreStructureModel();
		structure.setStructureId((short) 1);
		
		List<CoreMetadataModel> metadatalist = new ArrayList<>();
		Iterable<CoreMetadataModel> iterablemetadatalist = metadatalist;
		
		when(coreStructureDAO.findTopByModuleIdOrderByStructureIdDesc(any())).thenReturn(structure);
		when(coreMetadataDAO.countByModuleId(any())).thenReturn(500L);
		when(coreMetadataDAO.save(any())).thenReturn(new CoreMetadataModel());
		when(coreMetadataDAO.saveAll(any())).thenReturn(iterablemetadatalist);
		
		FieldResponseDTO responseDTO = coreModuleServiceImpl.saveField(fieldDTO, String.valueOf(0), 1L);
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreStructureDAO,atLeast(1)).findTopByModuleIdOrderByStructureIdDesc(any());
		verify(coreMetadataDAO,atLeast(1)).countByModuleId(any());
		verify(coreMetadataDAO,atLeast(1)).save(any());
		verify(coreMetadataDAO,atLeast(1)).saveAll(any());
	}
	
	@Test
	@DisplayName("getFieldsWithStructureTest method test to get all available fields related to structureid ")
	public void getFieldsWithStructureTest() {
		
		List<String> fields = new ArrayList<String>();
		fields.add("fieldId1");
		
		Pageable pageable = PageRequest.of(0, 10);
		
		when(coreMetadataDAO.findByStructureIdAndModuleIdAndTenantId((short)1, 1L, "0", pageable)).thenReturn(fields);
		
		FieldIdsWithStructureResponseDTO responseDTO = coreModuleServiceImpl.getFieldsWithStructure("1", 1L, "en", "0", "10", "0");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).findByStructureIdAndModuleIdAndTenantId((short)1, 1L, "0", pageable);
	}
	
	@Test
	@DisplayName("getFieldsWithStructureTest1 method test no fieldIds available ")
	public void getFieldsWithStructureTest1() {
		
Pageable pageable = PageRequest.of(0, 10);
		
		when(coreMetadataDAO.findByStructureIdAndModuleIdAndTenantId((short)1, 1L, "0", pageable)).thenReturn(null);
		
		FieldIdsWithStructureResponseDTO responseDTO = coreModuleServiceImpl.getFieldsWithStructure("1", 1L, "en", "0", "10", "0");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).findByStructureIdAndModuleIdAndTenantId((short)1, 1L, "0", pageable);
	}
	
	@Test
	@DisplayName("getFieldsWithStructureTest2 method test if list is empty ")
	public void getFieldsWithStructureTest2() {
		
		List<String> fields = new ArrayList<String>();
		
		Pageable pageable = PageRequest.of(0, 10);
		
		when(coreMetadataDAO.findByStructureIdAndModuleIdAndTenantId((short)1, 1L, "0", pageable)).thenReturn(fields);
		
		FieldIdsWithStructureResponseDTO responseDTO = coreModuleServiceImpl.getFieldsWithStructure("1", 1L, "en", "0", "10", "0");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).findByStructureIdAndModuleIdAndTenantId((short)1, 1L, "0", pageable);
	}
	
	@Test
	@DisplayName("getFieldsWithStructureTest3 method test for exception check ")
	public void getFieldsWithStructureTest3() {
		
		Pageable pageable = PageRequest.of(0, 10);
		
		when(coreMetadataDAO.findByStructureIdAndModuleIdAndTenantId((short)1, 1L, "0", pageable)).thenThrow(new RuntimeException());
		
		FieldIdsWithStructureResponseDTO responseDTO = coreModuleServiceImpl.getFieldsWithStructure("1", 1L, "en", "0", "10", "0");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).findByStructureIdAndModuleIdAndTenantId((short)1, 1L, "0", pageable);
	}
	
	@Test
	@DisplayName("getAllPicklistFieldsTest method test for Get All fieldId, MaxChar and shorttext based on pickList and searched description and Language")
	public void getAllPicklistFieldsTest() {
		
		List<Map<String,Object>> fields = new ArrayList<Map<String,Object>>();
		
		Map<String,Object> fieldObject = new HashMap<String, Object>();
		fieldObject.put("keay", new Object());

		fields.add(fieldObject);
		
		when(coreMetadataDAO.getpicklistFields(any(), any(), any(), any(), any(), any())).thenReturn(fields);

		PicklistFieldsRequestDTO picklistFieldsRequestDTO = new PicklistFieldsRequestDTO();
		picklistFieldsRequestDTO.setPickList("test");
		PickListFieldsResponseDTO responseDTO = coreModuleServiceImpl.getAllPicklistFields(picklistFieldsRequestDTO, 1L, "en", "0", "10", "0");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).getpicklistFields(any(), any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("getAllPicklistFieldsTest1 method test if no pickLists are available")
	public void getAllPicklistFieldsTest1() {
		
		when(coreMetadataDAO.getpicklistFields(any(), any(), any(), any(), any(), any())).thenReturn(null);

		PicklistFieldsRequestDTO picklistFieldsRequestDTO = new PicklistFieldsRequestDTO();
		picklistFieldsRequestDTO.setPickList("test");
		PickListFieldsResponseDTO responseDTO = coreModuleServiceImpl.getAllPicklistFields(picklistFieldsRequestDTO, 1L, "en", "0", "10", "0");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).getpicklistFields(any(), any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("getAllPicklistFieldsTest2 method test if list is empty")
	public void getAllPicklistFieldsTest2() {
		
		List<Map<String,Object>> fields = new ArrayList<Map<String,Object>>();
		
		when(coreMetadataDAO.getpicklistFields(any(), any(), any(), any(), any(), any())).thenReturn(fields);
		PicklistFieldsRequestDTO picklistFieldsRequestDTO = new PicklistFieldsRequestDTO();
		picklistFieldsRequestDTO.setPickList("test");
		PickListFieldsResponseDTO responseDTO = coreModuleServiceImpl.getAllPicklistFields(picklistFieldsRequestDTO, 1L, "en", "0", "10", "0");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).getpicklistFields(any(), any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("getAllPicklistFieldsTest3 method test for exception handling")
	public void getAllPicklistFieldsTest3() {
		
		when(coreMetadataDAO.getpicklistFields(any(), any(), any(), any(), any(), any())).thenThrow(new RuntimeException());

		PicklistFieldsRequestDTO picklistFieldsRequestDTO = new PicklistFieldsRequestDTO();
		picklistFieldsRequestDTO.setPickList("test");
		PickListFieldsResponseDTO responseDTO = coreModuleServiceImpl.getAllPicklistFields(picklistFieldsRequestDTO, 1L, "en", "0", "10", "0");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).getpicklistFields(any(), any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("getAllDataTypefieldsTest method test for Get All fieldId, MaxChar, DataType, pickList, structureId and shortText based on dataType and searched description and Language")
	public void getAllDataTypefieldsTest() {
		
		List<Map<String,Object>> fields = new ArrayList<Map<String,Object>>();
		
		Map<String,Object> fieldObject = new HashMap<String, Object>();
		fieldObject.put("keay", new Object());

		fields.add(fieldObject);
		
		when(coreMetadataDAO.getDataTypeFields(any(), any(), any(), any(), any(), any())).thenReturn(fields);

		DataTypeFieldsResponseDTO responseDTO = coreModuleServiceImpl.getAllDataTypefields(new DataTypeFieldsRequestDTO(), 1L, "en", "0", "10", "0");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).getDataTypeFields(any(), any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("getAllDataTypefieldsTest1 method test if no datatype fields are available")
	public void getAllDataTypefieldsTest1() {
		
		when(coreMetadataDAO.getDataTypeFields(any(), any(), any(), any(), any(), any())).thenReturn(null);

		DataTypeFieldsResponseDTO responseDTO = coreModuleServiceImpl.getAllDataTypefields(new DataTypeFieldsRequestDTO(), 1L, "en", "0", "10", "0");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).getDataTypeFields(any(), any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("getAllDataTypefieldsTest2 method test if list is empty")
	public void getAllDataTypefieldsTest2() {
		
		List<Map<String,Object>> fields = new ArrayList<Map<String,Object>>();
		
		when(coreMetadataDAO.getDataTypeFields(any(), any(), any(), any(), any(), any())).thenReturn(fields);

		DataTypeFieldsResponseDTO responseDTO = coreModuleServiceImpl.getAllDataTypefields(new DataTypeFieldsRequestDTO(), 1L, "en", "0", "10", "0");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).getDataTypeFields(any(), any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("getAllDataTypefieldsTest3 method test for exception handling")
	public void getAllDataTypefieldsTest3() {
		
		when(coreMetadataDAO.getDataTypeFields(any(), any(), any(), any(), any(), any())).thenThrow(new RuntimeException());

		DataTypeFieldsResponseDTO responseDTO = coreModuleServiceImpl.getAllDataTypefields(new DataTypeFieldsRequestDTO(), 1L, "en", "0", "10", "0");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreMetadataDAO,atLeast(1)).getDataTypeFields(any(), any(), any(), any(), any(), any());
	}
	
	@Test
	@DisplayName("updateModuleDescriptionTest methos to test update module description")
	public void updateModuleDescriptionTest() {

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);
		
		CoreModuleModel moduleModel = new CoreModuleModel();
		moduleModel.setModuleId(1L);
		
		when(coreModuleDAO.findByModuleIdAndTenantId(1L, "0")).thenReturn(moduleModel);
		doNothing().when(coreModuleDescriptionDAO).deleteByModuleIdAndTenantId(1L, "0");
		
		ModuleResponseDTO responseDTO = coreModuleServiceImpl.updateModuleDescription(moduledescription, "0", 1L);
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreModuleDAO,atLeast(1)).findByModuleIdAndTenantId(1L, "0");
		verify(coreModuleDescriptionDAO,atLeast(1)).deleteByModuleIdAndTenantId(1L, "0");
	}
	
	@Test
	@DisplayName("updateModuleDescriptionTest1 method to test exception handling")
	public void updateModuleDescriptionTest1() {

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");

		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		moduledescription.put("jr", jrData);

		CoreModuleModel moduleModel = new CoreModuleModel();
		moduleModel.setModuleId(1L);
		
		when(coreModuleDAO.findByModuleIdAndTenantId(1L, "0")).thenReturn(null);
		
		ModuleResponseDTO responseDTO = coreModuleServiceImpl.updateModuleDescription(moduledescription, "0", 1L);
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreModuleDAO,atLeast(1)).findByModuleIdAndTenantId(1L, "0");
	}
	
	@Test
	@DisplayName("getAllFieldsByStructureTest method is used to test fetching all available metadata fields")
	public void getAllFieldsByStructureTest() {
		
		Pageable pageable = PageRequest.of(0, 10);
		
		List<Object> objectList = new ArrayList<>();
		
		Object[] arr = new Object[2];
		
		CoreMetadataModel model = new CoreMetadataModel();
		model.setFieldId("FieldId");
		
		CoreMetadataLangModel landModel = new CoreMetadataLangModel();
		
		arr[0] = model;
		arr[1] = landModel;
		
		objectList.add(arr);

        CoreModuleDescriptionModel descriptionModel = new CoreModuleDescriptionModel();
        descriptionModel.setDescription("test");
        descriptionModel.setModuleId(1L);
        descriptionModel.setInformation("info");
        descriptionModel.setLanguage("en");


		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		metadataFields.add(model);
		
		when(coreMetadataDAO.findAllFieldsByStructure(Short.parseShort("1"), 1L, "0", "en", pageable))
		        .thenReturn(objectList);
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndParentField(1L, "0", "FieldId")).thenReturn(metadataFields);

		when(coreLayoutHeaderService.generateMetadata(any(), any(), any(), any())).thenReturn(new FieldDTO());
		
		List<FieldDTO> response = coreModuleServiceImpl.getAllFieldsByStructure(1L, "en", "1", "0", "10", "0");
		
		assertNotNull(response);
		
		verify(coreMetadataDAO, atLeast(1)).findAllFieldsByStructure(Short.parseShort("1"), 1L, "0", "en", pageable);
		verify(coreMetadataDAO, atLeast(1)).findByModuleIdAndTenantIdAndParentField(1L, "0", "FieldId");
		verify(coreLayoutHeaderService, atLeast(1)).generateMetadata(any(), any(), any(), any());
		
	}
	
	@Test
	@DisplayName("getAllFieldsByStructureTest1 method is used to test exception handling")
	public void getAllFieldsByStructureTest1() {
		
		Pageable pageable = PageRequest.of(0, 10);
		
		when(coreMetadataDAO.findAllFieldsByStructure(Short.parseShort("1"), 1L, "0", "en", pageable)).thenReturn(null);
		
		List<FieldDTO> response = coreModuleServiceImpl.getAllFieldsByStructure(1L, "en", "1", "0", "10", "0");
		
		assertNotNull(response);
		
		verify(coreMetadataDAO, atLeast(1)).findAllFieldsByStructure(Short.parseShort("1"), 1L, "0", "en", pageable);
	}
	
	@Test
	@DisplayName("getAllModulesTest is musedto test for getting List of all Modules")
	public void getAllModulesTest() {
		
		Pageable pageable = PageRequest.of(0, 10);
		
		List<Object> moduleList = new ArrayList<>();
		
		Object[] arr = new Object[2];
		
		CoreModuleModel module = new CoreModuleModel();
		
		CoreModuleDescriptionModel moduleDescriptionn = new CoreModuleDescriptionModel();
		moduleDescriptionn.setLanguage("en");
		moduleDescriptionn.setDescription("Description");
		
		arr[0] = module;
		arr[1] = moduleDescriptionn;
		
		moduleList.add(arr);
		
		when(coreModuleDAO.getAllModulesByTenantCode("0", "en", pageable)).thenReturn(moduleList);
		
		List<CoreModuleModel> response = coreModuleServiceImpl.getAllModules("en", "0", "10", "0");
		
		assertNotNull(response);
		
		verify(coreModuleDAO, atLeast(1)).getAllModulesByTenantCode("0", "en", pageable);
	}
	
	@Test
	@DisplayName("getAllModulesTest1 is musedto test for Exception handaling")
	public void getAllModulesTest1() {
		
		Pageable pageable = PageRequest.of(0, 10);
		
		when(coreModuleDAO.getAllModulesByTenantCode("0", "en", pageable)).thenThrow(new RuntimeException());
		
		List<CoreModuleModel> response = coreModuleServiceImpl.getAllModules("en", "0", "10", "0");
		
		assertNotNull(response);
		
		verify(coreModuleDAO, atLeast(1)).getAllModulesByTenantCode("0", "en", pageable);
	}
	
	@Test
	@DisplayName("getModuleTreeTest method to test generating module Tree based on the serch description.")
	public void getModuleTreeTest() {
		
		List<CoreModuleDescriptionModel> moduleDescriptionList = new ArrayList<>();
		
		CoreModuleDescriptionModel description = new CoreModuleDescriptionModel();
		description.setModuleId(1L);
		description.setTenantId("0");
		
		moduleDescriptionList.add(description);
		
		when(coreModuleDescriptionDAO.findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%")).thenReturn(moduleDescriptionList);
		when(coreModuleDAO.findByModuleIdAndTenantId(1L, "0")).thenReturn(new CoreModuleModel());
		
		List<ModuleTreeDTO> response = coreModuleServiceImpl.getModuleTree("en", "De", "0");
		
		assertNotNull(response);
		
		verify(coreModuleDescriptionDAO, atLeast(1)).findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%");
		verify(coreModuleDAO, atLeast(1)).findByModuleIdAndTenantId(1L, "0");
	}

	
	@Test
	@DisplayName("getModuleTreeTest1 method to test if serch text is not found in module description.")
	public void getModuleTreeTest1() {
		
		List<CoreMetadataLangModel> metadataLang = new ArrayList<>();
		
		CoreMetadataLangModel description = new CoreMetadataLangModel();
		description.setFieldId("fieldId");
		
		metadataLang.add(description);
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldId");
		metadataModel1.setParentField("fieldId");
		
		metadataFields.add(metadataModel);
		metadataFields.add(metadataModel1);
		
		FieldDTO fieldDto = new FieldDTO();
		fieldDto.setModuleId(1L);
		
		FieldDTO fieldDto1 = new FieldDTO();
		fieldDto1.setModuleId(2L);
		
		CoreModuleModel module = new CoreModuleModel();
		module.setModuleId(1L);
		
		CoreModuleDescriptionModel moduleDescription = new CoreModuleDescriptionModel();
		description.setLanguage("en");
		description.setShortText("descripetion");
		
		when(coreModuleDescriptionDAO.findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%")).thenReturn(null);
		when(coreMetadataLangDAO.findByLanguageAndTenantIdAndShortTextLike("en", "0", "%De%")).thenReturn(metadataLang);
		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenReturn(metadataFields);
		when(coreLayoutHeaderService.generateMetadata(any(), any(), any(), any())).thenReturn(fieldDto);
		when(coreLayoutHeaderService.generateMetadata(any(), any(), any(), any())).thenReturn(fieldDto1);
		when(coreModuleDAO.findByModuleIdAndTenantId(2L, "0")).thenReturn(module);
		when(coreModuleDescriptionDAO.findByModuleIdAndTenantIdAndLanguage(1L, "0", "en")).thenReturn(moduleDescription);
		
		List<ModuleTreeDTO> response = coreModuleServiceImpl.getModuleTree("en", "De", "0");
		
		assertNotNull(response);
		
		verify(coreModuleDescriptionDAO, atLeast(1)).findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%");
		verify(coreMetadataLangDAO, atLeast(1)).findByLanguageAndTenantIdAndShortTextLike("en", "0", "%De%");
		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId");
		verify(coreLayoutHeaderService, atLeast(2)).generateMetadata(any(), any(), any(), any());
		verify(coreModuleDAO, atLeast(1)).findByModuleIdAndTenantId(2L, "0");
		verify(coreModuleDescriptionDAO, atLeast(1)).findByModuleIdAndTenantIdAndLanguage(1L, "0", "en");
	}
	
	@Test
	@DisplayName("getModuleTreeTest2 method to test if field parent field is null")
	public void getModuleTreeTest2() {
		
		List<CoreMetadataLangModel> metadataLang = new ArrayList<>();
		
		CoreMetadataLangModel description = new CoreMetadataLangModel();
		description.setFieldId("fieldId");
		
		metadataLang.add(description);
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldId");
		metadataModel1.setParentField(null);
		
		metadataFields.add(metadataModel);
		metadataFields.add(metadataModel1);
		
		FieldDTO fieldDto = new FieldDTO();
		fieldDto.setModuleId(1L);
		
		FieldDTO fieldDto1 = new FieldDTO();
		fieldDto1.setModuleId(2L);
		
		CoreModuleModel module = new CoreModuleModel();
		module.setModuleId(1L);
		
		CoreModuleDescriptionModel moduleDescription = new CoreModuleDescriptionModel();
		description.setLanguage("en");
		description.setShortText("descripetion");
		
		when(coreModuleDescriptionDAO.findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%")).thenReturn(null);
		when(coreMetadataLangDAO.findByLanguageAndTenantIdAndShortTextLike("en", "0", "%De%")).thenReturn(metadataLang);
		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenReturn(metadataFields);
		when(coreLayoutHeaderService.generateMetadata(any(), any(), any(), any())).thenReturn(fieldDto);
		when(coreLayoutHeaderService.generateMetadata(any(), any(), any(), any())).thenReturn(fieldDto1);
		when(coreModuleDAO.findByModuleIdAndTenantId(2L, "0")).thenReturn(module);
		when(coreModuleDescriptionDAO.findByModuleIdAndTenantIdAndLanguage(1L, "0", "en")).thenReturn(moduleDescription);
		
		List<ModuleTreeDTO> response = coreModuleServiceImpl.getModuleTree("en", "De", "0");
		
		assertNotNull(response);
		
		verify(coreModuleDescriptionDAO, atLeast(1)).findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%");
		verify(coreMetadataLangDAO, atLeast(1)).findByLanguageAndTenantIdAndShortTextLike("en", "0", "%De%");
		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId");
		verify(coreLayoutHeaderService, atLeast(2)).generateMetadata(any(), any(), any(), any());
		verify(coreModuleDAO, atLeast(1)).findByModuleIdAndTenantId(2L, "0");
		verify(coreModuleDescriptionDAO, atLeast(1)).findByModuleIdAndTenantIdAndLanguage(1L, "0", "en");
	}
	
	@Test
	@DisplayName("getModuleTreeTest3 method to test if field parent field is empty")
	public void getModuleTreeTest3() {
		
		List<CoreMetadataLangModel> metadataLang = new ArrayList<>();
		
		CoreMetadataLangModel description = new CoreMetadataLangModel();
		description.setFieldId("fieldId");
		
		CoreMetadataLangModel description1 = new CoreMetadataLangModel();
		description1.setFieldId("fieldId");
		
		metadataLang.add(description);
		metadataLang.add(description1);
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadataModel = new CoreMetadataModel();
		metadataModel.setModuleId(1L);
		metadataModel.setFieldId("fieldId");
		
		CoreMetadataModel metadataModel1 = new CoreMetadataModel();
		metadataModel1.setModuleId(2L);
		metadataModel1.setFieldId("fieldId");
		metadataModel1.setParentField("");
		
		metadataFields.add(metadataModel);
		metadataFields.add(metadataModel1);
		
		FieldDTO fieldDto = new FieldDTO();
		fieldDto.setModuleId(1L);
		
		FieldDTO fieldDto1 = new FieldDTO();
		fieldDto1.setModuleId(2L);
		
		CoreModuleModel module = new CoreModuleModel();
		module.setModuleId(1L);
		
		CoreModuleDescriptionModel moduleDescription = new CoreModuleDescriptionModel();
		description.setLanguage("en");
		description.setShortText("descripetion");
		
		when(coreModuleDescriptionDAO.findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%")).thenReturn(null);
		when(coreMetadataLangDAO.findByLanguageAndTenantIdAndShortTextLike("en", "0", "%De%")).thenReturn(metadataLang);
		when(coreMetadataDAO.findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId")).thenReturn(metadataFields);
		when(coreLayoutHeaderService.generateMetadata(any(), any(), any(), any())).thenReturn(fieldDto);
		when(coreLayoutHeaderService.generateMetadata(any(), any(), any(), any())).thenReturn(fieldDto1);
		when(coreModuleDAO.findByModuleIdAndTenantId(2L, "0")).thenReturn(module);
		when(coreModuleDescriptionDAO.findByModuleIdAndTenantIdAndLanguage(1L, "0", "en")).thenReturn(moduleDescription);
		
		List<ModuleTreeDTO> response = coreModuleServiceImpl.getModuleTree("en", "De", "0");
		
		assertNotNull(response);
		
		verify(coreModuleDescriptionDAO, atLeast(1)).findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%");
		verify(coreMetadataLangDAO, atLeast(1)).findByLanguageAndTenantIdAndShortTextLike("en", "0", "%De%");
		verify(coreMetadataDAO, atLeast(1)).findByTenantIdAndFieldIdOrParentField("0", "fieldId", "fieldId");
		verify(coreLayoutHeaderService, atLeast(2)).generateMetadata(any(), any(), any(), any());
		verify(coreModuleDAO, atLeast(1)).findByModuleIdAndTenantId(2L, "0");
		verify(coreModuleDescriptionDAO, atLeast(1)).findByModuleIdAndTenantIdAndLanguage(1L, "0", "en");
	}
	
	@Test
	@DisplayName("getModuleTreeTest4 method to test if language metadata is not present")
	public void getModuleTreeTest4() {
		
		when(coreModuleDescriptionDAO.findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%")).thenReturn(null);
		when(coreMetadataLangDAO.findByLanguageAndTenantIdAndShortTextLike("en", "0", "%De%")).thenReturn(null);
		
		List<ModuleTreeDTO> response = coreModuleServiceImpl.getModuleTree("en", "De", "0");
		
		assertTrue(response.isEmpty());
		
		verify(coreModuleDescriptionDAO, atLeast(1)).findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%");
		verify(coreMetadataLangDAO, atLeast(1)).findByLanguageAndTenantIdAndShortTextLike("en", "0", "%De%");
	}
	
	@Test
	@DisplayName("getModuleTreeTest5 method to test for exception handling")
	public void getModuleTreeTest5() {
		
		when(coreModuleDescriptionDAO.findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%")).thenThrow(new ArrayIndexOutOfBoundsException());
		
		List<ModuleTreeDTO> response = coreModuleServiceImpl.getModuleTree("en", "De", "0");
		
		assertTrue(response.isEmpty());
		
		verify(coreModuleDescriptionDAO, atLeast(1)).findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%De%");
	}
	
	@Test
	@DisplayName("getModuleDescriptionBasedOnModuleidTest method used to test the get serch description")
	public void getModuleDescriptionBasedOnModuleidTest() {
		
		CoreModuleDescriptionModel coreModuleDescription = new CoreModuleDescriptionModel();
		coreModuleDescription.setModuleId(1L);
		
		when(coreModuleDescriptionDAO.findByModuleIdAndTenantIdAndLanguage(1L, "0", "en")).thenReturn(coreModuleDescription);
		
		ModuleDescriptionDTO response = coreModuleServiceImpl.getModuleDescriptionBasedOnModuleid(1L, "en", "0");
		
		assertNotNull(response);
		
		verify(coreModuleDescriptionDAO, atLeast(1)).findByModuleIdAndTenantIdAndLanguage(1L, "0", "en");
	}
	
	@Test
	@DisplayName("getModuleDescriptionBasedOnModuleidTest1 method used to test exception handaling")
	public void getModuleDescriptionBasedOnModuleidTest1() {
		
		when(coreModuleDescriptionDAO.findByModuleIdAndTenantIdAndLanguage(1L, "0", "en")).thenReturn(null);
		
		ModuleDescriptionDTO response = coreModuleServiceImpl.getModuleDescriptionBasedOnModuleid(1L, "en", "0");
		
		assertNull(response.getModuleid());
		
		verify(coreModuleDescriptionDAO, atLeast(1)).findByModuleIdAndTenantIdAndLanguage(1L, "0", "en");
	}
	
	@Test
	@DisplayName("getAllModulesBasedOnSearchDetailsTest methos to test Get All Modules Based On Search Details.")
	public void getAllModulesBasedOnSearchDetailsTest() {
		List<CoreModuleDescriptionModel> coreModuleDescription = new ArrayList<>();
		
		CoreModuleDescriptionModel model = new CoreModuleDescriptionModel();
		model.setModuleId(1L);
		
		CoreModuleDescriptionModel model1 = new CoreModuleDescriptionModel();
		model1.setModuleId(2L);
		
		coreModuleDescription.add(model);
		coreModuleDescription.add(model1);
		
		List<Long> moduleIds = new ArrayList<>();
		moduleIds.add(1L);
		moduleIds.add(2L);
		
		List<Object> moduleList = new ArrayList<>();
		
		Object[] arr = new Object[2];
		
		CoreModuleModel module = new CoreModuleModel();
		
		CoreModuleDescriptionModel moduleDescriptionn = new CoreModuleDescriptionModel();
		moduleDescriptionn.setLanguage("en");
		moduleDescriptionn.setDescription("Description");
		
		arr[0] = module;
		arr[1] = moduleDescriptionn;
		
		moduleList.add(arr);
		
		when(coreModuleDescriptionDAO.findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%Ma%")).thenReturn(coreModuleDescription);
		when(coreModuleDAO.findAllModulesBasedOnSearchDetail("0", "en", moduleIds)).thenReturn(moduleList);
		
		List<CoreModuleModel> responseData = coreModuleServiceImpl.getAllModulesBasedOnSearchDetails("en","Ma","0");
		
		assertNotNull(responseData);
		
		verify(coreModuleDescriptionDAO, atLeast(1)).findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%Ma%");
		verify(coreModuleDAO, atLeast(1)).findAllModulesBasedOnSearchDetail("0", "en", moduleIds);
	}
	
	@Test
	@DisplayName("getAllModulesBasedOnSearchDetailsTest1 methos to test if ModuleId list is empty")
	public void getAllModulesBasedOnSearchDetailsTest1() {
		List<CoreModuleDescriptionModel> coreModuleDescription = new ArrayList<>();
		
		when(coreModuleDescriptionDAO.findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%Ma%")).thenReturn(coreModuleDescription);
		
		List<CoreModuleModel> responseData = coreModuleServiceImpl.getAllModulesBasedOnSearchDetails("en","Ma","0");
		
		assertNull(responseData);
		
		verify(coreModuleDescriptionDAO, atLeast(1)).findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%Ma%");
	}
	
	@Test
	@DisplayName("getAllModulesBasedOnSearchDetailsTest2 methos to test if ModuleId list is null")
	public void getAllModulesBasedOnSearchDetailsTest2() {
		when(coreModuleDescriptionDAO.findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%Ma%")).thenReturn(null);
		
		List<CoreModuleModel> responseData = coreModuleServiceImpl.getAllModulesBasedOnSearchDetails("en","Ma","0");
		
		assertNull(responseData);
		
		verify(coreModuleDescriptionDAO, atLeast(1)).findByTenantIdAndLanguageAndDescriptionLike("0", "en", "%Ma%");
	}

	@Test
	@DisplayName("save/update structure method to test the creation/updation of the structure")
	public void saveAndUpdateStructureTest() {
		CoreStructureModel moduleStructure = new CoreStructureModel();
		moduleStructure.setLanguage("en");
		moduleStructure.setIsHeader(true);
		moduleStructure.setModuleId(0l);
		moduleStructure.setParentStrucId(Short.parseShort("0"));
		moduleStructure.setStrucDesc("Structure description");
		moduleStructure.setTenantId("0");
		moduleStructure.setParentStrucId(Short.parseShort("1"));
		List<CoreStructureModel> list = new ArrayList<>();
		list.add(moduleStructure);
		when(coreStructureDAO.findByModuleIdAndStructureIdInAndTenantId(any(),any(),any())).thenReturn(list);
		when(coreStructureDAO.save(any())).thenReturn(list.get(0));

		ModuleStructureDTO moduleStructureDTO = new ModuleStructureDTO();
		moduleStructureDTO.setLanguage("en");
		moduleStructureDTO.setIsHeader(true);
		moduleStructureDTO.setModuleId(0l);
		moduleStructureDTO.setParentStrucId(Short.parseShort("0"));
		moduleStructureDTO.setStrucDesc("Structure description");
		moduleStructureDTO.setTenantId("0");
		moduleStructureDTO.setParentStrucId(Short.parseShort("1"));
		CoreStructureModel coreStructureModel = coreModuleServiceImpl.saveAndUpdateStructure(moduleStructureDTO, "0");

		assertTrue(Objects.nonNull(coreStructureModel));

		verify(coreStructureDAO,atLeast(1)).findByModuleIdAndStructureIdInAndTenantId(any(),any(),any());
		verify(coreStructureDAO,atLeast(1)).save(any());

	}
	
	@Test
	@DisplayName("updateModuleTest1 method to test the updation of the module")
	public void updateModuleTest1() {

		String tenantCode = "0";

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		moduledescription.put("en", enData);

		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setSystemType("xyz");
		requestDTO.setIndustry("abc");
		requestDTO.setDisplayCriteria("view");
		requestDTO.setModuledescription(moduledescription);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");
		List<Long> parentModuleIds = new ArrayList<>();
		parentModuleIds.add(1l);
		requestDTO.setParentModuleIds(parentModuleIds);

		CoreModuleModel moduleModel = new CoreModuleModel();
		moduleModel.setModuleId(1L);

		when(coreModuleDAO.findByModuleIdAndTenantId(1L, "0")).thenReturn(moduleModel);
		when(coreModuleDAO.save(any())).thenReturn(moduleModel);
		when(coreModuleDescriptionDAO.findAllByTenantIdAndModuleId("0", 1l)).thenReturn(null);
		when(coreModuleDescriptionDAO.findByModuleIdAndTenantIdAndLanguage(any(), any(), any())).thenReturn(null);
		when(coreSubModuleDao.findAllByModuleId(1l)).thenReturn(null);

		ModuleResponseDTO responseDTO = coreModuleServiceImpl.updateModule(requestDTO, tenantCode, 1l);

		assertTrue(responseDTO.isAcknowledge());

		verify(coreModuleDAO, atLeast(1)).save(any());
		verify(coreModuleDescriptionDAO, atLeast(1)).saveAll(any());
		verify(coreSubModuleDao, atLeast(1)).save(any());
	}

	@Test
	@DisplayName("updateModuleTest2 method to test the updation of the module")
	public void updateModuleTest2() {

		String tenantCode = "0";

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		moduledescription.put("en", enData);

		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setSystemType("xyz");
		requestDTO.setIndustry("abc");
		requestDTO.setDisplayCriteria("view");
		requestDTO.setModuledescription(moduledescription);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");
		List<Long> parentModuleIds = new ArrayList<>();
		parentModuleIds.add(1l);
		requestDTO.setParentModuleIds(parentModuleIds);

		CoreModuleModel moduleModel = new CoreModuleModel();
		moduleModel.setModuleId(1L);

		when(coreModuleDAO.findByModuleIdAndTenantId(1L, "0")).thenReturn(moduleModel);
		when(coreModuleDAO.save(any())).thenReturn(moduleModel);
		when(coreModuleDescriptionDAO.findAllByTenantIdAndModuleId("0", 1l)).thenReturn(null);
		when(coreModuleDescriptionDAO.findByModuleIdAndTenantIdAndLanguage(any(), any(), any())).thenReturn(null);
		when(coreSubModuleDao.findAllByModuleId(1l)).thenReturn(null);

		ModuleResponseDTO responseDTO = coreModuleServiceImpl.updateModule(requestDTO, tenantCode, 1l);

		assertTrue(responseDTO.isAcknowledge());

		verify(coreModuleDAO, atLeast(1)).save(any());
		verify(coreModuleDescriptionDAO, atLeast(1)).saveAll(any());
		verify(coreSubModuleDao, atLeast(1)).save(any());
	}

	@Test
	@DisplayName("updateModuleTest3 method to test the updation of the module")
	public void updateModuleTest3() {

		String tenantCode = "0";

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription("ENGLIST");
		enData.setInformation("English info");
		moduledescription.put("en", enData);

		ModuleRequestDTO requestDTO = new ModuleRequestDTO();
		requestDTO.setSystemType("xyz");
		requestDTO.setIndustry("abc");
		requestDTO.setDisplayCriteria("view");
		requestDTO.setModuledescription(moduledescription);
		requestDTO.setDisplayCriteria("1");
		requestDTO.setUsermodified("amit.raghuwansi@prospecta.com");
		List<Long> parentModuleIds = new ArrayList<>();
		parentModuleIds.add(1l);
		requestDTO.setParentModuleIds(parentModuleIds);

		CoreModuleModel moduleModel = new CoreModuleModel();
		moduleModel.setModuleId(1L);

		CoreModuleDescriptionModel coreModuleDescriptionModel = new CoreModuleDescriptionModel();
		coreModuleDescriptionModel.setModuleId(1l);
		coreModuleDescriptionModel.setTenantId("0");
		coreModuleDescriptionModel.setLanguage("en");
		coreModuleDescriptionModel.setDescription("ENGLIST");
		coreModuleDescriptionModel.setInformation("English info");

		List<CoreModuleDescriptionModel> descList = new ArrayList<>();
		descList.add(coreModuleDescriptionModel);

		CoreSubModuleModel coreSubModuleModel = new CoreSubModuleModel();
		coreSubModuleModel.setModuleId(1l);
		coreSubModuleModel.setParentModuleId(1l);

		List<CoreSubModuleModel> subModuleList = new ArrayList<>();
		subModuleList.add(coreSubModuleModel);

		when(coreModuleDAO.findByModuleIdAndTenantId(1L, "0")).thenReturn(moduleModel);
		when(coreModuleDAO.save(any())).thenReturn(moduleModel);
		when(coreModuleDescriptionDAO.findAllByTenantIdAndModuleId("0", 1l)).thenReturn(descList);
		when(coreModuleDescriptionDAO.findByModuleIdAndTenantIdAndLanguage(any(), any(), any()))
				.thenReturn(coreModuleDescriptionModel);
		when(coreSubModuleDao.findAllByModuleId(1l)).thenReturn(subModuleList);

		ModuleResponseDTO responseDTO = coreModuleServiceImpl.updateModule(requestDTO, tenantCode, 1l);

		assertTrue(responseDTO.isAcknowledge());

		verify(coreModuleDAO, atLeast(1)).save(any());
		verify(coreModuleDescriptionDAO, atLeast(1)).save(any());
	}

	@Test
	@DisplayName("Construct Help Text Test")
	void constructHelpTextTest() {
		Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription =createModuleDescription("Earth",null);
		Map<String, String>longText =createMap();
		FieldDTO fieldDTO = createFieldDto(moduleDescription,null,"filedId");
		List<CoreMetadataLangModel> modelList=new ArrayList<>();
		coreModuleServiceImpl.constructHelpText(modelList,fieldDTO,"0",1L);
	    assertNotNull(modelList);
	    List<CoreMetadataLangModel> copyList=List.copyOf(modelList);
		moduleDescription =createModuleDescription("Earth","Planet");
		fieldDTO=createFieldDto(moduleDescription,longText,"fieldId");
		coreModuleServiceImpl.constructHelpText(copyList,fieldDTO,"0",1L);
		assertEquals(modelList,copyList);
	}

	@Test
	@DisplayName("Test to check Delete Module")
	void deleteModule() {

		CoreModuleModel model=new CoreModuleModel();
		model.setModuleId(1L);

		when(coreModuleDAO.findByModuleIdAndTenantId(anyLong(),anyString())).thenReturn(model);

		when(generationImpl.deleteTable(anyList(), anyList(), anyLong(), anyString())).thenReturn(true);
		when(generationImpl.deleteIndex(anyList(), anyList(), anyLong(), anyString())).thenReturn(true);

		ModuleResponseDTO responseDTO = coreModuleServiceImpl.deleteModule(1L,"0");

		assertTrue(responseDTO.isAcknowledge());

		verify(coreModuleDAO,atLeast(1)).findByModuleIdAndTenantId(1L,"0");
	}

	@Test
	@DisplayName("Test to check Delete Module Exception")
	void deleteModuleException() {

		when(coreModuleDAO.findByModuleIdAndTenantId(1L,"0")).thenReturn(null);

		when(generationImpl.deleteTable(anyList(), anyList(), anyLong(), anyString())).thenReturn(true);
		when(generationImpl.deleteIndex(anyList(), anyList(), anyLong(), anyString())).thenReturn(true);

		assertThrows(NotFound404Exception.class,()-> coreModuleServiceImpl.deleteModule(1L,"0"));

		verify(coreModuleDAO,atLeast(1)).findByModuleIdAndTenantId(1L,"0");
	}

	@Test
	@DisplayName("Test to check Get Details by Module Id")
	void getDetailsByModuleId() {

		CoreModuleModel coreModule = new CoreModuleModel();
		coreModule.setModuleId(1L);

		when(coreModuleDAO.findByModuleIdAndTenantId(1L,"0")).thenReturn(coreModule);

		CoreSubModuleModel coreSubModuleModel = new CoreSubModuleModel();
		coreSubModuleModel.setModuleId(1l);
		coreSubModuleModel.setUuid(UUID.randomUUID());

		List<CoreSubModuleModel> coreSubModuleModelsList = Arrays.asList(coreSubModuleModel);

		when(coreSubModuleDao.findAllByModuleId(anyLong())).thenReturn(coreSubModuleModelsList);

		CoreModuleDescriptionModel coreModuleDescriptionModel = new CoreModuleDescriptionModel();
		List<CoreModuleDescriptionModel> coreModuleDescriptionModelList = Arrays.asList(coreModuleDescriptionModel);

		when(coreModuleDescriptionDAO.findAllByTenantIdAndModuleId(anyString(), anyLong())).thenReturn(coreModuleDescriptionModelList);

		coreModuleServiceImpl.getDetailsByModuleId("0",1L);

		verify(coreModuleDAO,atLeast(1)).findByModuleIdAndTenantId(1L,"0");
	}


	@Test
	@DisplayName("Test to check Delete Structure")
	void deleteStructure() {

		CoreMetadataModel model = new CoreMetadataModel();
		model.setFieldId("field");
		model.setPickList("15");

		when(service.getChildStrucIds(any(),any(),any())).thenReturn(new ArrayList<>(){{add("2");}});

		when(coreMetadataDAO.findByStructureIdInAndModuleIdAndTenantId(any(),any(),any())).thenReturn(new ArrayList<>() {{add(model);}});

		when(generationImpl.deleteTable(anyList(), anyList(), anyLong(), anyString())).thenReturn(true);

		assertTrue(coreModuleServiceImpl.deleteStructure(1L,Short.parseShort("1"),"0").isAcknowledge());

	}

	@Test
	@DisplayName("Test to check Delete Structure Exception")
	void deleteStructureEx() {

		CoreMetadataModel model = new CoreMetadataModel();
		model.setFieldId("field");
		model.setPickList("15");

		when(service.getChildStrucIds(any(),any(),any())).thenReturn(new ArrayList<>(){{add("2");}});

		when(coreMetadataDAO.findByStructureIdInAndModuleIdAndTenantId(any(),any(),any())).thenReturn(new ArrayList<>() {{add(model);}});

		when(generationImpl.deleteTable(anyList(), anyList(), anyLong(), anyString())).thenReturn(false);

		assertThrows(GRPCException.class,()-> coreModuleServiceImpl.deleteStructure(1L,Short.parseShort("1"),"0"));

	}

	@Test
	@DisplayName("Test to check Get Structure")
	void getAllStructures() {

		CoreStructureModel model = new CoreStructureModel();
		model.setModuleId(1L);
        List<CoreStructureModel> list = Collections.singletonList(model);

        when(coreStructureDAO.findByModuleIdandTenantId(any(),any(),any(),anyString(),eq(PageRequest.of(1,1)))).thenReturn(list);

        List<ModuleStructureDTO> dto = coreModuleServiceImpl.getAllStructures(1L,"0","","en",1,1);
		assertEquals(1,dto.size());

		verify(coreStructureDAO,atLeast(1)).findByModuleIdandTenantId(1L,"0","","en",PageRequest.of(1,1));

	}

	private FieldDTO createFieldDto(Map<String, ModuleDescriptionInformationRequestDTO> moduleDescription,
									Map<String, String> longText,String fieldId){

		FieldDTO fieldDTO = new FieldDTO();
		fieldDTO.setFieldId(fieldId);
		fieldDTO.setShortText(moduleDescription);
		fieldDTO.setLongtexts(longText);
		fieldDTO.setDataType("GRID");
		fieldDTO.setPickList("15");
		fieldDTO.setMaxChar(200L);
		fieldDTO.setIsGridColumn(false);
		fieldDTO.setParentField("");
		return fieldDTO;
	}

	private Map<String, ModuleDescriptionInformationRequestDTO> createModuleDescription(String description,String information) {

		Map<String, ModuleDescriptionInformationRequestDTO> moduledescription = new HashMap<>();
		ModuleDescriptionInformationRequestDTO enData = new ModuleDescriptionInformationRequestDTO();
		enData.setDescription(description);
		enData.setInformation(information);
		ModuleDescriptionInformationRequestDTO frData = new ModuleDescriptionInformationRequestDTO();
		frData.setDescription("FRENCH");
		frData.setInformation("FRENCH info");
		ModuleDescriptionInformationRequestDTO arData = new ModuleDescriptionInformationRequestDTO();
		arData.setDescription("ARABIC");
		arData.setInformation("ARABIC info");
		ModuleDescriptionInformationRequestDTO jrData = new ModuleDescriptionInformationRequestDTO();
		jrData.setDescription("JAPANI");
		jrData.setInformation("JAPANI info");
		moduledescription.put("en", enData);
		moduledescription.put("fr", frData);
		moduledescription.put("ar", arData);
		return  moduledescription;
	}
	private Map<String,String> createMap() {
		Map<String, String> text = new HashMap<>();
		text.put("en", "Material");
		text.put("fr", "matériel");
		text.put("sp", "tipo de material");
		text.put("gj", "tipo de material");
		return text;
	}
}
