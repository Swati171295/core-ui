package com.prospecta.mdo.module.dao.virtualdata;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;

@ActiveProfiles("test")
@DataJpaTest
class CoreVdGrpTransInfoDaoTest {
	
	@Autowired
    private TestEntityManager entityManager;
	
	@Autowired
    private CoreVdGrpTransInfoDAO coreVdGrpTransInfoDAO;
	
	@DisplayName("findByCoreVdGroupsTest -> find group trans information by group join information")
	@Test
	void findByCoreVdGroupsTest() {		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		CoreVdGrpTransInfoModel CoreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		CoreVdGrpTransInfoModel.setUuid(UUID.randomUUID());
		CoreVdGrpTransInfoModel.setCoreVdGroups(coreVdGroupsModel);
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.persist(CoreVdGrpTransInfoModel);
		entityManager.flush();
		List<CoreVdGrpTransInfoModel> actualList = coreVdGrpTransInfoDAO.findByCoreVdGroups(coreVdGroupsModel);
		assertEquals(actualList.get(0).getCoreVdGroups().getGroupDescription(),coreVdGroupsModel.getGroupDescription(), "group trans information found is different than expected");
	}
	
	@DisplayName("deleteByCoreVdGroupsTest -> delete group trans information by group join information")
	@Test
	void deleteByCoreVdGroupsTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);		
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.flush();
		coreVdGrpTransInfoDAO.deleteByCoreVdGroups(coreVdGroupsModel);
		List<CoreVdGrpTransInfoModel> actualList = coreVdGrpTransInfoDAO.findByCoreVdGroups(coreVdGroupsModel);
		assertTrue(actualList.isEmpty(),"core group trans information is deleted.");
	}

}
