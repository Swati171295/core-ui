package com.prospecta.mdo.module.dao.virtualdata;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdHeaderModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;

@ActiveProfiles("test")
@DataJpaTest
class CoreVdTransFieldSettingDaoTest {
	
	@Autowired
    private TestEntityManager entityManager;
	
	@Autowired
    private CoreVdTransFieldSettingDAO coreVdTransFieldSettingDAO;

	@DisplayName("findByCoreVdGroupsTest -> find trans field setting by join information")
	@Test
	void findByCoreVdGroupsTest() {		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		coreVdGrpTransInfoModel.setUuid(UUID.randomUUID());
		coreVdGrpTransInfoModel.setCoreVdGroups(coreVdGroupsModel);
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = new CoreVdTransFieldSettingModel();
		coreVdTransFieldSettingModel.setTransId(UUID.randomUUID());
		coreVdTransFieldSettingModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdTransFieldSettingModel.setCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.persist(coreVdGrpTransInfoModel);
		entityManager.persist(coreVdTransFieldSettingModel);
		entityManager.flush();
		List<CoreVdTransFieldSettingModel> actualList = coreVdTransFieldSettingDAO.findByCoreVdGroups(coreVdGroupsModel);
		assertEquals(actualList.get(0).getCoreVdGroups().getGroupDescription(),coreVdGroupsModel.getGroupDescription(), "Trans field setting found is different than expected");
	}
	
	@DisplayName("findByCoreVdGrpTransInfoTest -> find trans field setting by group trans information")
	@Test
	void findByCoreVdGrpTransInfoTest() {		
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		coreVdGrpTransInfoModel.setUuid(UUID.randomUUID());
		coreVdGrpTransInfoModel.setCoreVdGroups(coreVdGroupsModel);
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = new CoreVdTransFieldSettingModel();
		coreVdTransFieldSettingModel.setTransId(UUID.randomUUID());
		coreVdTransFieldSettingModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdTransFieldSettingModel.setCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.persist(coreVdGrpTransInfoModel);
		entityManager.persist(coreVdTransFieldSettingModel);
		entityManager.flush();
		List<CoreVdTransFieldSettingModel> actualList = coreVdTransFieldSettingDAO.findByCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		assertEquals(actualList.get(0).getCoreVdGroups().getGroupDescription(),coreVdGroupsModel.getGroupDescription(), "Trans field setting found is different than expected");
	}
	
	@DisplayName("deleteByCoreVdGroupsTest -> delete trans field setting by join information")
	@Test
	void deleteByCoreVdGroupsTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);		
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.flush();
		coreVdTransFieldSettingDAO.deleteByCoreVdGroups(coreVdGroupsModel);
		List<CoreVdTransFieldSettingModel> actualList = coreVdTransFieldSettingDAO.findByCoreVdGroups(coreVdGroupsModel);
		assertTrue(actualList.isEmpty(),"Trans field setting is deleted.");
	}
	
	@DisplayName("deleteByCoreVdGrpTransInfoTest -> delete trans field setting by group trans information")
	@Test
	void deleteByCoreVdGrpTransInfoTest() {
		CoreVdHeaderModel coreVdHeaderModel = new CoreVdHeaderModel();
		coreVdHeaderModel.setVdId(UUID.randomUUID());
		coreVdHeaderModel.setVdName("Test virtual Dataset");
		coreVdHeaderModel.setVdDescription("Test Description");
		coreVdHeaderModel.setTenantId("12345");
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupId(UUID.randomUUID());
		coreVdGroupsModel.setTenantId("12345");
		coreVdGroupsModel.setGroupDescription("sample description");
		coreVdGroupsModel.setCoreVdHeader(coreVdHeaderModel);
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		coreVdGrpTransInfoModel.setUuid(UUID.randomUUID());
		coreVdGrpTransInfoModel.setCoreVdGroups(coreVdGroupsModel);
		entityManager.persist(coreVdHeaderModel);
		entityManager.persist(coreVdGroupsModel);
		entityManager.persist(coreVdGrpTransInfoModel);
		entityManager.flush();
		coreVdTransFieldSettingDAO.deleteByCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		List<CoreVdTransFieldSettingModel> actualList = coreVdTransFieldSettingDAO.findByCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		assertTrue(actualList.isEmpty(),"Trans field setting is deleted.");
	}
}
