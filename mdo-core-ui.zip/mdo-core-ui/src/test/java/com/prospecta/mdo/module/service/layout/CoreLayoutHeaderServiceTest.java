/**
 * 
 */
package com.prospecta.mdo.module.service.layout;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prospecta.mdo.module.dao.layout.CoreLayoutHeaderDAO;
import com.prospecta.mdo.module.dao.layout.CoreLayoutRuleMappingDAO;
import com.prospecta.mdo.module.dao.layout.CoreLayoutTabDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataDAO;
import com.prospecta.mdo.module.dao.metadata.CoreMetadataLangDAO;
import com.prospecta.mdo.module.dao.module.CoreModuleDAO;
import com.prospecta.mdo.module.dao.module.CoreModuleDescriptionDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabFieldsDAO;
import com.prospecta.mdo.module.dao.tab.CoreTabLabelsDAO;
import com.prospecta.mdo.module.dto.elastic.MDORecordES;
import com.prospecta.mdo.module.dto.layout.*;
import com.prospecta.mdo.module.dto.module.FieldDTO;
import com.prospecta.mdo.module.dto.tab.TabResponseDTO;
import com.prospecta.mdo.module.enums.FieldType;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.layout.CoreLayoutHeaderModel;
import com.prospecta.mdo.module.model.layout.CoreLayoutRuleMappingModel;
import com.prospecta.mdo.module.model.layout.CoreLayoutTabModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataLangModel;
import com.prospecta.mdo.module.model.metadata.CoreMetadataModel;
import com.prospecta.mdo.module.model.module.CoreModuleDescriptionModel;
import com.prospecta.mdo.module.model.module.CoreModuleModel;
import com.prospecta.mdo.module.model.tab.CoreTabFieldsModel;
import com.prospecta.mdo.module.model.tab.CoreTabLabelsModel;
import com.prospecta.mdo.module.model.tab.CoreTabModel;
import com.prospecta.mdo.module.service.metadata.CoreMetadataService;
import com.prospecta.mdo.module.service.tab.CoreTabModelService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * @author savan
 *
 */
@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
public class CoreLayoutHeaderServiceTest {

	@InjectMocks
	private CoreLayoutHeaderServiceImpl coreLayoutHeaderServiceImpl;

	@Mock
	private CoreLayoutHeaderDAO coreLayoutHeaderDAO;

	@Mock
	private CoreModuleDAO coreModuleDAO;
	
	@Mock
	private CoreTabDAO coreTabDAO;
	
	@Mock
	private CoreTabLabelsDAO coreTabLabelsDAO;
	
	@Mock
	private CoreTabFieldsDAO coreTabFieldsDAO;
	
	@Mock
	private CoreMetadataDAO coreMetadataDAO;
	
	@Mock
	private CoreMetadataLangDAO coreMetadataLangDAO;
	
	@Mock
	private CoreLayoutTabDAO coreLayoutTabDAO;
	
	@Mock
	private CoreLayoutRuleMappingDAO coreLayoutRuleMappingDAO;
	
	@Mock
	private CoreMetadataService coreMetadataService;

	@Mock
	private CoreModuleDescriptionDAO coreModuleDescriptionDAO;

	@Mock
	private CoreTabModelService coreTabService;

	@BeforeAll
	public void init() {
		coreLayoutHeaderServiceImpl = new CoreLayoutHeaderServiceImpl();
	}
	
	@Test
	@DisplayName("createLayoutTest method test for create layout")
	public void createLayoutTest() {

		LayoutRequestDTO requestDTO = new LayoutRequestDTO();
		requestDTO.setDescription("description");
		requestDTO.setType("0");

		CoreLayoutHeaderModel layout = new CoreLayoutHeaderModel();
		layout.setLayoutId(UUID.randomUUID());

		when(coreModuleDAO.findByModuleIdAndTenantId(any(),any())).thenReturn(new CoreModuleModel());
		when(coreLayoutHeaderDAO.save(any())).thenReturn(layout);

		LayoutResponseDTO responseDTO = coreLayoutHeaderServiceImpl.createLayout(requestDTO, 1L, "0", "Admin");

		assertTrue(responseDTO.isAcknowledge());

		verify(coreModuleDAO, atLeast(1)).findByModuleIdAndTenantId(any(),any());
		verify(coreLayoutHeaderDAO, atLeast(1)).save(any());
	}

	@Test
	@DisplayName("createLayoutTest1 method test Runtime exceptionn")
	public void createLayoutTest1() {

		LayoutRequestDTO requestDTO = new LayoutRequestDTO();
		requestDTO.setDescription("description");
		requestDTO.setType("0");

		when(coreModuleDAO.findByModuleIdAndTenantId(1L,"0")).thenReturn(null);
		LayoutResponseDTO responseDTO = coreLayoutHeaderServiceImpl.createLayout(requestDTO, 1L, "0", "Admin");

		assertFalse(responseDTO.isAcknowledge());

		verify(coreModuleDAO, atLeast(1)).findByModuleIdAndTenantId(1L,"0");
	}

	@Test
	@DisplayName("updateLayoutTest method test for update layout")
	public void updateLayoutTest() {

		LayoutRequestDTO requestDTO = new LayoutRequestDTO();
		requestDTO.setDescription("description");
		requestDTO.setType("0");

		CoreLayoutHeaderModel layout = new CoreLayoutHeaderModel();
		layout.setLayoutId(UUID.randomUUID());

		when(coreLayoutHeaderDAO.findByLayoutIdAndModuleIdAndTenantId(any(),any(),any())).thenReturn(new CoreLayoutHeaderModel());
		when(coreLayoutHeaderDAO.save(any())).thenReturn(layout);

		LayoutResponseDTO responseDTO = coreLayoutHeaderServiceImpl.updateLayout(requestDTO, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "0", "Admin");

		assertTrue(responseDTO.isAcknowledge());

		verify(coreLayoutHeaderDAO, atLeast(1)).findByLayoutIdAndModuleIdAndTenantId(any(),any(),any());
		verify(coreLayoutHeaderDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("updateLayoutTest1 method test for Runtime exceptionn")
	public void updateLayoutTest1() {

		LayoutRequestDTO requestDTO = new LayoutRequestDTO();
		requestDTO.setDescription("description");
		requestDTO.setType("0");

		CoreLayoutHeaderModel layout = new CoreLayoutHeaderModel();
		layout.setLayoutId(UUID.randomUUID());

		when(coreLayoutHeaderDAO.findByLayoutIdAndModuleIdAndTenantId(any(),any(),any())).thenReturn(null);

		LayoutResponseDTO responseDTO = coreLayoutHeaderServiceImpl.updateLayout(requestDTO, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "0", "Admin");

		assertFalse(responseDTO.isAcknowledge());

		verify(coreLayoutHeaderDAO, atLeast(1)).findByLayoutIdAndModuleIdAndTenantId(any(),any(),any());
	}
	
	@Test
	@DisplayName("getLayoutTest method to test fetching layout.")
	public void getLayoutTest() {

		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		
		List<CoreTabFieldsModel> coreTabFields = new ArrayList<>();
		
		CoreTabFieldsModel tabField = new CoreTabFieldsModel();
		tabField.setFieldId("fieldId");
		tabField.setFieldType(FieldType.FIELD);
		coreTabFields.add(tabField);
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadata = new CoreMetadataModel();
		metadata.setFieldId("fieldId");
		metadata.setModuleId(1L);
		
		CoreMetadataModel metadata1 = new CoreMetadataModel();
		metadata1.setParentField("");
		metadata1.setFieldId("fieldId");
		metadata1.setModuleId(1L);
		
		CoreMetadataModel metadata2 = new CoreMetadataModel();
		metadata2.setParentField("fieldId");
		metadata2.setFieldId("fieldId");
		metadata2.setModuleId(1L);
		
		CoreMetadataLangModel metadataLang = new CoreMetadataLangModel();
		
		metadataLang.setShortText("message");
		metadataLang.setHelpText("message");
		metadataLang.setLongText("message");
		
		metadataFields.add(metadata);
		metadataFields.add(metadata1);
		metadataFields.add(metadata2);
		
		CoreLayoutTabModel layoutTab = new CoreLayoutTabModel();
		layoutTab.setIsTabReadOnly(false);
		layoutTab.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		layoutTab.setLayoutId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		layoutTab.setTabOrder((short) 1);
		List<CoreLayoutTabModel> list =new ArrayList<>(){{add(layoutTab);}};

		when(coreTabLabelsDAO.findByTcodeAndLanguage(tabModel.getTcode(), "en")).thenReturn(new CoreTabLabelsModel());
		when(coreLayoutTabDAO.findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),"0")).thenReturn(list);
		when(coreTabFieldsDAO.findByTcode(tabModel.getTcode())).thenReturn(coreTabFields);
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", tabField.getFieldId(),tabField.getFieldId())).thenReturn(metadataFields);
		when(coreMetadataLangDAO.findByFieldIdAndLanguageAndTenantIdAndModuleId(metadata.getFieldId(), "en", "0", 1L)).thenReturn(metadataLang);
		
		List<FetchedLayoutDTO> response = coreLayoutHeaderServiceImpl.getLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");
		
		assertNotNull(response,"response must not be null");

		verify(coreTabLabelsDAO, atLeast(1)).findByTcodeAndLanguage(tabModel.getTcode(), "en");
		verify(coreLayoutTabDAO, atLeast(1)).findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),"0");
		verify(coreTabFieldsDAO, atLeast(1)).findByTcode(tabModel.getTcode());
		verify(coreMetadataDAO, atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", tabField.getFieldId(),tabField.getFieldId());
		verify(coreMetadataLangDAO, atLeast(1)).findByFieldIdAndLanguageAndTenantIdAndModuleId(metadata.getFieldId(), "en", "0", 1L);
	}
	
	@Test
	@DisplayName("getLayoutTest1 method to test if descriptions for fields are not available")
	public void getLayoutTest1() {
		
		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		
		List<CoreTabFieldsModel> coreTabFields = new ArrayList<>();
		
		CoreTabFieldsModel tabField = new CoreTabFieldsModel();
		tabField.setFieldId("fieldId");
		tabField.setFieldType(FieldType.FIELD);

		coreTabFields.add(tabField);
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadata = new CoreMetadataModel();
		metadata.setFieldId("fieldId");
		metadata.setModuleId(1L);
		
		CoreMetadataModel metadata1 = new CoreMetadataModel();
		metadata1.setParentField("");
		metadata1.setFieldId("fieldId");
		metadata1.setModuleId(1L);
		
		CoreMetadataModel metadata2 = new CoreMetadataModel();
		metadata2.setParentField("fieldId");
		metadata2.setFieldId("fieldId");
		metadata2.setModuleId(1L);
		
		CoreMetadataLangModel metadataLang = new CoreMetadataLangModel();
		
		metadataLang.setShortText(null);
		metadataLang.setHelpText(null);
		metadataLang.setLongText(null);
		
		metadataFields.add(metadata);
		metadataFields.add(metadata1);
		metadataFields.add(metadata2);
		
		CoreLayoutTabModel layoutTab = new CoreLayoutTabModel();
		layoutTab.setIsTabReadOnly(false);
		layoutTab.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		layoutTab.setLayoutId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		layoutTab.setTabOrder((short) 1);
		List<CoreLayoutTabModel> list =new ArrayList<>(){{add(layoutTab);}};
		
		when(coreTabLabelsDAO.findByTcodeAndLanguage(tabModel.getTcode(), "en")).thenReturn(new CoreTabLabelsModel());
		when(coreLayoutTabDAO.findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),"0")).thenReturn(list);
		when(coreTabFieldsDAO.findByTcode(tabModel.getTcode())).thenReturn(coreTabFields);
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", tabField.getFieldId(),tabField.getFieldId())).thenReturn(metadataFields);
		when(coreMetadataLangDAO.findByFieldIdAndLanguageAndTenantIdAndModuleId(metadata.getFieldId(), "en", "0", 1L)).thenReturn(metadataLang);
		
		List<FetchedLayoutDTO> response = coreLayoutHeaderServiceImpl.getLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");
		
		assertNotNull(response,"response must not be null");
		
		verify(coreTabLabelsDAO, atLeast(1)).findByTcodeAndLanguage(tabModel.getTcode(), "en");
		verify(coreLayoutTabDAO, atLeast(1)).findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),"0");
		verify(coreTabFieldsDAO, atLeast(1)).findByTcode(tabModel.getTcode());
		verify(coreMetadataDAO, atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", tabField.getFieldId(),tabField.getFieldId());
		verify(coreMetadataLangDAO, atLeast(1)).findByFieldIdAndLanguageAndTenantIdAndModuleId(metadata.getFieldId(), "en", "0", 1L);
	}
	
	@Test
	@DisplayName("getLayoutTest2 method to test id language metadata is not available.")
	public void getLayoutTest2() {
		
		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		
		List<CoreTabFieldsModel> coreTabFields = new ArrayList<>();
		
		CoreTabFieldsModel tabField = new CoreTabFieldsModel();
		tabField.setFieldId("fieldId");
		tabField.setFieldType(FieldType.FIELD);

		coreTabFields.add(tabField);
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadata = new CoreMetadataModel();
		metadata.setFieldId("fieldId");
		metadata.setModuleId(1L);
		
		CoreMetadataModel metadata1 = new CoreMetadataModel();
		metadata1.setParentField("");
		metadata1.setFieldId("fieldId");
		metadata1.setModuleId(1L);
		
		CoreMetadataModel metadata2 = new CoreMetadataModel();
		metadata2.setParentField("fieldId");
		metadata2.setFieldId("fieldId");
		metadata2.setModuleId(1L);
		
		metadataFields.add(metadata);
		metadataFields.add(metadata1);
		metadataFields.add(metadata2);
		
		CoreLayoutTabModel layoutTab = new CoreLayoutTabModel();
		layoutTab.setIsTabReadOnly(false);
		layoutTab.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		layoutTab.setLayoutId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		layoutTab.setTabOrder((short) 1);
		List<CoreLayoutTabModel> list =new ArrayList<>(){{add(layoutTab);}};

		when(coreTabLabelsDAO.findByTcodeAndLanguage(tabModel.getTcode(), "en")).thenReturn(new CoreTabLabelsModel());
		when(coreLayoutTabDAO.findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),"0")).thenReturn(list);
		when(coreTabFieldsDAO.findByTcode(tabModel.getTcode())).thenReturn(coreTabFields);
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", tabField.getFieldId(),tabField.getFieldId())).thenReturn(metadataFields);
		when(coreMetadataLangDAO.findByFieldIdAndLanguageAndTenantIdAndModuleId(metadata.getFieldId(), "en", "0", 1L)).thenReturn(null);
		
		List<FetchedLayoutDTO> response = coreLayoutHeaderServiceImpl.getLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");
		
		assertNotNull(response,"response must not be null");

		verify(coreTabLabelsDAO, atLeast(1)).findByTcodeAndLanguage(tabModel.getTcode(), "en");
		verify(coreLayoutTabDAO, atLeast(1)).findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),"0");
		verify(coreTabFieldsDAO, atLeast(1)).findByTcode(tabModel.getTcode());
		verify(coreMetadataDAO, atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", tabField.getFieldId(),tabField.getFieldId());
		verify(coreMetadataLangDAO, atLeast(3)).findByFieldIdAndLanguageAndTenantIdAndModuleId(metadata.getFieldId(), "en", "0", 1L);
	}

	@Test
	@DisplayName("getLayoutTest method to when field type is not FIELD")
	void getLayoutTestForText() {

		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));

		List<CoreTabFieldsModel> coreTabFields = new ArrayList<>();

		CoreTabFieldsModel tabField = new CoreTabFieldsModel();
		tabField.setFieldId("fieldId");
		tabField.setFieldType(FieldType.TEXT);

		coreTabFields.add(tabField);

		CoreLayoutTabModel layoutTab = new CoreLayoutTabModel();
		layoutTab.setIsTabReadOnly(false);
		layoutTab.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		layoutTab.setLayoutId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		layoutTab.setTabOrder((short) 1);
		List<CoreLayoutTabModel> list =new ArrayList<>(){{add(layoutTab);}};

		when(coreTabLabelsDAO.findByTcodeAndLanguage(tabModel.getTcode(), "en")).thenReturn(new CoreTabLabelsModel());
		when(coreLayoutTabDAO.findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),"0")).thenReturn(list);
		when(coreTabFieldsDAO.findByTcode(tabModel.getTcode())).thenReturn(coreTabFields);

		List<FetchedLayoutDTO> response = coreLayoutHeaderServiceImpl.getLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");

		assertNotNull(response,"response must not be null");

		verify(coreTabLabelsDAO, atLeast(1)).findByTcodeAndLanguage(tabModel.getTcode(), "en");
		verify(coreLayoutTabDAO, atLeast(1)).findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),"0");
		verify(coreTabFieldsDAO, atLeast(1)).findByTcode(tabModel.getTcode());
	}
	
	@Test
	@DisplayName("getLayoutTest3 method to test if there is no related tab found.")
	public void getLayoutTest3() {

		when(coreLayoutTabDAO.findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),"0")).thenReturn(null);
		
		List<FetchedLayoutDTO> response = coreLayoutHeaderServiceImpl.getLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");
		
		assertTrue(response.isEmpty(),"response must be empty");
		
		verify(coreLayoutTabDAO, atLeast(1)).findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),"0");
	}
	
	@Test
	@DisplayName("createUpdateLayoutTab to test create the layout tab.")
	void createUpdateLayoutTab() {
		
		LayoutTabDTO requestDTO = new LayoutTabDTO();
		requestDTO.setIsTabReadOnly(true);
		requestDTO.setTabOrder((short)1);
		requestDTO.setTabid("1444a553-1d90-4ee1-9b83-eaa68a28f17a");
		
		CoreTabModel coreTabModel = new CoreTabModel();
		coreTabModel.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		
		CoreLayoutTabModel layoutTab = new CoreLayoutTabModel();
		layoutTab.setUuid(UUID.randomUUID());
		
		when(coreLayoutHeaderDAO.findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L, "0")).thenReturn(new CoreLayoutHeaderModel());
		when(coreTabDAO.findByTcodeAndLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),1L, "0")).thenReturn(coreTabModel);
		when(coreLayoutTabDAO.findByTcodeAndLayoutIdAndTenantId(coreTabModel.getTcode(),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0")).thenReturn(null);
		when(coreLayoutTabDAO.save(any())).thenReturn(layoutTab);

		LayoutTabResponseDTO responseDTO = coreLayoutHeaderServiceImpl.createUpdateLayoutTab(requestDTO, 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "0");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreLayoutHeaderDAO,atLeast(1)).findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L, "0");
		verify(coreTabDAO,atLeast(1)).findByTcodeAndLayoutIdAndModuleIdAndTenantId(coreTabModel.getTcode(),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),1L, "0");
		verify(coreLayoutTabDAO,atLeast(1)).findByTcodeAndLayoutIdAndTenantId(coreTabModel.getTcode(),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0");
		verify(coreLayoutTabDAO,atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("createUpdateLayoutTab1 to test update the layout tab.")
	public void createUpdateLayoutTab1() {
		
		LayoutTabDTO requestDTO = new LayoutTabDTO();
		requestDTO.setIsTabReadOnly(true);
		requestDTO.setTabOrder((short)1);
		requestDTO.setTabid("1444a553-1d90-4ee1-9b83-eaa68a28f17a");
		CoreTabModel coreTabModel = new CoreTabModel();
		coreTabModel.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		
		CoreLayoutTabModel layoutTab = new CoreLayoutTabModel();
		layoutTab.setUuid(UUID.randomUUID());
		
		when(coreLayoutHeaderDAO.findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L, "0")).thenReturn(new CoreLayoutHeaderModel());
		when(coreTabDAO.findByTcodeAndLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),1L, "0")).thenReturn(coreTabModel);
		when(coreLayoutTabDAO.findByTcodeAndLayoutIdAndTenantId(coreTabModel.getTcode(),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0")).thenReturn(layoutTab);
		when(coreLayoutTabDAO.save(any())).thenReturn(layoutTab);
		
		LayoutTabResponseDTO responseDTO = coreLayoutHeaderServiceImpl.createUpdateLayoutTab(requestDTO, 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "0");
		
		assertTrue(responseDTO.isAcknowledge());
		
		verify(coreLayoutHeaderDAO,atLeast(1)).findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L, "0");
		verify(coreTabDAO,atLeast(1)).findByTcodeAndLayoutIdAndModuleIdAndTenantId(coreTabModel.getTcode(),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),1L, "0");
		verify(coreLayoutTabDAO,atLeast(1)).findByTcodeAndLayoutIdAndTenantId(coreTabModel.getTcode(),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0");
		verify(coreLayoutTabDAO,atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("createUpdateLayoutTab2 to test if layout tab id not present.")
	public void createUpdateLayoutTab2() {
		
		LayoutTabDTO requestDTO = new LayoutTabDTO();
		requestDTO.setIsTabReadOnly(true);
		requestDTO.setTabOrder((short)1);
		requestDTO.setTabid("1444a553-1d90-4ee1-9b83-eaa68a28f17a");
		
		when(coreLayoutHeaderDAO.findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L, "0")).thenReturn(new CoreLayoutHeaderModel());
		when(coreTabDAO.findByTcodeAndLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),1L, "0")).thenReturn(null);
		
		LayoutTabResponseDTO responseDTO = coreLayoutHeaderServiceImpl.createUpdateLayoutTab(requestDTO, 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "0");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreLayoutHeaderDAO,atLeast(1)).findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L, "0");
		verify(coreTabDAO,atLeast(1)).findByTcodeAndLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"),1L, "0");
	}
	
	@Test
	@DisplayName("createUpdateLayoutTab3 to test if layout not present.")
	public void createUpdateLayoutTab3() {
		
		LayoutTabDTO requestDTO = new LayoutTabDTO();
		requestDTO.setIsTabReadOnly(true);
		requestDTO.setTabOrder((short)1);
		
		when(coreLayoutHeaderDAO.findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L, "0")).thenReturn(null);
		
		LayoutTabResponseDTO responseDTO = coreLayoutHeaderServiceImpl.createUpdateLayoutTab(requestDTO, 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f17a", "0");
		
		assertFalse(responseDTO.isAcknowledge());
		
		verify(coreLayoutHeaderDAO,atLeast(1)).findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L, "0");
	}
	
	@Test
	@DisplayName("prepareMDOESRecordTest method to test fetching layout.")
	public void prepareMDOESRecordTest() {
		
		CoreTabModel tabModel = new CoreTabModel();
		tabModel.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"));
		
		List<CoreTabFieldsModel> coreTabFields = new ArrayList<>();
		
		CoreTabFieldsModel tabField = new CoreTabFieldsModel();
		tabField.setFieldId("fieldId");
		
		coreTabFields.add(tabField);
		
		List<CoreMetadataModel> metadataFields = new ArrayList<>();
		
		CoreMetadataModel metadata = new CoreMetadataModel();
		metadata.setFieldId("fieldId");
		metadata.setModuleId(1L);
		
		CoreMetadataModel metadata1 = new CoreMetadataModel();
		metadata1.setParentField("");
		metadata1.setFieldId("fieldId");
		metadata1.setModuleId(1L);
		
		CoreMetadataModel metadata2 = new CoreMetadataModel();
		metadata2.setParentField("fieldId");
		metadata2.setFieldId("fieldId");
		metadata2.setModuleId(1L);
		
		CoreMetadataLangModel metadataLang = new CoreMetadataLangModel();
		
		metadataLang.setShortText("message");
		metadataLang.setHelpText("message");
		metadataLang.setLongText("message");
		
		metadataFields.add(metadata);
		metadataFields.add(metadata1);
		metadataFields.add(metadata2);
		
		CoreTabLabelsModel lable = new CoreTabLabelsModel();
		lable.setTabText("tabtext");
		
		when(coreTabDAO.findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L,"0")).thenReturn(tabModel);
		when(coreTabFieldsDAO.findByTcode(tabModel.getTcode())).thenReturn(coreTabFields);
		when(coreTabLabelsDAO.findByTcodeAndLanguage(tabModel.getTcode(), "en")).thenReturn(lable);
		when(coreMetadataDAO.findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", tabField.getFieldId(),tabField.getFieldId())).thenReturn(metadataFields);
		when(coreMetadataLangDAO.findByFieldIdAndLanguageAndTenantIdAndModuleId(metadata.getFieldId(), "en", "0", 1L)).thenReturn(metadataLang);
		
		MDORecordES response = coreLayoutHeaderServiceImpl.prepareMDOESRecord("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");
		
		assertNotNull(response,"response must not be null");
		
		verify(coreTabDAO, atLeast(1)).findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L,"0");
		verify(coreTabFieldsDAO, atLeast(1)).findByTcode(tabModel.getTcode());
		verify(coreTabLabelsDAO, atLeast(1)).findByTcodeAndLanguage(tabModel.getTcode(), "en");
		verify(coreMetadataDAO, atLeast(1)).findByModuleIdAndTenantIdAndFieldIdOrParentField(1L, "0", tabField.getFieldId(),tabField.getFieldId());
		verify(coreMetadataLangDAO, atLeast(3)).findByFieldIdAndLanguageAndTenantIdAndModuleId(metadata.getFieldId(), "en", "0", 1L);
	}
	
	@Test
	@DisplayName("prepareMDOESRecordTest1 method to test exception handling.")
	public void prepareMDOESRecordTest1() {
		
		when(coreTabDAO.findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L,"0")).thenReturn(null);
		
		MDORecordES response = coreLayoutHeaderServiceImpl.prepareMDOESRecord("1444a553-1d90-4ee1-9b83-eaa68a28f17a", 1L, "en", "0");
		
		assertNull(response.getGvs(),"response must be null");
		
		verify(coreTabDAO, atLeast(1)).findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), 1L,"0");
	}

	@Test
	@DisplayName(" method to test generate Metadata Field")
	public void generateMetadataFieldTest() {

		CoreMetadataModel metadataModel=new CoreMetadataModel();
		metadataModel.setFieldId("test");
		metadataModel.setModuleId(1L);
		metadataModel.setTenantId("0");
		CoreMetadataModel secondMetadataModel=new CoreMetadataModel();
		secondMetadataModel.setFieldId("test2");
		secondMetadataModel.setModuleId(1L);
		secondMetadataModel.setTenantId("0");
		CoreMetadataLangModel metadataLang=new CoreMetadataLangModel();
		metadataLang.setShortText("short");
		metadataLang.setHelpText("help");
		metadataLang.setLongText("long");
		CoreMetadataLangModel emptyMetadataLang=new CoreMetadataLangModel();
		ObjectMapper mapper=new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		doReturn(metadataLang).when(coreMetadataLangDAO).findByFieldIdAndLanguageAndTenantIdAndModuleId("test","en","0",1L);
		doReturn(emptyMetadataLang).when(coreMetadataLangDAO).findByFieldIdAndLanguageAndTenantIdAndModuleId("test2","en","0",1L);

		FieldDTO testDto=coreLayoutHeaderServiceImpl.generateMetadataField("en","0",mapper,metadataModel);
		FieldDTO emptyTestDto=coreLayoutHeaderServiceImpl.generateMetadataField("en","0",mapper,secondMetadataModel);

		assertEquals(testDto.getShortText().get("en").getDescription(),metadataLang.getShortText());
		assertEquals(testDto.getLongtexts().get("en"),metadataLang.getLongText());
		assertEquals(testDto.getShortText().get("en").getInformation(),metadataLang.getHelpText());
        assertNull(emptyTestDto.getLongtexts().get("en"));
	}

	@Test
	@DisplayName("Delete Layout Test when id is Present")
	void deleteLayout() {

		LayoutTabDTO requestDTO = new LayoutTabDTO();
		requestDTO.setIsTabReadOnly(true);
		requestDTO.setTabOrder((short)1);
		requestDTO.setTabid("1444a553-1d90-4ee1-9b83-eaa68a28f17a");

		CoreLayoutTabModel model =new CoreLayoutTabModel();
		model.setIsTabReadOnly(false);
		model.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17"));
		List<UUID> tabCode=new ArrayList<>(){{add(model.getTcode());}};
		List<CoreLayoutTabModel> list =new ArrayList<>(){{add(model);}};

		CoreTabFieldsModel coreTabFieldsModel =new CoreTabFieldsModel();
		coreTabFieldsModel.setFieldId("fieldId");
		List<CoreTabFieldsModel> tabFieldsModels=new ArrayList<>(){{add(coreTabFieldsModel);}};

		when(coreLayoutHeaderDAO.findByLayoutIdAndTenantId(UUID.fromString("9ed2b4b4-1eee-49d5-a78e-362ae2526976"), "0")).thenReturn(java.util.Optional.of(new CoreLayoutHeaderModel()));
		when(coreLayoutTabDAO.findByLayoutIdAndTenantId(UUID.fromString("9ed2b4b4-1eee-49d5-a78e-362ae2526976"), "0")).thenReturn(list);
		when(coreTabFieldsDAO.findByTcodeIn(tabCode)).thenReturn(java.util.Optional.of(tabFieldsModels));

		LayoutResponseDTO responseDTO = coreLayoutHeaderServiceImpl.deleteLayout("9ed2b4b4-1eee-49d5-a78e-362ae2526976", "0");

		assertTrue(responseDTO.isAcknowledge());

		verify(coreLayoutHeaderDAO,atLeast(1)).findByLayoutIdAndTenantId(UUID.fromString("9ed2b4b4-1eee-49d5-a78e-362ae2526976"), "0");
		verify(coreLayoutTabDAO,atLeast(1)).findByLayoutIdAndTenantId(UUID.fromString("9ed2b4b4-1eee-49d5-a78e-362ae2526976"), "0");
		verify(coreTabFieldsDAO,atLeast(1)).findByTcodeIn(tabCode);

	}
	@Test
	@DisplayName("Delete Layout Test when Layout id is not Present")
	void deleteLayoutTabException() {

		when(coreLayoutHeaderDAO.findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0")).thenReturn(Optional.empty());

		assertThrows(NotFound404Exception.class,()->coreLayoutHeaderServiceImpl.deleteLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", "0"));

		verify(coreLayoutHeaderDAO,atLeast(1)).findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0");

	}
	@Test
	@DisplayName("Delete Layout Test when Layout Tabs are not Present")
	void deleteLayoutTabTest() {

		LayoutTabDTO requestDTO = new LayoutTabDTO();
		requestDTO.setIsTabReadOnly(true);
		requestDTO.setTabOrder((short)1);
		requestDTO.setTabid("1444a553-1d90-4ee1-9b83-eaa68a28f17a");

		CoreLayoutTabModel model =new CoreLayoutTabModel();
		model.setIsTabReadOnly(false);
		model.setTcode(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17"));
		List<UUID> tabCode=new ArrayList<>(){{add(model.getTcode());}};
		List<CoreLayoutTabModel> list =new ArrayList<>();

		CoreTabFieldsModel coreTabFieldsModel =new CoreTabFieldsModel();
		coreTabFieldsModel.setFieldId("fieldId");
		List<CoreTabFieldsModel> tabFieldsModels=new ArrayList<>(){{add(coreTabFieldsModel);}};

		when(coreLayoutHeaderDAO.findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0")).thenReturn(java.util.Optional.of(new CoreLayoutHeaderModel()));
		when(coreLayoutTabDAO.findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0")).thenReturn(list);

		LayoutResponseDTO responseDTO = coreLayoutHeaderServiceImpl.deleteLayout("1444a553-1d90-4ee1-9b83-eaa68a28f17a", "0");

		assertTrue(responseDTO.isAcknowledge());

		verify(coreLayoutHeaderDAO,atLeast(1)).findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0");
		verify(coreLayoutTabDAO,atLeast(1)).findByLayoutIdAndTenantId(UUID.fromString("1444a553-1d90-4ee1-9b83-eaa68a28f17a"), "0");

	}

	@Test
	@DisplayName("Fetch Layout List Test")
	void fetchLayoutList() {

		CoreLayoutHeaderModel model = new CoreLayoutHeaderModel();
		model.setDescription("test");
		model.setType(Short.parseShort("0"));
		List<CoreLayoutHeaderModel> modelList = new ArrayList<>(){{
			add(model);
		}};
		LayoutListRequestDTO emptyDto = new LayoutListRequestDTO();
		when(coreLayoutHeaderDAO.findLayoutList(any(), any(),any(),any(),any(),any(),any(),any(), any(Pageable.class))).thenReturn(modelList);
		List<LayoutDetailsResponseDTO> dto = coreLayoutHeaderServiceImpl.listLayouts(1L,"0","",0,1,emptyDto,1630412013513L,1630412013513L);

		assertFalse(dto.isEmpty());

		verify(coreLayoutHeaderDAO,atLeast(1)).findLayoutList(any(), any(),any(),any(),any(),any(),any(),any(),  any(Pageable.class));

	}

	@Test
	@DisplayName("Fetch Layout Test")
	void fetchLayout() {

		CoreLayoutHeaderModel model = new CoreLayoutHeaderModel();
		model.setDescription("test");
		model.setType(Short.parseShort("0"));

		when(coreLayoutHeaderDAO.findByLayoutIdAndModuleIdAndTenantId(any(), any(),any())).thenReturn(model);
		LayoutDetailsResponseDTO dto = coreLayoutHeaderServiceImpl.getLayout("509415c9-92f8-473a-a898-9fb3d657a165",1L,"0");

		assertEquals(dto.getDescription(),"test");

		verify(coreLayoutHeaderDAO,atLeast(1)).findByLayoutIdAndModuleIdAndTenantId(UUID.fromString("509415c9-92f8-473a-a898-9fb3d657a165"), 1L,"0");

	}

	@Test
	@DisplayName("Fetch Layout Count")
	void fetchLayoutCount() {


		when(coreLayoutHeaderDAO.countByModuleIdAndTenantId(1L, "0")).thenReturn(1L);

		Map<String,Long> count = coreLayoutHeaderServiceImpl.layoutCount(1L,"0");

		assertEquals(1L,count.get("count"));

		verify(coreLayoutHeaderDAO,atLeast(1)).countByModuleIdAndTenantId(1L, "0");

	}

	@Test
	@DisplayName("Test Module Meta Generation")
	void generateModuleMeta() {

		CoreMetadataLangModel landModel = new CoreMetadataLangModel();

		CoreModuleDescriptionModel descriptionModel = new CoreModuleDescriptionModel();
		descriptionModel.setDescription("test");
		descriptionModel.setModuleId(1L);
		descriptionModel.setInformation("info");
		descriptionModel.setLanguage("en");

		CoreMetadataModel model = new CoreMetadataModel();
		model.setModuleId(1L);

		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		when(coreMetadataLangDAO.findByFieldIdAndLanguageAndTenantIdAndModuleId(any(),any(),any(),any())).thenReturn(landModel);
		when(coreModuleDescriptionDAO.findByModuleIdAndTenantIdAndLanguage(any(),any(),any())).thenReturn(descriptionModel);

		FieldDTO dto = coreLayoutHeaderServiceImpl.generateMetadata("en","0",mapper,model);

		assertNotNull(dto);

	}

	@Test
	@DisplayName("Save Layout Details Test")
	void saveLayoutDetails() {

		CoreLayoutHeaderServiceImpl spyTemp = Mockito.spy(coreLayoutHeaderServiceImpl);


		FetchedLayoutDTO dto = new FetchedLayoutDTO();
		dto.setIsTabHidden(false);

		FetchedLayoutDTO dtoUpdate = new FetchedLayoutDTO();
		dtoUpdate.setIsTabHidden(false);
		dtoUpdate.setTcode(UUID.randomUUID());

		LayoutFieldsDTO fieldsDTO = new LayoutFieldsDTO();
		fieldsDTO.setFieldType(FieldType.FIELD);
		fieldsDTO.setFieldId("Field");

		LayoutFieldsDTO fieldsDTOUpdate = new LayoutFieldsDTO();
		fieldsDTO.setFieldType(FieldType.FIELD);
		fieldsDTO.setFieldId("Field");
		fieldsDTO.setTabFieldUuid(UUID.randomUUID());


		dto.setFields(List.of(fieldsDTO));
		dtoUpdate.setFields(List.of(fieldsDTOUpdate));


		List<FetchedLayoutDTO> dtoList = List.of(dtoUpdate,dto);

		TabResponseDTO responseDTO = new TabResponseDTO();
		responseDTO.setAcknowledge(true);
		responseDTO.setTcode(UUID.randomUUID().toString());

		LayoutTabResponseDTO layoutTabResponseDTO = new LayoutTabResponseDTO();
		layoutTabResponseDTO.setAcknowledge(true);

		when(coreTabService.createTab(any(), any(),any(),any())).thenReturn(responseDTO);
		when(coreTabService.updateTab(any(), any(),any(),any(),any())).thenReturn(responseDTO);

		Mockito.doReturn(layoutTabResponseDTO).when(spyTemp).createUpdateLayoutTab(any(),any(),any(),any());

		List<FetchedLayoutDTO> layout = spyTemp.saveLayoutDetails("509415c9-92f8-473a-a898-9fb3d657a165",dtoList,1L,"0","en","Admin");

		assertEquals(2,layout.size());

	}

	@Test
	@DisplayName("Save Layout Details Exception Test")
	void saveLayoutDetailsException() {

		CoreLayoutHeaderServiceImpl spyTemp = Mockito.spy(coreLayoutHeaderServiceImpl);


		FetchedLayoutDTO dto = new FetchedLayoutDTO();
		dto.setIsTabHidden(false);

		FetchedLayoutDTO dtoUpdate = new FetchedLayoutDTO();
		dtoUpdate.setIsTabHidden(false);
		dtoUpdate.setTcode(UUID.randomUUID());

		LayoutFieldsDTO fieldsDTO = new LayoutFieldsDTO();
		fieldsDTO.setFieldType(FieldType.FIELD);
		fieldsDTO.setFieldId("Field");

		LayoutFieldsDTO fieldsDTOUpdate = new LayoutFieldsDTO();
		fieldsDTO.setFieldType(FieldType.FIELD);
		fieldsDTO.setFieldId("Field");
		fieldsDTO.setTabFieldUuid(UUID.randomUUID());


		dto.setFields(List.of(fieldsDTO));
		dtoUpdate.setFields(List.of(fieldsDTOUpdate));


		List<FetchedLayoutDTO> dtoList = List.of(dtoUpdate,dto);

		TabResponseDTO responseDTO = new TabResponseDTO();
		responseDTO.setAcknowledge(false);
		responseDTO.setTcode(UUID.randomUUID().toString());

		LayoutTabResponseDTO layoutTabResponseDTO = new LayoutTabResponseDTO();
		layoutTabResponseDTO.setAcknowledge(true);

		when(coreTabService.updateTab(any(), any(),any(),any(),any())).thenReturn(responseDTO);

		Mockito.doReturn(layoutTabResponseDTO).when(spyTemp).createUpdateLayoutTab(any(),any(),any(),any());

		assertThrows(NotFound404Exception.class,()-> spyTemp.saveLayoutDetails("509415c9-92f8-473a-a898-9fb3d657a165",
				dtoList,1L,"0","en","Admin"));

		layoutTabResponseDTO.setAcknowledge(false);
		responseDTO.setAcknowledge(true);

		assertThrows(NotFound404Exception.class,()-> spyTemp.saveLayoutDetails("509415c9-92f8-473a-a898-9fb3d657a165",
				dtoList,1L,"0","en","Admin"));
	}
	
	@Test
	@DisplayName("createLayoutTest method test for create rule mapping")
	public void createRuleMappingTest() {

		RuleMappingRequestDTO ruleMappingRequestDTO = new RuleMappingRequestDTO();
		List<UUID> ruleMappingIds = new ArrayList<>();
		ruleMappingIds.add(UUID.randomUUID());
		ruleMappingIds.add(UUID.randomUUID());
		ruleMappingRequestDTO.setRuleMappingIds(ruleMappingIds);

		CoreLayoutRuleMappingModel ruleMapping = new CoreLayoutRuleMappingModel();
		ruleMapping.setLayoutId(UUID.randomUUID());
		
		when(coreLayoutRuleMappingDAO.findByLayoutIdAndModuleIdAndTenantId(any(), any(), any())).thenReturn(new CoreLayoutRuleMappingModel());

		RuleMappingResponseDTO responseDTO = coreLayoutHeaderServiceImpl.createOrUpdateRuleMapping(ruleMappingRequestDTO, 1L, "1444a553-1d90-4ee1-9b83-eaa68a28f1", "0");

		assertTrue(responseDTO.isAcknowledge());

	}
	
	@Test
	@DisplayName("Delete rule mapping Test")
	void deleteRuleMapping() {

		RuleMappingRequestDTO ruleMappingRequestDTO = new RuleMappingRequestDTO();
		List<UUID> ruleMappingIds = new ArrayList<>();
		ruleMappingIds.add(UUID.randomUUID());
		ruleMappingIds.add(UUID.randomUUID());
		ruleMappingRequestDTO.setRuleMappingIds(ruleMappingIds);
		
		RuleMappingResponseDTO responseDTO = coreLayoutHeaderServiceImpl.deleteRuleMapping(ruleMappingRequestDTO, 1L, "9ed2b4b4-1eee-49d5-a78e-362ae2526976", "0");

		assertTrue(responseDTO.isAcknowledge());
		
	}
}



