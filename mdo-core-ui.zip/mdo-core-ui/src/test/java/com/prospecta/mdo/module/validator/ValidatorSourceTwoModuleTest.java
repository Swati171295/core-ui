package com.prospecta.mdo.module.validator;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import javax.validation.ConstraintValidatorContext;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinInfoRequestDTO;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class ValidatorSourceTwoModuleTest {
	
	@Mock
	private ValidateSourceTwoModule validateSourceTwoModule;
	
	 @Mock
	 private ConstraintValidatorContext constraintValidatorContext;
	 
	 @Test
	 @DisplayName("isValidTest method test for custom validation exception")
	 void isValidTest() {
		 when(validateSourceTwoModule.fieldName()).thenReturn("sourceTwoType");
		 when(validateSourceTwoModule.fieldValue()).thenReturn("module");
		 when(validateSourceTwoModule.dependFieldName()).thenReturn("sourceTwoModule");
		 when(validateSourceTwoModule.message()).thenReturn("Please provide source module id");
		 ValidatorSourceTwoModule validatorSourceTwoModule = new ValidatorSourceTwoModule();
		 validatorSourceTwoModule.initialize(validateSourceTwoModule);
		 VdGroupJoinInfoRequestDTO vdGroupJoinInfoRequestDTO = new VdGroupJoinInfoRequestDTO();
		 vdGroupJoinInfoRequestDTO.setSourceTwoType("module");
		 vdGroupJoinInfoRequestDTO.setSourceTwoModule(null);
		 boolean result = validatorSourceTwoModule.isValid(vdGroupJoinInfoRequestDTO, constraintValidatorContext);
		 assertFalse(result);
	 }
	 
	 @Test
	 @DisplayName("isValidNullTest method test for custom validation exception")
	 void isValidNullTest() {
		 ValidatorSourceTwoModule validatorSourceTwoModule = new ValidatorSourceTwoModule();
		 validatorSourceTwoModule.initialize(validateSourceTwoModule);
		 boolean result = validatorSourceTwoModule.isValid(null, constraintValidatorContext);
		 assertTrue(result);
	 }

}
