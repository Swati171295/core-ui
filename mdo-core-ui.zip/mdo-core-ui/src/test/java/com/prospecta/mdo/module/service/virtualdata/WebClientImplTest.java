package com.prospecta.mdo.module.service.virtualdata;

import com.nimbusds.jose.JOSEException;
import com.prospecta.mdo.module.component.JWTTokenProvider;
import com.prospecta.mdo.module.dto.virtualdata.*;
import com.prospecta.mdo.module.exception.CommonVirtualDatasetException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@SpringBootTest
@ActiveProfiles("test")
@ExtendWith(MockitoExtension.class)
public class WebClientImplTest {

	@InjectMocks
	@Autowired
	private static WebClientImpl controllerMock;

	private static WebClient webclient;

	private static WebClient.Builder webClientBuilder;

	private static final String PAYLOAD = "{\"username\":\"initiator\",\"roles\":[],\"tenantCode\":\"0\"}";

	@Autowired
	private JWTTokenProvider jWTTokenProvider;

	@BeforeAll
	public static void setup() {

		webClientBuilder = WebClient.builder();
		controllerMock = new WebClientImpl(webClientBuilder);
		ReflectionTestUtils.setField(controllerMock, "serverUrl", "https://dev.masterdataonline.com/core");
		ReflectionTestUtils.setField(controllerMock, "sparkEndPoint", "https://dev.masterdataonline.com/core");
		webclient = webClientBuilder.build();
	}

	//@Test
	@DisplayName("deleteUdrIdTest method test for deleting data")
	void deleteUdrIdTest() throws JOSEException {

		String jwtToken = jWTTokenProvider.createToken(PAYLOAD);
		DeleteUdrResponse expectedData = new DeleteUdrResponse();
		expectedData.setAcknowledge(false);
		expectedData.setErrorMsg("No data found to delete");
		expectedData.setResponse(null);

		DeleteUdrResponse actualData = controllerMock.deleteUdrId("787878", jwtToken);
		assertNotNull(controllerMock.deleteUdrId("787878", jwtToken));
		assertEquals(expectedData, actualData);
	}

	@Test
	@DisplayName("deleteUdrIdCatchTest method test for testing exception")
	void deleteUdrIdCatchTest() throws JOSEException {
		String jwtToken = jWTTokenProvider.createToken(PAYLOAD);
		Assertions.assertThrows(RuntimeException.class, () -> {
			controllerMock.deleteUdrId(null, jwtToken);
		});
	}

	@Test
	@DisplayName("deleteUdrIdExceptionTest method test for testing exception")
	void deleteUdrIdExceptionTest() throws JOSEException {
		String jwtToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ7XCJ1c2VybmFtZVwiOlwiVGVjaC5FeHBlcnRcIn0iLCJpc3MiOiJNRE8iLCJleHAiOjE2MjE4MzE3NTgsImlhdCI6MTYyMTgzMDg1OH0.gpH_DJu3QsKGYyUQoC5saTY0CdsN5vz02prCezN20ck";
		Assertions.assertThrows(RuntimeException.class, () -> {
			controllerMock.deleteUdrId(null, jwtToken);
		});
	}

	//@Test
	@DisplayName("getVirtualDataUdrIdTest method test for getting data")
	void getVirtualDataUdrIdTest() throws JOSEException {

		String jwtToken = jWTTokenProvider.createToken(PAYLOAD);
		UdrResponseDTO expectedData = new UdrResponseDTO();
		List<UdrIdChildResponseDTO> when = new ArrayList<>();
		List<UdrIdChildResponseDTO> then = new ArrayList<>();
		expectedData.setThen(then);
		expectedData.setWhen(when);
		expectedData.setBrInfo(null);

		UdrResponseDTO actualData = controllerMock.getVirtualDataUdrId(Long.parseLong("787878"), jwtToken);
		assertNotNull(controllerMock.getVirtualDataUdrId(Long.parseLong("787878"), jwtToken));
		assertEquals(expectedData, actualData);
	}

	@Test
	@DisplayName("getVirtualDataUdrIdCatchTest method test for testing exception")
	void getVirtualDataUdrIdCatchTest() throws JOSEException {
		String jwtToken = jWTTokenProvider.createToken(PAYLOAD);
		Assertions.assertThrows(RuntimeException.class, () -> {
			controllerMock.getVirtualDataUdrId(null, jwtToken);
		});
	}

	@Test
	@DisplayName("getVirtualDataUdrIdExceptionTest method test for testing exception")
	void getVirtualDataUdrIdExceptionTest() throws JOSEException {
		String jwtToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ7XCJ1c2VybmFtZVwiOlwiVGVjaC5FeHBlcnRcIn0iLCJpc3MiOiJNRE8iLCJleHAiOjE2MjE4MzE3NTgsImlhdCI6MTYyMTgzMDg1OH0.gpH_DJu3QsKGYyUQoC5saTY0CdsN5vz02prCezN20ck";
		Assertions.assertThrows(RuntimeException.class, () -> {
			controllerMock.getVirtualDataUdrId(null, jwtToken);
		});
	}

	@Test
	@DisplayName("saveScheduleJobTest method test for save data")
	void saveScheduleJobTest() throws JOSEException {

		String jwtToken = jWTTokenProvider.createToken(PAYLOAD);

		RestJobRequestDTO requestDTO = new RestJobRequestDTO();
		requestDTO.setJobId(UUID.randomUUID());
		requestDTO.setVdId(UUID.randomUUID());
		requestDTO.setVdObject("abc");
		requestDTO.setRestEndpoint("sample rest endpoint");
		Map<String, String> map = new HashMap<>();
		map.put("value1", "value2");
		requestDTO.setRestParams(map);
		requestDTO.setRestBody("sample rest body");
		requestDTO.setRestMethod(HttpMethod.POST);
		requestDTO.setTenantId("6a3895d3-fc89-41f8-8975-8ca70ada27c7");
		requestDTO.setStartTime(Long.valueOf(78789));
		requestDTO.setEndTime(Long.valueOf(78789));
		requestDTO.setCron("0 0   0");

		Assertions.assertThrows(RuntimeException.class, () -> {
			controllerMock.saveScheduleJob(requestDTO, jwtToken);
		});
	}

	@Test
	@DisplayName("saveScheduleJobCatchTest method test for test exception")
	void saveScheduleJobCatchTest() throws JOSEException {
		String jwtToken = jWTTokenProvider.createToken(PAYLOAD);
		Assertions.assertThrows(RuntimeException.class, () -> {
			controllerMock.saveScheduleJob(null, jwtToken);
		});
	}

	@Test
	@DisplayName("saveScheduleJobTokenTest method test for test exception")
	void saveScheduleJobTokenTest() throws JOSEException {
		String jwtToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ7XCJ1c2VybmFtZVwiOlwiVGVjaC5FeHBlcnRcIn0iLCJpc3MiOiJNRE8iLCJleHAiOjE2MjE4MzE3NTgsImlhdCI6MTYyMTgzMDg1OH0.gpH_DJu3QsKGYyUQoC5saTY0CdsN5vz02prCezN20ck";
		Assertions.assertThrows(RuntimeException.class, () -> {
			controllerMock.saveScheduleJob(null, jwtToken);
		});
	}

	
	@Test
	@DisplayName("sendToSparkTest method test for send scheduler information to spark job")
	void sendToSparkTest() throws JOSEException {
		SyncReqDTO syncReq = new SyncReqDTO();
		String jwtToken = jWTTokenProvider.createToken(PAYLOAD);
		Assertions.assertThrows(CommonVirtualDatasetException.class, () -> {controllerMock.sendToSpark(syncReq,jwtToken);});
	}
	
	@Test
	@DisplayName("sendToSparkTestInternalError method test for send scheduler information to spark job exception")
	void sendToSparkTestInternalError() throws JOSEException {
		SyncReqDTO syncReq = new SyncReqDTO();
		String jwtToken = jWTTokenProvider.createToken(PAYLOAD);
		ResponseEntity<HashMap> test = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		Assertions.assertThrows(CommonVirtualDatasetException.class, () -> {when(controllerMock.sendToSpark(syncReq,jwtToken)).thenReturn(test);});
		
		
	}
	
	@Test
	@DisplayName("sendToSparkTestUnauthorization method test for send scheduler information to spark job exception")
	void sendToSparkTestUnauthorization() throws JOSEException {
		SyncReqDTO syncReq = new SyncReqDTO();
		ResponseEntity<HashMap> test = new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		Assertions.assertThrows(CommonVirtualDatasetException.class, () -> {when(controllerMock.sendToSpark(syncReq,"")).thenReturn(test);});
	}
	
	@Test
	@DisplayName("sendToSparkCatchTest method test for test exception")
	void sendToSparkCatchTest() throws JOSEException {
		String jwtToken = jWTTokenProvider.createToken(PAYLOAD);
		Assertions.assertThrows(RuntimeException.class, () -> {controllerMock.sendToSpark(null,jwtToken);});
	}
	
	@Test
	@DisplayName("sendToSparkTokenTest method test for test exception")
	void sendToSparkTokenTest() throws JOSEException {
		String jwtToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ7XCJ1c2VybmFtZVwiOlwiVGVjaC5FeHBlcnRcIn0iLCJpc3MiOiJNRE8iLCJleHAiOjE2MjE4MzE3NTgsImlhdCI6MTYyMTgzMDg1OH0.gpH_DJu3QsKGYyUQoC5saTY0CdsN5vz02prCezN20ck";
		Assertions.assertThrows(RuntimeException.class, () -> {controllerMock.sendToSpark(null,jwtToken);});
	}

}
