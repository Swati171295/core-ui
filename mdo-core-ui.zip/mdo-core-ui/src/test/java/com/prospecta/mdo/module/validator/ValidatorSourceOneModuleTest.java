package com.prospecta.mdo.module.validator;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import javax.validation.ConstraintValidatorContext;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinInfoRequestDTO;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class ValidatorSourceOneModuleTest {
	
	@Mock
	private ValidateSourceOneModule validateSourceOneModule;
	
	 @Mock
	 private ConstraintValidatorContext constraintValidatorContext;
	 
	 @Test
	 @DisplayName("isValidTest method test for custom validation exception")
	 void isValidTest() {
		 when(validateSourceOneModule.fieldName()).thenReturn("sourceOneType");
		 when(validateSourceOneModule.fieldValue()).thenReturn("module");
		 when(validateSourceOneModule.dependFieldName()).thenReturn("sourceOneModule");
		 when(validateSourceOneModule.message()).thenReturn("Please provide source module id");
		 ValidatorSourceOneModule validatorSourceOneModule = new ValidatorSourceOneModule();
		 validatorSourceOneModule.initialize(validateSourceOneModule);
		 VdGroupJoinInfoRequestDTO vdGroupJoinInfoRequestDTO = new VdGroupJoinInfoRequestDTO();
		 vdGroupJoinInfoRequestDTO.setSourceOneType("module");
		 vdGroupJoinInfoRequestDTO.setSourceOneModule(null);
		 boolean result = validatorSourceOneModule.isValid(vdGroupJoinInfoRequestDTO, constraintValidatorContext);
		 assertFalse(result);
	 }
	 
	 @Test
	 @DisplayName("isValidNullTest method test for custom validation exception")
	 void isValidNullTest() {
		 ValidatorSourceOneModule validatorSourceOneModule = new ValidatorSourceOneModule();
		 validatorSourceOneModule.initialize(validateSourceOneModule);
		 boolean result = validatorSourceOneModule.isValid(null, constraintValidatorContext);
		 assertTrue(result);
	 }

}
