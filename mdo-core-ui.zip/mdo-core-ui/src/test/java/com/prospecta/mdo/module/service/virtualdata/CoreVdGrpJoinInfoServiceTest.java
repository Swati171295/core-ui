package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpJoinInfoDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdGroupJoinInfoRequestDTO;
import com.prospecta.mdo.module.enums.JoinOperator;
import com.prospecta.mdo.module.enums.JoinType;
import com.prospecta.mdo.module.enums.SourceType;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpJoinInfoModel;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class CoreVdGrpJoinInfoServiceTest {
	
	@InjectMocks
	private CoreVdGrpJoinInfoServiceImpl coreVdGrpJoinInfoServiceImpl;
	
	@Mock
	private CoreVdGrpJoinInfoDAO coreVdGrpJoinInfoDAO;
	
	@Mock
	private CoreVdGroupsDAO coreVdGroupsDAO;

	
	@BeforeAll
	void init() {
		coreVdGrpJoinInfoServiceImpl = new CoreVdGrpJoinInfoServiceImpl();
	}
	
	@Test
	@DisplayName("getVdJoinInfobyJoinIdTest method test for getting virtual dataset join info by JoinId")
	void getVdJoinInfobyJoinIdTest() {		
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = spy(CoreVdGrpJoinInfoModel.class);
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinInfoDAO.findById(id)).thenReturn(Optional.of(coreVdGrpJoinInfoModel));
		coreVdGrpJoinInfoModel = coreVdGrpJoinInfoServiceImpl.getVdJoinInfobyJoinId(id);
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).findById(any());
		
	}
	
	@Test
	@DisplayName("getVdJoinInfobyJoinIdExceptionTest method test for test exception")
	void getVdJoinInfobyJoinIdExceptionTest() {		
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinInfoDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGrpJoinInfoModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinInfoServiceImpl.getVdJoinInfobyJoinId(id));
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).findById(any());
		
	}
	
	@Test
	@DisplayName("getVdJoinInfobyGroupIdTest method test for getting virtual dataset join info by GroupId")
	void getVdJoinInfobyGroupIdTest() {
		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = spy(CoreVdGrpJoinInfoModel.class);
		coreVdGrpJoinInfoModel.setCoreVdGroups(coreVdGroupsModel);
		List<CoreVdGrpJoinInfoModel> coreVdGrpJoinInfoModelList = new ArrayList<>();
		coreVdGrpJoinInfoModelList.add(coreVdGrpJoinInfoModel);
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinInfoDAO.findByCoreVdGroups(coreVdGroupsModel)).thenReturn(coreVdGrpJoinInfoModelList);
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		List<CoreVdGrpJoinInfoModel> CoreVdGrpJoinInfoList = coreVdGrpJoinInfoServiceImpl.getVdJoinInfobyGroupId(id);
		assertNotNull(CoreVdGrpJoinInfoList);
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).findByCoreVdGroups(any());
		
	}
	@Test
	@DisplayName("getVdJoinInfobyGroupIdExceptionTest method test for test exception")
	void getVdJoinInfobyGroupIdExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinInfoServiceImpl.getVdJoinInfobyGroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		
	}
	@Test
	@DisplayName("getVdJoinInfobyGroupIdListExceptionTest method test for test exception")
	void getVdJoinInfobyGroupIdListExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		List<CoreVdGrpJoinInfoModel> coreVdGrpJoinInfoModelList = new ArrayList<>();
		UUID id = UUID.randomUUID();
		when(coreVdGrpJoinInfoDAO.findByCoreVdGroups(coreVdGroupsModel)).thenReturn(coreVdGrpJoinInfoModelList);
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinInfoServiceImpl.getVdJoinInfobyGroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).findByCoreVdGroups(any());
		
	}
	
	@Test
	@DisplayName("deleteVdJoinInfobyJoinIdTest method test for deleting virtual dataset join info by JoinId")
	void deleteVdJoinInfobyJoinIdTest() {
		UUID id = UUID.randomUUID();
		doNothing().when(coreVdGrpJoinInfoDAO).deleteById(id);
		coreVdGrpJoinInfoServiceImpl.deleteVdJoinInfobyJoinId(id);
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).deleteById(any());
	}
	
	@Test
	@DisplayName("deleteVdJoinInfobyGroupIdTest method test for deleting virtual dataset join info by GroupId")
	void deleteVdJoinInfobyGroupIdTest() {
		
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		doNothing().when(coreVdGrpJoinInfoDAO).deleteByCoreVdGroups(coreVdGroupsModel);
		coreVdGrpJoinInfoServiceImpl.deleteVdJoinInfobyGroupId(id);
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).deleteByCoreVdGroups(any());
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		
	}
	
	@Test
	@DisplayName("deleteVdJoinInfobyGroupIdExceptionTest method test for exception handling")
	void deleteVdJoinInfobyGroupIdExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel= null;
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class,()->coreVdGrpJoinInfoServiceImpl.deleteVdJoinInfobyGroupId(id));		
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		
	}
	
	@Test
	@DisplayName("saveAndUpdateGrpJoinInfoTest method test for test save or update")
	void saveAndUpdateGrpJoinInfoTest() {
		VdGroupJoinInfoRequestDTO requestDto = new VdGroupJoinInfoRequestDTO();
		requestDto.setResultScopeUdr("123");
		requestDto.setSourceOneScopeUdr("12345");
		requestDto.setSourceTwoScopeUdr("123");
		requestDto.setSourceOneType("MODULE");
		requestDto.setSourceTwoType("MODULE");
		requestDto.setJoinType("INNER");
		requestDto.setJoinOperator("AND");
		requestDto.setSourceOneModule(null);
		requestDto.setSourceTwoModule(null);
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupName("Sample Name");
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();
		coreVdGrpJoinInfoModel.setUuid(any());
		coreVdGrpJoinInfoModel.setResultScopeUdrId(requestDto.getResultScopeUdr());
		coreVdGrpJoinInfoModel.setSourceOneScopeUdrId(requestDto.getSourceOneScopeUdr());
		coreVdGrpJoinInfoModel.setSourceTwoScopeUdrId(requestDto.getSourceTwoScopeUdr());
		coreVdGrpJoinInfoModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdGrpJoinInfoModel.setSourceOneType(SourceType.fromValue(requestDto.getSourceOneType()));
		coreVdGrpJoinInfoModel.setSourceTwoType(SourceType.fromValue(requestDto.getSourceTwoType()));
		coreVdGrpJoinInfoModel.setJoinType(JoinType.fromValue(requestDto.getJoinType()));
		coreVdGrpJoinInfoModel.setJoinOperator(JoinOperator.fromValue(requestDto.getJoinOperator()));
		coreVdGrpJoinInfoModel.setSourceOneModuleId(requestDto.getSourceOneModule());
		coreVdGrpJoinInfoModel.setSourceTwoModuleId(requestDto.getSourceTwoModule());
		
		when(coreVdGrpJoinInfoDAO.save(coreVdGrpJoinInfoModel)).thenReturn(coreVdGrpJoinInfoModel);
		coreVdGrpJoinInfoServiceImpl.saveAndUpdateGrpJoinInfo(requestDto, coreVdGroupsModel);
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("saveAndUpdateGrpJoinInfoWithGroupIdNullTest method test for test save or update")
	void saveAndUpdateGrpJoinInfoWithGroupIdNullTest() {
		VdGroupJoinInfoRequestDTO requestDto = new VdGroupJoinInfoRequestDTO();
		requestDto.setGroupJoinId(UUID.randomUUID());
		requestDto.setResultScopeUdr("123");
		requestDto.setSourceOneScopeUdr("12345");
		requestDto.setSourceTwoScopeUdr("123");
		requestDto.setSourceOneType("MODULE");
		requestDto.setSourceTwoType("MODULE");
		requestDto.setJoinType("INNER");
		requestDto.setJoinOperator("AND");
		requestDto.setSourceOneModule(null);
		requestDto.setSourceTwoModule(null);
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupName("Sample Name");
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();
		coreVdGrpJoinInfoModel.setUuid(any());
		coreVdGrpJoinInfoModel.setResultScopeUdrId(requestDto.getResultScopeUdr());
		coreVdGrpJoinInfoModel.setSourceOneScopeUdrId(requestDto.getSourceOneScopeUdr());
		coreVdGrpJoinInfoModel.setSourceTwoScopeUdrId(requestDto.getSourceTwoScopeUdr());
		coreVdGrpJoinInfoModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdGrpJoinInfoModel.setSourceOneType(SourceType.fromValue(requestDto.getSourceOneType()));
		coreVdGrpJoinInfoModel.setSourceTwoType(SourceType.fromValue(requestDto.getSourceTwoType()));
		coreVdGrpJoinInfoModel.setJoinType(JoinType.fromValue(requestDto.getJoinType()));
		coreVdGrpJoinInfoModel.setJoinOperator(JoinOperator.fromValue(requestDto.getJoinOperator()));
		coreVdGrpJoinInfoModel.setSourceOneModuleId(requestDto.getSourceOneModule());
		coreVdGrpJoinInfoModel.setSourceTwoModuleId(requestDto.getSourceTwoModule());
		when(coreVdGrpJoinInfoDAO.save(coreVdGrpJoinInfoModel)).thenReturn(coreVdGrpJoinInfoModel);
		coreVdGrpJoinInfoServiceImpl.saveAndUpdateGrpJoinInfo(requestDto, coreVdGroupsModel);
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("saveAndUpdateGrpJoinInfoWithCatchTest method test for test save or update")
	void saveAndUpdateGrpJoinInfoWithCatchTest() {
		VdGroupJoinInfoRequestDTO requestDto = new VdGroupJoinInfoRequestDTO();
		requestDto.setGroupJoinId(UUID.randomUUID());
		requestDto.setResultScopeUdr("123");
		requestDto.setSourceOneScopeUdr("12345");
		requestDto.setSourceTwoScopeUdr("123");
		requestDto.setSourceOneType("MODULE");
		requestDto.setSourceTwoType("MODULE");
		requestDto.setJoinType("INNER");
		requestDto.setJoinOperator("AND");
		requestDto.setSourceOneModule(null);
		requestDto.setSourceTwoModule(null);	
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupName("Sample Name");
		CoreVdGrpJoinInfoModel coreVdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();
		coreVdGrpJoinInfoModel.setUuid(any());
		coreVdGrpJoinInfoModel.setResultScopeUdrId(requestDto.getResultScopeUdr());
		coreVdGrpJoinInfoModel.setSourceOneScopeUdrId(requestDto.getSourceOneScopeUdr());
		coreVdGrpJoinInfoModel.setSourceTwoScopeUdrId(requestDto.getSourceTwoScopeUdr());
		coreVdGrpJoinInfoModel.setCoreVdGroups(coreVdGroupsModel);
		coreVdGrpJoinInfoModel.setSourceOneType(SourceType.fromValue(requestDto.getSourceOneType()));
		coreVdGrpJoinInfoModel.setSourceTwoType(SourceType.fromValue(requestDto.getSourceTwoType()));
		coreVdGrpJoinInfoModel.setJoinType(JoinType.fromValue(requestDto.getJoinType()));
		coreVdGrpJoinInfoModel.setJoinOperator(JoinOperator.fromValue(requestDto.getJoinOperator()));
		coreVdGrpJoinInfoModel.setSourceOneModuleId(requestDto.getSourceOneModule());
		coreVdGrpJoinInfoModel.setSourceTwoModuleId(requestDto.getSourceTwoModule());
		when(coreVdGrpJoinInfoDAO.save(coreVdGrpJoinInfoModel)).thenThrow(new RuntimeException());
		assertThrows(RuntimeException.class, ()-> coreVdGrpJoinInfoServiceImpl.saveAndUpdateGrpJoinInfo(requestDto, coreVdGroupsModel));
	}
	
	@Test
	@DisplayName("saveAndUpdateGrpJoinInfoWithRequestDtoNullTest method test for test save or update")
	void saveAndUpdateGrpJoinInfoWithRequestDtoNullTest() {
		VdGroupJoinInfoRequestDTO requestDto = null;
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		coreVdGroupsModel.setGroupName("Sample Name");
		assertThrows(NotFound404Exception.class, ()-> coreVdGrpJoinInfoServiceImpl.saveAndUpdateGrpJoinInfo(requestDto, coreVdGroupsModel));
	}
	
	@Test
	@DisplayName("saveAndUpdateGrpJoinInfoWithRequestModelNullTest method test for test save or update")
	void saveAndUpdateGrpJoinInfoWithRequestModelNullTest() {
		VdGroupJoinInfoRequestDTO requestDto = new VdGroupJoinInfoRequestDTO();
		requestDto.setGroupJoinId(UUID.randomUUID());
		CoreVdGroupsModel coreVdGroupsModel = null;
		assertThrows(NotFound404Exception.class, ()-> coreVdGrpJoinInfoServiceImpl.saveAndUpdateGrpJoinInfo(requestDto, coreVdGroupsModel));
	}

	@Test
	@DisplayName("deleteVdGroupInfoTest method test for deleting virtual dataset groups by vdId")
	void deleteVdGroupInfoTest() {
		List<VdGroupJoinInfoRequestDTO> groupJoinDetailDtos = new ArrayList<VdGroupJoinInfoRequestDTO>();
		VdGroupJoinInfoRequestDTO vdGroupJoinInfoRequestDTO = new VdGroupJoinInfoRequestDTO();
		vdGroupJoinInfoRequestDTO.setGroupJoinId(UUID.randomUUID());
		groupJoinDetailDtos.add(vdGroupJoinInfoRequestDTO);
		CoreVdGroupsModel coreVdGroupsModel = new CoreVdGroupsModel();
		List<CoreVdGrpJoinInfoModel> coreVdGrpJoinInfoModel = new ArrayList<CoreVdGrpJoinInfoModel>();
		CoreVdGrpJoinInfoModel VdGrpJoinInfoModel = new CoreVdGrpJoinInfoModel();
		VdGrpJoinInfoModel.setUuid(UUID.randomUUID());
		coreVdGrpJoinInfoModel.add(VdGrpJoinInfoModel);
		when(coreVdGroupsDAO.findById(any())).thenReturn(Optional.of(coreVdGroupsModel));
		when(coreVdGrpJoinInfoDAO.findByCoreVdGroups(any())).thenReturn(coreVdGrpJoinInfoModel);
		coreVdGrpJoinInfoServiceImpl.deleteVdGroupInfo(groupJoinDetailDtos,UUID.randomUUID() );
		verify(coreVdGrpJoinInfoDAO, atLeast(1)).deleteByUuidIn(any());			
	}
	
	@Test
	@DisplayName("deleteVdGroupInfoWithCatchTest method test for deleting virtual dataset groups by vdId")
	void deleteVdGroupInfoWithCatchTest() {
		List<VdGroupJoinInfoRequestDTO> groupJoinDetailDtos = new ArrayList<VdGroupJoinInfoRequestDTO>();
		assertThrows(Exception.class, ()->coreVdGrpJoinInfoServiceImpl.deleteVdGroupInfo(groupJoinDetailDtos,UUID.randomUUID()));
		
	}
}
