package com.prospecta.mdo.module.service.virtualdata;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.beans.BeanUtils.copyProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.prospecta.mdo.module.dao.virtualdata.CoreVdGroupsDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdGrpTransInfoDAO;
import com.prospecta.mdo.module.dao.virtualdata.CoreVdTransFieldSettingDAO;
import com.prospecta.mdo.module.dto.virtualdata.VdTransFieldSettingRequestDTO;
import com.prospecta.mdo.module.exception.NotFound404Exception;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGroupsModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdGrpTransInfoModel;
import com.prospecta.mdo.module.model.virtualdata.CoreVdTransFieldSettingModel;

@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class CoreVdTransFieldSettingServiceImplTest {

	@InjectMocks
	private CoreVdTransFieldSettingServiceImpl coreVdTransFieldSettingServiceImpl;
	
	@Mock
	private CoreVdTransFieldSettingDAO coreVdTransFieldSettingDAO;

	@Mock
	private CoreVdGroupsDAO coreVdGroupsDAO;

	@Mock
	private CoreVdGrpTransInfoDAO coreVdGrpTransInfoDAO;
	
	@BeforeAll
	void init() {
		coreVdTransFieldSettingServiceImpl = new CoreVdTransFieldSettingServiceImpl();
	}
	
	@Test
	@DisplayName("getVdTransFieldSettingbyFieldIdTest method test for get Transaction field setting by field Id")
	void getVdTransFieldSettingbyFieldIdTest() {		
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = spy(CoreVdTransFieldSettingModel.class);
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.of(coreVdTransFieldSettingModel));
		coreVdTransFieldSettingModel = coreVdTransFieldSettingServiceImpl.getVdTransFieldSettingbyFieldId(id);
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
		
	}
	
	@Test
	@DisplayName("getVdTransFieldSettingbyFieldIdExceptionTest method test for test exception")
	void getVdTransFieldSettingbyFieldIdExceptionTest() {		
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdTransFieldSettingModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransFieldSettingServiceImpl.getVdTransFieldSettingbyFieldId(id));
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdTransFieldSettingbygroupIdTest method test for get Transaction field setting by group Id")
	void getVdTransFieldSettingbygroupIdTest() {
		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = spy(CoreVdTransFieldSettingModel.class);
		coreVdTransFieldSettingModel.setCoreVdGroups(coreVdGroupsModel);
		List<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModelList = new ArrayList<>();
		coreVdTransFieldSettingModelList.add(coreVdTransFieldSettingModel);
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findByCoreVdGroups(coreVdGroupsModel)).thenReturn(coreVdTransFieldSettingModelList);
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		List<CoreVdTransFieldSettingModel> coreVdTransFieldSettingList = coreVdTransFieldSettingServiceImpl.getVdTransFieldSettingbygroupId(id);
		assertNotNull(coreVdTransFieldSettingList);
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findByCoreVdGroups(any());
	}
	
	@Test
	@DisplayName("getVdTransFieldSettingbygroupIdExceptionTest method test for test exception")
	void getVdTransFieldSettingbygroupIdExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransFieldSettingServiceImpl.getVdTransFieldSettingbygroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdTransFieldSettingbygroupIdListExceptionTest method test for test exception")
	void getVdTransFieldSettingbygroupIdListExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel = spy(CoreVdGroupsModel.class);
		List<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModelList = new ArrayList<>();
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findByCoreVdGroups(coreVdGroupsModel)).thenReturn(coreVdTransFieldSettingModelList);
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransFieldSettingServiceImpl.getVdTransFieldSettingbygroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findByCoreVdGroups(any());
	}
	
	@Test
	@DisplayName("getVdTransFieldSettingbytransformationIdTest method test for get Transaction field setting by Transformation Id")
	void getVdTransFieldSettingbytransformationIdTest() {
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = spy(CoreVdGrpTransInfoModel.class);
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = spy(CoreVdTransFieldSettingModel.class);
		coreVdTransFieldSettingModel.setCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		List<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModelList = new ArrayList<>();
		coreVdTransFieldSettingModelList.add(coreVdTransFieldSettingModel);
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findByCoreVdGrpTransInfo(coreVdGrpTransInfoModel)).thenReturn(coreVdTransFieldSettingModelList);
		when(coreVdGrpTransInfoDAO.findById(id)).thenReturn(Optional.of(coreVdGrpTransInfoModel));
		List<CoreVdTransFieldSettingModel> coreVdTransFieldSettingList = coreVdTransFieldSettingServiceImpl.getVdTransFieldSettingbytransformationId(id);
		assertNotNull(coreVdTransFieldSettingList);
		verify(coreVdGrpTransInfoDAO, atLeast(1)).findById(any());
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findByCoreVdGrpTransInfo(any());
	}
	
	@Test
	@DisplayName("getVdTransFieldSettingbytransformationIdExceptionTest method test for test exception")
	void getVdTransFieldSettingbytransformationIdExceptionTest() {
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = null;
		UUID id = UUID.randomUUID();
		when(coreVdGrpTransInfoDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGrpTransInfoModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransFieldSettingServiceImpl.getVdTransFieldSettingbytransformationId(id));
		verify(coreVdGrpTransInfoDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("getVdTransFieldSettingbytransformationIdListExceptionTest method test for test exception")
	void getVdTransFieldSettingbytransformationIdListExceptionTest() {
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = spy(CoreVdGrpTransInfoModel.class);
		List<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModelList = new ArrayList<>();
		UUID id = UUID.randomUUID();
		when(coreVdTransFieldSettingDAO.findByCoreVdGrpTransInfo(coreVdGrpTransInfoModel)).thenReturn(coreVdTransFieldSettingModelList);
		when(coreVdGrpTransInfoDAO.findById(id)).thenReturn(Optional.of(coreVdGrpTransInfoModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransFieldSettingServiceImpl.getVdTransFieldSettingbytransformationId(id));
		verify(coreVdGrpTransInfoDAO, atLeast(1)).findById(any());
		verify(coreVdTransFieldSettingDAO, atLeast(1)).findByCoreVdGrpTransInfo(any());
	}
	
	@Test
	@DisplayName("deleteVdTransFieldSettingbyFieldIdTest method test for  delete Transaction field setting by field id")
	void deleteVdTransFieldSettingbyFieldIdTest() {
		UUID id = UUID.randomUUID();
		doNothing().when(coreVdTransFieldSettingDAO).deleteById(id);
		coreVdTransFieldSettingServiceImpl.deleteVdTransFieldSettingbyFieldId(id);
		verify(coreVdTransFieldSettingDAO, atLeast(1)).deleteById(any());
	}
	
	@Test
	@DisplayName("deleteVdTransFieldSettingbygroupIdTest method test for delete Transaction field setting by group id")
	void deleteVdTransFieldSettingbygroupIdTest() {
		CoreVdGroupsModel coreVdGroupsModel= new CoreVdGroupsModel();
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.of(coreVdGroupsModel));
		doNothing().when(coreVdTransFieldSettingDAO).deleteByCoreVdGroups(coreVdGroupsModel);
		coreVdTransFieldSettingServiceImpl.deleteVdTransFieldSettingbygroupId(id);
		verify(coreVdTransFieldSettingDAO, atLeast(1)).deleteByCoreVdGroups(any());
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("deleteVdTransFieldSettingbygroupIdExceptionTest method test for test exception")
	void deleteVdTransFieldSettingbygroupIdExceptionTest() {
		CoreVdGroupsModel coreVdGroupsModel= null;
		UUID id = UUID.randomUUID();
		when(coreVdGroupsDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGroupsModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransFieldSettingServiceImpl.deleteVdTransFieldSettingbygroupId(id));
		verify(coreVdGroupsDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("deleteVdTransFieldSettingbytransformationIdTest method test for delete Transaction field setting by transformation id")
	void deleteVdTransFieldSettingbytransIdTest() {
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel= new CoreVdGrpTransInfoModel();
		UUID id = UUID.randomUUID();
		when(coreVdGrpTransInfoDAO.findById(id)).thenReturn(Optional.of(coreVdGrpTransInfoModel));
		doNothing().when(coreVdTransFieldSettingDAO).deleteByCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		coreVdTransFieldSettingServiceImpl.deleteVdTransFieldSettingbytransformationId(id);
		verify(coreVdTransFieldSettingDAO, atLeast(1)).deleteByCoreVdGrpTransInfo(any());
		verify(coreVdGrpTransInfoDAO, atLeast(1)).findById(any());
	}
	
	@Test
	@DisplayName("deleteVdTransFieldSettingbytransformationIdExceptionTest method test for test exception")
	void deleteVdTransFieldSettingbytransIdExceptionTest() {
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel= null;
		UUID id = UUID.randomUUID();
		when(coreVdGrpTransInfoDAO.findById(id)).thenReturn(Optional.ofNullable(coreVdGrpTransInfoModel));
		assertThrows(NotFound404Exception.class,()->coreVdTransFieldSettingServiceImpl.deleteVdTransFieldSettingbytransformationId(id));
		verify(coreVdGrpTransInfoDAO, atLeast(1)).findById(any());
	}
	
	
	@Test
	@DisplayName("saveAndUpdateTransFieldSettingTest method test for test save or update")
	void saveAndUpdateTransFieldSettingTest() {
		VdTransFieldSettingRequestDTO groupTransFieldSettingRequestDTO = new VdTransFieldSettingRequestDTO();
		groupTransFieldSettingRequestDTO.setTransFieldId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = new CoreVdTransFieldSettingModel();
		copyProperties(groupTransFieldSettingRequestDTO, coreVdTransFieldSettingModel);
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		coreVdTransFieldSettingModel.setTransId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		coreVdTransFieldSettingModel.setIsCustomField(false);
		coreVdTransFieldSettingModel.setIsGroupBy(false);
		coreVdTransFieldSettingModel.setCoreVdGroups(coreVdGrpTransInfoModel.getCoreVdGroups());
		coreVdTransFieldSettingModel.setCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		
		when(coreVdTransFieldSettingDAO.save(coreVdTransFieldSettingModel)).thenReturn(coreVdTransFieldSettingModel);
		coreVdTransFieldSettingServiceImpl.saveAndUpdateTransFieldSetting(groupTransFieldSettingRequestDTO, coreVdGrpTransInfoModel);
		verify(coreVdTransFieldSettingDAO, atLeast(1)).save(coreVdTransFieldSettingModel);
	}
	
	@Test
	@DisplayName("saveAndUpdateTransFieldSettingWithExceptionTest method test for test save or update")
	void saveAndUpdateTransFieldSettingWithExceptionTest() {
		VdTransFieldSettingRequestDTO groupTransFieldSettingRequestDTO = new VdTransFieldSettingRequestDTO();
		groupTransFieldSettingRequestDTO.setTransFieldId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = new CoreVdTransFieldSettingModel();
		copyProperties(groupTransFieldSettingRequestDTO, coreVdTransFieldSettingModel);
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		coreVdTransFieldSettingModel.setTransId(UUID.fromString("7947001c-d6d8-4a4e-850c-e8e5455a8f43"));
		coreVdTransFieldSettingModel.setIsCustomField(false);
		coreVdTransFieldSettingModel.setIsGroupBy(null);
		coreVdTransFieldSettingModel.setCoreVdGroups(coreVdGrpTransInfoModel.getCoreVdGroups());
		coreVdTransFieldSettingModel.setCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		
		when(coreVdTransFieldSettingDAO.save(coreVdTransFieldSettingModel)).thenReturn(coreVdTransFieldSettingModel);
		Assertions.assertThrows(Exception.class, () -> {
			coreVdTransFieldSettingServiceImpl.saveAndUpdateTransFieldSetting(groupTransFieldSettingRequestDTO, coreVdGrpTransInfoModel);
		});
	}
	
	@Test
	@DisplayName("saveAndUpdateTransFieldSettingWithNullTest method test for null")
	void saveAndUpdateTransFieldSettingWithNullTest() {
		VdTransFieldSettingRequestDTO groupTransFieldSettingRequestDTO = new VdTransFieldSettingRequestDTO();
		groupTransFieldSettingRequestDTO.setTransFieldId(null);
		CoreVdTransFieldSettingModel coreVdTransFieldSettingModel = new CoreVdTransFieldSettingModel();
		copyProperties(groupTransFieldSettingRequestDTO, coreVdTransFieldSettingModel);
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		coreVdTransFieldSettingModel.setTransId(any());
		coreVdTransFieldSettingModel.setIsCustomField(false);
		coreVdTransFieldSettingModel.setIsGroupBy(false);
		coreVdTransFieldSettingModel.setCoreVdGroups(coreVdGrpTransInfoModel.getCoreVdGroups());
		coreVdTransFieldSettingModel.setCoreVdGrpTransInfo(coreVdGrpTransInfoModel);
		
		when(coreVdTransFieldSettingDAO.save(coreVdTransFieldSettingModel)).thenReturn(coreVdTransFieldSettingModel);
		coreVdTransFieldSettingServiceImpl.saveAndUpdateTransFieldSetting(groupTransFieldSettingRequestDTO, coreVdGrpTransInfoModel);
		verify(coreVdTransFieldSettingDAO, atLeast(1)).save(any());
	}
	
	@Test
	@DisplayName("saveAndUpdateTransFieldSettingWithNullDTOTest method test for null")
	void saveAndUpdateTransFieldSettingWithNullDTOTest() {
		
		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		assertThrows(NotFound404Exception.class, ()-> coreVdTransFieldSettingServiceImpl.saveAndUpdateTransFieldSetting(null, coreVdGrpTransInfoModel));
	}
	
	@Test
	@DisplayName("saveAndUpdateTransFieldSettingWithNullModelTest method test for null")
	void saveAndUpdateTransFieldSettingWithNullModelTest() {
		
		assertThrows(Exception.class, ()-> coreVdTransFieldSettingServiceImpl.saveAndUpdateTransFieldSetting(new VdTransFieldSettingRequestDTO(), null));
	}
	
	@Test
	@DisplayName("deleteVdTransFieldSettingTest method test for test delete the virtual dataset transformation information")
	void deleteVdTransFieldSettingTest() {

		CoreVdGrpTransInfoModel coreVdGrpTransInfoModel = new CoreVdGrpTransInfoModel();
		List<VdTransFieldSettingRequestDTO> vdTransFieldSettingRequestDTO = new ArrayList<VdTransFieldSettingRequestDTO>();
		VdTransFieldSettingRequestDTO transFieldSettingRequestDTO= new VdTransFieldSettingRequestDTO();
		transFieldSettingRequestDTO.setTransFieldId(UUID.randomUUID());
		vdTransFieldSettingRequestDTO.add(transFieldSettingRequestDTO);
		List<CoreVdTransFieldSettingModel> coreVdTransFieldSettingModel = new ArrayList<CoreVdTransFieldSettingModel>();
		CoreVdTransFieldSettingModel vdTransFieldSettingModel =new CoreVdTransFieldSettingModel();
		vdTransFieldSettingModel.setTransId(UUID.randomUUID());
		coreVdTransFieldSettingModel.add(vdTransFieldSettingModel);
		when(coreVdGrpTransInfoDAO.findById(any())).thenReturn(Optional.of(coreVdGrpTransInfoModel));
		when(coreVdTransFieldSettingDAO.findByCoreVdGrpTransInfo(any())).thenReturn(coreVdTransFieldSettingModel);
		doNothing().when(coreVdTransFieldSettingDAO).deleteByTransIdIn(any());
		coreVdTransFieldSettingServiceImpl.deleteVdTransFieldSetting(vdTransFieldSettingRequestDTO, UUID.randomUUID());
		verify(coreVdTransFieldSettingDAO, atLeast(1)).deleteByTransIdIn(any());
	}

	@Test
	@DisplayName("deleteVdTransFieldSettingWithExceptionTest method test for any exception")
	void deleteVdTransFieldSettingWithExceptionTest() {
		Assertions.assertThrows(Exception.class, () -> {
			coreVdTransFieldSettingServiceImpl.deleteVdTransFieldSetting(new ArrayList<VdTransFieldSettingRequestDTO>(), null);
		});
	}
	
}
